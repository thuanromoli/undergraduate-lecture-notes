---
tags:
  - MT3501
type: def
aliases:
  - diagonalisable
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $T:V\to V$ be a [[Linear transformations|linear transformation]].

>[!def] Diagonalisability of a linear transformation
>$T$ is diagonalisable if there is a [[Bases|basis]] for $V$ consisting of [[Eigenvectors and Eigenvalues|eigenvectors]] for $T$.

>[!def] Diagonalisability of a square matrix
>A [[Square matrices|square matrix]] $A$ is diagonalisable if there is an [[The inverse of a matrix|invertible]] [[Matrices|matrix]] $P$ such that $P^{-1}AP$ is a [[Diagonal matrices|diagonal matrix]].
