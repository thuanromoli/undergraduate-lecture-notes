---
tags:
  - MT4531
aliases:
---
Let $\boldsymbol{\theta}=(\theta_{1},...,\theta_{p})$ be a random vector with distribution $\pi(\boldsymbol{\theta}| \boldsymbol{x})$. For readability, drop the conditioning on the data and notation gives $\pi(\boldsymbol{\theta}| \boldsymbol{x})=\pi(\boldsymbol{\theta})$.

Let $\mathcal K(\boldsymbol{\theta}, \boldsymbol{\phi})$ be the transition Kernel.

> [!def] Definition
> The transition Kernel in the Metropolis-Hasting algorithm is set to be
>  $$\mathcal K(\boldsymbol{\theta}, \boldsymbol{\phi})=q(\boldsymbol{\phi}|\boldsymbol{\theta})\alpha(\boldsymbol{\theta},\boldsymbol{\phi})$$
>  where $q(\boldsymbol{\phi}|\boldsymbol{\theta})$ is the candidate generating density (of arbitrary choice) and $\alpha(\boldsymbol{\theta},\boldsymbol{\phi})$ is the acceptance function.

> [!thm]- Lemma 1
> Suppose that a Markov chain has a transition kernel $\mathcal K(\boldsymbol{\theta}, \boldsymbol{\phi})$ and that it satisfies detailed balance for $\pi$, i.e.
> $$\pi(\boldsymbol{\theta})\mathcal K (\boldsymbol{\theta},\boldsymbol{\phi})=\pi(\boldsymbol{\phi})\mathcal K(\boldsymbol{\phi},\boldsymbol{\theta}).$$
> Then the chain has stationary density $\pi(\cdot)$.
> 
> Proof:
> Suppose that $\pi(\boldsymbol{\theta})\mathcal K (\boldsymbol{\theta},\boldsymbol{\phi})=\pi(\boldsymbol{\phi})\mathcal K(\boldsymbol{\phi},\boldsymbol{\theta})$. We wish to show that $\mathbb E_{\boldsymbol{\theta}}(\mathcal K (\boldsymbol{\theta},\boldsymbol{\phi}))= \pi(\boldsymbol{\phi})$.
> Indeed,
> $$\begin{align*}
\int_{}^{}\pi(\boldsymbol{\theta})\mathcal K(\boldsymbol{\theta}, \boldsymbol{\phi})d \boldsymbol{\theta} &= \int_{}^{}\pi(\boldsymbol{\phi})\mathcal K(\boldsymbol{\phi}, \boldsymbol{\theta})d \boldsymbol{\theta}\\
&= \pi(\boldsymbol{\phi})\int_{}^{}\mathcal K(\boldsymbol{\phi}, \boldsymbol{\theta})d \boldsymbol{\theta}\\
&=\pi(\boldsymbol{\phi}).
\end{align*}$$

> [!thm]- Optimal form of $\alpha$
> Suppose $\alpha$ is given by
> $$\alpha(\boldsymbol{\theta},\boldsymbol{\phi})=\min \left(1, \frac{\pi(\boldsymbol{\phi})q(\boldsymbol{\theta}|\boldsymbol{\phi})}{\pi(\boldsymbol{\theta})q(\boldsymbol{\phi}|\boldsymbol{\theta})}\right).$$
> Then Lemma 1 is satisfied, i.e. the Markov chain has a stationary distribution.
>
> Proof (assuming its form is given):
> Using the definition of the kernel of the M-H algorithm, $\mathcal K(\boldsymbol{\theta}, \boldsymbol{\phi})=q(\boldsymbol{\phi}|\boldsymbol{\theta})\alpha(\boldsymbol{\theta},\boldsymbol{\phi})$ and using Lemma 1, $\pi(\boldsymbol{\theta})\mathcal K (\boldsymbol{\theta},\boldsymbol{\phi})=\pi(\boldsymbol{\phi})\mathcal K(\boldsymbol{\phi},\boldsymbol{\theta})$, hence we must have
> $$\pi(\boldsymbol{\theta}) q(\boldsymbol{\phi}|\boldsymbol{\theta})\alpha(\boldsymbol{\theta},\boldsymbol{\phi}) =\pi(\boldsymbol{\phi}) q(\boldsymbol{\theta}|\boldsymbol{\phi})\alpha(\boldsymbol{\phi},\boldsymbol{\theta}).$$
> Case 1: $\boldsymbol{\theta} \neq \boldsymbol{\phi}$.
> $$\begin{align*}
\pi(\boldsymbol{\theta}) \mathcal K(\boldsymbol{\theta}, \boldsymbol{\phi}) 
&= \pi(\boldsymbol{\theta}) q(\boldsymbol{\phi}  \boldsymbol{\theta}) \min\left(1, \frac{\pi(\boldsymbol{\phi}) q(\boldsymbol{\theta}  \boldsymbol{\phi})}{\pi(\boldsymbol{\theta}) q(\boldsymbol{\phi}  \boldsymbol{\theta})} \right) \\
&= \min\left( \pi(\boldsymbol{\theta}) q(\boldsymbol{\phi}  \boldsymbol{\theta}), \pi(\boldsymbol{\phi}) q(\boldsymbol{\theta}  \boldsymbol{\phi}) \right) \\
&= \min\left( \frac{\pi(\boldsymbol{\theta}) q(\boldsymbol{\phi}  \boldsymbol{\theta})}{\pi(\boldsymbol{\phi}) q(\boldsymbol{\theta}  \boldsymbol{\phi})}, 1 \right) \pi(\boldsymbol{\phi}) q(\boldsymbol{\theta}  \boldsymbol{\phi}) \\
&= \pi(\boldsymbol{\phi}) \mathcal K(\boldsymbol{\phi}, \boldsymbol{\theta}).
\end{align*} $$
> Case 2: $\boldsymbol{\theta} = \boldsymbol{\phi}$.
> Trivial.

> [!gen] Algorithm
> 1. Set arbitrary starting values $\boldsymbol{\theta}^{0} = (\theta_{1}^{0},..., \theta_{p}^{0})$.
> 2. Given that the Markov chain is in state $\boldsymbol{\theta}^{t}=(\theta_{1}^{t},...,\theta_{p}^{t})$, generate a new value $\boldsymbol{\phi}$ from the distribution $q(\boldsymbol{\phi}|\boldsymbol{\theta}^{t})$.
> 3. Calculate
>    $$\alpha(\boldsymbol{\theta},\boldsymbol{\phi})=\min \left(1, \frac{\pi(\boldsymbol{\phi})q(\boldsymbol{\theta}|\boldsymbol{\phi})}{\pi(\boldsymbol{\theta})q(\boldsymbol{\phi}|\boldsymbol{\theta})}\right)$$
> 4. With probability $\alpha(\boldsymbol{\theta}^{t})$, set $\boldsymbol{\theta}^{t+1}=\boldsymbol{\phi}$, else set $\boldsymbol{\theta}^{t+1}=\boldsymbol{\theta}^{t}$.
> 5. This completes a transition from $\boldsymbol{\theta}^{t}$ to $\boldsymbol{\theta}^{t+1}$. The Markov chain is then the sequence $\boldsymbol{\theta}^{0},\boldsymbol{\theta}^{1},...,\boldsymbol{\theta}^{T}$.

> [!gen] Remarks
> - $q(\boldsymbol{\phi}|\boldsymbol{\theta}^{t})$ is called candidate generating density (or proposal density), the choice is arbitrary.
> - $\alpha(\boldsymbol{\phi}|\boldsymbol{\theta}^{t})$ is called acceptance function, its optimal form is given in the algorithm.
> - The transition kernel is then ${\cal K}(\boldsymbol{\theta}^t,\boldsymbol{\phi}) =q(\boldsymbol{\phi}|\boldsymbol{\theta}^t)\alpha(\boldsymbol{\theta}^t,\boldsymbol{\phi})$.
> - We only need to know $\pi$ up to proportionality, the constants cancel in the numerator and denominator of $\alpha$.
> - The performance of the MCMC algorithm is dependent on the choice of the proposal distribution $q$. If $q$ is chosen poorly, then the number of rejections may be high, so that the efficiency of the procedure can be low; conversely if $q$ is chosen such that only very small moves are proposed, it may take a very long time for the Markov chain to traverse the set of plausible posterior parameter values.
> - For special cases, see [[Random walk Metropolis]], [[The independent sampler]], [[Single-update Metropolis]], [[Gibbs sampler]].
