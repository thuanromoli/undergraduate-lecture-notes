---
tags:
  - MT3504
type: def
aliases:
  - homogeneous
---
Consider a general second-order ODE: $L[y]=g$.

>[!def] Homogeneous, Inhomogeneous ODEs
>If $g(x) \equiv 0$ on $[a,b]$ then the ODE is called homogeneous, otherwise it is inhomogeneous.

> [!def] Standard form
> We write a general second order homogeneous ODE as $y''+p(x)y'+q(x)y=0$.

>[!thm] $L[y]=0$ always has the trivial solution $y=0$

>[!thm] If $y_{1}$ and $y_{2}$ are two solutions to $L[y]=0$, then the [[Linear combinations|linear combination]] of $y_{1}$ and $y_{2}$ is also a solution: $L[\alpha_{1}y_{1}+\alpha_{2}y_{2}]=0$

>[!thm] There are always exactly two [[Linear independence|linearly independent]] solutions to the homogeneous equation $L[y]=0$
>Let $L:A\to B$ be a [[Linear transformations|linear transformation]] between [[Vector spaces|vector spaces]] $A$ and $B$.
>Then $\ker L=\set{v\in A: L[v]=0}$ and $\text{null }L=2$
