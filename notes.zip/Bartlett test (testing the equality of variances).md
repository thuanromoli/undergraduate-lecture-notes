---
tags:
  - MT3508
aliases:
---
Suppose we have $p$ [[Normal distribution|normal]] distributions, with unknown variances $\sigma_{1},...,\sigma_{p}$.

> [!gen] [[Statistical hypothesis|Hypothesis]]
> $H_{0}$: $\sigma_{1} = \cdots = \sigma_{p}$.
> $H_{1}$: $\sigma_{1},...,\sigma_{p}$ are not all equal.

> [!gen] [[Test statistics]]
> Omitted.

```R
mydata <- data.frame(y = c(y_1, y_2, ...), x = c(x_1, x_2, ...))

lmfit <- lm(formula = y ~ x, data = mydata)
residuals <- residuals(lmfit)

res.y_1 <- residuals[mydata$ x == x_1]
res.y_2 <- residuals[mydata$ x == x_2]
...

bartlett.test(x = list(res.y_1, res.y_2, ...))
```
