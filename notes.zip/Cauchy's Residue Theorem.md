---
tags:
  - MT3503
aliases:
---
> [!thm] Proposition
> Let $f$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] with an [[Isolated singularity|isolated singularity]] at $a$.
> Let $\gamma$ be a positively oriented circular [[Contours|contour]] of radius $R$ where $0< R <r$ about $a$.
> Suppose that $f$ is [[Holomorphic functions|holomorphic]] on a punctured disc $B'(a,r)$. Then
> $$\int_{\gamma}^{}f(z)dz = 2 \pi i \text{res}(f,a)$$

> [!thm] Cauchy's Residue Theorem
> Let $f$ be a [[Functions|function]] of a [[Complex numbers|complex variable]].
> Let $U$ be an [[Open sets|open set]] and $\gamma$ be a positively oriented contour such that $I(\gamma) \cup \gamma^{*} \subseteq U$.
> Suppose that $f$ is [[Holomorphic functions|holomorphic]] $U$, except for finitely many [[Isolated singularity|isolated singularities]] $a_{1},...,a_{k}$ in $I(\gamma)$. Then
> $$\int_{\gamma} f(z) \, \mathrm{d}z = 2\pi i \sum_{j=1}^{k} \mathrm{res}(f,a_{j}).$$
