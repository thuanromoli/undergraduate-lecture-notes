---
tags:
  - MT4527
aliases:
---
Let $(X_{t})_{t \in \mathbb Z}$ be an [[ARIMA(p,d,q) Process]].

> [!def] Forecast
> The forecast for $X_{t+L}$ made at origin $t$ for lead time $L$ is
> $$\widehat x_{t}(L).$$

> [!def] Forecast error
> The error in the forecast is
> $$\begin{align}
  e_t (L)  = X_{t+L} - \hat x_t (L)  & =    \varepsilon_{t+L} + \nu_1 \varepsilon_{t+L-1}+ \dots  +  \nu_{L-1}\varepsilon_{t+1} +\nonumber  \\
  &+   (\nu_L-\nu_{L,0})\varepsilon_{t} + (\nu_{L+1} - \nu_{L,1}) \varepsilon_{t-1} + \dots
  \end{align}$$

> [!thm] Minimum mean square error predictor
> The minimum mean square error predictor $\widehat x_{t}(L)$ for $X_{t+L}$ made at origin $t$ for lead time $L$ is
> $$\widehat x_{t}(L) = \nu_{L} \varepsilon_{t} + \nu_{L+1} \varepsilon_{t-1}+\nu_{L+2} \varepsilon_{t-2}+\cdots$$
> where $\nu_{L},\nu_{L+1},...$ are the coefficients of the moving average representation of the process.

Assumptions
- All parameters are known (in practice, estimates are used).
- MA operators are invertible
- We only consider forecasts that are linear functions of $X_{t},X_{t-1},...$.

Consider that the forecast is made based on previous data. By the linearity assumption,
$$\widehat x_{t}(L)= a_{0} X_{t}+a_{1}X_{t-1}+\cdots \quad \text{for constants } a_{0},a_{1},...$$
Each $X_{t},X_{t-1},...$ may be written in random shock form and since each is a linear function of $\varepsilon_{t},\varepsilon_{t-1},...$, we must have that $\widehat x_{t}(L)$ is also a linear combination of $\varepsilon_{t},\varepsilon_{t-1},...$. That is,
$$\widehat x_{t}(L)= \nu_{L,0} \varepsilon_{t}+\nu_{L,1}\varepsilon_{t-1}+\cdots\quad \text{for constants } (\nu_{L,k})_{k=0,1,...}.$$
Now consider that the random variable $X_{t+L}$ is itself part of the ARIMA process. We write in shock form
$$X_{t+L}= \nu(B)\varepsilon_{t+L}=\varepsilon_{t+L}+\nu_{1} \varepsilon_{t+L-1}+\cdots.$$
Hence the error in the forecast is
$$\begin{align}
e_t (L)  = X_{t+L} - \hat x_t (L)  & =    \varepsilon_{t+L} + \nu_1 \varepsilon_{t+L-1}+ \dots  +  \nu_{L-1}\varepsilon_{t+1} +\nonumber  \\
        &+   (\nu_L-\nu_{L,0})\varepsilon_{t} + (\nu_{L+1} - \nu_{L,1}) \varepsilon_{t-1} + \dots
\end{align}$$
Note that $\mathbb E(e_t (L))=0$, if uncorrelated $\text{Var }(A+B)=\text{Var }(A)+\text{Var }(B)$, and $\text{Var }(cA)=c^{2}\text{Var }(A)$.
The mean squared error is defined to be
$$\begin{align*}
\mathbb E[e^{2}_{t}(L)]&=\mathbb E[e^{2}_{t}(L)]-(\mathbb E[e_{t}(L)])^{2}\\
&= \text{Var}[e_{t}(L)]\\
&= \text{Var}[X_{t+L} - \hat x_t (L) ]\\
&=  \sigma^2_{\varepsilon} (1+ \nu_1^2 + \nu_2^2 + \dots +  \nu^2_{L-1} + (\nu_L-\nu_{L,0})^2 + (\nu_{L+1} - \nu_{L,1})^2 + \dots ).
\end{align*}$$
This is clearly minimised by choosing $\nu_{L+k}=\nu_{L,k}$ for $k=0,1,2,...$.

At the minimum MSE forecast, we have
$$\begin{align*}
e_{t}(L) &= X_{t+L}-\widehat x_{t}(L)\\
&=  \varepsilon_{t+L} + \nu_1 \varepsilon_{t+L-1}+ \dots  +  \nu_{L-1}\varepsilon_{t+1}\\
&= \sum\limits_{i=0}^{L-1} \nu_{i} \varepsilon_{t+L-i} \quad \text{with }\nu_{0}=1.
\end{align*}$$
In particular,
$e_{t}(1)=\varepsilon_{t+1}$.