---
tags:
  - MT4003
aliases:
  - centraliser
---
Let $G$ be a [[Groups|group]] [[Group actions|acting]] on a non-empty set $X$ and let $x \in X$.

> [!def] Definition
> The centraliser of $x$ in $G$ is
> $$C_{G}(x) = \set{g \in G : xg=gx} = \set{g \in G : x^{g}=x}$$
> the set of all elements in $G$ that commute with $x$.

> [!thm] Theorem
> The centraliser of $x$ is precisely the [[Stabilisers|stabiliser]] of $x$ under [[Conjugacy|conjugation]] of $G$. Hence $C_{G}(x)$ is a [[Subgroups|subgroup]] of $G$.
