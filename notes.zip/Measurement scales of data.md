---
alias:
  - nominal
  - ordinal
  - interval
  - ratio
type: def
tag: MT2508
---
Nominal (discrete [[Random variables|rvs]] only):
	when our data are simply labels

Ordinal (discrete [[Random variables|rvs]] only):
	when the data can be rank-ordered

Interval (either discrete or continuous [[Random variables|rvs]]):
	when the differences can be measured and are meaningful, but the 'zero' point on the scale is arbitrary

Ratio (either discrete or continuous [[Random variables|rvs]]):
	like the interval but the zero value is not arbitrary
