---
tags:
  - MT3503
aliases:
  - complex number
---
> [!def] Definition
> A complex number is a number of the form
> $$a + bi$$
> where $a$ and $b$ are real numbers and the number $i$ satisfies
> $$i^{2} = -1.$$

Let $z = a + bi$ be a complex number.

> [!def] Complex conjugate
> The complex conjugate of $z$ is
> $$\bar z = a-bi$$
