---
tags:
  - MT4551
aliases:
---
> [!gen] Hedging process for a European call
> 1. Sell a call at time $t=t_{0}$ and get $C(S,t)$ in cash. Hedge $- \Delta S$ where $\Delta = \frac{\partial C}{\partial S} > 0$.
> 2. At $t=t_{1}$, move onto a new solution curve and recompute $\Delta$.
> 3. For $t=t_{2},t_{3},...$ repeat stage 2.
> 4. At $t=T$,
>    $$C = \begin{cases}
   S - E  & \text{if } S > E \\
   0  & \text{if } S < E
   \end{cases} \implies \Delta= \frac{\partial C}{\partial S} = \begin{cases}
   1  & \text{if } S > E \\
   0  & \text{if } S < E
   \end{cases}$$

> [!gen] Hedging process for a European put
> 1. Sell a put at time $t=t_{0}$ and get $P(S,t)$ in cash. Hedge $- \Delta S$ where $\Delta = \frac{\partial P}{\partial S} < 0$.
> 2. At $t=t_{1}$, move onto a new solution curve and recompute $\Delta$.
> 3. For $t=t_{2},t_{3},...$ repeat stage 2.
> 4. At $t=T$,
>    $$P = \begin{cases}
   E - S  & \text{if } S < E \\
   0  & \text{if } S > E
   \end{cases} \implies \Delta= \frac{\partial P}{\partial S} = \begin{cases}
   -1  & \text{if } S < E \\
   0  & \text{if } S > E
   \end{cases}$$

Note: $\Delta > 0$ means going long and $\Delta < 0$ means selling short.
