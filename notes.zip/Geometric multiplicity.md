---
tags:
  - MT3501
type: def
aliases:
  - geometric multiplicity
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $T:V\to V$ be a [[Linear transformations|linear transformation]] and $\lambda$ be an [[Eigenvectors and Eigenvalues|eigenvalue]] of $T$.

>[!def] Definition
>The geometric multiplicity of $\lambda$ is the dimension of the [[Eigenspaces|eigenspace]] $E_\lambda$ corresponding to $\lambda$.
