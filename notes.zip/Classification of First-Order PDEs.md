---
tags:
  - MT3504
type: def
aliases:
  - quasilinear
  - semilinear
  - linear homogeneous
---
>[!def] General form
>A general first-order PDE is of the form
>$$au_{x}+bu_{u}=c$$
>where depending on $a,b,c$ we have a
>$$\begin{align*}
   &\bullet\text{ quasilinear PDE if }&\begin{cases}
   a=a(x,y,u) \\
   b=b(x,y,u) \\
   c=c(x,y,u) \\
   \end{cases}\\\\
   &\bullet\text{ semilinear PDE if }&\begin{cases}
   a=a(x,y) \\
   b=b(x,y) \\
   c=c(x,y,u) \\
   \end{cases}\\\\
   &\bullet\text{ linear homogeneous PDE if }&\begin{cases}
   a=a(x,y,u) \\
   b=b(x,y,u) \\
   c = 0\\
   \end{cases}\\
   \end{align*}$$
