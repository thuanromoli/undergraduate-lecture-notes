---
tags:
  - MT4528
type: def
aliases:
  - Birth/death process
---
>[!def] Definition
>A birth/death process is a [[Markov chains and processes|Markov process]] $\set{X(t):t \geqslant 0}$ which is non-negative integer values, such that as $h\to 0$:
>1. $\mathbb P(X(t+h)=n+1|X(t)=n)=\lambda_{n}h+O(h)$.
>2. $\mathbb P(X(t+h)=n-1|X(t)=n)=\mu_{n}h+O(h)$
>3. $\mathbb P(X(t+h)=n|X(t)=n)=1-(\lambda_{n}+\mu_{n})h+O(h)$
>4. $\mathbb P(X(t+h)=n+j|X(t)=n)=O(h)$ for $J\notin\set{-1,0,1}$
>
>for birth rates $\lambda_{n}\geqslant 0$, and death rates $\mu_{n}\geqslant 0$, $n=0,1,2,...$, and $\mu_{0}=0$.

>[!gen] Remarks
>- $\lambda_{n}=0$, $n=0,1,2,...$ gives a pure death process.
>- $\lambda_{n}=0$, $n=0,1,2,...$, $\mu_{n}=n \mu$ gives a linear pure death process.
>- $\mu_{n}=0$, $n=0,1,2,...$ gives a pure birth process.
>- $\mu_{n}=0$, $n=0,1,2,...$, $\lambda_{n}=n \lambda$ gives a linear pure birth process.
>- $\mu_{n}=0$, $n=0,1,2,...$, $\lambda_{n}=\lambda$, and $X(0)=0$ corresponds to the special case of a [[Poisson processes|Poisson process]].
