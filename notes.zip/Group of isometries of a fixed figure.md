---
type: def
tag: MT2505
---
Let $X$ be a figure on the plane.

>[!def] Definition
>The group of isometries of a fixed figure $\text{Isom}(X)$ is the set of [[Isometries of the real plane|isometries of the real plane]] that map $X$ to itself: $$\text{Isom}(X)=\set{f\in \text{Isom}(\mathbb R^2):Xf=X}$$

>[!thm] Theorem
>The group of isometries of a fixed figure is a [[Groups|group]].
>PROOF: this is a [[Subgroups|subgroup]] of [[the isometry group]].
