---
type: def
tag: MT2505
alias: isometries of the real plane
---
Let $\boldsymbol v_1=(x_1,y_1)$ and $\boldsymbol v_2 =(x_2,y_2)$.

>[!def] Definition
>An isometry of the real plane is a [[Bijective functions|bijective]] [[Functions|function]] $f:\mathbb{R}^{2}\to \mathbb{R}^{2}$ that preserves [[Distance|distances]]: 
>$$ \lvert \boldsymbol v_1f-\boldsymbol v_2f\rvert = \lvert \boldsymbol v_1-\boldsymbol v_2\rvert\;\;\forall \ \boldsymbol v_1,\boldsymbol v_2 \in \mathbb R^2 $$
