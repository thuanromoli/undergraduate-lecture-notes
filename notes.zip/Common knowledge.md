---
tags:
  - MT4554
type: def
aliases:
---
>[!def] Definition
>Complete information about the game is available to all players, that is payoffs and strategies.
