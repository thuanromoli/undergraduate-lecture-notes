---
tags:
  - MT3503
aliases:
---
> [!thm] Type I, multiple [[Classification of isolated singularities|poles]]
> Suppose that
> $$f(z) = \frac{g(z)}{(z-a)^{m}}$$
> where $g$ is [[Holomorphic functions|holomorphic]] in some [[Open balls|open ball]] $B(a,r)$ about $a$ and $g(a) \neq 0$.
> Then $f$ has a pole of order $m$ at $a$ and
> $$\mathrm{res}(f,a) = \frac{1}{(m-1)!} \, g^{(m-1)}(a).$$

> [!thm] Type II, simple [[Classification of isolated singularities|pole]]
> Suppose that
> $$f(z) = \frac{f(z)}{h(z)}$$
> where $g$ and $h$ are [[Holomorphic functions|holomorphic]] in some [[Open balls|open ball]] $B(a,r)$ about $a$ and $g(a) \neq 0,\;h(a) = 0,\; h'(a) \neq 0$.
> Then $f$ has a simple pole at $a$ and
> $$\mathrm{res}(f,a) = \frac{g(a)}{h'(a)}.$$
