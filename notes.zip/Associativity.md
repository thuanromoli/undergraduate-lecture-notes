---
type: def
tag: MT2505
alias: [associativity,associative]
---
Let $A$ be a set and $*$ be a [[Binary operations|binary operation]] on $A$.

>[!def] Definition
>$*$ is associative if $(a*b)*c=a*(b*c) \ \ \forall a,b,c \in A$.