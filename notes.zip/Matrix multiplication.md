---
type: def
tag: MT2501
alias: matrix multiplication
---
Let $A=[a_{ij}]$ and $B=[a_{ij}]$ be [[Matrices|matrices]].

>[!def] Definition
>Matrix multiplication is defined as $$AB=[c_{ij}]$$
>where $c_{ij}=\sum_{k=1}^na_{ik}b_{kj}$.
