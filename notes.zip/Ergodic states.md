---
tags:
  - MT4528
type: def
aliases:
  - ergodic
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S$.

>[!def] Definition
>A state $i \in S$ is called ergodic if it is both [[Periodic and aperiodic states|aperiodic]] and [[Recurrent states|positive recurrent]].
