---
tags:
  - MT3503
aliases:
---
Let $\gamma:[a,b] \to \mathbb C$ be a positively oriented [[Contours|contour]] and let $f: U \to \mathbb C$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] defined on an [[Open sets|open subset]] $U$ such that $\gamma^{*} \cup I(\gamma) \subset U$.

> [!thm] Theorem
> Let $a \in I(\gamma)$ be a point.
> Suppose that $f$ is [[Holomorphic functions|holomorphic]] on $U$. Then
> $$f(a) = \frac{1}{2 \pi i} \int_{\gamma}^{}\frac{f(z)}{z-a}\;dz.$$

Proof:
Our aim is to show that
$$\frac{1}{2 \pi i} \int_{\gamma}^{}\frac{f(z)}{z-a}\;dz - f(a) =0.$$
Firstly, we note that $f$ is holomorphic so it is [[Differentiability|differentiable]] at $a$ and $f'(a)$ exists.
So $\forall \varepsilon>0 \;\exists \delta>0$ s.t. $|z-a|<\delta \implies \left |\frac{f(z)-f(a)}{z-a} -f'(a)\right |<\varepsilon$.
So since $\varepsilon$ is any number, set $\varepsilon=1$ to obtain $|z-a|<\delta \implies \left |\frac{f(z)-f(a)}{z-a} -f'(a)\right |<1$.

Let $\gamma_\varepsilon$ be the positively oriented circular contour of radius $\varepsilon$ about $a$.
Pick $\varepsilon>0$ satisfying $0<\varepsilon<\delta$ and such that $\gamma_{e}^{*}\cup I(\gamma_\varepsilon) \subset I(\gamma)$.

Since $a \in I(\gamma)$, $\gamma_{\varepsilon}$ is circular about $a$, $\gamma_\varepsilon^{*}\cup I(\gamma_\varepsilon)\subset I(\gamma)$, and $\frac{f(z)}{z-a}$ is holomorphic on $U\setminus \set{a}$, apply the [[Deformation Theorem]] to obtain
$$\int_{\gamma}^{}\frac{f(z)}{z-a}\;dz = \int_{\gamma_\varepsilon}^{}\frac{f(z)}{z-a}\;dz.$$
Parametrise $\gamma_\varepsilon$ as $\gamma_\varepsilon(t)=a+\varepsilon e^{it}$ for $0 \leqslant t \leqslant 2 \pi$, so that we can evaluate the [[Integral along a curve|integral along the contour]]
$$\int_{\gamma_\varepsilon}^{}\frac{1}{z-a}\;dz = \int_{0}^{2 \pi} \frac{1}{(a+\varepsilon e^{it})-a}\cdot i \varepsilon e^{it}\;dt=\int_{0}^{2 \pi} \frac{i \varepsilon e^{it}}{\varepsilon e^{it}}\;dt=i\int_{0}^{2 \pi}dt=2\pi i.$$

Now we have the tools to tackle our problem. We first re-write our expression that we wish to show equals zero.
$$\begin{align*}
\frac{1}{2 \pi i} \int_{\gamma}^{}\frac{f(z)}{z-a}\;dz - f(a) &= \frac{1}{2 \pi i} \int_{\gamma_\varepsilon}^{}\frac{f(z)}{z-a}\;dz - f(a)\\
&= \frac{1}{2 \pi i}\left ( \int_{\gamma_\varepsilon}^{} \frac{f(z)}{z-a}\;dz - 2 \pi i \cdot f(a)\right )\\
&= \frac{1}{2 \pi i}\left ( \int_{\gamma_\varepsilon}^{} \frac{f(z)}{z-a}\;dz - \int_{\gamma_\varepsilon}^{}\frac{1}{z-a}\;dz \cdot f(a)\right )\\
&= \frac{1}{2 \pi i}\left ( \int_{\gamma_\varepsilon}^{} \frac{f(z)}{z-a}\;dz - \int_{\gamma_\varepsilon}^{}\frac{f(a)}{z-a} \;dz\right )\\
&= \frac{1}{2 \pi i}\left ( \int_{\gamma_\varepsilon}^{} \frac{f(z)-f(a)}{z-a}\;dz \right ).
\end{align*}$$
Now, integrating along the circular contour $\gamma_\varepsilon$ implies that $z$ is such that $|z-a|=\varepsilon < \delta$, so
$$\begin{align*}
\left | \frac{f(z)-f(a)}{z-a} \right | &= \left | \frac{f(z)-f(a)}{z-a} -f'(a) +f'(a) \right |\\
& \leqslant \left | \frac{f(z)-f(a)}{z-a} -f'(a)\right | + |f'(a)|\\
&< 1+|f'(a)|.
\end{align*}$$
Since $\left | \frac{f(z)-f(a)}{z-a} \right |$ is bounded by $1+|f'(a)|$, we apply the [[Crude Estimation Theorem]] to obtain
$$\begin{align*}
\left | \int_{\gamma_\varepsilon}^{} \frac{f(z)-f(a)}{z-a} \right | &\leqslant (1+|f'(a)|) \cdot L(\gamma_\varepsilon)\\
&= (1+|f'(a)|) \cdot 2 \pi \varepsilon.
\end{align*}$$
So putting this together,
$$\begin{align*}
\left |\frac{1}{2 \pi i} \int_{\gamma}^{}\frac{f(z)}{z-a}\;dz - f(a) \right |&= \left | \frac{1}{2 \pi i}\left( \int_{\gamma_\varepsilon}^{} \frac{f(z)-f(a)}{z-a}\;dz \right) \right |\\
&= \frac{1}{2 \pi }\left |  \int_{\gamma_\varepsilon}^{} \frac{f(z)-f(a)}{z-a}\;dz\; \right |\\
& \leqslant \frac{1}{2 \pi}\cdot(1+|f'(a)|)\cdot 2 \pi \varepsilon\\
&= \varepsilon(1+|f'(a)|).
\end{align*}$$
This is true for any $\varepsilon$ satisfying $0 < \varepsilon < \delta$, while the left-hand side is independent of $\varepsilon$. Hence, we may let $\varepsilon \to 0$ and conclude the left-hand side is 0. Thus our proof is complete.