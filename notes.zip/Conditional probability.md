---
tags:
  - MT2504
  - MT4528
type: def
aliases:
---
Let $A$ and $B$ be any two [[Sample space, Sample points, and Events|events]] such that $\mathbb{P}(B)>0$.

>[!def] Definition
>The conditional probability of $A$, given that the event $B$ has occurred is written as $\mathbb{P}(A\vert B)$ and is defined by
>$$\mathbb{P}(A \vert B)=\frac{\mathbb{P}(A \cap B)}{\mathbb{P}(B)}$$
>If $\mathbb{P}(B) = 0$, then $\mathbb{P}(A \vert B)$ is not defined.
