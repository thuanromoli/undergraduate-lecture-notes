---
tags:
  - MT3508
aliases:
---
> [!def] Definition (Matrix Form)
> The Fisher information, $\boldsymbol{I}(\boldsymbol{\theta})$, is the [[Variance and standard deviation|variance]] of the [[Score statistics|score statistics]].
> The $ij$th element of $\boldsymbol{I}(\boldsymbol{\theta})$ is
> $$I_{ij}(\boldsymbol{\theta})=\mathbb E\left( \frac{\partial l}{\partial \boldsymbol{\theta}_i} \Bigg. \Bigg|_{\boldsymbol{\theta}_{ti}} \frac{\partial l}{\partial \boldsymbol{\theta}_j} \Bigg. \Bigg|_{\boldsymbol{\theta}_{tj}} \right)$$
> where $\boldsymbol{\theta}_{i}$ and $\boldsymbol{\theta}_{j}$ are the $i$th and $j$th elements of $\boldsymbol{\theta}$, respectively, and $\boldsymbol{\theta}_{ti}$ and $\boldsymbol{\theta}_{tj}$ are the $i$th and $j$th elements of $\boldsymbol{\theta}_{t}$, the true parameter vector.

> [!def] Definition (Univariate)
> The Fisher information, $\boldsymbol{I}(\boldsymbol{\theta})$, is the [[Variance and standard deviation|variance]] of the [[Score statistics|score statistics]]. That is,
> $$I(\theta) = \mathbb E\left[\left.\left(\frac{\partial }{\partial \theta}\log f(X; \theta)\right)^{2}\right|_{\theta}\;\right]= \int_{\mathbb R}^{}\left(\frac{\partial }{\partial \theta}\log f(X; \theta)\right)^{2}f(x;\theta)\;dx.$$

> [!gen] Remarks
> It can be shown that
> $$\mathbf{I}(\boldsymbol{\theta}) = -\mathbb{E} \left( \frac{\partial^2 l}{\partial \boldsymbol{\theta}\partial \boldsymbol{\theta}^T} \Bigg. \Bigg|_{\boldsymbol{\theta}_t} \right)$$
> and so the observed Fisher information matrix is the negative of the [[Hessian matrix]].

> [!gen] Intuition
> The Fisher information quantifies how much information an observable random variable $X$ carries about an unknown parameter $\theta$ of its probability distribution. It measures how sensitive the likelihood function is to changes in $\theta$.
> 
> The idea is that if small changes in $\theta$ lead to large changes in the probability distribution of $X$, then $X$ provides a lot of information about $\theta$.
