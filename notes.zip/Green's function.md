---
tags:
  - MT3504
  - MT3506
type: def
aliases:
---
Let $L[y]=a_{2}y''+a_{1}y'+a_{0}y=g(x)$ with $y(a)=y(b)=0$ be a [[Boundary conditions|boundary]] value problem on $a \leqslant x \leqslant b$.

>[!def] Definition
>The Green's function $G(x,s)$ is such that
>$$L[G(x,s)]=\delta(x-s) \;\; \text{ and } \;\;  G(a,s)=G(b,s)=0$$
> where $\delta(x-s)$ is [[Delta and Heaviside functions|the Dirac delta function]].
> 
>This ensures that $y(x)=\int_{a}^{b}G(x,s)g(s) \;ds$ is a solution to the BVP.

>[!gen] Motivation
>If $y(x)=\int_{a}^{b}G(x,s)g(s) \;ds$ is the solution to the BVP, we expect $L[y]=g$.
>In fact $L[y(x)]=L\left[\int\limits_{a}^{b}G(x,s)g(s)\;ds \right]=\int\limits_{a}^{b}L[G(x,s)]g(s)ds$ = $\int\limits_{a}^{b}\delta(x-s)g(s)ds$ = $g(x)$

>[!thm] Properties of Green's function:
>- if $x \neq s$, then $L[G(x,s)]=0$ (i.e $G$ will satisfy the homogeneous equation)
>- if $x=s$, then we need to consider two conditions:
>	1. $G$ is [[Continuity|continuous]]
>	2. $\frac{\partial G}{\partial x}$ has a step discontinuity: $\left. \frac{\partial G}{\partial x}\right |_{x=s^{+}}-\left.\frac{\partial G}{\partial x}\right |_{x=s^{-}}=\frac{1}{a_{2}(x)}$
