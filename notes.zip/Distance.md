---
type: def
tag: MT2505
alias: [distance,distances]
---
Let $\boldsymbol v_1=(x_1,y_1)$ and $\boldsymbol v_2 =(x_2,y_2)$.

>[!def] Definition
>The distance between two points is defined as
>$$d=\lvert \boldsymbol v_1-\boldsymbol v_2\rvert=\sqrt{(x_2-x_1)^2-(y_2-y_1)^2}$$

