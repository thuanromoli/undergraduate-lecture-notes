---
type: def
tags:
  - MT2508
  - MT3508
---
Let $\boldsymbol y=\set{y_{1},...,y_{n}}$ be a set of observations each with [[Probability mass function|pmf]]/[[Probability density function|pdf]] $f(y_{i})$ which depend on some known explanatory variables $\boldsymbol{x}$, known parameters $\boldsymbol{\gamma}$, and unknown parameters $\boldsymbol{\theta}$.

>[!def] Definition
>The joint [[Probability mass function|pmf]]/[[Probability density function|pdf]] is
>$$f(\boldsymbol y;\boldsymbol\theta,\boldsymbol{x},\boldsymbol{\gamma})=\prod_{i=1}^{n}f(y_i)$$
