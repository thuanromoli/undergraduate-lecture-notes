---
tags:
  - MT3501
type: 
aliases:
  - eigenspace
  - eigenspaces
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $T:V\to V$ be a [[Linear transformations|linear transformation]].

>[!def] Definition
>The eigenspace corresponding to the [[Eigenvectors and Eigenvalues|eigenvalue]] $\lambda$ is the [[Subspaces|subspace]]
>$$\begin{align*}
   E_{\lambda} &= \set{v\in V:T(v)=\lambda v}\\
   &= \set{v\in V:T(v)-\lambda v=\boldsymbol{0}}\\
   &= \set{v\in V:T(v)-\lambda I(v)=\boldsymbol{0}}\\
   &= \set{v\in V:(T-\lambda I)(v)=\boldsymbol{0}}\\
   &= \ker (T-\lambda I)\\
   \end{align*}$$
>That is, the set of all [[Eigenvectors and Eigenvalues|eigenvectors]] of $T$ with [[Eigenvectors and Eigenvalues|eigenvalue]] $\lambda$ together with the zero vector $\boldsymbol{0}$.
