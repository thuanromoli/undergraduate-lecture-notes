---
tags:
  - MT3502
aliases:
  - metric
  - metric space
---
Let $X$ be a non-empty set.

>[!def] Definition
> A metric or distance [[Functions|function]] $d$ on $X$ is a function
> $$\begin{align*}
   X\times X &\to \mathbb R\\
   (x,y) &\mapsto d(x,y)
   \end{align*}$$
> such that the following conditions all hold:
> M1: positivity, $d(x,y) \geqslant 0 \;\;\forall x,y \in X$ and $d(x,y)=0 \iff x=y$.
> M2: symmetry, $d(x,y) = d(y,x) \;\;\forall x,y \in X$.
> M3: [[Triangle inequality|triangle inequality]], $d(x,y) \leqslant d(x,z)+d(z,y) \;\;\forall x,y,z \in X$.
> 
> The pair $(X,d)$ is called a metric space.
