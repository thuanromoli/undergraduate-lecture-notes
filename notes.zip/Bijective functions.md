---
alias: bijective
type: def
tag: MT2505
---
Let $f: X\to Y$ be a [[Functions|function]].

> [!def] Definition
> $f$ is bijective if each element of the codomain is mapped to by exactly one element of the domain.

> [!def] Definition
> $f$ is bijective if
> $$\forall y \in Y, \; \exists! \; x\in X \; \text{ s.t }\; y=xf$$

> [!def] Definition
> - $f$ is bijective if it is both [[Injective functions|injective]] and [[Surjective functions|surjective]].
> - $f$ is bijective if it has an inverse.
