---
tags:
  - MT4551
aliases:
---
Let
- $S$ be the current share price.
- $E$ be the strike price.
- $T$ be the time to expiry.
- $C_{E} / C_{A}$ be the price of a European/American call.
- $P_{E} / P_{A}$ be the price of a European/American put.
- $r$ be the [[Risk-free assets|risk-free]] rate for time $T$ ($r>0$).

|  | European | American |
| ---- | ---- | ---- |
| Call | $S-Ee^{-rt} \leqslant C_{E} \leqslant S$ | $C_{E} \leqslant C_{A} \leqslant S$ |
| Put | $Ee^{-rt}-S \leqslant P_{E} \leqslant Ee^{-rt}$ | $E-S \leqslant P_{A} \leqslant E$ |

> [!thm] The [[Boundedness|upper bound]] for the price of a European call is $S$
> Consider the short call position:
> 1. Sell a call for $X>S$.
> 2. Buy stocks at $S$.
> 3. If long party exercises, they pay you $E$ and you give them the stocks.
> 
> So the profit is $E$.

> [!thm] The upper bound for the price of a European put is $Ee^{-rt}$
> Consider the short put position:
> 1. Sell a put for $X>Ee^{-rT}$.
> 2. Bank $X$ which grows to $Xe^{rT}$ where $Xe^{rT}>E$.
> 3. If long party exercises, they give you stocks and you pay them $E$.
> 
> So the profit is $Xe^{rT}-E$ (not including stocks).

> [!thm] The lower bound for the price of a European call is $S-Ee^{-rT}$
> Consider two portfolios:
> 1. One call option and cash $Ee^{-rT}$ (long party).
> 2. One share $S$ (short party).
> 
> At the expiry time $T$, the portfolios are worth:
> 1. $\max(S,E)$.
> 2. $S$.
> 
> And so at time $T$, $\text{portfolio}(1) \geqslant \text{portfolio}(2)$ and to avoid arbitrage, this is true $\forall t$. Hence,
> $$C_{E}+Ee^{-rT} \geqslant  S \implies C_{E} \geqslant  S-Ee^{-rT}$$
> Additionally, $C_{E} \geqslant 0$ so $C_{E} = \max(S-Ee^{rT},0)$.

> [!thm] The lower bound for the price of a European put is $Ee^{-rT}-S$
> Consider two portfolios:
> 1. One put option and one share $S$ (long party).
> 2. Cash $Ee^{-rT}$ (short party).
> 
> At the expiry time $T$, the portfolios are worth:
> 1. $\max(S,E)$.
> 2. $E$.
> 
> And so at time $T$, $\text{portfolio}(1) \geqslant \text{portfolio}(2)$ and to avoid arbitrage, this is true $\forall t$. Hence,
> $$P_{E}+S \geqslant  Ee^{-rT} \implies P_{E} \geqslant Ee^{-rT} - S$$
> Additionally, $P_{E} \geqslant 0$ so $P_{E} = \max(Ee^{-rT}-S,0)$.
