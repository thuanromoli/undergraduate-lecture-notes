---
type: mthd
tag: MT2508
---
Given the paired [[Random variables|rvs]] $(X_1,Y_1), \ldots, (X_n,Y_n)$, carry out a matched-pair permutation test.

>[!gen]+ CONDITIONS:
>$(X_1,Y_1), \ldots, (X_n,Y_n)$ must be at least [[Measurement scales of data|interval]] rvs with means $\mu_X$ and $\mu_{Y}$

>[!gen]+ [[Statistical hypothesis|HYPOTHESIS]]:
>$H_0:\mu_X=\mu_Y$ vs $H_1:\mu_X\neq\mu_Y$

>[!gen]+ [[Test statistics|TEST STATISTIC]]:
>$D = \frac 1 n \sum_{i=1}^n (y_i-x_i)=\bar Y- \bar X$

>[!gen]+ METHOD:
>- PRELIMINARY STEPS:
>	1. Calculate $d_i=y_i-x_i$ for each rv.
>- OBTAINING THE TEST STATISTIC:
>	1. Calculate the observed test statistic $d_0$
>	2. permute the data by permuting the signs of each $d_i$
>	3. evaluate $D$ for each permutation
>- PERMUTATION TEST:
>	1. Find the # of [[Permutations and Cycles]] $p$ whose $D$ is at least as extreme as $d_0$
>	2. the $p$-value will be $\frac p {\text{\# all permutations}}$ where $\text{\# all permutations} = {2}^n$

---

#### Spaced repetition

Given the paired [[Random variables|rvs]] $(X_1,Y_1), \ldots, (X_n,Y_n)$, carry out a matched-pair permutation test.

CONDITIONS:
	$(X_1,Y_1), \ldots, (X_n,Y_n)$ must be at least [[Measurement scales of data|interval]] rvs with means $\mu_X$ and $\mu_{Y}$
[[Statistical hypothesis|HYPOTHESIS]]:
	$H_0:\mu_X=\mu_Y$ vs $H_1:\mu_X\neq\mu_Y$
[[Test statistics|TEST STATISTIC]]:
	$D = \frac 1 n \sum_{i=1}^n (y_i-x_i)=\bar Y- \bar X$
METHOD:
	PRELIMINARY STEPS:
		1. Calculate $d_i=y_i-x_i$ for each rv.
	OBTAINING THE TEST STATISTIC:
		1. Calculate the observed test statistic $d_0$
		2. permute the data by permuting the signs of each $d_i$
		3. evaluate $D$ for each permutation
	PERMUTATION TEST:
		1. Find the # of [[Permutations and Cycles]] $p$ whose $D$ is at least as extreme as $d_0$
		2. the $p$-value will be $\frac p {\text{\# all permutations}}$ where $\text{\# all permutations} = {2}^n$