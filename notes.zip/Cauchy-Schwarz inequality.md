---
tags:
  - MT3501
type: thm
aliases:
---
Let $V$ be an [[Inner product spaces|inner product space]] with inner product $\langle \cdot,\cdot \rangle$.

>[!thm] Theorem
>$|\langle u,v \rangle|\leqslant  \Vert u \Vert\cdot \Vert v \Vert$ for all $u,v \in V$.

Proof:
If $v= \boldsymbol{0}$, then we see
$$\langle u,v \rangle=\langle u,\boldsymbol{0} \rangle=\langle u,0\cdot \boldsymbol{0} \rangle=0\langle u,\boldsymbol{0} \rangle=0$$
Hence $$|\langle u,v \rangle|=0=\Vert u \Vert \cdot \Vert v \Vert$$
since $\Vert v \Vert=0$,

Now let's work with the case $v\neq \boldsymbol{0}$. Let $\alpha$ be a scalar, put $w=u+\alpha v$ and expand $\langle w,w \rangle$:
$$\begin{align*}
0 \leqslant \langle w,w \rangle &= \langle u+\alpha v,u+\alpha v \rangle\\
&= \langle u,u+\alpha v \rangle + \alpha \langle v,u+\alpha v \rangle\\
&= \overline{\langle u+\alpha v,u \rangle} + \alpha \overline{\langle u+\alpha v,v \rangle}\\
&= \overline{\langle u,u \rangle} + \bar \alpha \overline{\langle v,u \rangle}+\alpha \overline{\langle u,v \rangle} + \alpha \bar \alpha \overline{\langle v,v \rangle}\\
&= {\Vert u \Vert}^{2}+\bar \alpha \langle u,v \rangle + \alpha \overline{\langle u,v \rangle} + {\vert \alpha \vert}^{2} {\Vert v \Vert}^{2}\\
\end{align*}$$
Now take $\alpha= - \frac{\langle u,v \rangle}{{\Vert v \Vert}^{2}}$. We deduce that
$$\begin{align*}
0 &\leqslant  {\Vert u \Vert}^{2}- \frac{\overline{\langle u,v \rangle} \cdot {\langle u,v \rangle}}{{\Vert v \Vert}^{2}}-\frac{\langle u,v \rangle \cdot \overline{\langle u,v \rangle}}{{\Vert v \Vert}^{2}}+\frac{{|\langle u,v \rangle|}^{2}}{{\Vert v \Vert}^{4}}\cdot {\Vert v \Vert}^{2}\\
&= {\Vert u \Vert}^{2} -2\left(\frac{{|\langle u,v \rangle|}^{2}}{{\Vert v \Vert}^{2}}\right)+\frac{{|\langle u,v \rangle|}^{2}}{{\Vert v \Vert}^{2}}\\
&= {\Vert u \Vert}^{2}-\frac{{|\langle u,v \rangle|}^{2}}{{\Vert v \Vert}^{2}}
\end{align*}$$
In particular we have that
$$0 \leqslant {\Vert u \Vert}^{2}-\frac{{|\langle u,v \rangle|}^{2}}{{\Vert v \Vert}^{2}} \implies\frac{{|\langle u,v \rangle|}^{2}}{{\Vert v \Vert}^{2}}\leqslant {\Vert u \Vert}^{2} \implies{|\langle u,v \rangle|}^{2} \leqslant {\Vert u \Vert}^{2}{\Vert v \Vert}^{2}$$
Taking square roots, we obtain the required result.