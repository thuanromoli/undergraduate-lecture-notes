---
tags:
  - MT4509
aliases:
---
Consider an inviscid, incompressible and potential flow.

> [!thm] Flow around a sphere
> The potential and components of velocity for the irrotational flow around a solid sphere, of radius $R$ are
> $$\begin{cases}
   \Phi &= U \cos \theta \left(r+ \frac{R^{3}}{2r^{2}}\right)\\
   u_{r}&= U\left(1-\frac{R^{3}}{r^{3}}\right)\cos \theta\\
   u_{\theta}&= -U\left(1+\frac{R^{3}}{2r^{3}}\right)\sin \theta
   \end{cases}$$
> ![[potflowsphere_att.png|300]]

> [!thm] D'Alembert's Paradox.
> The sum of all pressures is zero around the surface of a sphere, this yields $\boldsymbol{F}=\boldsymbol{0}$. Which can't be the case, this is known as d'Alembert's Paradox. This occurs as we neglected viscosity.

The assumptions imply that $\nabla^{2} \Phi=0$, $\boldsymbol{u}=\nabla \Phi$ in the fluid and $\boldsymbol{u} \cdot \boldsymbol{n}=0$ on boundaries.

Consider the potential $\Phi=\Phi_{1}+\Phi_{2}= \underbrace{Uz}_{\text{uniform flow}}+ \underbrace{\frac{Az}{r^{3}}}_{\text{dipole}}$.
It can be shown that $\Phi$ is indeed a potential as $\nabla^{2}\Phi=0$.

We want to express the potential in spherical coordinates.
![[sphercoord_att.png|300]]

Here $\frac{\partial }{\partial \phi}=0$, no $\phi$ dependence and $z=r \cos \theta$.

So
$$\Phi=\left(Ur+\frac{A}{r^{2}}\right)\cos \theta.$$
So
$$\begin{align*}
\boldsymbol{u}=\nabla \Phi &= \frac{\partial \Phi}{\partial r}\boldsymbol{e}_{r}+\frac{1}{r}\frac{\partial \Phi}{\partial \theta}\boldsymbol{e}_\theta\\
&= \left(U-\frac{2A}{r^{3}}\right)\cos \theta \;\boldsymbol{e}_{r}-\left(U+\frac{A}{r^{3}}\right) \sin \theta \;\boldsymbol{e}_{\theta}.
\end{align*}$$
Note that $u_{r}$ vanishes at $r=R$ if and only if
$$U-\frac{2A}{R^{3}}=0 \iff R= \left(\frac{2A}{U}\right)^{1/3} \iff A= \frac{1}{2}UR^{3}.$$
So if we take $A=\frac{1}{2}UR^{3}$, then $u_{r}=0$ on the surface of a sphere of radius $R$ centred at the origin.
That is, the boundary condition $\boldsymbol{u \cdot n }=u_{r}=0$ for a solid surface.

Now, this is the potential and components of velocity for the irrotational flow around a solid sphere, of radius $R$
$$\begin{cases}
\Phi &= U \cos \theta \left(r+ \frac{R^{3}}{2r^{2}}\right)\\
u_{r}&= U\left(1-\frac{R^{3}}{r^{3}}\right)\cos \theta\\
u_{\theta}&= -U\left(1+\frac{R^{3}}{2r^{3}}\right)\sin \theta
\end{cases}$$

We now wish to calculate the force
$$\boldsymbol{F}=- \iint_{S \text{ closed}}(p-p_{\infty}) \cdot n \;dS$$
But we need to find $p$ first.
Assume a steady flow, ignore gravity
We use steady Bernoulli, take streamline with end points at -$\infty$ and on the sphere surface.
At a far point: $p = p_\infty$, $|\boldsymbol{u}| \to \sqrt{U^{2}\cos^{2} \theta+U^{2}\sin^{2} \theta}=U$.
On the sphere's surface: $p=?$, $|\boldsymbol{u}|=|u_{\theta}|$.
$$\frac{p_\infty}{\rho}+\frac{1}{2}U^{2}=\frac{p(R, \theta)}{\rho}+\frac{1}{2}u_{\theta}^2$$
So
$$\begin{align*}
p(R, \theta)&=\left.p_\infty+\frac{1}{2}\rho U^{2}\left(1-\left(1+\frac{R^{3}}{2r^{3}}\right)^{2}\sin ^{2}\theta\right)\right|_{r=R}\\
&= p_{\infty} +\frac{1}{2}\rho U^{2}\left(1-\frac{9}{4}\sin ^{2}\theta\right)
\end{align*}$$
Remarks
- The maximum pressure occurs at $\theta=0$ and $\theta= \pi$ (surprisingly).
- The minimum pressure occurs at $\pi/2$, where the flow field is fastest.
- The pressure at $\theta$ and $\pi-\theta$ is equal (symmetry).

So the sum of all pressures is zero around the surface of a sphere, this yields $\boldsymbol{F}=\boldsymbol{0}$. Which can't be the case, this is known as d'Alembert's Paradox. This occurs as we neglected viscosity.