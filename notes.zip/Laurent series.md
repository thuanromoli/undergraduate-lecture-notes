---
tags:
  - MT3503
aliases:
---
Let $D$ be some subset of $\mathbb C$ and $f: D \to \mathbb C$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] defined on $D$ with an [[Isolated singularity|isolated singularity]] at $a$.

> [!def] Definition
> The Laurent series of $f$ at $a$ is a doubly infinite [[Series|series]]
> $$f(z) = \sum\limits_{\infty}^{\infty}c_{n}(z-a)^{n}$$
> valid for all $z$ in some punctured disc $B'(a,r)=B(a,r)\setminus \set{a}$ about $a$.

> [!thm] Theorem
> If $f$ is [[Holomorphic functions|holomorphic]] on an open annulus $A = \set{z \in \mathbb C: R< |z-a| < S}$, the coefficients in any Laurent series of $f$ at $a$ are uniquely determined by $f$.
