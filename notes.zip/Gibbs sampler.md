---
tags:
  - MT4531
aliases:
---
Let $\boldsymbol{\theta}=(\theta_{1},...,\theta_{p})$ be a random vector with distribution $\pi(\boldsymbol{\theta}| \boldsymbol{x})$. For readability, drop the conditioning on the data and notation gives $\pi(\boldsymbol{\theta}| \boldsymbol{x})=\pi(\boldsymbol{\theta})$.

Let $\pi(\theta_{i}| \boldsymbol{\theta}_{(i)})$ denote the full conditional of $\theta_{i}$, given the other components $\boldsymbol{\theta}_{(i)}=(\theta_{1},...,\theta_{i-1},\theta_{i+1},...,\theta_{p})$, (and the data).

> [!gen] Algorithm
> 1. Set arbitrary starting values $\boldsymbol{\theta}^{0} = (\theta_{1}^{0},..., \theta_{p}^{0})$.
> 2. Given that the Markov chain is in state $\boldsymbol{\theta}^{t}=(\theta_{1}^{t},...,\theta_{p}^{t})$, then the Gibbs sampler successively makes random drawings from the full conditional distributions $\pi(\theta_{i}| \boldsymbol{\theta}_{(i)}^{t})$, $i=1,...,p$ as follows:
>    $$\begin{eqnarray*}
\theta_1^{t+1} & \hbox{ is sampled from } & \pi(\theta_1 |
\theta_2^{t},\dots,\theta_p^{t} ) \\
\theta_2^{t+1} & \hbox{ is sampled from } & \pi(\theta_2 |
\theta_1^{t+1}, \theta_3^{t},\dots,\theta_p^{t}) \\
\vdots & \vdots & \vdots \\
\theta_i^{t+1} & \hbox{ is sampled from } & \pi(\theta_i |
\theta_j^{t+1}, \: j < i \hbox{ and } \theta_j^t, j > i) \\
\vdots & \vdots & \vdots \\
\theta_p^{t+1} & \hbox{ is sampled from } & \pi(\theta_p |
\theta_1^{t+1},\dots,\theta_{p-1}^{t+1}).
\end{eqnarray*}$$
> 3. This completes a transition from $\boldsymbol{\theta}^{t}$ to $\boldsymbol{\theta}^{t+1}$. The Markov chain is then the sequence $\boldsymbol{\theta}^{0},\boldsymbol{\theta}^{1},...,\boldsymbol{\theta}^{T}$.

> [!thm] Transition Kernel
> The transition kernel for going from $\boldsymbol{\theta}^{t}$ to $\boldsymbol{\theta}^{t+1}$ is given by
> $$\begin{equation}
{\cal K}_G ({\boldsymbol{\theta}}^t , {\boldsymbol{\theta}}^{t+1}) =
\prod_{i=1}^k
\pi(\theta_i^{t+1} | \theta_j^{t+1}, \: j < i \hbox{ and }
\theta_j^t, \: j > i),
\end{equation}$$
