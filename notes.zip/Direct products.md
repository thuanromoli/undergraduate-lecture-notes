---
tags:
  - MT4003
aliases:
  - direct product
---
Let $G$ and $H$ be [[Groups|groups]].

> [!def] Definition
> The direct product of $G$ and $H$ is
> $$G \times H = \set{(g,h):g\in G,h\in H},$$
> the set of ordered pairs of an element in $G$ and an element in $H$, with multiplication given by
> $$(g_{1},h_{1})(g_{2},h_{2}) = (g_{1}g_{2},h_{1}h_{2}).$$

> [!thm] Theorem
> The direct product $G \times H$ under the above multiplication is a group with order
> $$|G \times H| = |G|\cdot |H|.$$
> Proof is straight forward and is omitted.

^bb7e4d

