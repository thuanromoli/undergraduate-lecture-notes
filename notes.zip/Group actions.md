---
tags:
  - MT4003
aliases:
  - action
  - acts
  - act
  - acting
---
Let $G$ be a [[Groups|group]] and $X$ a non-empty set.

> [!def] Definition
> An action of a group $G$ on a non-empty set $X$ is a [[Functions|function]]
> $$\begin{align*}
   X \times G &\to X\\
   (x,g) &\mapsto x^{g}
   \end{align*}$$
> which satisfies
> A1: $x^{1_{G}}=x \;\;\forall x\in X$.
> A2: $x^{(gh)} = (x^{g})^{h} \;\;\forall x\in X,\;\forall g,h\in G$.

> [!thm] Theorem
> Let $G$ act on $X$.
> Define the relation $\sim$ on $X$ by $x \sim y$ if and only if $y=x^{g}$ for some $g\in G$.
> Then $\sim$ is an [[Equivalence relations|equivalence relation]] on $G$.

Proof:
Reflexivity: by A1, $x^{1}=x \;\;\forall x \in X$, so $x\sim x$.

Symmetry: Suppose $x \sim y$.
Then there exists a $g\in G$ such that $y=x^{g}$.
Using A2, $y=x^{g} \implies y^{g^{-1}}=(x^{g})^{g^{-1}} \implies  y^{g^{-1}}=x^{(gg^{-1})} \implies y^{g^{-1}}= x^{1} \implies  y^{g^{-1}}=x$.
Hence $y\sim x$ and $\sim$ is symmetric.

Transitivity: Suppose $x\sim y$ and $y \sim z$.
Then there exist $g,h \in G$ such that $y = x^{g}$ and $z = y^{h}$.
Using A2, $z = y^{h} = (x^{g})^{h} = x^{(gh)}$.
Hence $x\sim z$ and $\sim$ is transitive.
