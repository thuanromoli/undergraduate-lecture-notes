---
tags:
  - MT3503
aliases:
---
> [!thm] Theorem
> If $0<t \leqslant \frac{1}{2} \pi$, then
> $$\frac{2}{\pi} \leqslant \frac{\sin t}{t} \leqslant 1.$$
