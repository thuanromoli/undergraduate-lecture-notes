---
type: def
tags:
  - MT2505
  - MT3502
aliases:
  - equivalence relation
---
Let $\sim$ be a [[Relations|relation]] defined on a set $A$.

>[!def] Definition
>$\sim$ is an equivalence relation if $\sim$ is [[Reflexivity|reflexive]], [[Symmetry|symmetric]], and [[Transitivity|transitive]].

