---
type: model
tag: MT2508
---
### [[Two-sample permutation test|Two-sample randomisation test]]
```R
x <- c(x_1, ..., x_n)
y <- c(y_1, ..., y_m)

obsteststat <- mean(x) - mean(y)
nx <- length(x)
ny <- length(y)

pooledxy <- vector(length=(nx+ny))
pooledxy[1:nx] <- x
pooledxy[(nx+1):(nx+ny)] <- y

nr <- # number of randomisations
rteststat <- vector(length = nr+1) # stores test statistics

for (i in 1:nr) {
	rpool <- sample(pooledxy, (nx+ny), replace=F)
	rx <- rpool[1:nx]
	ry <- rpool[(nx+1):(nx+ny)]
	rteststat[i] <- mean(rx) - mean(ry)
}

rteststat[nr+1] <- obsteststat

p=0

for (i in 1:(nr+1)) {
	if (rteststat[i] <= obsteststat) {
		p = p + 1
	}
}

p / (nr + 1) # this is the p-value (multiply by 2 if two-tailed)

```

### [[Mann-Whitney U-test]]
```R
x <- c(x_1, ..., x_n)
y <- c(y_1, ..., y_m)

wilcox.test(x, y, paired=FALSE, alternative="two.sided")
```

### [[Wilcoxon's signed rank test]]
```R
x <- c(x_1, ..., x_n)
y <- c(y_1, ..., y_n)

diff <- x - y
print(diff) # Now by hand find the (signed) ranks for each d_i

ranks <- c(r_1,...,r_n)
n <- length(ranks)
obsteststat <- sum(ranks[ranks>0])

nr <- # number of randomisations
rteststat <- vector(length = nr+1) # stores test statistics
pm <- c(-1,1) # this will be used to randomise

for (i in 1:nr) {
	rranks <- sample(pm, n, replace=T) * ranks
	rteststat[i] <- sum(rranks[rranks>0])
}

rteststat[nr+1] <- obsteststat

p = 0

for (i in 1:(nr+1)) {
	if (rteststat[i] <= obsteststat) {
		p = p + 1
	}
}

p / (nr + 1) # this is the p-value (multiply by 2 if two-tailed)

```

```R
x <- c(x_1, ..., x_n)
y <- c(y_1, ..., y_n)

wilcox.test(x, y, paired=TRUE, alternative="two.sided")
```

### [[Matched-pairs permutation test|Matched-pairs randomisation test]]
```R
x <- c(x_1, ..., x_n)
y <- c(y_1, ..., y_n)

diff <- x - y
n <- length(diff)
obsteststat <- mean(diff)

nr <- # number of randomisations
rteststat <- vector(length = nr+1) # stores test statistics
pm <- c(-1,1) # this will be used to randomise

for (i in 1:nr) {
	rdiff <- sample(pm, n, replace=T) * diff
	rteststat[i] <- mean (rdiff)
}

rteststat[nr+1] <- obsteststat

p = 0

for (i in 1:(nr+1)) {
	if (rteststat[i] <= obsteststat) {
		p = p + 1
	}
}

p / (nr + 1) # this is the p-value (multiply by 2 if two-tailed)

```

---

#### Spaced repetition

Carry out a two-sample randomisation test
?
```R
x <- c(x_1, ..., x_n)
y <- c(y_1, ..., y_m)

obsteststat <- mean(x) - mean(y)
nx <- length(x)
ny <- length(y)

pooledxy <- vector(length=(nx+ny))
pooledxy[1:nx] <- x
pooledxy[(nx+1):(nx+ny)] <- y

nr <- # number of randomisations
rteststat <- vector(length = nr+1) # stores test statistics

for (i in 1:nr) {
	rpool <- sample(pooledxy, (nx+ny), replace=F)
	rx <- rpool[1:nx]
	ry <- rpool[(nx+1):(nx+ny)]
	rteststat[i] <- mean(rx) - mean(ry)
}

rteststat[nr+1] <- obsteststat

p=0

for (i in 1:(nr+1)) {
	if (rteststat[i] <= obsteststat) {
		p = p + 1
	}
}

p / (nr + 1) # this is the p-value (multiply by 2 if two-tailed)

```

Carry out a Mann-Whitney randomisation test
?
```R
x <- c(x_1, ..., x_n)
y <- c(y_1, ..., y_m)

wilcox.test(x, y, paired=FALSE, alternative="two.sided")
```

Carry out a Wilcoxon's randomisation test
?
```R
x <- c(x_1, ..., x_n)
y <- c(y_1, ..., y_n)

diff <- x - y
print(diff) # Now by hand find the (signed) ranks for each d_i

ranks <- c(r_1,...,r_n)
n <- length(ranks)
obsteststat <- sum(ranks[ranks>0])

nr <- # number of randomisations
rteststat <- vector(length = nr+1) # stores test statistics
pm <- c(-1,1) # this will be used to randomise

for (i in 1:nr) {
	rranks <- sample(pm, n, replace=T) * ranks
	rteststat[i] <- sum(rranks[rranks>0])
}

rteststat[nr+1] <- obsteststat

p = 0

for (i in 1:(nr+1)) {
	if (rteststat[i] <= obsteststat) {
		p = p + 1
	}
}

p / (nr + 1) # this is the p-value (multiply by 2 if two-tailed)

```
```R
x <- c(x_1, ..., x_n)
y <- c(y_1, ..., y_n)

wilcox.test(x, y, paired=TRUE, alternative="two.sided")
```

Carry out a mathced-pairs randomisation test
?
```R
x <- c(x_1, ..., x_n)
y <- c(y_1, ..., y_n)

diff <- x - y
n <- length(diff)
obsteststat <- mean(diff)

nr <- # number of randomisations
rteststat <- vector(length = nr+1) # stores test statistics
pm <- c(-1,1) # this will be used to randomise

for (i in 1:nr) {
	rdiff <- sample(pm, n, replace=T) * diff
	rteststat[i] <- mean (rdiff)
}

rteststat[nr+1] <- obsteststat

p = 0

for (i in 1:(nr+1)) {
	if (rteststat[i] <= obsteststat) {
		p = p + 1
	}
}

p / (nr + 1) # this is the p-value (multiply by 2 if two-tailed)

```
