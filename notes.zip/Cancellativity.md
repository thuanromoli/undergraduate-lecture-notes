---
type: thm
tags:
  - MT2505
---
Let $G$ be a [[Groups|group]] and let $a,b,x \in G$.

>[!thm] Theorem
>Right cancellativity: $ax=bx \implies a = b$
>Left cancellativity: $xa=xb \implies a=b$

PROOF:
	$ax=bx$ $\implies$ $(ax)x^{-1}=(bx)x^{-1}$ $\implies$ $a(xx^{-1})=b(xx^{-1})$ $\implies$ $a=b$