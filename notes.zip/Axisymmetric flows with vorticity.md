---
tags:
  - MT4509
aliases:
---
Consider an inviscid, homogeneous and axisymmetric flow.

> [!thm] Main result
> The vorticity satisfies
> $$\frac{D}{Dt}\bigg(\frac{\omega_\phi}{R}\bigg)=0$$
> and so $\omega_{\phi}/R$ is constant and as the radius increases, so does $\omega_\phi$.
> Note: The volume $V=2 \pi RA$ is constant and as $R$ increases $A$ decreases.

![[vortexring_att.png|250]]

SETUP
Consider the velocity field in cylindrical polar coordinates
$$\boldsymbol{u}=(u_{R},u_{\phi},u_{z})=u_{R}(R,z,t),0,u_{z}(R,z,t).$$
Then
$$\boldsymbol{\omega}=\boldsymbol{\nabla  \times u}=\left(0, \frac{\partial u_{R}}{\partial z}-\frac{\partial u_{z}}{\partial R},0\right)=(0,\omega_\phi,0).$$
We wish to investigate how $\boldsymbol{\omega}$ evolves over time.

SOLUTION
We could just use $\frac{D}{Dt} \boldsymbol{\omega}= (\boldsymbol{\omega \cdot \nabla })\boldsymbol{u}$, but there is an easier way.
Direct proof by taking the curl of Euler's equation.
We use the handy identity $\boldsymbol{u \cdot \nabla u} = \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \boldsymbol{u} \times (\boldsymbol{\nabla \times u})$.
$$\begin{align*}
&\frac{D \boldsymbol{u}}{Dt} = - \frac{\nabla p}{\rho} + \boldsymbol{F}\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} +\boldsymbol{u} \cdot \nabla  \boldsymbol{u} = - \frac{\nabla p}{\rho} + \boldsymbol{F}\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} + \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) = - \frac{\nabla p}{\rho} + \boldsymbol{F}\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) =  - \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \frac{\nabla p}{\rho} + \boldsymbol{F}
\end{align*}$$
and assume that $\boldsymbol{F}=-\nabla V$ where $V$ is some potential.
$$\begin{align*}
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) =  - \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \frac{\nabla p}{\rho} - \nabla V \\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) =  - \nabla \left(\frac{1}{2} |\boldsymbol{u}|^{2} + \frac{ p}{\rho} + V\right)\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times \boldsymbol{\omega} =  - \nabla H
\end{align*}$$
now take the curl
$$\begin{align*}
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times \boldsymbol{\omega} =  - \nabla H \\
\implies& \nabla \times\left(\frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times \boldsymbol{\omega}\right) =  \nabla \times(- \nabla H)\\
\implies& \frac{\partial }{\partial t}(\nabla \times \boldsymbol{u}) - \nabla  \times(\boldsymbol{u \times \omega}) = 0\\
\implies& \frac{\partial \boldsymbol{\omega}}{\partial t} - \nabla  \times(\boldsymbol{u \times \omega})=0\\
\implies& \frac{\partial \boldsymbol{\omega}}{\partial t} + \nabla  \times(\boldsymbol{\omega \times u})=0.
\end{align*}$$
Now note that
$$\begin{align*}
\boldsymbol{\nabla } \times (\boldsymbol{\omega } \times \boldsymbol{u} )&= \boldsymbol{\nabla } \times \left(\begin{pmatrix} 0\\ \omega_{\phi}\\ 0 \end{pmatrix} \times \begin{pmatrix} u_{R}\\ 0 \\ u_{z} \end{pmatrix} \right) = \boldsymbol{\nabla } \times \begin{pmatrix}\omega_{\phi}u_{z} \\0\\-\omega_{\phi}u_{R}\end{pmatrix} =\left(\frac{\partial }{\partial z}\omega_{\phi}u_{z}+\frac{\partial }{\partial R} \omega_{\phi}u_{R}\right) \boldsymbol{e_\phi}.
\end{align*}$$
So we have
$$\begin{align*}
&\frac{\partial \boldsymbol{\omega}}{\partial t} + \nabla  \times(\boldsymbol{\omega \times u})=0\\
\implies&\boldsymbol{e}_{\phi}\cdot\left(\frac{\partial \boldsymbol{\omega}}{\partial t} + \nabla  \times(\boldsymbol{\omega \times u})\right)=0\\
&\implies\frac{\partial \omega_\phi}{\partial t} + \left(\frac{\partial }{\partial z}\omega_{\phi}u_{z}+\frac{\partial }{\partial R} \omega_{\phi}u_{R}\right)
\end{align*}$$
If we expand the derivatives and use the fact that $\boldsymbol{\nabla \cdot u}=0$, and through some heavy algebra, we obtain
$$\frac{D}{Dt}\bigg(\frac{\omega_\phi}{R}\bigg)=0$$
