---
tags:
  - MT4509
aliases:
---
Assume homogeneous fluids.

> [!thm] Theorem
> Kelvin's circulation theorem states that
> $$\frac{D \Gamma}{Dt}=0.$$

> [!thm] Corollary
> Suppose that $\boldsymbol{\omega}=\boldsymbol{0}$ at some time $t$.
> Then $\Gamma =0$ around all closed curves $\mathcal C$ for all $t$, and so $\boldsymbol{\omega}=\boldsymbol{0}$ for all $t$.
> In other words, an irrotational flow remains irrotational.

Proof.
$$\frac{D \Gamma}{Dt}=\frac{D}{Dt}\oint_\mathcal c \boldsymbol{u}\cdot d \boldsymbol{l}=\oint_\mathcal C \frac{D \boldsymbol{u}}{Dt}\cdot d  \boldsymbol{l}+\oint_\mathcal C \boldsymbol{u}\cdot \frac{D}{Dt}d \boldsymbol{l}.$$
Claim 1: $\oint_\mathcal C \frac{D \boldsymbol{u}}{Dt}\cdot d  \boldsymbol{l}=0$ using [[Euler's equation]] $\frac{D \boldsymbol{u}}{Dt}=-\frac{\nabla p}{\rho}-\nabla V$ where $V=gz$.
$$\begin{align*}
\oint_\mathcal C \frac{D \boldsymbol{u}}{Dt}\cdot d  \boldsymbol{l} &= - \oint_\mathcal C \nabla \left(\frac{p}{\rho}+V\right)\cdot d \boldsymbol{l} =0\\
\end{align*}$$
as, in general, $\oint_{\mathcal C}\nabla \phi \cdot d \boldsymbol{l}= \iint _{S}(\nabla \times \nabla \phi) \cdot d \boldsymbol{S}=0$.

Claim 2: $\oint_\mathcal C \boldsymbol{u}\cdot \frac{D}{Dt}d \boldsymbol{l}=0$.
$$\oint_\mathcal C \boldsymbol{u}\cdot \frac{D}{Dt}d \boldsymbol{l}=\oint_\mathcal C \boldsymbol{u}\cdot (d \boldsymbol{l \cdot \nabla u})=\oint_\mathcal C \frac{1}{2}d \boldsymbol{l \cdot \nabla }|\boldsymbol{u}|^{2}=\oint_{\mathcal C} \nabla \left(\frac{1}{2}{ |\boldsymbol{u}|^{2}}\right)\cdot d\boldsymbol{l}=0$$
So we obtain the result.