---
type: mthd
tags:
  - MT3504
---
>[!gen] ODE
>$$y'=f(\frac{y}{x})$$

>[!gen] Subsitution
>$$v=\frac{y}{x}$$
>such that $y=vx$ and $y'=v+xv'$

>[!gen] Solution
>$$y'=f(\frac{y}{x})$$
>$$v+xv'=f(v)$$
>$$xv'=f(v)-v$$
>$$\frac{1}{f(v)-v}v'=\frac{1}{x}$$
>Then integrate.

---

#### Spaced repetition

What is the form of a Bernoulli first-order ODE?
?
>$y'=f(\frac{y}{x})$

How do you solve $y'=f(\frac{y}{x})$?
?
>Using substitution $v=\frac{y}{x}$
>$y'=f(\frac{y}{x})$
>$v+xv'=f(v)$
>$xv'=f(v)-v$
>$\frac{1}{f(v)-v}v'=\frac{1}{x}$
>Then integrate.