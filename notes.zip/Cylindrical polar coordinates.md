---
type: def
tag: MT2506
---
>[!gen]+ [[Unit basis vectors|Basis vectors]]:
>$\boldsymbol e_R,\; \boldsymbol e_\phi,\;\boldsymbol e_z$

>[!gen]+ The relations to [[Cartesian coordinates]]:
>$R=x^2 + y^2$, $R \geqslant 0$
>$\phi=\text{arctan}(\frac{y}{x})$, $0 \leqslant\phi < 2\pi$

>[!gen]+ The inverse relations to [[Cartesian coordinates]]:
>$x=R\cos\phi$
>$y=R\sin\phi$

>[!gen]+ [[Position vectors|Position vector]] in terms of [[Cartesian coordinates]]:
>$\boldsymbol{r}=R\cos\phi\,\boldsymbol{i}+R\sin\phi\,\boldsymbol{j}+z\,\boldsymbol{k}$

>[!gen]+ [[Unit basis vectors|Basis vectors]] in terms of [[Cartesian coordinates]]:
>$\boldsymbol e_R=\cos\phi\ \boldsymbol i+ \sin\phi\ \boldsymbol j$
>$\boldsymbol e_\phi=-\sin\phi\ \boldsymbol i+ \cos\phi\ \boldsymbol j$
>$\boldsymbol e_z=\boldsymbol k$

>[!gen]+ [[Position vectors|Position vector]] in terms of Cylindrical polar coordinates:
>$\boldsymbol{r}(t)=R(t)\boldsymbol{e}_R(\phi(t))+z(t)\,\boldsymbol{e}_z$

---

#### Spaced repetition

What are the relations between Cylindrical polar and Cartesian coordinates?
?
The relations to [[Cartesian coordinates]]:
	$R=x^2 + y^2$, $R \geqslant 0$
	$\phi=\text{arctan}(\frac{y}{x})$, $0 \leqslant\phi < 2\pi$
The inverse relations to [[Cartesian coordinates]]:
	$x=R\cos\phi$
	$y=R\sin\phi$

What is the position vector of Cylindrical polar coordinates in terms of Cartesian coordinates?
?
$\boldsymbol{r}=R\cos\phi\,\boldsymbol{i}+R\sin\phi\,\boldsymbol{j}+z\,\boldsymbol{k}$

What are the basis vectors of Cylindrical polar coordinates in terms of Cartesian coordinates?
?
	$\boldsymbol e_R=\cos\phi\ \boldsymbol i+ \sin\phi\ \boldsymbol j$
	$\boldsymbol e_\phi=-\sin\phi\ \boldsymbol i+ \cos\phi\ \boldsymbol j$
	$\boldsymbol e_z=\boldsymbol k$

What is the position vector of Cylindrical polar coordinates?
?
$\boldsymbol{r}(t)=R(t)\boldsymbol{e}_R(\phi(t))+z(t)\,\boldsymbol{e}_z$
