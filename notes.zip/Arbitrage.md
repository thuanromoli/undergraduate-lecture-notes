---
tags:
  - MT4551
aliases:
  - arbitrage
---
>[!def] Definition
>Process of making an assured profit with no risk.
>No arbitrage opportunities should occur.

(See examples on slides)