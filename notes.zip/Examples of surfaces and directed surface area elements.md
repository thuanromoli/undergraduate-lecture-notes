---
type: mthd
tag: MT2506
---
>[!gen]+  The sphere
>Surface: $f(\boldsymbol x): r=\sqrt{x^2+y^2+z^2}=a$;
>Cartesian: $\boldsymbol r(\theta,\phi)=a\sin\theta\cos\phi \,\boldsymbol i +a\sin\theta\sin\phi \,\boldsymbol j + a\cos\theta \,\boldsymbol k$
>Spherical: $\boldsymbol r(\theta,\phi)=a\,\boldsymbol e_r$
>$\text d\boldsymbol S = a^2\sin\theta \,\text d\theta\,\text >d\phi\,\boldsymbol e_r$

>[!gen]+ The cylinder
Surface: $f(\boldsymbol x): R=\sqrt{x^2+y^2}=a$
Cartesian: $\boldsymbol r(\phi,z)=a\cos\phi \,\boldsymbol i +a\sin\phi \,\boldsymbol j + z\,\boldsymbol k$
Cylindrical: $\boldsymbol r(\phi,z)=a \,\boldsymbol e_R + z\,\boldsymbol k$
$\text d\boldsymbol S = a\,\text d\phi \,\text dz\,\boldsymbol e_R$

>[!gen]+ The paraboloid of revolution
>Surface: $f(\boldsymbol x): R^2=x^2+y^2=az$
>Cartesian: $\boldsymbol r(R,\phi)=R\cos\phi \,\boldsymbol i +R\sin\phi \,\boldsymbol j + \frac {R^2}a\,\boldsymbol k$
>Cylindrical: $\boldsymbol r(R,\phi)=R \,\boldsymbol e_R+ \frac {R^2}a\,\boldsymbol e_z$

>[!gen]+ The hyperboloid of revolution
>Surface: $f(\boldsymbol x): R^2=x^2+y^2=a^2+b^2z^2$
>Cartesian: $\boldsymbol r(\phi,z)=\sqrt{a^2+b^2z^2}\cos\phi \,\boldsymbol i +\sqrt{a^2+b^2z^2}\sin\phi \,\boldsymbol j + z\,\boldsymbol k$
>Cylindrical: $\boldsymbol r(\phi,z)=\sqrt{a^2+b^2z^2} \,\boldsymbol e_R + z\,\boldsymbol k$

>[!gen]+ The plane
>Surface: $f(\boldsymbol x): z= ax+by+c$
>Cartesian: $\boldsymbol r(x,y)=x \,\boldsymbol i +y \,\boldsymbol j + (ax+by+c)\,\boldsymbol k$
>$\text d\boldsymbol S=(-a\,\boldsymbol i-b\,\boldsymbol j+\boldsymbol k)\,\text dx\,\text dy$
