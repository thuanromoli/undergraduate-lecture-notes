---
tags:
  - MT4531
aliases:
---
Suppose we are comparing a two nested models with parameters $\boldsymbol{\theta}_{0}=(\theta_{0},\theta_{1},..., \theta_{p})$ and $\boldsymbol{\theta}_{1}=(\theta_{0},\theta_{1},..., \theta_{p},\theta_{p+1},...)$.
Then the hypothesis test would be $M_{0}: \theta_{p+1} = \theta_{p+1}=\cdots = 0$ vs $M_{1}:$ the opposite.

> [!def] Definition
> The DIC for model $m$ is given by
> $$DIC_{m} = - 2 \mathbb E_{\pi}(\log f(\boldsymbol{x}| \boldsymbol{\theta}_{m}, M=m))+p_{D}(m)$$
> or, equivalently
> $$DIC_{m} = -2\log f(\boldsymbol{x}|\widehat{\boldsymbol{\theta}}_{m},M=m)+2p_{D}(m)$$
> where $p_{D}(m) = - 2 \mathbb E_{\pi}(\log f(\boldsymbol{x}| \boldsymbol{\theta}_{m}, M=m))+ 2 \log f(\boldsymbol{x}|\widehat{\boldsymbol{\theta}}_{m},M=m)$.

> [!gen] Remarks
> - In practice, we are given
>   $$\begin{align*}
   \widehat {D(x,\theta)}&=- 2 \mathbb E_{\pi}(\log f(\boldsymbol{x}| \boldsymbol{\theta}_{m}, M=m)) \\
   {D(x,\widehat \theta)}&= -2\log f(\boldsymbol{x}|\widehat{\boldsymbol{\theta}}_{m},M=m)
   \end{align*}$$
> - Hence,
>   $$\begin{align*}
   DIC &= \widehat {D(x,\theta)} + p_{D}\\
   DIC &= {D(x,\widehat \theta)}+ 2p_{D}\\
   p_{D} &= \widehat {D(x,\theta)} - {D(x,\widehat \theta)}
   \end{align*}$$
