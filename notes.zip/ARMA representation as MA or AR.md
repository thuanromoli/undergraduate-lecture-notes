Method 1
Assume form and sub into equation
$\varphi(B)X_{t}=\vartheta(B)\varepsilon_{t}$ assume $X_{t}=\psi(B)\varepsilon_{t}$ and sub for $X_{t}$.
Expand and compare coefficients.
Solve using recurrent relations.

Method 2
Write in desired form $X_{t}=\frac{\vartheta(B)}{\varphi(B)}\varepsilon_{t}$.
Use series expansion and find coefficients directly.
