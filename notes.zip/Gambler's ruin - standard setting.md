---
tags:
  - MT4528
type: model
aliases:
---
>[!gen] Standard setting
>- Let the capital of players $A$ and $B$ be $a$ and $b$, and let $N=a+b$ be the total capital in the game.
>- Let $p$ be the probability that $A$ wins a given game.
>- The game continues until one player runs out of money.
>- Let $X_{t}$ be (capital of player $A$ after game $t$) $+ 1$

>[!gen] Model
>$\set{X_{0},X_{1},X_{2},\ldots}$ is a [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S=\set{1,2,...,a+b+1}$ and
>$$\begin{matrix}X_{0}=a+1 \;\;\;\;\;\;\; \\ X_{t}=X_{t-1}+Z_{t}\end{matrix}$$
>$$\text{where }Z_{t}=\begin{cases}
   1  & \text{with probability } p \\
   -1 & \text{with probability } q=1-p
   \end{cases}$$

>[!gen] Directed graph and communication classes
>![[gamblersruin_att.png|500]]
>
>There are three communication classes: $\mathcal{D}_{1}=\set{1}$, $\mathcal{D}_{2}=\set{2,3,...,a+b}$, $\mathcal{D}_{a+b+1 }=\set{a+b+1}$