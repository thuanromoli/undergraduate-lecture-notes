---
type: def
tag: MT2505
alias: index
---
Let $G$ be a [[Groups|group]] and $H$ be a [[Subgroups|subgroup]] of $G$.

>[!def] Definition
>The index of $H$ in $G$ is the number of right [[Cosets|cosets]] of $H$ occuring in $G$. We shall denote it by $|G:H|$.
