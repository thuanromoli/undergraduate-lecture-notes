---
tags:
  - MT3507
aliases:
---
Let $X_{1},...,X_{n}$ be continuous [[Random variables|rvs]] and set the random vector as $\boldsymbol{X} = (X_{1},...,X_{n})$ with [[Probability density function|pdf]] $f_{\boldsymbol{X}}(\boldsymbol{x})$.

Define a new random vector $\boldsymbol{Y}=(Y_{1},...,Y_{n})$ by
$$Y_{i}=g_{i}(\boldsymbol{X})= g_{i}(X_{1},...,X_{n})\;\;\; \text{for } i=1,...,n$$
where $g_{i}$ are functions for $i = 1,...,n$
$$\begin{align*}
g_{i}: X_{1}\times X_{2}\times\cdots\times X_{n} &\to Y_{i}\\
(x_{1},x_{2},...,x_{n}) &\mapsto y_{i}.
\end{align*}$$

> [!thm] Theorem
> The distribution of $\boldsymbol{Y}$ is
> $$f_{\boldsymbol{Y}}(\boldsymbol{y}) = |\boldsymbol{J}|f_{\boldsymbol{X}}(h_{1}(\boldsymbol{y}),h_{2}(\boldsymbol{y}),...,h_{n}(\boldsymbol{y}))$$
> where $h_{i}$ is the inverse function of $g_{i}$ such that
> $$\begin{align*}
   h_{i}: Y_{1}\times Y_{2}\times\cdots\times Y_{n} &\to X_{i}\\
   (y_{1},y_{2},...,y_{n}) &\mapsto x_{i}.
   \end{align*}$$
> and where $|\boldsymbol{J}|$ is the absolute value of the determinant of the Jacobian matrix
> $$\boldsymbol{J} = \frac{\partial (h_{1},...,h_{n})}{\partial (y_{1},...,y_{n})}=\begin{pmatrix}
  \frac{\partial h_{1}}{\partial y_{1}} & \frac{\partial h_{1}}{\partial y_{2}} & \cdots & \frac{\partial h_{1}}{\partial y_{n}} \\
  \frac{\partial h_{2}}{\partial y_{1}} & \frac{\partial h_{2}}{\partial y_{2}} & \cdots & \frac{\partial h_{2}}{\partial y_{n}} \\
  \vdots & \vdots & \ddots & \vdots \\
  \frac{\partial h_{n}}{\partial y_{1}} & \frac{\partial h_{n}}{\partial y_{2}} & \cdots & \frac{\partial h_{n}}{\partial y_{n}}
  \end{pmatrix}$$
