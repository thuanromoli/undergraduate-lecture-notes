---
type: def
tags:
  - MT2505
  - MT4003
aliases:
  - isomorphisms
  - isomorphism
---
Let $G$ and $H$ be [[groups]] and we assume that the [[binary operations]] are written as multiplication in both these groups.

>[!def] Definition
>An isomorphism $\phi : G \to H$ is a [[Bijective functions|bijective]] [[Homomorphisms|homomorphism]] such that
>$$(g_{1}g_{2})\phi=(g_{1}\phi)(g_{2}\phi)=h_{1}h_{2}$$
>If there is an isomorphism between $G$ and $H$ we say that $G$ and $H$ are isomorphic and we write $G \cong H$
