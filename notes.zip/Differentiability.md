---
tags:
  - MT3503
aliases:
  - differentiable
---
#### For complex analysis:
Let $U$ be an [[Open sets|open subset]] of $\mathbb C$ and $f:U \to \mathbb C$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] defined on $U$.

> [!def] Limit definition
> $f$ is differentiable at a point $c \in U$ if the limit
> $$\lim\limits_{h \to 0} \frac{f(c+h)-f(c)}{h}$$
> exists.
> 
> When this limit exists, we call it $f'(c)$, the derivative of $f$ at $c$ and we write $\frac{df}{dz}$ for the function $f'(z)$ whenever is defined.

> [!def] Epsilon-Delta definition
> $f$ is differentiable at a point $c \in U$ with derivative $f'(c)$ if
> $$\begin{align*}
   &\forall \varepsilon > 0 \;\; \exists \delta > 0 \;\;\text{s.t}\\
   & |h| \leqslant \delta \implies \left\lvert \frac{f(c+h)-f(c)}{h}-f'(c) \right\rvert \leqslant  \varepsilon.
\end{align*}$$

#### For real analysis:
Let $I \subseteq \mathbb R$ be an open interval and $f: I \to \mathbb R$ be a [[Functions|function]] on $A$.

> [!def] Limit definition
> $f$ is differentiable at a point $c \in I$ with derivative $f'(c)$ if
> $$\lim\limits_{x \to c} \frac{f(x)-f(c)}{x-c}$$
> exists.
> 
> When this limit exists, we call it $f'(c)$, the derivative of $f$ at $c$ and we write $\frac{df}{dx}$ for the function $f'(x)$ whenever is defined.

> [!def] Epsilon-Delta definition
> $f$ is differentiable at a point $c \in U$ with derivative $f'(c)$ if
> $$\begin{align*}
   &\forall \varepsilon > 0 \;\; \exists \delta > 0 \;\;\text{s.t}\\
   & x \in I\setminus \set{c} \text{ with } |x-c| \leqslant \delta \implies \left\lvert \frac{f(x)-f(c)}{x-c}-f'(c) \right\rvert \leqslant  \varepsilon.
   \end{align*}$$
