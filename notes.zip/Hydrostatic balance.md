---
tags:
  - MT4509
aliases:
---
> [!thm] Theorem
> If a flow is at rest $\boldsymbol{u}=0$ and the fluid is homogeneous $\rho = \text{constant}$, then the hydrostatic pressure satisfies
> $$\frac{dp}{dz}=-\rho g$$

Using [[Euler's equation]],
$$\frac{D \boldsymbol{u}}{Dt}= -\frac{\nabla  p}{\rho}+\boldsymbol{F}$$
and take $\boldsymbol{F}=\boldsymbol{g}=(0,0,-g)$.

Assume fluid is homogeneous $\rho=$ constant.
Then equation becomes
$$0=-\frac{\nabla p}{\rho}+\boldsymbol{g}\implies \nabla p=\rho \boldsymbol{g}=-\rho g \boldsymbol{k}.$$
So
$$\frac{\partial p}{\partial x}=0 \qquad \frac{\partial p}{\partial y}=0 \qquad \frac{\partial p}{\partial z}=-\rho g$$
$p(z)$ is a function of $z$ so
$$\frac{dp}{dz}=-\rho g \implies p =p_{0}-\rho g z.$$
Pressure linearly decreases with height.