---
tags:
  - MT3501
type: def
aliases:
  - linear functionals
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$.

>[!def] Definition
>A linear functional is a [[Linear transformations|linear transformation]] $f:V\to F$ where $F$ is viewed as a vector space over itself.
