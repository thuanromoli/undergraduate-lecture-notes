---
alias:
  - estimator
  - estimate
type: def
tag: MT2508
---
>[!def] Estimator
>An estimator $T$ of $\theta$ is a [[Functions|function]] of the [[random variables]] $\boldsymbol{X}=\set{X_1,...,X_n}$, namely $T=f(\boldsymbol{X})$.

>[!def] Estimate
>An estimate $t$ of $\theta$ is the value of the observed variables $\boldsymbol{x}=\set{x_1,...,x_n}$, namely $t=f(\boldsymbol{x})$.
