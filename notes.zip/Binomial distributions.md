---
tags:
  - MT2508
  - MT2504
  - MT3508
  - MT3507
aliases: binomial distribution
---
> [!gen] Parameters
> $n \in \set{0,1,2,...}$ - number of trials
> $p \in [0,1]$ - success probability for each trial

> [!gen] Support
> $x\in\set{0,1,2,...,n}$ - number of successes

>[!gen] [[Probability mass function]]
>$$f(x)={n \choose x}p^x(1-p)^{n-x}$$

> [!gen] Typical use
> Used for count data when there are a fixed number ($N$) of _trials_ and a binary outcome for each trial.

>[!gen] Intuition
>The binonial distribution is obtained when considering the number of successes in $n$ identical and [[Independent events|independent]] [[Bernoulli distribution|bernoulli]] trials, each with probability of success $p$.

> [!thm] Properties
> - $G(S) = (1-p+sp)^{n}$
>   Proof: definition.
> - $\mathbb E(X) = np$, $\text{Var }(X) = np(1-p)$
>   Proof: use derivatives of the pgf.
> - $X \sim \text{Bin}(n,p)$ and $Y \sim \text{Bin}(m,p)$ $\implies$ $X+Y \sim \text{Bin}(n+m,p)$
>   Proof: use pgfs.