---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A stochastic process $(\varepsilon_{t})_{t \in \mathbb Z}$ is called a generalised autoregressive conditionally heteroscedastic process of order ($p,q$) if there exists an independent [[White noise|white noise]] $(\eta_{t})_{t \in \mathbb Z}$ of unit variance $\sigma^{2}_\eta=1$ and real numbers $\alpha_{0}>0, \alpha_{1}\geqslant 0,...,\alpha_{q} \geqslant 0, \beta_{1} \geqslant 0,...,\beta_{p} \geqslant 0$ such that for all $t \in \mathbb Z$,
> $$\begin{align*}
   \varepsilon_{t}&=\sigma_{t} \eta_{t} \qquad \text{with}\\
   \sigma^{2}_{t} &= \alpha_{0}+\alpha_{1} \varepsilon^{2}_{t-1}+\cdots+\alpha_{q}\varepsilon^{2}_{t-q}+\beta_{1}\sigma^{2}_{t-1} + \cdots + \beta_{p} \sigma^{2}_{t-p}
   \end{align*}$$
> where $\eta_{t}$ is referred to as "innovation".

> [!thm] Properties (under certain [[Stationarity of AR(p) Processes|regularity conditions]])
> - Conditional mean $$\mathbb E(\varepsilon_{t}|\varepsilon_{t-1},\varepsilon_{t-2},...)=0.$$
> - Conditional variance (general) $$\text{Var }(\varepsilon_{t}|\varepsilon_{t-1},\varepsilon_{t-2},...)=\sigma^{2}_{t}= \alpha_{0}+\alpha_{1}\varepsilon^{2}_{t-1}+\cdots+\alpha_{q}\varepsilon^{2}_{t-q}+\beta_{1} \sigma^{2}_{t-1}+\cdots+\beta_{p}\sigma^{2}_{t-p}.$$
> - Conditional variance (requiring $\alpha_{1}+\cdots + \alpha_{q}+\beta_{1}+\cdots + \beta_{p}<1$) $$\text{Var }(\varepsilon_{t}|\varepsilon_{t-1},\varepsilon_{t-2},...)=\sigma^{2}_{t}= \frac{\alpha_{0}}{1-\alpha_{1}-\cdots-\alpha_{q}-\beta_{1}-\cdots -\beta_{p}}.$$
> - Kurtosis $>3$.

> [!gen] Remarks
> - A GARCH($p,q$) process is a white noise.
> - The innovation's distribution is often specified as normal (then $\eta$ is a Gaussian white noise) or t-distributed (if heavy tails are needed).
> - Under suitable conditions, the GARCH($p,q$) model can be represented in the form of an ARMA($\max(p,q),p$) process for $\varepsilon^{2}_{t}$. Let $\zeta_{t}= \varepsilon_{t}^{2}-\sigma^{2}_{t}$, then: $$\varepsilon^{2}_{t}= \alpha_{0}+ \sum\limits_{i=1}^{\max (p,q)}(\alpha_{i}+ \beta_{i})\varepsilon^{2}_{t-i}+ \zeta_{t} - \sum\limits_{i=1}^{p}\beta_{i} \zeta_{t-i} \quad \text{with white noise} \quad \zeta_{t}= \varepsilon^{2}_{t}-\sigma_{t}^{2}$$ where $\alpha_{1}=0$ for $i>q$ and $b_{i}=0$ for $i>p$.
> - GARCH(1,1) displays volatility clustering.
