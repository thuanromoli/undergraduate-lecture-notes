---
tags:
  - MT3506
aliases:
---
Let $f(x)$ be an [[Integrability|integrable]] [[Functions|function]] on the real line.

> [!def] Forward FT
> The Fourier Transform of $f(x)$ is the complex valued function $\tilde f(k)$, defined by the integral
> $$\tilde f(k) = \int_{-\infty}^{\infty}f(x) e^{-i k x }dx,\quad \forall k \in \mathbb R.$$

> [!thm] Fourier Inversion Theorem
> The theorem states that for sufficiently nice functions, it is possible to recover the original function from its Fourier Transform.
> The Inverse Fourier Transform of a Forward FT $\tilde f(k)$ is the function $f(x)$, defined by the integral
> $$f(x) = \frac{1}{2 \pi} \int_{-\infty}^{\infty}\tilde f(k) e^{i k x }dk,\quad \forall x \in \mathbb R.$$

The motivation for this is obtained by extending the [[Fourier Series]] of a function $f:[-\pi, \pi] \to \mathbb R$ to the real numbers.
Recall that the Fourier series for $f(x)$ is
$$f(x) = \frac{1}{2}a_{0}+\sum\limits_{n=1}^{\infty}a_{n}\cos(nx)+\sum\limits_{n=1}^{\infty}b_{n}\sin(nx)$$
where
$$\begin{align*}
a_{n} = \frac{1}{\pi} \int_{-\pi}^{\pi}f(x) \cos(nx)dx\\
b_{n} = \frac{1}{\pi} \int_{-\pi}^{\pi}f(x) \sin(nx)dx\\
\end{align*}$$
which follows from the [[Orthogonality|orthogonality]] of $\cos(nx)$ and $\sin (nx)$ on $[-\pi,\pi]$.

Let us write this succinctly in complex notation, that is
$$\begin{align*}
f(x) &= \sum\limits_{n=-\infty}^{\infty} c_{n} e^{inx}\\
c_{n} &= \frac{1}{2 \pi} \int_{-\pi}^{\pi}f(x)e^{-inx}dx
\end{align*}$$
which follows again from orthogonality (recall $\int_{-\pi}^{\pi}e^{inx}e^{-imx}dx=2\pi \delta_{nm}$).

We now proceed to motivate the definition of the FT by considering a stretching on the interval $[-\pi,\pi]$ to $[-L/2,L/2]$.

Relabel our original Fourier Series in terms of $y$ as
$$\begin{align*}
g(y) &= \sum\limits_{n=-\infty}^{\infty} c_{n} e^{iny}\\
c_{n} &= \frac{1}{2 \pi} \int_{-\pi}^{\pi}g(y)e^{-iny}dy
\end{align*}$$ for $y \in [-\pi,\pi]$.

Define a new independent variable $x=\frac{Ly}{2 \pi}$ ($\implies y=2\pi x/L$). 
Write $f(x) = g(y(x))$. Then $x \in [-L/2,L/2]$ and
$$\begin{align*}
c_{n} &= \frac{1}{2 \pi} \int_{-\pi}^{\pi}g(y) e^{-iny}dy\\
&= \frac{1}{2 \pi} \int_{-L/2}^{L/2}g(y(x))e^{-i (2 \pi n /L) x}(dx \cdot2 \pi /L)\\
&= \frac{1}{L} \int_{-L/2}^{L/2} f(x) e^{-ikx}dx
\end{align*}$$
where $k = 2 \pi n/L$ and we relabel $C_{n}=Lc_{n} = \int_{-L/2}^{L/2} f(x) e^{-ikx}dx$. Then taking the limit $L \to \infty$ gives
$$C(k) = \int_{-\infty}^{\infty}f(x)e^{-ikx}dx.$$

We now wish to find the inverse relation. We use $y = 2 \pi x/L$ and $c_{n}= C_{n}/L$, as before:
$$\begin{align*}
f(x) = g(y(x)) &= \sum\limits_{n=-\infty}^{\infty}c_{n} e^{iny}\\
&= \sum\limits_{n=-\infty}^{\infty}\left(\frac{C_{n}}{L}\right)e^{in 2 \pi x/L}.
\end{align*}$$
Now we transform the sum into a integral (by letting $n$ be very small)
$$\begin{align*}
f(x) &=\int_{-\infty}^{\infty}\frac{C_{n}}{L}e^{i n 2 \pi x/L}dn
\end{align*}$$
and apply a change of variable $k = 2 \pi n /L$ ($\implies dk = dn \cdot 2 \pi /L$) and letting $L \to \infty$, we obtain
$$\begin{align*}
f(x) &= \int_{-\infty}^{\infty}\frac{C_{n}}{L}e^{ikx}(dk \cdot L/2 \pi)\\
&= \frac{1}{2 \pi} \int_{-\infty}^{\infty}C(k)e^{ikx}dk.
\end{align*}$$
