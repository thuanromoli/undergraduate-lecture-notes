---
tags:
  - MT3507
aliases: gamma distribution
---
> [!gen] Relationships to other distributions
> - [[Exponential distributions]] $\Gamma(1,\lambda)$
> - [[Chi-squared distributions]] $\Gamma\left(\frac{k}{2},\frac{1}{2}\right)$

> [!gen] Parameters
> $\alpha \in (0,\infty)$ - shape
> $\lambda \in (0,\infty)$ - scale

> [!gen] Support
> $x\in (0, \infty)$ - continuous [[Random variables|rv]] 

>[!gen] [[Probability density function]]
> $$f(x) = \frac{\lambda^{\alpha}}{\Gamma(\alpha)}x^{\alpha-1}e^{-\lambda x}$$

> [!gen] Typical use
> Generalisation of the [[Exponential distributions|exponential distribution]] to allow for greater or lesser variance.

>[!thm] Properties
> - $X \sim \Gamma(\alpha, \lambda) \implies cX \sim \Gamma(\alpha, \lambda/c)$
>   Proof: use mgfs.
> - $\mu'_{r} = \mathbb E(X^{r}) = \frac{\Gamma(\alpha+r)}{\lambda^{r}\Gamma(\alpha)}$
>   Proof: direct calculation.
> - $\mathbb E(X) = \frac{\alpha}{\lambda}$, $\mathbb E(X^{2}) = \frac{(\alpha+1)\alpha}{\lambda^{2}}$, $\text{Var }(X) = \frac{\alpha}{\lambda^{2}}$
>   Proof: use (2) and direct calculation.
> - $X_{i}\sim \Gamma(\alpha_{i}, \lambda)$, where $X_{i}$ are independent rvs $\implies \sum\limits_{i=1}^{n}X_{i} \sim \Gamma\left(\sum\limits_{i=1}^{n}\alpha_{i}, \lambda\right)$
>   Proof: use mgfs.
