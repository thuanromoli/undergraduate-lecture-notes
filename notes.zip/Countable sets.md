---
tags:
  - MT3502
aliases:
  - countable
---
Let $A$ be an [[Cardinality|infinite]] set.

> [!def] Definition
> $A$ is countable if $A$ is [[Similarity|similar]] to $\mathbb N$
> $$\mathbb N \simeq A$$
> that is, if there exists a bijection $f: \mathbb N \to A$.
> 
> We can think of such bijection as a list or enumeration of the elements of $A$:
> $$\begin{matrix}
   \mathbb N & 1 & 2 & 3 & 4 & \cdots \\
   & \updownarrow & \updownarrow & \updownarrow & \updownarrow & \\ 
   \mathbb A & a_{1} & a_{2} & a_{3} & a_{4} & \cdots \\
   \end{matrix}$$
> where each element of $A$ appears exactly once as an $a_{i}$.
