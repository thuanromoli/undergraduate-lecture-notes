---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is called a moving average process of order $q \in \mathbb N$ if there exists a [[White noise|white noise]] $(\varepsilon_{t})_{t \in \mathbb Z}$ and real numbers $\theta_{1},...,\theta_{q} \in \mathbb R$ such that for all $t \in \mathbb Z$,
> $$X_{t}=\varepsilon_{t}+ \theta_{1} \varepsilon_{t-1}+\cdots+\theta_{q}\varepsilon_{t-q}.$$
> 
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is a moving average of order $q$ with mean $\mu$ if $X_{t}-\mu$ is a MA($q$) process.

> [!thm] Properties
> - $(X_{t})_{t \in \mathbb Z}$ is [[Stationarity|weakly stationary]].
> - $$\gamma_X (h) = \left\{ \begin{array}{ll}
\sigma^2_{\varepsilon} \sum_{l=0}^{q-|h|} \theta_l\theta_{l+|h|} & \quad |h| \le q \\
0 & \quad \mbox{otherwise}.
\end{array} \right.$$
> - $$\rho_X (h) = \left\{ \begin{array}{ll}
\frac{\sum_{l=0}^{q-|h|} \theta_l\theta_{l+|h|}}{\sum_{l=0}^{q} \theta^2_l} & \quad |h| \le q \\
0 & \quad \mbox{otherwise}.
\end{array} \right.$$

> [!gen] Remarks
> - The ACF vanishes from lag $q+1$ on.
> - The PACF decays gradually.
> - $$\begin{vmatrix}
\hline
 & ACF & PACF \\ \hline
 \text{MA($q$)} & \text{Cuts off after lag $q$} & \text{Decays to zero} \\ \hline
\text{AR($p$)} & \text{Decays to zero} & \text{Cuts off after lag $p$} \\
\hline
\end{vmatrix}$$