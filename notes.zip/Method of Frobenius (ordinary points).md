---
tags:
  - MT3506
aliases:
---
Consider a general second order ODE $c_{2}(x)y''+c_{1}(x)y'+c_{0}y=0$ written in [[Homogeneous and inhomogeneous Second-Order ODEs|standard]] form $y''+p(x)y'+q(x)=0$.

Step 1
Consider $y(x) = \sum\limits_{n=0}^{\infty}a_{n}x^{n}$.
Step 2
Differentiate to find $y'$ and $y''$.
Step 3
Substitute $y,y',y''$ into the ODE and collect terms $x^{n}$. Note $p(x) = \sum\limits_{n=9}^{\infty}p_{n}x^{n}$ and $q(x) = \sum\limits_{n=9}^{\infty}q_{n}x^{n}$.
Step 4
Obtain a recurrence relation for $a_{n}$.
Step 5
Solve for $a_{n}$.
