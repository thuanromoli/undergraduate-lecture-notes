---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A [[Stochastic processes|stochastic process]] is called Gaussian if all its marginal distributions are Gaussian.
