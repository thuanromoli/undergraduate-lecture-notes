---
tags:
  - MT4551
aliases:
---
Let $S$ be the share price at time $t$.

> [!gen] Method
> 1. Construct usual binomial tree as in [[Binomial trees - general principles|here]].
> 2. When working back through the nodes, if option values fall below $E-S$, replace by $E-S$ (this is to avoid arbitrage).
> In other words,
> $$\begin{align*}
   \text{node value} &= \max(\text{risk-free value}, \text{payoff of node})\\
   &= \max(V_{0}=e^{-r \delta t}(pV_{1}+(1-p)V_{2}, E-S_{i}).
   \end{align*}$$

Example:
![[bintreeamput_att.png]]
