---
tags:
  - MT3502
aliases:
---
Let $A_{1},A_{2},...$ be a [[Countable sets|countable]] family of countable sets.

> [!thm] Theorem
> The union
> $$\bigcup_{i=1}^{\infty}A_{i}$$
> is countable.

Proof:
For each $i = 1,2,3,...$ let $A_{i} = \set{a_{i_{1}},a_{i_{2}},a_{i_{3}},...}$.
Then we can enumerate $\bigcup_{i=1}^{\infty} A_{i}$ as $(a_{11},a_{12},a_{21},a_{13},a_{22},a_{31},...)$ and then delete any duplicates.
Alternatively, define $f:\bigcup_{i=1}^{\infty} A_{i} \to \mathbb N$ by $f(a_{ij})=2^{i}3^{j}$ (taking the least $j$ in the case of duplicates).
Then $f$ is an injection as $f(a_{ij})=f(a_{i'j'})$ $\implies$ $2^{i}3^{j} = 2^{i'}3^{j'}$ $\implies$ $(i,j)=(i',j')$ by unique factorisation $\implies$ $a_{ij}=a_{i'j'}$.
And by [[Theorems about countable sets#^e649c1|this theorem]], since $\mathbb N$ is countable, so is $\bigcup_{i=1}^{\infty} A_{i}$.