---
tags:
  - MT3504
type: def
aliases:
  - IVP
  - initial values
---
>[!def] First-Order ODE
>An Initial Value Problem is a first-order ODE together with an initial value:
>$$y'=f(x,y) \;\; \text{with } \;\; y(x_{0})= y_{0}$$

>[!def] Second-Order ODE
>An Initial Value Problem is a second-order ODE together with an initial value:
>$$L[y]=g(x) \;\; \text{with } \;\; y(x_{0})= y_{0} \text{ and } y'(x_{0})=y'_{0}$$
