---
tag: MT2507
type: thm
alias:
- 
---
Let $f(x)$ be a [[Continuity|continuous]] and [[Differentiability|differentiable]] [[Functions|function]] that has a root at $x=r$.

Consider the [[Newton-Raphson Method (1D)]] and the approximation $x_{n}$ of the root $r$.
This approximation has an error, let us call it $\varepsilon$. Then $$r=x_{n}+\varepsilon_{n}$$
Hence $x_{n}=r-\varepsilon_{n}$ and $x_{n+1}=r-\varepsilon_{n+1}$.

Now we wish to evaluate the error $\varepsilon_{n+1}$ and to do so we will use the N-R Method: 
$$r-\varepsilon_{n+1}=r-\varepsilon_{n}- \frac{f(r-\varepsilon_{n})}{f'(r-\varepsilon_{n})}$$
$$\implies \varepsilon_{n+1}=\varepsilon_{n}+\frac{f(r-\varepsilon_{n})}{f'(r-\varepsilon_{n})}=\frac{\varepsilon_{n}f'(r-\varepsilon_{n})+f(r-\varepsilon_{n})}{f'(r-\varepsilon_{n})}$$
The next step is to expand $f(r-\varepsilon_{n})$ using the [[Taylor's Theorem|Taylor expansion]]
$$f(z)=f(z_{0})+(z-z_{0})f'(z_{0})+ \frac{(z-z_{0})^{2}}{2}f''(z_{0}) + \ldots$$
with $z=r- \varepsilon_{n}$ and $z_{0}=r$, which implies $(z-z_{0})=-\varepsilon_{n}$: 
$$f(r-\varepsilon_{n})=f(r)+(-\varepsilon_{n})f'(r)+ \frac{(-\varepsilon_{n})^{2}}{2}f''(r)+\ldots$$
$$\implies f(r-\varepsilon_{n})=f(r)-\varepsilon_{n}f'(r)+ \frac{\varepsilon_{n}^{2}}{2}f''(r)+\ldots=-\varepsilon_{n}f'(r)+ \frac{\varepsilon_{n}^{2}}{2}f''(r)+\ldots$$
since $f(r)=0$. Now we can also find $f'(r-\varepsilon_{n})$:
$$f'(r-\varepsilon_{n})=f'(r)-\varepsilon_{n}f''(r)+\ldots$$
Hence the numerator of the method above becomes
$$\varepsilon_{n}(f'(r)-\varepsilon_{n}f''(r)+\ldots)+(-\varepsilon_{n}f'(r)+ \frac{\varepsilon_{n}^{2}}{2}f''(r)+\ldots)=-\frac{f''(r)}{2}\varepsilon_{n}^{2}+O(\varepsilon_{n}^{3})$$
The denominator is expanded again using the [[Taylor's Theorem|Taylor expansion]]: $$\frac{1}{f'(r-\varepsilon_{n})}=\frac{1}{f'(r)}+(-\varepsilon_{n}) \left(-\frac{f''(r)}{[f'(r)]^{2}}\right)+\ldots\approx \frac{1}{f'(r)}+\varepsilon_{n} \frac{f''(r)}{[f'(r)]^{2}}$$
Hence we get
$$\frac{\varepsilon_{n}f'(r-\varepsilon_{n})+f(r-\varepsilon_{n})}{f'(r-\varepsilon_{n})}\approx\left(-\frac{1}{2}f''(r)\varepsilon_{n}^{2}\right)\left(\frac{1}{f'(r)}+\varepsilon_{n} \frac{f''(r)}{[f'(r)]^{2}}\right)\approx- \frac{f''(r)}{f'(r)} \frac{\varepsilon_{n}^{2}}{2}+O(\varepsilon_{n}^2)$$
And finally
$$\varepsilon_{n+1}\approx -\frac{f''(r)}{f'(r)} \frac{\varepsilon_{n}^{2}}{2}$$
i.e $\varepsilon_{n+1} \propto \varepsilon_{n}^{2}$ which means that the scheme is second order.






---

#### Spaced repetition
