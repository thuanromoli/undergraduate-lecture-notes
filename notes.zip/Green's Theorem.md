---
type: thm
tag: MT2506
---
Let $A$ be a planar area [[Boundedness|bounded]] by a contour $C$ in the $x$-$y$ plane ($z=0$).

>[!thm] Theorem
>Green's Theorem states that if $p(x,y)$ and $q(x,y)$ are both [[Differentiability|differentiable]] scalar fields defined on $S$, then $$\oint_{C}p \ \text{d}x + q \ \text{d}y = \iint \left(\frac{\partial q}{\partial x}- \frac{\partial p}{\partial y}\right)\ \text{d}x \ \text{d}y $$

PROOF:
see [[Stokes' Theorem]].
