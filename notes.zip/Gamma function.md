---
tags:
  - MT3507
aliases:
---
> [!def] Definition
> The gamma function is defined as
> $$\Gamma(\alpha) = \int_{0}^{\infty} y^{\alpha-1}e^{-}y$$

> [!thm]- $\Gamma(\alpha+1) = \alpha \Gamma (\alpha)$, for $\alpha>0$

> [!thm]- $\Gamma(1) = 1$

> [!thm]- $\Gamma(n) = (n-1)!$, for $n \in \mathbb N$
