---
tags:
  - MT3508
aliases:
---
> [!def] The problem
> The mark-recapture method is used to estimate the abundance of populations of wild animals.
> 1. Capture and mark some wild animals.
> 2. Release them back into the population.
> 3. Capture a second sample of animals.
> 4. Do statistical analysis on the percentage of marked animals in the second sample.
> 
> ![[caprecap_att.png]]

> [!gen] Model 1
> The method splits the population $N$ into four kinds:
> A. Those caught only on the first occasion.
> B. Those caught only on the second occasion.
> C. Those caught on both occasions.
> D. Those not caught on either occasion.
> 
> A [[multinomial distribution]] is used:
> $$f(\boldsymbol{y}) = \left(\frac{N!}{y_{A}!y_{B}!y_{C}!y_{D}!}\right) p_{A}^{y_{A}} p_{B}^{y_{B}} p_{C}^{y_{C}} p_{D}^{y_{D}}$$
> where
> - $\boldsymbol{y} = (y_{A},y_{B},y_{C})$.
> - $\boldsymbol{\theta} = (N,y_{D},p_{A},p_{B},p_{C},p_{D})$.
> 
> We have a problem: we are trying to estimate 6 things from 3 bits of data and that is too much.
> Firstly, we can write $y_{D}$ in terms of $N,y_{A},y_{B},y_{C}$, so we don't need to estimate it.
> Then we need to make some assumptions.
> Let $p=\mathbb P(\text{being caught on occasion 1}) = \mathbb P(\text{being caught on occasion 2})$ such that $p_{A}= p(1-p)$, $p_{B}=(1-p)p$, $p_{C}=p^{2}$, and $p_{D}=(1-p)^{2}$.
> Our mode is then
> $$f(\boldsymbol{y}) = \left(\frac{N!}{y_{A}!y_{B}!y_{C}!(N-y_{A}-y_{B}-y_{C})!}\right) p^{y_{A}+y_{B}+2y_{C}}(1-p)^{y_{A}+y_{B}+2(N-y_{A}-y_{B}-y_{C})}$$
> where
> - $\boldsymbol{y} = (y_{A},y_{B},y_{C})$.
> - $\boldsymbol{\theta} = (N,p)$.
