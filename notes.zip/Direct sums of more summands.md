---
tags:
  - MT3501
type: def
aliases: []
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$.

>[!def] Notation
>$V=\bigoplus\limits_{i=1}^{k} U_{i}$ means $V$ is the direct sum of the [[Subspaces|subspaces]] $U_{1},U_{2},...,U_{k}$.

>[!def] Definition 1
>$V=\bigoplus\limits_{i=1}^{k} U_{i}$ if every vector in $V$ can be expressed uniquely in the form $\sum\limits_{i=1}^{k} u_{i}$ where $u_{i}\in U_{i} \;\;\forall i$.

>[!def] Definition 2
>$V=\bigoplus\limits_{i=1}^{k} U_{i}$ if and only if
>1. $V=\sum\limits_{i=1}^{k} U_{i}$
>2. $U_{i} \cap (U_{1}+\ldots+U_{i-1}+U_{i+1}+\ldots+U_{k}) =\set {\boldsymbol{0}}$

>[!thm] The two definitions above are equivalent.
>We shall show that the two requirements in definition 2 are enough to show the existence and uniqueness of the form in definition 1.
>
>Existence:
>
>Uniqueness:
>

---

#### Spaced repetition

What are the two definitions of a direct sum $V=\bigoplus\limits_{i=1}^{k} U_{i}$?
?
>Definition 1
>$V=\bigoplus\limits_{i=1}^{k} U_{i}$ if every vector in $V$ can be expressed uniquely in the form $\sum\limits_{i=1}^{k} u_{i}$ where $u_{i}\in U_{i} \;\;\forall i$.
>
>Definition 2
>$V=\bigoplus\limits_{i=1}^{k} U_{i}$ if and only if
>1. $V=\sum\limits_{i=1}^{k} U_{i}$
>2. $U_{i} \cap (U_{1}+\ldots+U_{i-1}+U_{i+1}+\ldots+U_{k}) =\set {\boldsymbol{0}}$

Prove that the two definitions for a direct sum $V=\bigoplus\limits_{i=1}^{k} U_{i}$ are equivalent.
?
>We shall show that the two requirements in definition 2 are enough to show the existence and uniqueness of the form in definition 1.
