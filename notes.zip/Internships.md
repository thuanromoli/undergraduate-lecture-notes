```
Dear Sir/Madam,

I hope you are doing well,

I am writing to express my interest in any opportunities for undergraduate research that you may be offering in Summer 2024.

I am a third year maths student at the University of St Andrews and I am based in London during vacations. I would like to pursue a Master's and PhD in maths after my Bachelor's and would love to get some experience of operating in a research-focused position.

This semester I really enjoyed the *module* module because *reason*. This in turn sparked my interest for *topic*. Recently, I came across the article *title* on the university website and read about *content*. I would be particularly keen to participate in any programs which align with my passion for this area of research.

Please find attached to this email my resume and academic transcript. If you have any openings for internships or other methods of allowing undergraduates to gain some research experience, I would be thrilled if you got in touch.

Thank you for your time,

Best wishes,

Van Thuan Romoli
```


```
Dear Sir/Madam,

I hope you are doing well,

My name is Thuan and I took your **course name** module last year. I greatly enjoyed your course, and was thrilled to have received a **grade** in such a challenging and important course for my field.

This year, I intend to apply to maths Master's programs to study statistics and probability. I am wondering if you would be willing and able to write me a good letter of recommendation for my applications?

The following is a bit about my education and research background to aid you in making your decision.

I am a direct entry student going to graduate with a BSc in maths this year and currently I average 17.4/20 across my modules. This summer, I undertook two research projects. One was with the University of Edinburgh, where I used extreme value theory and decision trees to model the snowfall in the Alps; and the other one was with Generative Alchemy, a start-up in addittive manufacturing. I used statistics to model the porosity of objects and explored how some machine learning models can be used to understand which parameters are more significant when manufacturing an object.

I have also attached my CV here for your reference.
I would be happy to set up a meeting to further discuss my interests any background if needed and provide you with any additional written materials you may need.

Thank you for your time,
Thuan
```
