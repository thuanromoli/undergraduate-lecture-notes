---
tags:
  - MT2501
  - MT3501
type: def
aliases:
  - linear transformation
  - linear transformations
---
Let $V$ and $W$ be two [[Vector spaces|vector spaces]] over the same [[Fields (Algebra)|field]] $F$ of scalars.

>[!def] Definition
>A linear transformation is a [[Functions|function]] $T:V \to W$ such that:
>- $T(u+v)=T(u)+T(v) \;\;\forall u,v \in V$
>- $T(\alpha v)=\alpha T(v) \;\;\forall v \in V \;\land\; \forall\alpha \in F$
