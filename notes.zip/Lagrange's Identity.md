---
tags:
  - MT3504
type: 
aliases:
---
Let $C^{2}(a,b)$ be the [[Inner product space of twice-differentiable functions|inner product space of twice-differentiable functions]].
Let $L$ be in [[Sturm-Liouville form]].

>[!def] Definition
>The Lagrange's Identity is
>$$\int_{a}^{b}(y_{1}L[y_{2}]-y_{2}L[y_{1}])dx= -[p(y_{1}y_{2}'-y_{2}y_{1}')]_{a}^{b}$$

>[!gen] Motivation
>The [[Sturm-Liouville form]] of the differential operator $L$ is chosen such that [[Sturm-Liouville problems|Sturm-Liouville problems]] $L[y]=\lambda w y$ have a [[Self-adjoint transformations|self-adjoint]] form.
>That is,
>$$\begin{align*}
   \int_{a}^{b}(y_{1}L[y_{2}]-y_{2}L[y_{1}])dx &= \int_{a}^{b} y_{1}(-py_{2}')'+y_{1}qy_{2}dx-\int_{a}^{b}y_{2}(-py_{1}')'+y_{2}qy_{1}dx\\
   &= \int_{a}^{b} y_{1}(-py_{2}')'dx-\int_{a}^{b}y_{2}(-py_{1}')'dx\\
   \text{by parts }&= [-y_{1}py_{2}']_{a}^{b}-\int_{a}^{b}y_{1}'py_{2}'dx-\left([-y_{2}py_{1}']_{a}^{b}-\int_{a}^{b}y_{2}'py_{1}'dx\right)\\
   &= [-y_{1}py_{2}']_{a}^{b} -[-y_{2}py_{1}']_{a}^{b}\\
   &= -[p(y_{1}y_{2}'-y_{2}y_{1}')]_{a}^{b}
   \end{align*}$$
