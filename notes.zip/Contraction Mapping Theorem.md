---
tags:
  - MT3502
aliases:
---
Let $f$ be a [[Functions|function]] on a [[Completeness|complete]] [[Metric spaces|metric space]] $(X,d)$.

> [!thm] Theorem
> If $f$ is a [[Contractions|contraction]], then $f$ has a unique fixed point $x_{0}$, i.e. there exists exactly one $x_{0} \in X$ such that $f(x_{0})= x_{0}$.
> 
> Furthermore, for every $x \in X$, we have $d\Big(f^{n}(x),x_{0}\Big) \leqslant c^{n} \; d(x,x_{0}) \to 0 \; \text{as}\; n \to \infty$.
