---
tags:
  - MT3503
aliases:
---
Let $z$ be a [[Complex numbers|complex number]].

> [!def] Definition
> The complex logarithm on a suitable cut plane using a branch cut starting at the branch point $z = 0$ and a suitable choice of argument is defined as
> $$\log z = \log |z| + i \arg z.$$

> [!thm] Theorem
> The complex logarithm $\log z$ is [[Holomorphic functions|holomorphic]] on $\mathbb C_{\text{cut}}$ with derivative
> $$\frac{d}{dz}(\log z) = \frac{1}{z}.$$
