---
tags:
  - MT4527
aliases:
---
Let $(X_{t})_{t \in \mathbb Z}$ be a [[Stochastic processes|stochastic process]].

> [!def] Definition
> The lag-1 difference operator $\nabla$ is defined by
> $$\nabla X_{t} = X_{t}-X_{t-1} = (1-B)X_{t}$$
> where $B$ is the backward shift operator
> $$BX_{t} = X_{t-1}.$$

Powers of these operators are defined in the obvious way
$$B^{j}X_{t} = X_{t-j} \qquad \text{and} \qquad \nabla ^{j}X_{t} = \nabla (\nabla ^{j-1}X_{t}) = (1-B)^{j}X_{t}$$
for $j = 1,2,...$ with $B^{0}X_{t}=X_{t}$.
