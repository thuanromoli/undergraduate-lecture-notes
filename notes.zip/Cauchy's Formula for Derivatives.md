---
tags:
  - MT3503
aliases:
---
Let $\gamma:[a,b] \to \mathbb C$ be a positively oriented [[Contours|contour]] and let $f: U \to \mathbb C$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] defined on an [[Open sets|open subset]] $U$ such that $\gamma^{*} \cup I(\gamma) \subset U$.

> [!thm] Theorem
> Let $a \in I(\gamma)$ be a point.
> Suppose that $f$ is [[Holomorphic functions|holomorphic]] on $U$. Then, for any natural number $n$, $f$ has an $n$th derivative $f^{(n)}$ on $U$ given by
> $$f^{(n)}(a) = \frac{n!}{2 \pi i}  \int_{\gamma}^{}\frac{f(z)}{(z-a)^{n+1}}\;dz.$$

Proof:
We proceed by induction on $n$.
The case $n=0$ is [[Cauchy's Integral Formula]].
Assume that for $n \geqslant 1$, $f^{(n-1)}$ exists on $U$ and is given by the formula $f^{(n-1)}(a) = \frac{(n-1)!}{2 \pi i}  \int_{\gamma}^{}\frac{f(z)}{(z-a)^{n}}\;dz$ in the statement.
We want to show that $f^{(n)}$ exists.
If $a \in I(\gamma)$, then when $h$ is small enough, $a+h \in  I(\gamma)$, so write
$$\begin{align*}
E(h) &= \frac{f^{(n-1)}(a+h)-f^{(n-1)}(a)}{h}-\frac{n!}{2 \pi i}  \int_{\gamma}^{}\frac{f(z)}{(z-a)^{n+1}}\;dz\\
&= \frac{1}{h}\left(\frac{(n-1)!}{2 \pi i}  \int_{\gamma}^{}\frac{f(z)}{(z-a +h)^{n}}\;dz -\frac{(n-1)!}{2 \pi i}  \int_{\gamma}^{}\frac{f(z)}{(z-a )^{n}}\;dz\right) - \frac{1}{h}\frac{(n-1)!}{2 \pi i}  \int_{\gamma}^{}nh\frac{f(z)}{(z-a)^{n+1}}\;dz\\
&= \frac{(n-1)!}{2 \pi i h} \int_{\gamma}^{} f(z) \left(\frac{1}{(z-a+h)^{n}} - \frac{1}{(z-a)^{n}}- \frac{nh}{(z-a)^{n+1}}\right)dz.
\end{align*}$$
Choose $r$ such that the positively oriented circular contour $\gamma_{r}$ of radius $2r$ about $a$ is contained in the interior of $\gamma$.
Assume $|h|<r$. Then, by the [[Deformation Theorem]],
$$E(h) = \frac{(n-1)!}{2 \pi i h} \int_{\gamma_{r}}^{} f(z) \left(\frac{1}{(z-a+h)^{n}} - \frac{1}{(z-a)^{n}}- \frac{nh}{(z-a)^{n+1}}\right)dz$$
We wish to express each fraction as an integral.

Consider the line segment from $a$ to $a+h$, and by noting that
$$\frac{d}{dw}\left(\frac{1}{(z-w)^{n}}\right)=\frac{n}{(z-w)^{n+1}},$$
we apply [[The Fundamental Theorem of Calculus]] to obtain
$$\int_{[a,a+h]}^{}\frac{n}{(n-w)^{n+1}}dw=\left [ \frac{1}{(z-w)^{n}}\right ]^{a+h}_{a}=\frac{1}{(z-a-h)^{n}}-\frac{1}{(z-a)^{n}}$$
for any $z$ not on the line segment $[a,a+h]$ including, for example, any $z \in \gamma^{*}_{r}$.

Now we rewrite $E(h)$ as (where I note that the $h$ in $nh$ just disappears for some reason):
$$\begin{align*}
E(h) &= \frac{(n-1)!}{2 \pi i h} \int_{\gamma_{r}}^{} f(z) \left(\int_{[a,a+h]}^{} \frac{n}{(n-w)^{n+1}}dw- \frac{n}{(z-a)^{n+1}}\right)dz\\
&= \frac{(n-1)!}{2 \pi i h} \int_{\gamma_{r}}^{} f(z) \int_{[a,a+h]}^{} \left(\frac{n}{(n-w)^{n+1}}- \frac{n}{(z-a)^{n+1}}\right)dw\;dz \\
&= \frac{(n-1)!}{2 \pi i h} \int_{\gamma_{r}}^{}n f(z) \int_{[a,a+h]}^{} \left(\frac{1}{(n-w)^{n+1}}- \frac{1}{(z-a)^{n+1}}\right)dw\;dz.
\end{align*}$$
Repeating the process, we consider the line segment $[a,w]$ and note that
$$\frac{d}{d \zeta}\left(\frac{1}{(n-\zeta)^{n+1}}\right) = \frac{n+1}{(z-\zeta)^{n+2}},$$
and after applying the FTC, we obtain
$$\int_{[a,w]}^{}\frac{n+1}{(z- \zeta)^{n+2}} d \zeta=\left [ \frac{1}{(z-\zeta)^{n+1}}\right ]^{w}_{a}=\frac{1}{(z-w)^{n+1}}-\frac{1}{(z-a)^{n+1}}$$
for any $z$ not on the line segment $[a,a+h]$ including, for example, any $z \in \gamma^{*}_{r}$.

Hence
$$\begin{align*}
E(h) &= \frac{(n-1)!}{2 \pi i h} \int_{\gamma_{r}}^{}n f(z) \int_{[a,a+h]}^{} \left(\frac{1}{(n-w)^{n+1}}- \frac{1}{(z-a)^{n+1}}\right)dw\;dz\\
&= \frac{(n-1)!}{2 \pi i h} \int_{\gamma_{r}}^{}n f(z) \int_{[a,a+h]}^{} \left(\int_{[a,w]}^{}\frac{n+1}{(z-\zeta)^{n+2}}\;d \zeta\right) dw\;dz\\
&= \frac{(n-1)!}{2 \pi i h} \int_{\gamma_{r}}^{}n(n+1)  \int_{[a,a+h]}^{} \left(\int_{[a,w]}^{}\frac{f(z)}{(z-\zeta)^{n+2}}\;d \zeta\right) dw\;dz\\
&= \frac{(n+1)!}{2 \pi i h} \int_{\gamma_{r}}^{}  \int_{[a,a+h]}^{} \int_{[a,w]}^{}\frac{f(z)}{(z-\zeta)^{n+2}}\;d \zeta\; dw\;dz.
\end{align*}$$

Note the arrangement of the variables so far declared
![[cacuhyformder_att.png|400]]
We apply the [[Crude Estimation Theorem]] to bound $E(h)$.
$f$ is [[Boundedness|bounded]] on $\gamma^{*}_{r}$ as this [[Image|image]] is a [[Closed sets and limit points|closed]] and bounded subset of $\mathbb C$, say $|f(z)| \leqslant M$ for $z \in \gamma^{*}_{r}$.
Furthermore
$$\begin{align*}
&\left|z-\zeta\right| &&\geq r\\
& L([a,w]) &&= \left|w-a\right| \leq \left|h\right|\\
& L([a,a+h]) &&= \left|h\right|
\end{align*}$$
and so
$$\begin{align*}
|E(h)| &= \left |\frac{(n+1)!}{2 \pi i h} \int_{\gamma_{r}}^{}  \int_{[a,a+h]}^{} \int_{[a,w]}^{}\frac{f(z)}{(z-\zeta)^{n+2}}\;d \zeta\; dw\;dz \right |\\
&= \frac{(n+1)!}{2 \pi |h|} \left |\int_{\gamma_{r}}^{}  \int_{[a,a+h]}^{} \int_{[a,w]}^{}\frac{f(z)}{(z-\zeta)^{n+2}}\;d \zeta\; dw\;dz \right |\\
&\leqslant \frac{(n+1)!}{2 \pi |h|} \cdot \frac{M}{r^{n+2}}\cdot L(\gamma_{r}) \cdot L([a,a+h]) \cdot L([a,w])\\
& \leqslant \frac{(n+1)!}{2 \pi |h|} \cdot \frac{M}{r^{n+2}} \cdot 4\pi r \cdot |h| \cdot |h|\\
&=  {(n+1)!} \cdot \frac{M}{r^{n+1}} \cdot 2 \cdot |h|\\
&=  2(n+1)! \cdot \frac{M}{r^{n+1}} \cdot |h|.
\end{align*}$$
So $E(h) \to 0$ as $h \to 0$, and the proof is finished.