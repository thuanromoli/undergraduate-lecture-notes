---
tags:
  - MT3504
type: mthd
aliases:
---
>[!gen] ODE
>$$x^{2}y''+axy'+by=0$$
>where $a$ and $b$ are constants.

>[!gen] Subsitution
>Let $z=\ln x$. Then
>$$\frac{dy}{dx}=\frac{dy}{dz} \frac{dz}{dx}=\left(\frac{dy}{dz}\right) \frac{1}{x}$$
>$$\frac{d^{2}y}{dx^{2}}= \frac{d}{dx} \left(\frac{1}{x}\frac{dy}{dz}\right)= -\frac{1}{x^{2}} \frac{dy}{dz} + \frac{1}{x} \frac{d}{dx}\left(\frac{dy}{dz}\right)=-\frac{1}{x^{2}} \frac{dy}{dz} + \frac{1}{x} \frac{d^{2}y}{dz^{2}} \frac{dz}{dx}$$
>$$\frac{d^{2}y}{dx^{2}}= -\frac{1}{x^{2}} \frac{dy}{dz} + \frac{1}{x^{2}} \frac{d^{2}y}{dz^{2}}$$

>[!gen] Solution
>$$x^{2}y''+axy'+by=0$$
>$$\left(\frac{d^{2}y}{dz^{2}} - \frac{dy}{dz} \right)+a \frac{dy}{dz}+by =0$$
>$$\frac{d^{2}y}{dz^{2}}+ (a-1) \frac{dy}{dz}+by =0$$
>Then this is a [[Constant coefficients homogeneous second-order ODEs]] with auxiliary equation
>$$\lambda^{2}+(a-1) \lambda+b=0$$

---

#### Spaced repetition

What is the form of a equidimensional homogeneous second-order ODE?
?
>$x^{2}y''+axy'+by=0$ where $a$ and $b$ are constants.

How do you solve $x^{2}y''+axy'+by=0$?
?
>using substitution $z= \ln x$, and differentiating to find $dy/dx$
>$x^{2}y''+axy'+by=0$
>$\left(\frac{d^{2}y}{dz^{2}} - \frac{dy}{dz} \right)+a \frac{dy}{dz}+by =0$
>$\frac{d^{2}y}{dz^{2}}+ (a-1) \frac{dy}{dz}+by =0$
>Then this is a [[Constant coefficients homogeneous second-order ODEs]] with auxiliary equation
>$$\lambda^{2}+(a-1) \lambda+b=0$$

