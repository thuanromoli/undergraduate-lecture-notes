---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is called a moving average process of order 1 if there exists a [[White noise|white noise]] $(\varepsilon_{t})_{t \in \mathbb Z}$ and a real number $\theta \in \mathbb R$ such that for all $t \in \mathbb Z$,
> $$X_{t}=\varepsilon_{t}+ \theta \varepsilon_{t-1}.$$
> 
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is a moving average of order 1 with mean $\mu$ if $X_{t}-\mu$ is a MA(1) process.

> [!thm] Properties
> - $(X_{t})_{t \in \mathbb Z}$ is [[Stationarity|weakly stationary]].
> - $(X_{t})_{t \in \mathbb Z}$ is invertible if and only if $|\theta|<1$.
> - $$\gamma_X (h) = \left\{ \begin{array}{ll}
(1+\theta^2)\sigma^2_{\varepsilon} & \quad h=0 \\
\theta \sigma^2_{\varepsilon} & \quad |h|=1 \\
0 & \quad \mbox{otherwise}.
\end{array} \right.$$
> - $$\rho_X (h) = \left\{ \begin{array}{ll}
1 & \quad h=0 \\
\frac{\theta}{(1+\theta^2)}  & \quad |h|=1 \\
 0 & \quad \mbox{otherwise}.
\end{array} \right.$$
> - $$\alpha_X (h) = (-1)^{h-1} \frac{\theta^h}{1+\theta^2 +... + \theta^{2h}}.$$

> [!gen] Remarks
> - The ACF vanishes from lag 2 on.
> - The PACF decays gradually.
> - The ACF at lag 1 is between -0.5 and 0.5.

![[ma1_att.png]]
