---
tags: 
aliases:
---
Let $\mathcal D$ be a [[Dissections|dissection]] of the [[Closed sets and limit points|closed]] interval $[a,b]$.

> [!def] Definition
> The mesh of the dissection is the maximum length of the intervals formed by the dissection. That is,
> $$\text{mesh } = \max_{1 \leqslant i \leqslant n} \set{a_{i}-a_{i-1}}.$$
