---
type: def
tag: MT2505
alias: [distributive]
---
Let $A$ be a set and $(*,\circ)$ be [[Binary operations|binary operations]] on $A$.

>[!def] Left distributivity
>$*$ is left-distributive over $\circ$ if $a*(b\circ c)=(a * b) \circ ( a * c) \ \ \forall a,b,c \in A$.

>[!def] Right distributivity
>$*$ is right-distributive over $\circ$ if $(a\circ b) * c = (a*c) \circ (b * c) \ \ \forall a,b,c \in A$.

If the binary operation $*$ is both left and right distributive then it's distributive.