---
tags:
  - MT3503
aliases:
  - curve
---
> [!def] Definition
> A curve is a [[Continuity|continuous]] [[Functions|function]]
> $$\gamma: [a,b] \to \mathbb C$$
> defined on some closed interval $[a,b] \in \mathbb R$. We write
> $$\gamma^{*} = \set{\gamma(t): t \in [a,b]}$$
> for the image of the curve (that is, the actual subset of $\mathbb C$ that is traced as one follows the curve).

> [!def] Smooth curves
> A curve $\gamma: [a,b] \to \mathbb C$ is smooth if $\gamma$ is [[Differentiability|differentiable]] and the derivative $\gamma'$ is continuous.

> [!gen] Remarks
> 1. At $a$ and $b$, the derivatives of $\gamma$ are one-sided.
> 2. We can write $\gamma(t) = x(t)+iy(t)$ where $x,y:[a,b] \to \mathbb R$ are continuous real-valued functions.
> 3. $\gamma$ is smooth if and only if $x$ and $y$ are differentiable with continuous derivatives.

> [!def] Piecewise smooth curves
> A curve $\gamma: [a,b] \to \mathbb C$ is piecewise smooth if there are real numbers
> $$a = a_{0} < a_{1} < a_{2} < \ldots < a_{n} = b$$
> such that $\gamma:[a_{i}:a_{i+1}] \to \mathbb C$ is a smooth curve for $i = 0,1,...,n-1$

> [!def] Closed curves
> A curve $\gamma: [a,b] \to \mathbb C$ is closed if $\gamma(a) = \gamma(b)$.

> [!def] Simple curves
> A curve $\gamma: [a,b] \to \mathbb C$ is simple if whenever $a \leqslant t_{1} <t_{2} \leqslant b$ (except for $t_{1}=a$ and $t_{2}= b)$ then necessarily $\gamma(t_{1}) \neq \gamma(t_{2})$.

> [!gen] Remarks
> - A piecewise smooth curve is one obtained by gluing together finitely many smooth curves.
> - A closed curve is one which finishes where it starts.
> - A simple curve is one which has no crossings, except possibly the start and the end coincide (that is, simple curve are permitted to be closed).
