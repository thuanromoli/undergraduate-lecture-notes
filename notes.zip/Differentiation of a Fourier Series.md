---
tags:
  - MT3504
type: 
aliases:
---
Let $f(x)$ be a [[Functions|function]] and $S(x)$ be its [[Fourier Series]].

>[!thm] Theorem
>- If $f(x)$ is discontinuous, then we can't find a Fourier Series for $f'(x)$.
>- If $f(x)$ is [[Continuity|continuous]] and $f'(x)$ has finitely many discontinuities, $f'(x)$ has a Fourier series which can be obtained by term-by-term differentiation of $S(x)$.
>
>In this case $S'(x)=\sum\limits_{n=-\infty}^{\infty}\underbrace{c_{n} \frac{in\pi}{l}}_{\tilde c}\;\;e^{\frac{i n \pi x}l}$
