---
tags:
  - MT3504
type: def
aliases:
  - complimentary function
  - particular integral
  - general solutions of a second-order ODE
---
>[!def] Definition
>The general solution to the linear equation $L[y]=g$ is given by
>$$y=y_{CF}+y_{PI}$$
>where
>- $y_{CF}=C_{1}y_{1}+C_{2}y_{2}$ is the complimentary function, a [[Linear combinations|linear combination]] of any two [[Linear independence|linearly independent]] solutions $y_{1},y_{2}$ to the [[Homogeneous and inhomogeneous Second-Order ODEs|homogeneous]] equation $L[y]=0$.
>- $y_{PI}$ is a particular integral, any solution to the inhomogeneous equation $L[y]=g$
>
>In fact $L[y_{CF}+y_{PI}]=L[y_{CF}]+L[y_{PI}]=0+g=g$

---

#### Spaced repetition

What is the general solution to $L[y]=g$, explain all terms.
?
>The general solution to the linear equation $L[y]=g$ is given by
>$$y=y_{CF}+y_{PI}$$
>where
>- $y_{CF}=C_{1}y_{1}+C_{2}y_{2}$ is the complimentary function, a [[Linear combinations|linear combination]] of any two [[Linear independence|linearly independent]] solutions $y_{1},y_{2}$ to the [[Homogeneous and inhomogeneous Second-Order ODEs|homogeneous]] equation $L[y]=0$.
>- $y_{PI}$ is a particular integral, any solution to the inhomogeneous equation $L[y]=g$
>  
>In fact $L[y_{CF}+y_{PI}]=L[y_{CF}]+L[y_{PI}]=0+g=g$
