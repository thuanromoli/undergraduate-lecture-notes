---
tags:
  - MT3504
type: mthd
aliases:
---
>[!gen] ODE
>$$L[y]=a_{2}y''+a_{1}y'+a_{0}y=g(x)$$
>on $a \leqslant x \leqslant b$ such that $y(a)=0$ and $y(b)=0$

>[!gen] Solution
>Step 1.
>Using the [[Green's function]], we know that $L[G(x,s)]=\delta(x-s)$.
>Find the solutions to the [[Homogeneous and inhomogeneous Second-Order ODEs|homogeneous]] problem $L[y]=0$. Suppose these are $u_{1}$ and $u_{2}$.
>Then the general solution is $y=Cu_{1}+Du_{2}$.
>Use the [[Boundary conditions|boundary conditions]] $y(a)=0$ to find $C$ in terms of $D$ and adapt $y_{1}$ such that $y_{1}(a)=0$.
>Use the [[Boundary conditions|boundary conditions]] $y(b)=0$ to find $C$ in terms of $D$ and adapt $y_{2}$ such that $y_{2}(b)=0$.
>
>Step 2.
>Set
>$$G(x,s)\begin{cases}
   A(s)y_{1}(x) & x<s \\
   B(s)y_{2}(x) & x>s
   \end{cases}$$
>to ensure that $G(x=a,s)=0$ since $y_{1}(a)=0$ and similarly for the other case.
>
>Step 3.
>Use the [[continuity]] and step discontinuity properties to solve for $A(s)$ and $B(s)$
>$$\begin{align}
   & [G]_{x=s^{-}}^{x=s^{+}}=0 \\
   &[{\partial G}/{\partial x}]_{x=s^{-}}^{x=s^{+}}=\frac{1}{a_{2}(s)}
   \end{align}$$
>
>Step 4.
>Find the solution by evaluating
>$$\begin{align}
   y(x) & =\int_{a}^{b}G(x,s)g(s)\;ds \\
   & = \int_{s=a}^{x} G(x,s)g(s)\;ds + \int_{s=x}^{b} G(x,s)g(s)\;ds \\
   & =  \int_{s=a}^{x} B(s)y_{2}(x)g(s)\;ds + \int_{s=x}^{b} A(s)y_{1}(x)g(s)\;ds
   \end{align}$$