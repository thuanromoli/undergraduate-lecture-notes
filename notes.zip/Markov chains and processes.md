---
tags:
  - MT4528
  - MT4527
type: def
aliases:
  - Markov chain
  - Markov process
---
>[!def] Markov chain (discrete-time)
>A Markov chain is a discrete-time [[Stochastic processes|stochastic process]] $\set{X_{t}:t=0,1,2,...}$ with discrete [[State spaces|state space]] $S$ such that
>$$\mathbb{P}(X_{t+1}=i_{t+1} \vert X_{t}=i_{t},...,X_{0}=i_{0})=\mathbb{P}(X_{t+1}=i_{t+1} \vert X_{t}=i_{t})$$
>for all $t=0,1,2,...$ and all $i_{0},...,i_{t+1}\in S$. Each element $s\in S$ is called a state of the Markov chain.

>[!def] Markov process (conitnuous-time)
>A Markov process is a continuous-time [[Stochastic processes|stochastic process]] $\set{X(t):t \geqslant 0}$ with discrete [[State spaces|state space]] $S$ such that
>$$\mathbb P(X(t)=i_{t}|X(u)=i_{u} \text{ for } 0 \leqslant u\leqslant s)=P(X(t)=i_{t}|X(s)=i_{s})$$
>for all $t,s \in \mathbb R_{\geqslant 0}$ and $t>s$ where $i_{l}$ represents a state the system could be at, for time $l$.

> [!thm] Markov Property
> A Markov process satisfies $\mathbb E(X_{t}|X_{t-1},X_{t-2},...)=\mathbb E(X_{t}|X_{t-1})$.

