---
tags:
  - MT3502
aliases:
  - dissection
  - partition
---
> [!def] Definition
> A dissection or partition $\mathcal D$ of a [[Closed sets and limit points|closed]] interval $[a,b]$ is a set of numbers
> $$a = a_{0} < a_{1} < a_{2} < \ldots < a_{n-1} < a_{n} = b.$$
> The numbers $\set{a_{i}: i = 0,1,...,n}$ are called the points of dissection of $[a,b]$.
