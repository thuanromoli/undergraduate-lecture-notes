---
tags:
  - MT3503
aliases:
---
> [!def] Definition
> Laplace's equation is given by
> $$\nabla^{2}f = 0$$
> Laplace's equation is the [[Homogeneous and inhomogeneous Second-Order ODEs|homogeneous]] case of [[Poisson's equation]].

>[!gen] PDE in plane polar coordinates
> $$\frac{1}{r} \frac{\partial }{\partial r}\left(r \frac{\partial u}{\partial r}\right)+ \frac{1}{r^{2}} \frac{\partial ^{2}u}{\partial \theta^{2}}=0.$$

>[!gen] Solution TO DOOOO
