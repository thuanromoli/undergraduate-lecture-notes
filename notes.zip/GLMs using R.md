---
tags:
  - MT3508
aliases:
---
Let $Y$ be an outcome and $X$ be a vector of explanatory variables, and suppose we have the following data:

|                  | $X_{1}$                      | $X_{2}$                      | $\ldots$ | $X_{n}$                      |
| ---------------- | ---------------------------- | ---------------------------- | -------- | ---------------------------- |
| $\boldsymbol{Y}$ | $\boldsymbol{Y} \vert X_{1}$ | $\boldsymbol{Y} \vert X_{2}$ | $\ldots$ | $\boldsymbol{Y} \vert X_{n}$ |

where $\boldsymbol{Y}|X_{i} = (y_{1}|x_{i},\; y_{2}|x_{i},\ldots)$, a vector of all observations given an explanatory variable.

Firstly, we import the dataset in `R`:
```R
> mydata <- load('./a/path.Rdata')
> explanatory.variables <- c(X_1, X_2, ..., X_n)
```

#### `glm`

```R
> fitmodel <- glm(y ~ explanatory.variables, family = myfamily, data = mydata)
```

```R
family = binomial(link = "logit")
family = gaussian(link = "identity")
family = Gamma(link = "inverse")
family = poisson(link = "log")
```

Use `?family` for all links functions that are allowed in `R`.

#### `summary`

```R
> summary(fitmodel)

Call:
	glm(formula = y ~ explanatory.variables, family = myfamily, data = mydata)

Coefficients:
	        Estimate   Std. Error  t value   Pr(>|t|)
(Intercept)   beta_0        [...]    [...]     [...]
X_1           beta_1        [...]    [...]     [...]
X_2           beta_2        [...]    [...]     [...]
...
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

(Dispersion parameter for myfamily taken to be [...])

	Null deviance: [...] on [...] degrees of freedom
Residual deviance: [...] on [...] degrees of freedom
AIC: [...]

Number of Fisher Scoring iterations: [...]
```

- The `Number of Fisher Scoring iterations` is the number of times the numerical method iterates. This will be lower in [[Generalised linear models|GLM]] compared to [[Optim]] due to optimisations.
- The `Estimate` in `Coefficients` are the coefficients used by $\boldsymbol{\beta}^{T} = (\beta_{0},\beta_{1}, \ldots, \beta_{n})$ to obtain the linear predictor $\eta = \boldsymbol{x}\boldsymbol{\beta} = x_{0}\beta_{0}+x_{1}\beta_{1}+\cdots+x_{n}\beta_{n}$. This is in turn used to obtain the mean $\mu = g^{-1}(\eta)$.
- The `Std. Error` in `Coefficients` is the [[Standard error|standard error]] of the estimates. They differ from Optim as the latter uses numerical methods, while GLM uses analytical ones.
- The `Dispersion parameter` is the value of $\varphi$ (in Gaussian GLMs this would be the conditional variance $\sigma^{2}= \text{Var }(Y|X)$, see [[Properties of exponential dispersion families|here]]). Optim will use the variance of the MLE while GLMs will report an unbiased estimator (difference divisors).
