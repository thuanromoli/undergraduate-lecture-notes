---
tags:
  - MT4528
type: 
aliases:
---
Let $\set{X(t):t \geqslant 0}$ be a [[Birth and death processes|Birth/death process]].

>[!thm] Theorem
>The Kolmogorov forward equations give the time-derivative of the [[State occupation distribution|state occupation distribution]] vector, with components $u_{j}=u_{j}(t)=\mathbb P(X(t)=j)$
>$$\frac{d}{dt} u_{n}=\begin{cases}
   \lambda_{n-1}u_{n-1}-(\lambda_{n}+\mu_{n})u_{n}+\mu_{n+1}u_{n+1} & \text{for }n \geqslant 1 \\
   -\lambda_{0}u_{0}+\mu_{1}u_{1} & \text{for } n=0
   \end{cases}$$

Proof when $n \geqslant 1$
By [[The Law of Total Probability]]:
$$\begin{align*}
 u_{n}(t+h) &= \mathbb P(X(t+h)=n)\\
 &= \sum\limits_{j=0}^{\infty} \mathbb P(X(t+h)=n|X(t)=j)u_{j}(t)\\
 &= \mathbb P(X(t+h)=n|X(t)=n-1)u_{n-1}(t)\\
 &\;\;+ \mathbb P(X(t+h)=n|X(t)=n)u_{n}(t)\\
 &\;\;+ \mathbb P(X(t+h)=n|X(t)=n+1)u_{n+1}(t)\\
 &\;\;+ \sum\limits_{j\in S'}^{} \mathbb P(X(t+h)=n|X(t)=j)u_{j}(t)
 \end{align*}$$
where $S'=S \setminus \set{n-1,n,n+1}$. As $h\to 0$, we have
$$u_{n}(t+h)=\lambda_{n-1}hu_{n-1}(t)+[1-(\lambda_{n}+\mu_{n})h]u_{n}(t)+\mu_{n+1}hu_{n+1}(t)+O(h)$$
This is equivalent to
$$\frac{u_{n}(t+h)-u_{n}(t)}{h} =\lambda_{n-1}u_{n-1}(t)-(\lambda_{n}+\mu_{n})u_{n}(t)+\mu_{n+1}u_{n+1}(t)+\frac{O(h)}{h}$$
Taking the limit $h\to 0$, we obtain
$$\frac{d}{dt}u_{n}(t)=\lambda_{n-1}u_{n-1}(t)-(\lambda_{n}+\mu_{n})u_{n}(t)+\mu_{n+1}u_{n+1}(t)$$

Proof when $n=0$:
By [[The Law of Total Probability]]:
$$\begin{align*}
 u_{0}(t+h) &= \mathbb P(X(t+h)=0)\\
 &= \sum\limits_{j=0}^{\infty} \mathbb P(X(t+h)=0|X(t)=j)u_{j}(t)\\
 &= \mathbb P(X(t+h)=0|X(t)=0)u_{0}(t)\\
 &\;\;+ \mathbb P(X(t+h)=0|X(t)=1)u_{1}(t)\\
 &\;\;+ \sum\limits_{j\in S'}^{} \mathbb P(X(t+h)=0|X(t)=j)u_{j}(t)
 \end{align*}$$
where $S'=S \setminus \set{0,1}$. As $h\to 0$, we have
$$u_{0}(t+h)=[1-(\lambda_{0}+\mu_{0})h]u_{0}(t)+\mu_{1}hu_{1}+O(h)$$
This is equivalent to
$$\frac{u_{0}(t+h)-u_{0}(t)}{h} =-\lambda_{0}u_{0}(t)+\mu_{1}u_{1}(t)+ \frac{O(h)}{h}$$
Taking the limit $h\to 0$, we obtain
$$\frac{d}{dt}u_{0}(t)=-\lambda_{0}u_{0}(t)+\mu_{1}u_{1}(t)$$