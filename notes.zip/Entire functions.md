---
tags:
  - MT3503
aliases:
  - entire function
---
Let $f: \mathbb C \to \mathbb C$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] defined on $\mathbb C$.

> [!def] Definition
> $f$ is entire if it is [[Holomorphic functions|holomorphic]] on the whole complex plane $\mathbb C$.
