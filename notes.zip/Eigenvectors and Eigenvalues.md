---
tags:
  - MT3501
type: def
aliases:
  - eigenvector
  - eigenvectors
  - eigenvalue
  - eigenvalues
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $T:V\to V$ be a [[Linear transformations|linear transformation]].

>[!def] Definition
>A non-zero vector $v\in V$ is an eigenvector for $T$ with eigenvalue $\lambda \in F$ if
>$$T(v)= \lambda v$$
