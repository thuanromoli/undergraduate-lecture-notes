---
tag: MT2505
type: def
alias: coset
---
Let $G$ be a [[Groups|group]] and $H$ be a [[Subgroups]] of $G$ and $x\in G$.

> [!def] Right coset
> The right coset of $H$ with representative $x$ is the following subset of $G$: $$Hx=\set{hx:h\in H}$$that is, $Hx$ consists of all the products $hx$ as $h$ ranges over all elements of $H$.

> [!def] Left coset
> The left coset of $H$ with representative $x$ is the following subset of $G$: $$xH=\set{xh:h\in H}$$that is, $xH$ consists of all the products $xh$ as $h$ ranges over all elements of $H$.
