---
tags:
  - MT4531
aliases:
---
Let $\theta$ be a parameter and $\boldsymbol{x}$ be the data.

> [!def] Definition
> Jeffreys' prior is given by
> $$p(\theta)\propto \sqrt{I(\theta|\boldsymbol{x})}$$
> where $I(\theta|\boldsymbol{x})$ is the [[Fisher information]]
> $$I(\theta|\boldsymbol{x}) = \mathbb E\left[\left(\frac{d }{d \theta}\log f(\boldsymbol{x}|\theta)\right)^{2}\;\right] =^{*} -  \mathbb E\left[\frac{d^{2} }{d \theta^{2}}\log f(\boldsymbol{x}|\theta)\;\right]$$
> $^{*}$ under certain regularity conditions.

> [!thm]- Suppose that $p(\theta)\propto \sqrt{I(\theta|\boldsymbol{x})}$ and that $\phi = h(\theta)$ is a bijective transformation of $\theta$. Then $p(\phi)\propto \sqrt{I(\phi|\boldsymbol{x})}$
> Using [[Distribution of functions of rvs (univariate)|this theorem]], and noting that $\theta=h^{-1}(\phi)$, we observe that
> $$f_\Phi(\phi)=f_\Theta(\theta)\left|\frac{d}{d \phi} \theta \right|=f_\Theta(h^{-1}(\phi))\left|\frac{d}{d \phi} \theta \right|$$
> Now note that
> $$\begin{align*}
   I(\theta|\boldsymbol{x}) &= \mathbb E\left[\left(\frac{d }{d \theta}\log f(\boldsymbol{x}|\theta)\right)^{2}\;\right] \\
   &= \mathbb E\left[\left(\frac{d }{d \theta}\log f(\boldsymbol{x}|h^{-1}(\phi))\right)^{2}\;\right] \\
   &= \mathbb E\left[\left(\frac{d }{d \phi}\log f(\boldsymbol{x}|\phi) \times \frac{d \phi}{d \theta}\right)^{2}\;\right], \quad \text{as }h \text{ is bijective} \\
   &= \left|\frac{d \phi}{d \theta} \right|^{2} \mathbb E\left[\left(\frac{d }{d \phi}\log f(\boldsymbol{x}|\phi)\right)^{2}\right]\\
   &= I(\phi|\boldsymbol{x}) \left|\frac{d \phi}{d \theta} \right|^{2}.
   \end{align*}$$
> Now, putting this together,
> $$\begin{align*}
   f_\Theta(h^{-1}(\phi)) &\propto \sqrt{I(h^{-1}(\phi)|\boldsymbol{x})}\\
   &= \sqrt{I(\phi|\boldsymbol{x})}\left| \frac{d \phi}{d \theta} \right|
   \end{align*}$$
> Hence,
> $$p(\phi)=f_\Phi(\phi)\propto\sqrt{I(\phi|\boldsymbol{x})} \left| \frac{d \phi}{d \theta} \right| \times \left| \frac{d \phi}{d \theta} \right| = \sqrt{I(\phi|\boldsymbol{x})}.$$

> [!thm] If we have $n$ independent observations $\boldsymbol{x}=\set{x_{1},...,x_{n}}$ generated from the same distribution $f$, then $I(\theta|\boldsymbol{x})=nI(\theta|x)$

> [!gen] Remarks
> - Jeffreys' prior does not satisfy the likelihood principle.
> - Jeffreys' prior need not satisfy the honesty condition, as long as the posterior does.
