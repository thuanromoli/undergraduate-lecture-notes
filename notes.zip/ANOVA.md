---
type: model
tag: MT2508
---
>[!gen]+ MOTIVATION:
>If we have less coefficients in a multiple linear regression model, it's easier to work with hence we test whether having some coefficients as zero will make the model a lot worse.

Given a [[Multiple regression|multiple linear regression]] model $$Y_{i} \sim N(\beta_{1}+\beta_{2}x_{2i}+\ldots+\beta_{p1}x_{p1i},\sigma^{2})\ \ \text{ for } i=1,...,n$$
we are interested in a submodel in which $p_{1}-p_{0}$ of the regression coefficients $\beta_{1},...,\beta_{p1}$ are zero (i.e the model has $p_0$ coefficients).

>[!gen]+ CONDITIONS:
>see [[Checking the linear regression assumptions]]

>[!gen]+ [[Statistical hypothesis|HYPOTHESIS]]:
>$H_0$ : the specified regression coefficients are all zero  vs  $H_{1}$ : there are no restrictions on the specified regression coefficients.

>[!gen]+ INTUITION:
>The full model has more parameters, so always fits the data a little more closely than the submodel.
>However, if H0 is true, then the difference in fit between the two models should be small.
>By contrast, a big difference in fit would tend to suggest that H0 is false, and that the full model should be preferred to the submodel.

>[!gen]+ [[Test statistics|TEST STATISTIC]]:
>$$\frac{(\text{RSS}_{0}-\text{RSS}_{1})/(p_{1}-p_{0})}{(\text{RSS}_{1})/(n-p_{1})} \sim F_{p_{1}-p_{0},n-p_{1}}\;\;\;\text{under $H_{0}$}$$if $H_{0}$ is false, this test statistic will be large.
