---
type: def
tag: MT2506
---
>[!def] Definition
>The Laplacian is a vector operator s.t $\nabla \cdot \nabla =\nabla^{2}: \mathbb{R} \to \mathbb{R}^{3} \to \mathbb{R}$ and it represents a measure of 'diffusion'.

>[!gen]+ [[Cartesian coordinates]]:
>$$\nabla^2=\frac{\partial^2}{\partial x^2}+\frac{\partial^2}{\partial y^2}+\frac{\partial^2}{\partial z^2}$$
>note: when in Cartesian form it can operate on both scalar and vector fields.
