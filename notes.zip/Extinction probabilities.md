---
tags:
  - MT4528
type: def
aliases:
---
>[!def] Definition
>Define the following:
>- $A_{n}$ as the event $\set{X_{n}=0}$, that is the event that the population is extinct by generation $n$.
>- $e_{n}$ as $\mathbb P(A_{n})=\mathbb P(X_{n}=0)$, that is the probability that the population is extinct by generation $n$.
>- $A=\bigcup\limits_{j=1}^{\infty} A_{j}$, that is the event that the population eventually becomes extinct
>- $e=\mathbb P(A)$, that is the probability of extinction.
