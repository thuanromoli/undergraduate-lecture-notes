---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A stochastic process $(\varepsilon_{t})_{t \in \mathbb Z}$ is called a generalised autoregressive conditionally heteroscedastic process of order (1,1) if there exists an independent [[White noise|white noise]] $(\eta_{t})_{t \in \mathbb Z}$ of unit variance $\sigma^{2}_\eta=1$ and real numbers $\alpha_{0}>0, \alpha_{1}\geqslant 0, \beta_{1} \geqslant 0$ such that for all $t \in \mathbb Z$,
> $$\begin{align*}
   \varepsilon_{t}&=\sigma_{t} \eta_{t} \qquad\text{with}\\
   \sigma^{2}_{t} &= \alpha_{0}+\alpha_{1} \varepsilon^{2}_{t-1}+\beta_{1}\sigma^{2}_{t-1}
   \end{align*}$$
> where $\eta_{t}$ is referred to as "innovation".

> [!thm] Properties (under certain [[Stationarity of AR(p) Processes|regularity conditions]])
> - Conditional mean $$\mathbb E(\varepsilon_{t}|\varepsilon_{t-1},\varepsilon_{t-2},...)=0.$$
> - Conditional variance (requiring $\alpha_{1}+\beta_{1}<1$) $$\text{Var }(\varepsilon_{t}|\varepsilon_{t-1},\varepsilon_{t-2},...)=\sigma^{2}_{t} = \frac{\alpha_{0}}{1-\alpha_{1}-\beta_{1}}.$$
> - Kurtosis (requiring normal $\eta_{t}$, $1-2\alpha_{1}^{2}-(\alpha_{1}+\beta_{1})^{2}>0$) $$\kappa_{\varepsilon}=3 \frac{1-(\alpha_{1}+\beta_{1})^{2}}{1-2\alpha_{1}^{2}-(\alpha_{1}+\beta_{1})^{2}}>3$$

> [!gen] Remarks
> - A GARCH(1,1) process is a white noise.
> - The innovation's distribution is often specified as normal (then $\eta$ is a Gaussian white noise) or t-distributed (if heavy tails are needed).
> - Under suitable conditions, the GARCH(1,1) model can be represented in the form of an ARMA(1,1) process for $\varepsilon^{2}_{t}$. Let $\zeta_{t}= \varepsilon_{t}^{2}-\sigma^{2}_{t}$, then: $$\varepsilon^{2}_{t}= \alpha_{0}+(\alpha_{1}+ \beta_{1})\varepsilon^{2}_{t-1}+ \zeta_{t} - \beta_{1} \zeta_{t-1} \quad \text{with white noise} \quad \zeta_{t}= \varepsilon^{2}_{t}-\sigma_{t}^{2}.$$
> - GARCH(1,1) displays volatility clustering.
