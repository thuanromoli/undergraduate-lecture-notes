---
tags:
  - MT3503
aliases:
---
Let $\gamma:[a,b]  \to \mathbb C$ be a piecewise smooth [[Curves|curve]] and let $f: \gamma^{*} \to \mathbb C$ be [[Continuity|continuous]].

> [!thm] Lemma
> $$\left| \int_{\gamma}^{}f(z) \;dz \right| \leqslant \int_{a}^{b}|f(\gamma(t))\;\gamma'(t)|\;dt.$$

> [!thm] Theorem
> Suppose that $|f(z)| \leqslant M$ for all $z \in \gamma^{*}$. Then
> $$\left | \int_{\gamma}^{} f(z)\;dz \right| \leqslant M \cdot L(\gamma)$$
> where $L(\gamma)$ is the [[Length of curves|length]] of $\gamma$.

Proof:
Firstly, we prove the lemma.
Note that our integral $\int_{\gamma}^{}f(z)dz$ is just a complex number. So let $c = \int_{\gamma}^{} f(z)dz$ and write $c= |c|e^{i \theta}$ for some $\theta \in [0, 2 \pi]$. Then
$$\begin{align*}
|c| &= \text{Re }|c|\\
&= \text{Re }\Big(ce^{-i \theta}\Big)\\
&= \text{Re }\left(e^{-i \theta}\int_{\gamma}^{} f(z)dz \right)\\
&= \text{Re }\left( e^{-i \theta} \int_{a}^{b}f(\gamma(t))\; \gamma'(t)\;dt   \right)\\
&= \text{Re }\left(\int_{a}^{b} e^{-i \theta}f(\gamma(t))\; \gamma'(t)\;dt   \right)\\
&= \int_{a}^{b} \text{Re }\Big(e^{-i \theta}f(\gamma(t))\; \gamma'(t)  \Big)dt\\
&\leqslant  \int_{a}^{b} \Big|e^{-i \theta}f(\gamma(t))\; \gamma'(t)  \Big|dt\\
&=  \int_{a}^{b} \Big|f(\gamma(t))\; \gamma'(t)  \Big|dt.
\end{align*}$$

Now we suppose that $|f(z)| \leqslant M$. And note
$$\begin{align*}
|f(z)| \leqslant M &\iff |f(\gamma(t))| \leqslant  M\\
&\iff |f(\gamma(t))\gamma'(t)| \leqslant  M|\gamma'(t)|.
\end{align*}$$
Hence
$$\begin{align*}
\left | \int_{\gamma}^{} f(z)\;dz \right| &\leqslant \int_{a}^{b} \Big|f(\gamma(t))\; \gamma'(t)  \Big|dt \\
&\leqslant \int_{a}^{b} M|\gamma'(t)|dt\\
&= M \int_{a}^{b} |\gamma'(t) |dt\\
&= M \cdot L(\gamma).
\end{align*}$$
