---
type: def
tag: MT2506
---
>[!def] Definition
>The curl is a vector operator such that $\nabla \times \boldsymbol F: \mathbb{R}^{3} \to \mathbb{R}^3$ and it represents a measure of '[[Circulation|circulation]]'.

>[!gen]+ General coordinates:
>Let $\nabla = \boldsymbol e_u \frac{1}{g_u}\frac{\partial}{\partial u}+\boldsymbol e_v \frac{1}{g_v}\frac{\partial}{\partial v}+\boldsymbol e_w \frac{1}{g_w}\frac{\partial}{\partial w}$ and $\boldsymbol F = F_u\,\boldsymbol e_u+F_v\,\boldsymbol e_v+F_w\,\boldsymbol e_w$. Then
>$$\nabla\times\boldsymbol F= \boldsymbol e_u \frac{1}{g_u}\boldsymbol \times\frac{\partial\boldsymbol F}{\partial u}+\boldsymbol e_v \frac{1}{g_v}\boldsymbol \times\frac{\partial\boldsymbol F}{\partial v}+\boldsymbol e_w \frac{1}{g_w}\boldsymbol \times\frac{\partial\boldsymbol F}{\partial w}$$

>[!gen]+  [[Cartesian coordinates]]:
>$$\nabla\times\boldsymbol F=(\frac{\partial F_z}{\partial y}-\frac{\partial F_y} {\partial z})\boldsymbol i+
 (\frac{\partial F_x}{\partial z}-\frac{\partial F_z}{\partial x})\boldsymbol j+(\frac{\partial F_y}{\partial x}-\frac{\partial F_x}{\partial y})\boldsymbol k$$

---

#### Spaced repetition

What is the meaning of $\nabla \times f$ ?
?
The curl is a vector operator such that $\nabla \times \boldsymbol F: \mathbb{R}^{3} \to \mathbb{R}^3$ and it represents a measure of '[[Circulation|circulation]]'.

What is $\nabla \times f$ in general coordinates?
?
$$\nabla\times\boldsymbol F= \boldsymbol e_u \frac{1}{g_u}\boldsymbol \times\frac{\partial\boldsymbol F}{\partial u}+\boldsymbol e_v \frac{1}{g_v}\boldsymbol \times\frac{\partial\boldsymbol F}{\partial v}+\boldsymbol e_w \frac{1}{g_w}\boldsymbol \times\frac{\partial\boldsymbol F}{\partial w}$$

What is $\nabla \times f$ in Cartesian Coordinates?
?
$$\nabla\times\boldsymbol F=(\frac{\partial F_z}{\partial y}-\frac{\partial F_y} {\partial z})\boldsymbol i+

(\frac{\partial F_x}{\partial z}-\frac{\partial F_z}{\partial x})\boldsymbol j+

(\frac{\partial F_y}{\partial x}-\frac{\partial F_x}{\partial y})\boldsymbol k
$$
