---
tags:
  - MT3503
aliases:
---
Let $f: \mathbb C \to \mathbb C$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] defined on $\mathbb C$.

> [!thm] Theorem
> If $f$ is [[Boundedness|bounded]] and [[Holomorphic functions|holomorphic]], then $f$ is constant.

Proof:
Suppose that $|f(z)| \leqslant M$ for all $z \in \mathbb C$.
Fix two points $a,b \in \mathbb C$.
Now consider any radius $R$ such that $|R| \geqslant 2 \max \set{|a|,|b|}$.
Let $\gamma$ be the positively oriented [[Contours|contour]] of radius $R$ about $0$.
![[liuvthm_att.png|350]]
Since both $a$ and $b$ lie inside $\gamma$ and since $f$ is [[Entire functions|entire]], we apply [[Cauchy's Integral Formula]] to write
$$f(a) = \frac{1}{2\pi i} \int_{\gamma} \frac{f(z)}{z-a} \, \mathrm{d}z \qquad\textsf{and}\qquad f(b) = \frac{1}{2\pi i} \int_{\gamma} \frac{f(z)}{z-b} \, \mathrm{d}z.$$
Hence
$$\begin{align*}
f(a) - f(b) &= \frac{1}{2\pi i} \int_{\gamma} \left( \frac{f(z)}{z-a} - \frac{f(z)}{z-b} \right) \, \mathrm{d}z \\
&= \frac{1}{2\pi i} \int_{\gamma} \frac{f(z) \, (a-b)}{(z-a)(z-b)} \, \mathrm{d}z.
\end{align*}$$
Now if $z$ lies on the contour $\gamma$, then by the [[Triangle inequality|triangle inequalities]],
$$\begin{align*}
|z-a| &\geqslant \Big||z|-|a| \Big |\\
&=|z|-|a| && \text{as } |z|>|a|\\
&= R - |a|\\
&\geqslant  R - \frac{1}{2}R && \text{as } |a| \leqslant \frac 1 2 R \implies-|a| \geqslant -\frac{1}{2} R
\end{align*}$$
and similarly
$$|z-b| \geqslant \frac{1}{2}R.$$
We now apply the [[Crude Estimation Theorem]] with upper bound $M$, and together with the above inequalities to obtain
$$\int_{\gamma}^{}\frac{f(z)}{(z-a)(z-b)}\;dz \leqslant \frac{ML(\gamma)}{\left(\frac{1}{2}R\right)^{2}}.$$
Therefore,
$$\begin{align*}
|f(a)-f(b)| &= \frac{1}{2 \pi} \left | \int_{\gamma}^{} \frac{f(z)(a-b)}{(z-a)(z-b)}\;dz \right |\\
&= \frac{1}{2 \pi} \cdot |a-b| \cdot \left |\int_{\gamma}^{}\frac{f(z)}{(z-a)(z-b)}\;dz\;\right |\\
&\leqslant \frac{1}{2 \pi} \cdot |a-b| \cdot \frac{ML(\gamma)}{\left(\frac{1}{2}R\right)^{2}}\\
&= \frac{1}{2 \pi} \cdot |a-b| \cdot \frac{M(2 \pi R)}{\frac{1}{4}R^{2}}\\
&= 4\cdot\frac{|a-b|\cdot M}{R}.
\end{align*}$$
As $R \to \infty$, $|f(a)-f(b)| \to 0$. And we can take $R$ as big as we wish.
So we conclude the proof.