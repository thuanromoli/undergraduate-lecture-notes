---
type: mthd
tag: MT2506
---
#### Given $\iint_S\boldsymbol F(\boldsymbol r) \cdot \,\text{d}\boldsymbol S$
where $S$ is the surface area of integration, $\boldsymbol{r}(u,v)$ is the position vector defining all points on $S$, and $\boldsymbol{F}$ is the vector field, evaluate the [[General surface integral|surface integral]].

1. For the surface $f(\boldsymbol x) =f(u,v)=C$, determine $\boldsymbol r(u,v)$;
2. calculate the tangent vectors to $S$: $\boldsymbol t_u=\frac{\partial\boldsymbol{r}}{\partial u \ }$ and $\boldsymbol t_v=\frac{\partial\boldsymbol{r}}{\partial v}$;
3. find the [[Directed surface area element|directed surface area element]] $\text{d}\boldsymbol S=(\boldsymbol t_u \times \boldsymbol t_v)\text{ d}u\,\text{d}v$;
4. evaluate $\boldsymbol F(\boldsymbol r)$ on $S$;
5. take the inner product $\boldsymbol F(\boldsymbol r) \cdot\text d\boldsymbol S$;
6. integrate $\iint_S\boldsymbol F(\boldsymbol r) \cdot \,\text{d}\boldsymbol S$

#### Given $\iint_S g(\boldsymbol r) \,\text{d}S$
where $S$ is the surface area of integration, $\boldsymbol{r}(u,v)$ is the position vector defining all points on $S$, and $\boldsymbol{F}$ is the vector field, evaluate the [[General surface integral|surface integral]].

1. For the surface $f(\boldsymbol x) =f(u,v)=C$, determine $\boldsymbol r(u,v)$;
2. calculate the tangent vectors to $S$: $\boldsymbol t_u=\frac{\partial\boldsymbol{r}}{\partial u \ }$ and $\boldsymbol t_v=\frac{\partial\boldsymbol{r}}{\partial v}$;
3. find the [[Directed surface area element|directed surface area element]] $\text{d}\boldsymbol S=(\boldsymbol t_u \times \boldsymbol t_v)\text{ d}u\,\text{d}v$;
4. evaluate $\text dS=\lvert\lvert\text d \boldsymbol S\rvert\rvert$;
5. evaluate $g(\boldsymbol{r})$ on $S$;
6. integrate $\iint_S g(\boldsymbol r) \,\text{d}S$ using appropriate ranges of $u$ and $v$.

---

#### Spaced repetition

Show the algorithm to compute $$\iint_S\boldsymbol F(\boldsymbol r) \cdot \,\text{d}\boldsymbol S$$
?
1. For the surface $f(\boldsymbol x) =f(u,v)=C$, determine $\boldsymbol r(u,v)$;
2. calculate the tangent vectors to $S$: $\boldsymbol t_u=\frac{\partial\boldsymbol{r}}{\partial u \ }$ and $\boldsymbol t_v=\frac{\partial\boldsymbol{r}}{\partial v}$;
3. find the [[Directed surface area element|directed surface area element]] $\text{d}\boldsymbol S=(\boldsymbol t_u \times \boldsymbol t_v)\text{ d}u\,\text{d}v$;
4. evaluate $\boldsymbol F(\boldsymbol r)$ on $S$;
5. take the inner product $\boldsymbol F(\boldsymbol r) \cdot\text d\boldsymbol S$;
6. integrate $\iint_S\boldsymbol F(\boldsymbol r) \cdot \,\text{d}\boldsymbol S$

Show the algorithm to compute $$\iint_S g(\boldsymbol r) \,\text{d}S$$
1. For the surface $f(\boldsymbol x) =f(u,v)=C$, determine $\boldsymbol r(u,v)$;
2. calculate the tangent vectors to $S$: $\boldsymbol t_u=\frac{\partial\boldsymbol{r}}{\partial u \ }$ and $\boldsymbol t_v=\frac{\partial\boldsymbol{r}}{\partial v}$;
3. find the [[Directed surface area element|directed surface area element]] $\text{d}\boldsymbol S=(\boldsymbol t_u \times \boldsymbol t_v)\text{ d}u\,\text{d}v$;
4. evaluate $\text dS=\lvert\lvert\text d \boldsymbol S\rvert\rvert$;
5. evaluate $g(\boldsymbol{r})$ on $S$;
6. integrate $\iint_S g(\boldsymbol r) \,\text{d}S$ using appropriate ranges of $u$ and $v$.