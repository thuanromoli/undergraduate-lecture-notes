---
tags:
  - MT4528
type: def
aliases:
---
Let $X_{1},...,X_{n}$ be [[Independent events|independent]] and identically distributed [[Random variables|random variables]] with [[Probability generating functions|pgf]] $\mathcal G_{X}$. Let $N$ be a non-negative integer.

>[!def] Definition
>The compound distribution $T$ is defined by:
>$$T = 
 \begin{cases}
0  & \text{if } N=0 \\
X_{1}+\ldots+ X_{N} & \text{if } N \geqslant 1
 \end{cases}$$

>[!thm] Theorem
>If $N$ is a [[Random variables|random variable]], which is [[Independent events|independent]] of the $X_{i}$'s, then $\mathcal G_{T}(s)=\mathcal G_{N}(\mathcal G_{X}(s))$.
>
>Proof:
>$$\begin{align*}
   \mathcal G_{T}(s) &= \sum\limits_{k=0}^{\infty} s^{k}\cdot \mathbb P(T=k)\\
   &= \sum\limits_{k=0}^{\infty}s^{k}\cdot \left(\sum\limits_{n=0}^{\infty} \mathbb P(T=k | N=n)\mathbb P(N=n)\right)\\
   &= \sum\limits_{n=0}^{\infty}\left(\sum\limits_{k=0}^{\infty}\mathbb P(T=k|N=n)s^{k}\right) \mathbb P(N=n)\\
   &= \sum\limits_{n=0}^{\infty}\mathbb E(s^{T}|N=n)\mathbb P(N=n)\\
   &= \sum\limits_{n=0}^{\infty} \mathbb E(s^{X_{1}+X_{2}+\cdots+X_{N}}|N=n) \mathbb P(N=n)\\
   &= \sum\limits_{n=0}^{\infty} \mathbb E(s^{X_{1}+X_{2}+\cdots+X_{n}}) \mathbb P(N=n)\\
   &= \sum\limits_{n=0}^{\infty}(\mathbb E(s^{X_{1}})\cdot\ldots\cdot \mathbb E(S^{X_{1}})) \mathbb P(N=n)\\
   &= \sum\limits_{n=0}^{\infty} (\mathcal G_{X}(s))^{n}\mathbb P(N=n)\\
   &= \mathcal G_{N}(\mathcal G_{X}(s))
   \end{align*}$$
