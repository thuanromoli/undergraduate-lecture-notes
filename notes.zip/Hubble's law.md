---
tags:
  - MT3508
aliases:
---
> [!def] The problem
> Hubble's law states that the further away a galaxy is the faster it is moving away from us
> $$d=\frac{1}{\theta}v$$
> where $d$ is the distance, $v$ the velocity, and $\frac{1}{\theta}$ is approximately the age of the universe.
> Our aim is to infer about the age of the universe.


> [!gen] Model
> - $\boldsymbol{y} = d$ is the observed [[Random variables|random variable]].
> - $\boldsymbol{x} = v$ is the known constant.
> - $\boldsymbol{\gamma}$ (not present) is the known parameters.
> - $\boldsymbol{\theta} = \theta$ is the unknown parameter.
> 
> So the model is $f(\boldsymbol{y};\boldsymbol{\theta},\boldsymbol{x})= f(d;\theta,x)$.
