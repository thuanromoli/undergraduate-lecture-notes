---
aliases:
  - equivalence class
type: def
tags:
  - MT2505
  - MT3502
---
Let $\sim$ be an [[Equivalence relations|equivalence relation]] on a set $A$.

>[!def] Definition
>The equivalence class of $a\in A$ with respect to $\sim$ is $$[a]=\set{b\in A :a\sim b}$$that is, $[a]$ is the subset of $A$ consisting of all elements that are related to $a$ under $\sim$.
