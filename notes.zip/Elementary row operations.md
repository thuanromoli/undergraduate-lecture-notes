---
tag: MT2501
type: def
alias:
- e.r.o.s
- row-equivalent
---
Let $A$ be a $m \times n$ [[Matrices|matrix]], and let $r_{1},...,r_{m}$ be its rows.

>[!def] E.r.o.s
>Elementary row operations on $A$ are the following:
>- interchanging of two rows $r_{i},r_{j}$ ($r_{i}\leftrightarrow r_{j}, i\neq j$)
>- multiplying a row by a non-zero scalar $\lambda$ ($r_{i}\mapsto \lambda r_{i}, \lambda \neq 0$)
>- adding to one row a non-zero scalar multiple of another row ($r_{i}\mapsto r_{i} + \lambda r_{j}, i\neq j$)

>[!def] Row-equivalence
>For matrices $A$ and $B$, we say that $A$ is row equivalent to $B$ precisely if there is a sequence of e.r.o.s that transform $A$ into $B$; we write $A \sim B$

---

#### Spaced repetition
What are the elementary row operations?
?
>Elementary row operations on $A$ are the following:
>- interchanging of two rows $r_{i},r_{j}$ ($r_{i}\leftrightarrow r_{j}, i\neq j$)
>- multiplying a row by a non-zero scalar $\lambda$ ($r_{i}\mapsto \lambda r_{i}, \lambda \neq 0$)
>- adding to one row a non-zero scalar multiple of another row ($r_{i}\mapsto r_{i} + \lambda r_{j}, i\neq j$)
<!--SR:!2023-07-06,3,250-->

What does it mean for two matrices $A$ and $B$ to be row equivalent?
?
For matrices $A$ and $B$, we say that $A$ is row equivalent to $B$ precisely if there is a sequence of e.r.o.s that transform $A$ into $B$; we write $A \sim B$
