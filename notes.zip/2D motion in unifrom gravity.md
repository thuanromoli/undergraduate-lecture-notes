---
type: model
tag: MT2507
---
Consider a [[Particle (Dynamics)|particle]] of constant mass $m$ that moves in a 2D plane comprising of:
- Horizontal motion: $x$-direction
- Vertical motion: $y$ or $z$-direction

### Model without air resistance

![[2dnoairmotion_att.png|500]]

>[!gen]+ [[Position vectors|Position vector]]
>$$\boldsymbol{r}(t) = x(t) \boldsymbol{i} + z(t) \boldsymbol{k}$$

>[!gen]+ [[Equation of Motion]]
>Forces acting:
>$$\boldsymbol{F} = -mg \boldsymbol{k}$$
>Equation of motion:
>$$-mg \boldsymbol{k}  = m \frac{d^{2}\boldsymbol{r}}{dt^{2}}$$

>[!gen]+ Method to find position vector
>Equate the component of the equation of motion:
>$$\frac{d^{2}x}{dt^{2}}=0 \ \ \text{ and } \ \ \frac{d^{2}z}{dt^{2}}=-g$$


### Model with [[air resistance]]

![[2dairmotion_att.png|500]]

>[!gen]+ [[Position vectors|Position vector]]
>$$\boldsymbol{r}(t) = x(t) \boldsymbol{i} + z(t) \boldsymbol{k}$$

>[!gen]+ [[Equation of Motion]]
>Forces acting:
>$$\boldsymbol{F} = -mg \boldsymbol{k}-mk \boldsymbol{v}$$
>Equation of motion:
>$$-mg \boldsymbol{k} - mk\frac{d\boldsymbol{r}}{dt}  = m \frac{d^{2}\boldsymbol{r}}{dt^{2}}$$

>[!gen]+ Method to find position vector
>Equate the component of the equation of motion:
>$$\frac{d^{2}x}{dt^{2}}=-k \frac{dx}{dt} \ \  \text{ and } \ \ \frac{d^{2}z}{dt^{2}}=-g-k \frac{dz}{dt}$$
>$$\frac{dv_{x}}{dt}=-k v_{x} \ \ \text{ and } \ \ \frac{dv_{z}}{dt}=-g-kv_{z}$$


### Nomenclature

>[!def]+ [[Time of flight]]
>The time of flight $T$ is the time that satisfies $z(T)=0$ (when the particle touches the ground again).
>In other words, the time of flight is how long the particle stays in air.

>[!def]+ Maximum height
>The maximum height $z_{max}$ is the height $z_{max}=z(t_{max})$ where $t_{max}$ is the time that satisfies $v_{z}=0$.
>In other words, the maximum height occcurs when the vertical velocity is zero.

>[!def]+ Range
>The range $R$ is the distance $R=x(T)$ where $T$ is the time of flight.
>In other words, the range is the horizontal distance travelled by the particle while in the air.

>[!def]+ Equation of the trajectory
>The equation of the trajectory is the path of the particle $z(x)$. To find this, find $t(x)$ by inverting $x(t)$ and then find $z(t)=z(t(x))=z(x)$.

>[!def]+ Return velocity
>The return velocity is the velocity of the particle at $z=0$ (hence at $t=T$).

