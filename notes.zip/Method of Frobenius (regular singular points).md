---
tags:
  - MT3506
aliases:
---
Consider a general second order ODE $c_{2}(x)y''+c_{1}(x)y'+c_{0}y=0$ written in [[Homogeneous and inhomogeneous Second-Order ODEs|standard]] form $y''+p(x)y'+q(x)=0$.

There always exists a solution of the form
$y(x) = \sum\limits_{n=9}^{\infty} a_{n}x^{n+s}=x^{s}\sum\limits_{n=0}^{\infty}a_{n}x^{n}$.
Remarks
- Constant $s \in \mathbb R$ is the index of the series expansion
- $a_{n}$ are unknown coefficients
- we aim to obtain two linearly independent series solutions to the ODE.

General method
Step 1
Expand the coefficients $p(x)$ and $q(x)$ near the singular point.
Expand $xp(x)$ (we can as it's bounded). $xp(x) = p_{0}+xp_{1}+\cdots$
Expand $x^{2}q(x)$ (we can as it's bounded) $x^{2}q(x)=q_{0}=xq_{1}+\cdots$
So $p(x) = \sum\limits_{n=0}^{\infty}p_{n}x^{n-1}$ and $q(x) = \sum\limits_{n=0}^{\infty}q_{n}x^{n-2}$.

Step 2
Expand $y(x)$ into as a convergent series $y(x) = \sum\limits_{n=0}^{\infty}a_{n}x^{n+s}$.
Find $y'$ and $y''$.

Step 3
Sub into $y''+p(x)y'+q(x)y=0$.
Multiply by $x^{2}$ to simplify the expansions.
$$\underbrace{x^{2}y''}_{(1)}+\underbrace{xp(x)xy'}_{(2)}+\underbrace{x^{2}q(x)y}_{(3)}=0.$$
1. Expression 1: $x^{2}y''=\sum\limits_{n=0}^{\infty}(n+s)(n+s-1)a_{n}x^{n+s}$.
2. Expression 2: $$\begin{align*}
xp(x)xy'&=\left(\sum\limits_{k=0}^{\infty}p_{k}x^{k}\right)\left(\sum\limits_{j=0}^{\infty}(j+s)a_{j}x^{j+s}\right)\\
&= \sum\limits_{k=0}^{\infty}\sum\limits_{j=0}^{\infty}p_{k}(j+s)a_{j}x^{k+j+s}\\
& \text{change of variables $(k,j)\mapsto (n,m)$ where $n=k+j$ and $m=j$. That is, $k=n-m$ and $j=m$.}\\
&= \sum\limits_{n=0}^{\infty}\sum\limits_{m=0}^{\infty}p_{n-m}(m+s)a_{m}x^{n+s}\\
&= \sum\limits_{n=0}^{\infty}x^{n+s}\left(\sum\limits_{m=0}^{n}p_{n-m}(m+s)a_{m}\right)
\end{align*}$$
3. Expression 3: $x^{2}q(x)y=\sum\limits_{n=0}^{\infty}x^{n+s}\left(\sum\limits_{m=0}^{n}q_{n-m}a_{m}\right)$

Step 4
Collect powers of $x^{n+s}$.
$$\sum\limits_{n=0}^{\infty}x^{n+s}\left[(n+s)(n+s-1)a_{n}+\sum\limits_{m=0}^{n}\Big\{  p_{n-m}(m+s)+q_{n-m}\Big\}a_{m} \right]=0$$

The coefficients of $x^{s}$ $(n=0)$ yields an equation for $s$.
$s(s-1)a_{0}+\{sp_{0}+q_{0}\}a_{0}=0$ and for $a_{0}\neq 0$, we have
$$s^{2}+(p_{0}-1)s+q_{0}=0$$
That is, the indicial equation for $s$.

For $n \geqslant 1$,
$$\begin{align*}
&(n+s)(n+s-1)a_{n}+\sum\limits_{m=0}^{n}\Big\{  p_{n-m}(m+s)+q_{n-m}\Big\}a_{m}=0\\
\implies& a_{n}\Big[ (n+s)(n+s-1)+(n+s)p_{0} +q_{0} \Big] = - \sum\limits_{m=0}^{n-1}p_{n-m}(m+s)+q_{n-m}a_{m}\\
\implies& a_{n}\Big[ n^{2}+(2s-1+p_{0})n + (s^{2}+(p_{0}-1)s+q_{0}) \Big] = - \sum\limits_{m=0}^{n-1}p_{n-m}(m+s)+q_{n-m}a_{m}\\
\implies& a_{n}\Big[ n^{2}+(2s-1+p_{0})n +0\Big] = - \sum\limits_{m=0}^{n-1}p_{n-m}(m+s)+q_{n-m}a_{m}\\
\implies& a_{n} = -\frac{\sum\limits_{m=0}^{n-1}p_{n-m}(m+s)+q_{n-m}a_{m}}{ n(n+2s-1+p_{0})}.
\end{align*}$$

Things that go wrong: denominator could be zero.
Denote the two solutions as $s_{1}$ and $s_{2}$ (wlog $s_{2} \leqslant s_{1}$).
$$s_{1,2}=\frac{(1-p_{0})\pm \sqrt{(p_{0}-1)^{2}-4q_{0}}}{2}$$
$2s_{1}=(1-p_{0})+\sqrt{\Delta}$
$2s_{2}=(1-p_{0})-\sqrt{\Delta}$
$(s_{1}+s_{2})=(1-p_{0})$.
Consider denominator of $a_{n}$.
$n+2s-1+p_{0}$.

For one solution is always non-zero, for the other might be zero.
$s_{1}$: $n+2s_{1}-1+p_{0}>0$ (check) so denominator is always non zero.
$$y(x) = \sum\limits_{n=0}^{\infty}a_{n}x^{n+s_{1}}+\sum\limits_{n=0}^{\infty}b_{n}x^{n+s_{2}}$$
The first solution always exists.

$s_{2}$: $n+2s_{2}-1+p_{0}=\underbrace{n}_{>0} + \underbrace{s_{2}-s_{1}}_{<0}$.
The possibility arises that $s_{2}-s_{1} \in \mathbb Z$, in which case we must have a zero denominator. And the recurrence relation becomes undetermined at $n= s_{2}-s_{1}$.
So to find a root we must go through more work.

Suppose $s_{2}-s_{1}=N \in \mathbb Z$.
$y_{2}(x) = \log (x) \sum\limits_{n=0}^{\infty}a_{n}x^{n+s_{1}}+\sum\limits_{n=0}^{\infty}b_{n}x^{n+s_{2}}$.
