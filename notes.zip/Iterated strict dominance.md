---
tags:
  - MT4554
type: def
aliases:
  - ISD
---
>[!gen] Motivation
>A [[Rationality|rational]] player will not use a [[strictly dominated strategy]].
>This solution concept will iterate and remove all the dominated strategies.

>[!def] Iteration over pure strategies
>Set $S_{i}^{0} \equiv S_{i}$ and $\Sigma_{i}^{0} \equiv \Sigma_{i}$. We define $S_{i}^{n}$ via the recurrence relation
>$$S_{i}^{n}=\set{s_{i}\in S_{i}^{n-1}: \nexists \sigma_{i}\in \Sigma_{i}^{n-1} \text{ s.t. } u_{i}(\sigma_{i},s_{-i}) > u_{i}(s_{i},s_{-i}) \;\;\forall s_{-i} \in S_{-i}^{n-1}}$$

>[!def] Iteration over mixed strategies
>Set $S_{i}^{0} \equiv S_{i}$ and $\Sigma_{i}^{0} \equiv \Sigma_{i}$. We define $\Sigma_{i}^{n}$ via the recurrence relation
>$$\Sigma_{i}^{n}=\set{\sigma_{i}\in \Sigma_{i}:\sigma(s_{i})>0 \text{ only if } s_{i}\in S_{i}^{n}}$$

>[!def] Set of all not strictly dominated pure strategies
>$S_{i}^{\infty}=\bigcap\limits_{n=0}^{\infty} S_{i}^{n}$

>[!def] Set of all not strictly dominated mixed strategies
>$\Sigma_{i}^{\infty}=\bigcap\limits_{n=0}^{\infty} \Sigma_{i}^{n}$, with the additional condition that this set excludes any mixed strategies $\sigma_{i}$ for which there exists another strategy $\sigma_{i}'$ such that $u_{i}(\sigma_{i}',s_{-i}) > u_{i}(\sigma_{i},s_{-i}), \;\;\forall s_{-i} \in S_{-i}^{\infty}$.
>It is necessary to specify this final condition since mixed strategies can be dominated even when the pure strategies they are comprised of are not.

>[!def] Solution
>A game is solvable by iterated strict dominance if, for each player $i$, $S_{i}^{\infty}$ is a one element set.
