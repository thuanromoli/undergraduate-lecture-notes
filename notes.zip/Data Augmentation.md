---
tags:
  - MT4531
aliases:
---
Let $\boldsymbol{x}$ denote the observed data and $\boldsymbol{y}$ the unobserved (or missing or predictive) data.

We treat the missing data (or auxiliary variables) as additional parameters to be estimated.

Prediction can be seen in the framework of missing data - the values we wish to predict are simply missing values! These missing values are treated as auxiliary variables and the joint posterior distribution formed over the model parameters and auxiliary variables.

> [!gen] Algorithm
> 1. Evaluate $\pi(\boldsymbol{\theta}, \boldsymbol{y}|\boldsymbol{x}) \propto f(\boldsymbol{x},\boldsymbol{y},\boldsymbol{\theta})\propto f(\boldsymbol{x},\boldsymbol{y}|\boldsymbol{\theta})p(\boldsymbol{\theta})$.
> 2. We are interested in $\pi(\boldsymbol{\theta}|\boldsymbol{x})$ so we use $\pi(\boldsymbol{\theta}|\boldsymbol{x})= \int\pi(\boldsymbol{\theta}, \boldsymbol{y}|\boldsymbol{x})d \boldsymbol{y}$.
