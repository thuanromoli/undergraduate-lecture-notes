---
type: def
tag: MT2505
---
Let $a,b\in \mathbb{Z}$.

>[!def] Definition
>$a$ _divides_ $b$ or $b$ is a _divisor_ of $a$ if $b=ka$ for some $k\in \mathbb{Z}$. Notation: $a\mid b$
