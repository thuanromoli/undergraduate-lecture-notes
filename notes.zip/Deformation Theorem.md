---
tags:
  - MT3503
aliases:
---
Let $U$ be an [[Open sets|open set]] and $\gamma$ be a positively oriented [[Contours|contour]] such that $\gamma^{*}\cup I(\gamma) \subset U$.

> [!thm] Theorem
> Let $a \in I(\gamma)$ be a point and $\gamma_{1}$ be a positively oriented circular contour, centred at $a$, such that $\gamma_{1}^{*}\cup I(\gamma_{1}) \subset I(\gamma)$.
> Suppose that $f$ is [[Holomorphic functions|holomorphic]] on $U \setminus \set{a}$. Then
> $$\int_{\gamma}^{}f(z)\;dz = \int_{\gamma_{1}}^{}f(z)\;dz.$$
> ![[deformthm_att.png]]

Proof:
Pick two points $w$ and $z$ on the contour $\gamma$.
Pick two points $u$ and $v$ on the contour $\gamma_{1}$ in such a way that we can join $w$ to $u$ by a curve $\gamma_{2}$ and $z$ to $v$ by a curve $\gamma_{3}$ that do not cross. Complete the rest as shown.
![[deformthmproof_att.png|300]]
Write $\delta_{1}$ for the contour $\gamma_{3} \to \overleftarrow \gamma_{7} \to \overleftarrow \gamma_{2} \to \gamma_{5}$.
Write $\gamma_{2}$ for the contour $\gamma_{2} \to \overleftarrow \gamma_{6} \to \overleftarrow \gamma_{3} \to \gamma_{4}$.
Note that, by construction, $a$ does not lie in the interior of $\delta_{1}$ or $\delta_{2}$ (so that $\delta_{i}^{*}\cup I(\delta_{i}) \subset U\setminus \set{a}$).
Since $f$ is holomorphic on $U \setminus \set{a}$, we can apply [[Cauchy's Theorem]] to conclude
$$\int_{\delta_{1}}^{}f(z)\;dz = \int_{\delta_{2}}^{}f(z)\;dz=0.$$
Hence
$$\begin{multline*}
\int_{\gamma_{3}} f(z) \, \mathrm{d}z - \int_{\gamma_{7}} f(z) \, \mathrm{d}z -\int_{\gamma_{2}} f(z) \, \mathrm{d}z + \int_{\gamma_{5}} f(z) \, \mathrm{d}z \\ \mbox{} + \int_{\gamma_{2}} f(z) \, \mathrm{d}z - \int_{\gamma_{6}} f(z) \, \mathrm{d}z - \int_{\gamma_{3}} f(z) \, \mathrm{d}z + \int_{\gamma_{4}} f(z)  \, \mathrm{d}z = 0.
\end{multline*}$$
Thus
$$\int_{\gamma_{4}} f(z) \, \mathrm{d}z + \int_{\gamma_{5}} f(z) \, \mathrm{d}z = \int_{\gamma_{6}} f(z) \, \mathrm{d}z + \int_{\gamma_{7}} f(z) \, \mathrm{d}z;$$
that is,
$$\int_{\gamma} f(z) \, \mathrm{d}z = \int_{\gamma_{1}} f(z) \, \mathrm{d}z,$$
as claimed.
