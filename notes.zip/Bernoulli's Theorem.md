---
tags:
  - MT4509
aliases:
---
Assume a steady, inviscid, homogeneous, and incompressible flow.

> [!thm] Theorem
> Along a [[Streamlines|streamline]],
> $$H=\frac{1}{2}|\boldsymbol{u}|^{2}+ \frac{p}{\rho}+gz = \text{constant}.$$

> [!gen] Remarks
> - $H$ may take different values on different streamlines.
> - If all the streamlines originate in a region where $\boldsymbol{u},p,gz$ have the same value, then $H$ is constant everywhere.
> - $H$ = kinetic energy + internal energy + kinetic energy.

Direct proof by taking the curl of [[Euler's equation]].
We use the handy identity $\boldsymbol{u \cdot \nabla u} = \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \boldsymbol{u} \times (\boldsymbol{\nabla \times u})$.
$$\begin{align*}
&\frac{D \boldsymbol{u}}{Dt} = - \frac{\nabla p}{\rho} + \boldsymbol{F}\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} +\boldsymbol{u} \cdot \nabla  \boldsymbol{u} = - \frac{\nabla p}{\rho} + \boldsymbol{F}\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} + \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) = - \frac{\nabla p}{\rho} + \boldsymbol{F}\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) =  - \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \frac{\nabla p}{\rho} + \boldsymbol{F}
\end{align*}$$
and assume that $\boldsymbol{F}=-\nabla V$ where $V$ is the potential $V=gz$.
$$\begin{align*}
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) =  - \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \frac{\nabla p}{\rho} - \nabla V \\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) =  - \nabla \left(\frac{1}{2} |\boldsymbol{u}|^{2} + \frac{ p}{\rho} + V\right)\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times \boldsymbol{\omega} =  - \nabla H
\end{align*}$$
Since the flow is steady, $\frac{\partial \boldsymbol{u}}{\partial t}=0$ so
$$\boldsymbol{u} \times \boldsymbol{\omega} =  \nabla H$$
where $H= \frac{1}{2}  |\boldsymbol{u}|^{2}+\frac{ p}{\rho}+ gz$.

So by noting that $\boldsymbol{u\times \omega}$ is orthogonal to $\boldsymbol{u}$ and so their dot product is zero, we have
$$\begin{align*}
&\boldsymbol{u \times \omega}= \nabla H \\
\implies& \boldsymbol{u}\cdot(\boldsymbol{u \times \omega})=\boldsymbol{u} \cdot \nabla H \\
\implies& 0= \boldsymbol{u}\cdot \nabla H.
\end{align*}$$

Now suppose we are on a streamline $\mathcal C$ parametrised by $s$, then
$$\frac{dx}{ds}=u, \qquad \frac{dy}{ds}=v, \qquad \frac{dz}{ds}=w$$
and so
$$\begin{align*}
\frac{dH}{ds}&= \frac{\partial H}{\partial x}\frac{dx}{ds}+ \frac{\partial H}{\partial y}\frac{dy}{ds}+\frac{\partial H}{\partial z}\frac{dz}{ds}\\
&=\frac{\partial H}{\partial x}u+ \frac{\partial H}{\partial y}v+\frac{\partial H}{\partial z}w\\
&=\boldsymbol{u}\cdot \nabla H\\
&=0
\end{align*}$$
That is, $H$ is constant on streamlines.