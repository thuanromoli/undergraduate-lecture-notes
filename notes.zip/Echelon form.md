---
tag: MT2501
type: def
alias:
- echelon
- reduced echelon
---
Let $E$ be a [[Matrices|matrix]].

>[!def] Echelon form
>A matrix $E$ is said to be in (row) echelon form if it has the following two properties:
>- each leading (non-zero) entry in a row is to the right of the leading entry of the row above it
>- the zero rows, if any, occur at the bottom

>[!def] Reduced echelon form
>An echelon matrix $E$ is said to be in reduced echelon form if, in addition:
>- in each non-zero row, the leading entry is 1
>- in each column that contains the leading entry of a row, all other entries are zero.

---

#### Spaced repetition
When is a matrix in echelon form?
?
>A matrix $E$ is said to be in (row) echelon form if it has the following two properties:
>- each leading (non-zero) entry in a row is to the right of the leading entry of the row above it
>- the zero rows, if any, occur at the bottom

When is a matrix in reduced echelon form?
?
>An echelon matrix $E$ is said to be in reduced echelon form if, in addition:
>- in each non-zero row, the leading entry is 1
>- in each column that contains the leading entry of a row, all other entries are zero.