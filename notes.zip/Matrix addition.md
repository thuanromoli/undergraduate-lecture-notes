---
type: def
tag: MT2501
alias: matrix addition
---
Let $A=[a_{ij}]$ and $B=[a_{ij}]$ be [[Matrices|matrices]].

>[!def] Definition
>Matrix addition is defined as
>$$A+B=[a_{ij}+b_{ij}]$$
