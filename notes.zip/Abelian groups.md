---
type: def
tags:
  - MT2505
  - MT4003
aliases:
  - abelian
---
>[!def] Definition
>An abelian group is a [[Groups|group]] that satisfies [[commutativity]].
