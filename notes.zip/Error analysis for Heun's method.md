---
tag: MT2507
type: thm
alias:
- 
---
Suppose the exact solution to the system $\frac{dx}{dt}=f(t,x)$ is $x(t)$.
Let us expand this using the [[Taylor's Theorem|Taylor expansion]] $$x(t)=x(t_{0})+\left(\frac{dx}{dt}\right)_{t_{0}}(t-t_{0})+\left(\frac{d^{2}x}{dt^{2}}\right)_{t_{0}}\frac{(t-t_{0})^{2}}{2}+\ldots$$
and evaluating at $t=t_{1}$ and use $t_{1}=t_{0}+h \implies t_{1}-t_{0}=h$ and $\frac{dx}{dt}=f(t,x)$:
$$x(t_{1})=x_{0}+hf(t_{0},x_{0})+ \frac{h^{2}}{2} \left(\frac{df}{dt}\right)_{t_{0}}+\frac{h^{3}}{6} \left(\frac{d^{2}f}{dt^{2}}\right)_{t_{0}}+\ldots$$
We now wish to compare [[Heun's method]] solution to the above expression:
$$x(t_{1})=x_{0}+ \frac{h}{2}\left(f(t_{0},x_{0})+f(t_{1},x^{*}_{1})\right)$$
We need to use the 2D [[Taylor's Theorem|Taylor expansion]] to symplify:
$$g(z,w)=g(z_{0},w_{0})+(z-z_{0})\left(\frac{\partial g}{\partial z}\right)_{(z_{0},w_{0})}+(w-w_{0})\left(\frac{\partial g}{\partial w}\right)_{(z_{0},w_{0})}+$$
$$\frac{(z-z_{0})^{2}}{2}\left(\frac{\partial^{2} g}{\partial z^{2}}\right)_{(z_{0},w_{0})}+\frac{(w-w_{0})^{2}}{2}\left(\frac{\partial^{2} w}{\partial w^{2}}\right)_{(z_{0},w_{0})}+(z-z_{0})(w-w_{0})\left(\frac{\partial^{2} g}{\partial z\partial w}\right)_{(z_{0},w_{0})}$$
Letting $z=t_{1}$ and $z_{0}=t_{0}$ and $w=x^{*}_{1}$ and $w_{0}=x_{0}$ and using $x_{1}^{*} = x_{0}+hf(t_{0},x_{0})$
$$f(t_{1},x^{*}_{1})=f(t_{0}+h,x_{0}+hf(t_{0},x_{0}))\approx f(t_{0},x_{0})+h \left(\frac{\partial f}{\partial t}\right)_{(t_{0},x_{0})}+hf(t_{0},x_{0})\left(\frac{\partial f}{\partial x}\right)_{(t_{0},x_{0})}$$
Hence plugging this in Heun's method and letting $f_{0}=f(t_{0},x_{0})$ and $f_{1}=f(t_{1},x_{1})$
$$x(t_{1})=x_{0}+ \frac{h}{2}\left(f_{0}+\left[f_{0}+h \left(\frac{\partial f}{\partial t}\right)_{(t_{0},x_{0})}+hf_{0}\left(\frac{\partial f}{\partial x}\right)_{(t_{0},x_{0})}+O(h^{2})\right]\right)$$
$$\implies x(t_{1})=x_{0}+hf_{0}+ \frac{h^{2}}{2} \left[ \left(\frac{\partial f}{\partial t}\right)_{(t_{0},x_{0})}+f_{0}\left(\frac{\partial f}{\partial x}\right)_{(t_{0},x_{0})}+O(h^{2})\right]$$
Then using the chain rule:
$$\frac{df}{dt}=\frac{\partial f}{\partial x} \frac{dx}{dt}+\frac{\partial f}{\partial t} \frac{dt}{dt}$$
and since
$$\frac{dx}{dt}=f(t,x) \text{ and } \frac{dt}{dt}=1$$
then we have 
$$\left(\frac{df}{dt}\right)_{t_{0}}=f_{0}\left(\frac{\partial f}{\partial x}\right)_{t_{0}}+\left(\frac{\partial f}{\partial t}\right)_{t_{0}}$$
and finally
$$x(t_{1})=x_{0}+hf_{0}+ \frac{h^{2}}{2} \left(\frac{df}{dt}\right)_{t_{0}}+O(h^{3})$$
This agrees with the exact solution for the first three terms.


---

#### Spaced repetition
