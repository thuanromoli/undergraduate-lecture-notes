---
tags:
  - MT2502
aliases:
  - upper bound
  - lower bound
  - bounded
---
#### For real analysis in any [[Metric spaces|metric]] or [[Normed spaces|normed]] space
Let $(X,d)$ be a [[Metric spaces|metric space]]. Let $K \subseteq X$ be a subset.

> [!def] Bounded metric spaces
> $K$ is bounded if
> $$\exists r >0 \;\;\text{s.t}\;\; d(x,y)<r \;\;\forall x,y \in K.$$

#### For real analysis in the metric $(\mathbb R,|\cdot |)$
Let $(x_{n})_{n}$ be a [[Sequences|sequence]].

> [!def] Bounded sequences
> $(x_{n})_{n}$ is bounded if
> $$\exists M \geqslant 0 \;\; \text{s.t}\;\; |x_{n}| \leqslant M \;\;\forall n \in N.$$

Let $A \subseteq \mathbb R$ and $f: A \to \mathbb R$ be a [[Functions|function]] on $A$.

> [!def] Bounded functions
> $f$ is bounded if
> $$\exists M \geqslant 0 \;\; \text{s.t}\;\; |f(x)| \leqslant M \;\;\forall x \in A.$$

Let $(X,<)$ be an [[Ordered sets|ordered set]] and $A \subseteq X$.

> [!def] Upper and lower bounds
> $u \in X$ is called an upper bound for $A$ if
> $$\forall a \in A, \;\; a \leqslant u.$$
> $\mathscr l \in X$ is called a lower bound for $A$ if
> $$\forall a \in A, \;\; \mathscr l \leqslant a.$$
