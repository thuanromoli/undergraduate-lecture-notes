---
tags:
  - MT4551
aliases:
  - FC
  - forward contract
---
> [!def] Definition
> A forward contract is the simplest form of derivative. It has three conditions:
> 1. It is a binding agreement to buy and sell an asset for a strike price $E$ at a strike date $T$.
> 2. No fee.
> 3. At conception, it has zero value.
