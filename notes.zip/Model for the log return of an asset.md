---
tags:
  - MT4527
aliases:
---
> [!gen] Stylised facts of asset returns
> - The returns' distribution has heavier tails than the normal distribution.
> - Returns are nearly uncorrelated, but there is significantly positive autocorrelation in absolute or squared returns.
> - Returns large in absolute value are often followed by returns of large absolute value and returns small in absolute value are often followed by returns of small absolute value (volatility clustering).

Let $r_{t}$ be the log return of an asset at time index $t \in \mathbb Z$.

> [!def] General model
> We entertain the following model for $r_{t}$:
> $$r_{t}=\mu_{t}+ \varepsilon_{t}$$
> where
> $$\mu_{t} = \mathbb E(r_{t}|r_{t-1},r_{t-2},\ldots)$$
> is the mean equation for $r_{t}$.

> [!gen] Remarks
> - $\set{r_{t}}_{t\in \mathbb Z}$ are nearly uncorrelated $\implies$ the model for $\mu_{t}$ should be simple.
> - The conditional variance of $r_{t}$ is $\sigma^{2}_{t}= \text{Var }(r_{t}|r_{t-1},r_{t-2},...)= \text{Var }(\varepsilon_{t}|r_{t-1},r_{t-2},...)$.
> - The models in this chapters are concerned with the evolution of $\sigma^{2}_{t}$, such a model is referred to as the volatility equation for $r_{t}$.
