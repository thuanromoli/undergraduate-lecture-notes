---
type: def
tags:
  - MT2506
aliases: []
---
>[!def] Definition
>A field is a collection of scalars or vectors defined at all spatial points in our domain.
