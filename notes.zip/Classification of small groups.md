---
tags:
  - MT4003
aliases:
---
For $1 \leqslant n \leqslant 15$ we shall use the theory we have developed over the course to describe the [[Groups|groups]] of [[Order|order]] $n$ up to [[Isomorphisms|isomorphism]].

> [!thm]- A group of order 1 is isomorphic to the trivial group

> [!thm]- A group of order $p$ is isomorphic to $C_{p}$
> $G$ is [[Cyclic groups|cyclic]] ([[Lagrange's Theorem#^816d54|see here]]).
> Cyclic groups of order $p$ are isomorphic to $C_{p}$ ([[Theorems about cyclic groups#^ec5cdd|see here]]).

> [!thm]- A group of order $p^{2}$ is isomorphic to $C_{p^{2}}$ or $C_{p} \times C_{p}$.

> [!thm]- A group of order $2p$ is isomorphic to $C_{2p}$ if abelian or $D_{2p}$ if not abelian

> [!thm]- A group of order $8$ is isomorphic to one of $C_{8}$, $C_{2}\times C_{4}$, or $C_{2}\times C_{2} \times C_{2}$

> [!thm]- A group of order $pq$, where $p,q$ primes, $p<q$, and $p \not\mid q-1$ is isomorphic to one of $C_{pq}$

> [!thm]- A group of order $12$ is isomorphic to one of $C_{2}\times C_{6}$, $C_{12}$, $A_{4}$, $D_{12}$, or $T$
