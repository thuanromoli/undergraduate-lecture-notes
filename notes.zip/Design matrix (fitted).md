---
tags:
  - MT3508
aliases:
---
Consider a fitted [[General linear models|linear model]] with $p$ parameters and $n$ observations $y_{i} \sim N \set{\mu(x_{i,1},x_{i,2},...,x_{i,p}), \sigma^{2}}$.
Let $\mu_{i} = \beta_{0} + \beta_{1} x_{i,1} + \beta_{2} x_{i,2}+\ldots + \beta_{p}x_{i,p} = \boldsymbol{x}_{i}\boldsymbol{\beta}$ be the expected value for the observation $y_{i}$, where $x_{i,j}$ is the $j$th covariate of the $i$th observation and $\beta_{j}$ is the $j$th estimate (of any observation) such that $\boldsymbol{x}_{i} = (x_{i,1},x_{i,2},\ldots,x_{i,p})$ and $\boldsymbol{\beta} = (\beta_{1},\beta_{2},\ldots, \beta_{p})^{T}$.

> [!def] Definition
> The design matrix is the matrix $\boldsymbol{X}$ such that
> $$\begin{align*}
   \boldsymbol{\mu} &= \boldsymbol{X}\boldsymbol{\beta}\\
   \begin{pmatrix}\mu_{1}\\ \mu_{2}\\ \vdots \\ \mu_{n-1} \\ \mu_{n}  \end{pmatrix}&= \left( \begin{array}{cccc} x_{1,0} & x_{1,1} & \cdots & x_{1,p} \\  x_{2,0} & x_{2,1} & \cdots & x_{2,p} \\ \vdots & \vdots & \ddots & \vdots \\  x_{n,0} & x_{n,1} & \cdots & x_{n,p}  \end{array} \right) \left( \begin{array}{c}    \beta_0 \\    \beta_1 \\    \vdots \\    \beta_p  \end{array} \right)
   \end{align*}$$
> or in other words is the matrix obtained by 'stacking' in a vector all the $\boldsymbol{x}_{i}$:
> $$\boldsymbol{X} = \begin{pmatrix}\boldsymbol{x}_{1} \\ \boldsymbol{x}_{2} \\ \vdots \\ \boldsymbol{x}_{n} \\ \end{pmatrix}$$

> [!gen] Remarks
> With the above notation, if we let $\boldsymbol{y} = (y_{1}),y_{2},\ldots,y_{n})^{T}$ then we can write notationally
> $$\boldsymbol{y} \sim N(\boldsymbol{X}\boldsymbol{\beta}, \boldsymbol{I}\sigma^{2}).$$
