---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is called an autoregressive process of order $p$ if it is [[Stationarity|weakly stationary]] and there exists a [[White noise|white noise]] $(\varepsilon_{t})_{t \in \mathbb Z}$ and real numbers $\phi_{1},...,\phi_{p} \in \mathbb R$ such that for all $t \in \mathbb Z$,
> $$X_{t}=\phi_{1} X_{t-1}+\cdots+\phi_{p}X_{t-p}+\varepsilon_{t}.$$
> 
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is an autoregressive process of order $p$ with mean $\mu$ if $X_{t}-\mu$ is an AR($p$) process.

> [!thm] Properties (under certain [[Stationarity of AR(p) Processes|regularity conditions]])
> - $$\gamma_{X} (h) = \phi_{1} \gamma_{X}(h-1)+\phi_{2}\gamma_{X}(h-2)+\cdots+\phi_{p}\gamma_{X}(h-p).$$
> - $$\rho_{X} (h) = \phi_{1} \rho_{X}(h-1)+\phi_{2}\rho_{X}(h-2)+\cdots+\phi_{p}\rho_{X}(h-p).$$
> - $$\alpha_{X}(h)=\begin{cases} \beta_{h} &\quad h=1,...,p \\0 &\quad h>p.\end{cases}$$

> [!gen] Remarks
> - The autocorrelation function can be solved using recurrent relations and the coefficients type will determine the behaviour (regardless, will decay to zero)
>   ![[arp_att.png|500]]
> - $$\begin{vmatrix}
\hline
 & ACF & PACF \\ \hline
 \text{MA($q$)} & \text{Cuts off after lag $q$} & \text{Decays to zero} \\ \hline
\text{AR($p$)} & \text{Decays to zero} & \text{Cuts off after lag $p$} \\
\hline
\end{vmatrix}$$
