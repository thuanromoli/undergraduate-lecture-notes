---
tag: MT2505
type: thm
---
Let $A$ be a set and $*$ be a [[Binary operations|binary operation]] on $A$.

>[!thm] Theorem
>If $a_1,a_2,\ldots,a_n \in A$, then the element $$a_1*a_2*\cdots*a_n$$is uniquely determined irrespective of how this expression is bracketed.
