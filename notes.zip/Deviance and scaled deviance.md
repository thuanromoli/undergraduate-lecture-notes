---
tags:
  - MT3508
aliases:
  - scaled deviance
  - deviance
---
Let $l(\boldsymbol{\mu},\phi; \boldsymbol{y})$ be the [[Log-likelihood|log-likelihood]] of a GLM where $\boldsymbol{y}\in \mathbb R^{n}$.

> [!def] Scaled deviance
> The scaled deviance is the [[Likelihood ratio test (model comparison)|likelihood ratio test statistic]] for the [[Saturated model|saturated model]] against the fitted model. That is,
> $$D^{*}(\widehat{\boldsymbol{\mu}},\phi; \boldsymbol{y}) = 2\left\{l(\boldsymbol{y},\phi; \boldsymbol{y}) - l(\widehat {\boldsymbol{\mu}},\phi; \boldsymbol{y})\right\}$$
> since in the saturated model $\boldsymbol{\mu}=\boldsymbol{y}$ and in the fitted model $\boldsymbol{\mu} = \widehat {\boldsymbol{\mu}}$.

> [!thm] Distribution of the scaled deviance
> The scaled deviance $D^{*}$ is $\chi^{2}_{n-p}$ distributed where $n$ is the number of observations and $p$ is the number of parameters.
> Note: this result comes from different theory than the likelihood ratio test statistic and has the following constraints:
> - It does not hold outside [[Exponential dispersion families|exponential dispersion families]].
> - It does not hold for [[Bernoulli distribution|Bernoulli distributions]].
> - It requires that $\phi$ is known (hence won't immediately work for Gamma and Normal).

> [!def] Deviance
> The deviance of a given fitted model is
> $$D(\widehat {\boldsymbol{\mu}};\boldsymbol{y})=D^{*}(\widehat{\boldsymbol{\mu}},\phi; \boldsymbol{y}) \phi= 2\left\{l(\boldsymbol{y},\phi; \boldsymbol{y}) - l(\widehat {\boldsymbol{\mu}},\phi; \boldsymbol{y})\right\}\phi.$$

![[glmdeviance_att.png]]

> [!gen] Remarks
> - The deviance doesn't depend on $\phi$, since the scaled deviance has a $\phi$ in the denominator.
> - The deviance depends on the model.
> - For [[Bernoulli distribution]] use a [[Binomial distributions]] with $N=1$.
> - For an [[Exponential distributions]] use a Gamma distribution with $\alpha = 1$.
