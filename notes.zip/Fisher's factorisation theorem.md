---
tags:
  - MT3507
aliases:
---
> [!thm] Theorem
> The statistics $\boldsymbol{T}(\boldsymbol{X})$ are jointly sufficient statistics for the parameter vector $\boldsymbol{\theta}$ if and only if we can factorise the [[Likelihood|likelihood]] as in
> $$L(\boldsymbol{\theta};\boldsymbol{x}) = h(\boldsymbol{x})g(\boldsymbol{\theta};\boldsymbol{T}(\boldsymbol{x}))$$
> for appropriate functions $h$ and $g$.
