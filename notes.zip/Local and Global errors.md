---
tag: MT2507
type: def
alias:
- 
---
>[!def] Local error
>The local error is the error that is made during each step of the calculation:
>(this is the error calculated in [[Error analysis for Heun's method]], [[Error analysis for Euler's method]], [[Error analysis for the Newton-Raphson Method (1D)]]).

>[!def] Global error
>The global error is the error given by the sum of the local error in each step.

---

#### Spaced repetition
