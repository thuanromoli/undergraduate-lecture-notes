---
tags:
  - MT4528
type: model
aliases:
---
>[!def] Definition
>The M/M/1 queue has:
>- [[Poisson processes|Poisson process]] arrivals with rate $\lambda$
>- service times $\overset{iid}{\sim}\text{Exp}(\mu)$
>- one server and capacity is $\infty$
>
>This is a [[Birth and death processes|Birth/death process]] where:
>$$\lambda_{n}=\begin{cases}
   \lambda & \text{for all }n \\
   \end{cases}$$
>$$\mu_{n}=\begin{cases}
   0 & \text{for }n=0 \\
   \mu & \text{for }n>0 \\
   \end{cases}$$

>[!thm] Theorem
>For an M/M/1 queue with $\mu>\lambda$, the [[Stationary distributions|stationary distribution]] of the process $\set{X(t):t\geqslant 0}$ is given by
>$$\begin{align*}
   \pi_{n}=\lim\limits_{t \to \infty}\mathbb P(X(t)=n) = \left(1-\frac{\lambda}{\mu}\right)\left(\frac{\lambda}{\mu}\right)^{n}\\
   \end{align*}$$
>For $\mu \leqslant \lambda$ no equilibrium distribution exists.
>
>Proof: see [[Equilibrium distribution of a birth death process|this proposition]], and then use algebra.

>[!thm] Corollary
>For an M/M/1 queue with $\mu>\lambda$ that is in its equilibrium, we have:
>- $\mathbb E(X(t))=\frac{\lambda}{\mu-\lambda}$
>- $\mathbb E(T(t))=\frac{\lambda^{2}/\mu}{\mu-\lambda}$
