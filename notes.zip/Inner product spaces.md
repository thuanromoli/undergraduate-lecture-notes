---
tags:
  - MT3501
type: def
aliases:
  - inner product space
---
Let $F$ be the [[Fields (Algebra)|field]] of $\mathbb C$ or $\mathbb R$.

>[!def] Definition
>An inner product space is a [[Vector spaces|vector space]] $V$ over $F$ together with an inner product:
>$$\begin{align*}
   V\times V&\to F \\
   (v,w) &\mapsto \langle v, w \rangle
   \end{align*}$$
>such that 
>(i) $\langle u+v,w \rangle = \langle u,w \rangle \;\;\forall u,v,w\in V$.
>(ii) $\langle \alpha v,w \rangle= \alpha \langle v,w \rangle \;\;\forall v,w\in V$ and $\alpha \in F$.
>(iii) $\langle v,w \rangle=\overline{\langle w,v \rangle} \;\;\forall v,w\in V$.
>(iv) $\langle v,v \rangle$ is a real number satisfying $\langle v,v \rangle \geqslant 0 \;\;\forall v\in V$.
>(v) $\langle v,v \rangle=0$ if and only if $v=\boldsymbol{0}$.
>
>Note that when $F = \mathbb R$, condition (iii) implies that the inner product spaces is symmetric: $\langle v,w \rangle=\langle w,v \rangle \;\;\forall v,w\in V$.
