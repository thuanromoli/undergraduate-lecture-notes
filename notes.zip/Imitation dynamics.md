---
tags:
  - MT4554
type: 
aliases:
---
>[!def] Imitation dynamics
>Imitation update rule works as follows:
>1. a player $i$ chooses another player $j$ from the population at random.
>2. player $i$ compares player $j$'s payoff to their own.
>3. depending on the difference in their payoffs, $i$ copies $j$'s strategy with probability
>   $$\Pi(\sigma_{i}\to \sigma_{j})= \frac{1}{1+\exp[h(V_{i}-V_{j})]}$$
>![[imitlear_att.png|300]]

>[!gen] Remarks
>The update rule is probabilistic and therefore the evolution of a population under this rule is a [[Stochastic processes|stochastic process]]. Typically the rule is applied as follows:
>1. play $N-1$ pairwise games with every other member of the population.
>2. use the update rule.
>3. repeat.
>
>The algorithm describes a [[Markov chains and processes|Markov process]] in which the state of the system is the number of players with a given strategy $\sigma^k$.
