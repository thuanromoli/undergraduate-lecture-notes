---
type: def
tags:
  - MT2505
  - MT4003
aliases:
  - group
  - groups
---
>[!def] Definition
>A group is a set $G$ together with a [[Binary operations|binary operation]] $$(x,y)\mapsto x*y$$that satisfies all the following properties:
>- it's [[associativity|associative]];
>- it has an [[identity element]];
>- all elements have an [[inverse element]].
