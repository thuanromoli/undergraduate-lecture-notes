---
type: model
tag: MT2507
---
Consider a [[Particle (Dynamics)|particle]] of constant mass $m$ that moves radially.
Now the gravity is no longer constant and we can't use $\boldsymbol{F}=-mg \boldsymbol{k}$ anymore.

>[!gen]+ [[Position vectors|Position vector]]
>$\boldsymbol{r}(t)$ represents the radial distance from the centre of the Earth.

>[!gen]+ [[Equation of Motion]]
>Forces acting:
>$$\boldsymbol{F} = -\frac{GMm}{r^{2}} \hat{\boldsymbol{r}}=-g{R_{E}}^{2}\cdot \frac{m}{r^{2}} \hat{\boldsymbol{r}}=-gm\left(\frac{R_{e}}{r}\right)^{2}\hat{\boldsymbol{r}}$$
>since $g=\frac{GM}{{R_{E}}^{2}}$.
>Equation of motion: $$-mg\left(\frac{R_{e}}{r}\right)^{2}\hat{\boldsymbol{r}} = m \frac{d^{2}\boldsymbol{r}}{dt^{2}}$$

>[!gen]+ Method to find velocity in terms of $r$
>1. Equate the radial component of the equation of motion:
>$$\frac{d^{2}r}{dt^{2}}=-g\left(\frac{R_{e}}{r}\right)^{2} \implies \frac{dv}{dt}=-g \left(\frac{R_{E}}{r}\right)^{2}$$
>2. Express $v$ in terms of $r$ using the chain rule: $$\frac{dv}{dt}=\frac{dv}{dr}\cdot \frac{dr}{dt}\implies \frac{dv}{dt}=v \frac{dv}{dr}$$
>3. Solve the equation: $$v \frac{dv}{dr}=-g \left(\frac{R_{E}}{r}\right)^{2}$$

