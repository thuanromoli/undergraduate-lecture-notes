---
tags:
  - MT3501
type: def
aliases:
  - direct sum
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$.

>[!def] Notation
>$V=U_{1}\oplus U_{2}$ means $V$ is the direct sum of two [[Subspaces|subspaces]] $U_{1}$ and $U_{2}$.

>[!def] Definition 1
>$V=U_{1}\oplus U_{2}$ if every vector in $V$ can be expressed uniquely in the form $u_{1}+u_{2}$ where $u_{1}\in U_{1}$ and $u_{2}\in U_{2}$.

>[!def] Definition 2
>$V=U_{1}\oplus U_{2}$ if and only if
>1. $V=U_{1}+U_{2}$
>2. $U_{1} \cap U_{2} =\set {\boldsymbol{0}}$

>[!thm] The two definitions above are equivalent.
>We shall show that the two requirements in definition 2 are enough to show the existence and uniqueness of the form in definition 1.
>
>Existence:
>By definition $U_{1}+U_{2}=\set{u_{1}+u_{2}: u_{1}\in U_{1}, u_{2}\in U_{2}}$, so every $v\in V$ can be written in the form $u_{1}+u_{2}$ if and only if $V=U_{1}+U_{2}$.
>
>Uniqueness:
>Suppose $V=U_{1}\oplus U_{2}$. Let $u\in U_{1}\cap U_{2}$.
>Then $u=u+\boldsymbol{0}=\boldsymbol{0}+u$. The uniqueness condition forces $u=\boldsymbol{0}$. So $U_{1}\cap U_{2}=\set {\boldsymbol{0}}$.
>Conversely, suppose $U_{1}\cap U_{2}=\set {\boldsymbol{0}}$.
>Suppose $v=u_{1}+u_{2}=u_{1}'+u_{2}'$ where $u_{1},u_{1}'\in U_{1}$ and $u_{2},u_{2}'\in U_{2}$.
>Then $u_{1}-u_{1}'=u_{2}'-u_{2}$ but since these are equal and LHS $\in U_{1}$ and RHS $\in U_{2}$ then they must lie in $U_{1}\cap U_{2}$.
>Hence $u_{1}-u_{1}'=u_{2}'-u_{2}=\boldsymbol{0}$ $\implies$ $u_{1}=u_{1}'$ and $u_{2}=u_{2}'$.
>Hence our expressions are unique.

---

#### Spaced repetition

What are the two definitions of a direct sum $V=U_{1}\oplus U_{2}$?
?
>Definition 1
>$V=U_{1}\oplus U_{2}$ if every vector in $V$ can be expressed uniquely in the form $u_{1}+u_{2}$ where $u_{1}\in U_{1}$ and $u_{2}\in U_{2}$.
>
>Definition 2
>$V=U_{1}\oplus U_{2}$ if and only if
>1. $V=u_{1}+U_{2}$
>2. $U_{1} \cap U_{2} =\set {\boldsymbol{0}}$

Prove that the two definitions for a direct sum are equivalent.
?
>We shall show that the two requirements in definition 2 are enough to show the existence and uniqueness of the form in definition 1.
>
>Existence:
>By definition $U_{1}+U_{2}=\set{u_{1}+u_{2}: u_{1}\in U_{1}, u_{2}\in U_{2}}$, so every $v\in V$ can be written in the form $u_{1}+u_{2}$ if and only if $V=U_{1}+U_{2}$.
>
>Uniqueness:
>Suppose $V=U_{1}\oplus U_{2}$. Let $u\in U_{1}\cap U_{2}$.
>Then $u=u+\boldsymbol{0}=\boldsymbol{0}+u$. The uniqueness condition forces $u=\boldsymbol{0}$. So $U_{1}\cap U_{2}=\set {\boldsymbol{0}}$.
>Conversely, suppose $U_{1}\cap U_{2}=\set {\boldsymbol{0}}$.
>Suppose $v=u_{1}+u_{2}=u_{1}'+u_{2}'$ where $u_{1},u_{1}'\in U_{1}$ and $u_{2},u_{2}'\in U_{2}$.
>Then $u_{1}-u_{1}'=u_{2}'-u_{2}$ but since these are equal and LHS $\in U_{1}$ and RHS $\in U_{2}$ then they must lie in $U_{1}\cap U_{2}$.
>Hence $u_{1}-u_{1}'=u_{2}'-u_{2}=\boldsymbol{0}$ $\implies$ $u_{1}=u_{1}'$ and $u_{2}=u_{2}'$.
>Hence our expressions are unique.