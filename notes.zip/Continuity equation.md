---
tags:
  - MT4509
aliases:
  - continuity equation
---
Let $V$ be a volume fixed in space with surface $S$ and outward normal $\boldsymbol{n}$.

> [!thm] Theorem
> Suppose that the fluid mass inside $V$ is $M(t) = \iiint_{V} \rho\;dV$ where $\rho(\boldsymbol{x},t)$ is the fluid density. Then
> $$\iiint_{V}\left[\frac{\partial p}{\partial t}+\nabla \cdot (\rho \boldsymbol{u})\right] dV = 0$$
> where, in particular,
> $$\frac{\partial p}{\partial t}+\nabla \cdot (\rho \boldsymbol{u})=0$$
> is the continuity equation, which expresses mass conservation.
> This may be written, by noticing that $\nabla \cdot (\rho \boldsymbol{u})= \rho \nabla \cdot \boldsymbol{u}+ \boldsymbol{u}\cdot \nabla \rho$, as
> $$\frac{D \rho}{Dt}+\rho \nabla \cdot \boldsymbol{u}=0.$$

![[fixedvolume_att.png|300]]

Only normal component of velocity tells us if something is going in or out of a volume.
So consider $u_{n} = \boldsymbol{u} \cdot \boldsymbol{n}$.

Over a time interval $dt$, we wish to know how much mass has entered or left the volume. Recall that we define $M = \iiint_{V}\rho\;dV$.

Let $dn$ be the length perpendicular to $S$.
Then think of $dS$ going into the volume, travelling a distance, $dn$, equal to velocity times time.
We obtain $dn = u_{n}dt$.

A volume is swept out as time moves $\delta V = dS \; dn$.
Then $|\delta M| = \delta V \cdot \rho$.

Over a time interval $dt$, $\delta M = -dS (u_{n} dt) \rho$ and so $\frac{\delta M}{dt}=-\rho u_{n}dS$.

We have chosen a particular $dS$, so we sum over all $dS$ for a time $dt$.
$$\frac{dM}{dt}= - \iint_{S \text{ closed}} \rho u_{n} dS=- \iint_{S \text{ closed}} \rho (\boldsymbol{u}\cdot \boldsymbol{n}) dS.$$

We now use $M = \iiint_{V}\rho\;dv$ to derive an evolution equation for $\rho$.

$$\frac{dM}{dt} = \iiint_{V} \frac{\partial \rho}{\partial t} dV =- \iint_{S \text{ closed}} \rho (\boldsymbol{u}\cdot \boldsymbol{n}) dS$$

Recall [[Gauss' Theorem]], for our case, $\boldsymbol{F} = \rho\cdot \boldsymbol{u}$. So

$$- \iint_{S \text{ closed}} \rho (\boldsymbol{u}\cdot \boldsymbol{n}) dS= -\iiint_{V} \nabla \cdot(\rho \boldsymbol{u})\;dV$$
So we now have

$$ \iiint_{V} \frac{\partial \rho}{\partial t} dV  = -\iiint_{V} \nabla \cdot(\rho \boldsymbol{u})\;dV \implies \iiint_{V}\left[\frac{\partial p}{\partial t}+\nabla \cdot (\rho \boldsymbol{u})\right] dV = 0$$

where $\frac{\partial p}{\partial t}+\nabla \cdot (\rho \boldsymbol{u})=0$ is the Continuity Equation.

Alternatively,
$$\frac{\partial p}{\partial t}+\nabla \cdot (\rho \boldsymbol{u})= \frac{\partial \rho}{\partial t}+(\boldsymbol{u}\cdot \nabla \rho +\rho \nabla \cdot \boldsymbol{u})= \left(\frac{\partial \rho}{\partial t}+\boldsymbol{u}\cdot \nabla \rho \right)+\rho \nabla \cdot \boldsymbol{u}=\frac{D \rho}{Dt}+\rho \nabla \cdot \boldsymbol{u}=0.$$
