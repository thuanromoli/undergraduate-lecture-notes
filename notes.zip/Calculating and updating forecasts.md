---
tags:
  - MT4527
aliases:
---
Let $(X_{t})_{t \in \mathbb Z}$ be an [[ARIMA(p,d,q) Process]] written in the difference equation form
$$X_{t}= a_{1}X_{t-1}+a_{2}X_{t-2}+\cdots+a_{p+d}X_{t-p-d}+ \varepsilon_{t}+b_{1}\varepsilon_{t-1}+b_{2}\varepsilon_{t-2}+\cdots+b_{q+d}\varepsilon_{t-q-d}.$$
Then the process satisfies
$$X_{t+L}= a_{1}X_{t+L-1}+a_{2}X_{t+L-2}+\cdots+a_{p+d}X_{t+L-p-d}+ \varepsilon_{t+L}+b_{1}\varepsilon_{t+L-1}+b_{2}\varepsilon_{t+L-2}+\cdots+b_{q+d}\varepsilon_{t+L-q-d}.$$
[[Properties of the forecasts|We showed that]] for $L>0$, $\widehat x_{t}(L)= \mathbb E(X_{t+L})$ and $\epsilon_{t+L} = \mathbb E(\varepsilon_{t+L})$ so we may evaluate, for observations $x_{t},x_{t-1},...$
$$\begin{align*}
\widehat x_{t}(1) &= \mathbb E(X_{t+1}) = a_{1}x_{t} + a_{2}x_{t-1}+\cdots+a_{p+d}x_{t-p-d+1}+b_{1}\epsilon_{t}+b_{2}\epsilon_{t-1}+\cdots+b_{q+d}\epsilon_{t-q-d-1}\\
\widehat x_{t}(2) &= \mathbb E(X_{t+2}) = a_{1}\widehat x_{t}(1) + a_{2}x_{t}+\cdots+a_{p+d}x_{t-p-d+2}+b_{2}\epsilon_{t}+\cdots+b_{q+d}\epsilon_{t-q-d+2}\\
&\;\;\vdots\\
\widehat x_{t}(L) &= \mathbb E(X_{t+L}) = a_{1}\widehat x_{t}(L-1)+ a_{2}\widehat x_{t}(L-2) +\cdots+a_{p+d}\widehat x_{t}(L-p-d) \qquad \text{for }L>q+d
\end{align*}$$
That is, we obtain a recurrence relation for the forecast function $\widehat x_{t}(L)$.
The solution is called the eventual forecast function.
