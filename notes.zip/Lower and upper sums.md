---
tags:
  - MT3502
aliases:
  - lower sum
  - upper sum
---
Let $f:[a,b] \to \mathbb R$ be a [[Boundedness|bounded]] [[Functions|function]].

> [!def] Definition
> The lower and upper sums of $f$ with respect to the [[Dissections|dissection]] $\mathcal D = \set{a = a_{0} < a_{1} < \ldots < a_{n} = b}$ are
> $$\begin{align*}
   \underline S(\mathcal D) = \sum\limits_{i=1}^{n}(a_{i}-a_{i-1})\inf_{a_{i-1}\leqslant x \leqslant a_{i}} f(x)\\
   \overline S(\mathcal D) = \sum\limits_{i=1}^{n}(a_{i}-a_{i-1})\sup_{a_{i-1}\leqslant x \leqslant a_{i}} f(x)
   \end{align*}$$
