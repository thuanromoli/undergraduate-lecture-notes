---
alias: injective
type: def
tag: MT2505
---
Let $f: X\to Y$ be a [[Functions|function]].

> [!def] Definition
> $f$ is injective if each element of the codomain is mapped to by at most one element of the domain.

> [!def] Definiton
> $f$ is injective if $$x_{1}f=x_{2}f \implies x_{1}=x_{2} \;\;  \text{ for any } x_{1},x_{2} \in X$$

> [!def] Definition
> $f$ is injective if
> $$\ker f = \boldsymbol{1}$$
