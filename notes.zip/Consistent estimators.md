---
alias: consistent estimator
type: def
tag: MT2508
---
>[!def] Definition
>An [[Estimators|estimator]] $T$ of $\theta$ is consistent if $\mathbb{E}(T)\to\theta$ and $\text{Var}(T)\to 0$ as $n\to \infty$
