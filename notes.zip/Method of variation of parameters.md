---
tags:
  - MT3504
type: mthd
aliases:
---
>[!gen] ODE
>$$L[y]=y''+py'+qy=g(x)$$
>where $y_{CF}=Ay_{1}(x)+By_{2}(x)$ such that $L[y_{CF}]=0$

>[!gen] Solution
>We assume that $y_{PI}$ has a form similar to $y_{CF}$ but with constants replaced by functions:
>$$y_{PI}=u_{1}(x)y_{1}(x)+u_{2}(x)y_{2}(x)$$
>where $u_{1}$ and $u_{2}$ are as yet unknown functions.
>There are two unknowns and only one constraint: $L[y_{PI}]=g$, so we are free to choose a constraint that makes the procedure as easy as possible:
>$$u_{1}'y_{1}+u_{2}'y_{2}=0$$
>
>Now we have
>$$y'=u_{1}y_{1}'+u_{1}'y_{1}+u_{2}y_{2}'+u_{2}'y_{2}=u_{1}y_{1}'+u_{2}y_{2}'$$
>$$y''=u_{1}y_{1}''+u_{2}y_{2}''+u_{1}'y_{1}'+u_{2}'y_{2}'$$
>And $L[y]=g(x)$ becomes
>$$(u_{1}y_{1}''+u_{2}y_{2}''+u_{1}'y_{1}'+u_{2}'y_{2}')+p(u_{1}y_{1}'+u_{2}y_{2}')+q(u_{1}y_{1}+u_{2}y_{2})=g(x)$$
>$$u_{1}(y_{1}''+py_{1}'+qy_{1})+u_{2}(y_{2}''+py_{2}'+qy_{2})+u_{1}'y_{1}'+u_{2}'y_{2}'=g(x)$$
>$$u_{1}(L[y_{1}])+u_{2}(L[y_{2}])+u_{1}'y_{1}'+u_{2}'y_{2}'=g(x)$$
>Hence these are the two conditions:
>$$\begin{matrix}
   u_{1}'y_{1}'+u_{2}'y_{2}'=g(x) \\ 
   u_{1}'y_{1}+u_{2}'y_{2}=0 \;\;\;\;\;
   \end{matrix}$$
>Which are easily solvable since it can be re-written as a [[Testing for linear independence|Wronskian]]:
>$$\begin{pmatrix}y_{1} & y_{2} \\ y_{1}' & y_{2}'\end{pmatrix}\begin{pmatrix} u_{1}' \\ u_{2}'\end{pmatrix}=\begin{pmatrix}0 \\ g(x)\end{pmatrix}$$

>[!gen] Remarks
>- $L[y]=g(x)$ should have coefficient of $1$ for $y''$.
