---
tags:
  - MT3502
aliases:
  - complete
---
> [!def] Complete metric spaces
> A [[Metric spaces|metric space]] $(X,d)$ is called complete if every [[Cauchy sequence|Cauchy]] [[Sequences|sequence]] in the space converges to some point in the space. 

> [!def] Banach spaces
> A [[Normed spaces|normed space]] $(X,{\Vert \cdot \Vert})$ is called complete if every [[Cauchy sequence|Cauchy]] [[Sequences|sequence]] in the space converges to some point in the space.
