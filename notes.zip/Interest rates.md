---
tags:
  - MT4551
aliases:
  - interest rate
---
Let $A$ be an amount invested for $n$ years at a fixed rate of $r$ (always assume per annum unless specified).

>[!def] Interest rates
>The value of $A$ after $n$ years is
>1. $A(1+r)^{n}$ if compounded annually.
>2. $A(1+ \frac{r}{m})^{nm}$ if compounded $m$ times a year.
>3. $Ae^{nr}$ if compounded continually.
>
>To verify that the statements are consistent, use the fact that $e=\lim\limits_{x \to \infty}(1 + \frac{1}{x})^{x}$.

> [!thm] Value of money
> Let $t=t_{0}$ be the initial time and $t=t_{1}$ the future time and $P(t)$ be the amount of money at time $t$. Then
> - $P(t_{1})=P(t_{0})e^{r(t_{1}-t_{0})}$ (future value);
> - $P(t_{0})= P(t_{1})e^{-r(t_{1}-t_{0})}$ (discounting).