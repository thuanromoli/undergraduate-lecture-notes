---
tags:
  - MT4528
type: model
aliases:
---
>[!def] Definition
>The expected time / number of steps until [[Absorbing states|absorption]] (i.e the expected time until the game ends, because either $A$ or $B$ is ruined) is defined as
>$$E(a)=\mathbb{E}(T|X_{0}=a+1)$$
>where $T$ is the [[Random variables|rv]] such that $T=\text{time / mumber of steps until ruin}$.

>[!thm] Theorem
>We can calculate the probability $E(a)$:
>$$E(a)=\begin{cases}
   \frac{1}{q-p}\left(a-N\frac{1-(q/p)^{a}}{1-(q/p)^{N}}\right) & \text{if }p\neq q \\
   a(N-a) & \text{if } p=q
   \end{cases}$$
>
>Proof:
>First of all, we have that $E(0)=E(N)=0$. Then
>$$\begin{align*}
   E(a) &= \mathbb{E}(T | X_{0}=a+1)\\
   &= \sum\limits_{k\in\set{-1,1}}^{}\mathbb{E}(T | Z_{1}=k,X_{0}=a+1)\mathbb{P}(Z_{1}=k|X_{0}=a+1)\\
   \end{align*}$$
>since $Z_{1}=k$ for $K=-1,1$ forms a [[Partitions|partition]] of the [[Sample space, Sample points, and Events|sample space]] and we can use a modified version of [[The Law of Total Conditional Probability]].
>
>Now note that
>$$\begin{cases}
   Z_{1}=1 \implies X_{1}=(a+1)+1 \\
   Z_{1}=-1 \implies X_{1}=(a+1)-1 \\
   \end{cases}$$
>hence $Z_{1}=k \implies X_{1}=(a+1)+k$. Therefore
>$E(a)=\sum\limits_{k\in\set{-1,1}}^{}\mathbb{E}(T | X_{1}=a+k+1,X_{0}=a+1)\mathbb{P}(Z_{1}=k)$
>
>Now using the [[Markov chains and processes|memoryless property]],
>$$\begin{align*}
   E(a) &= \sum\limits_{k\in\set{-1,1}}^{}\mathbb{E}(T | X_{1}=a+k+1)\mathbb{P}(Z_{1}=k)\\
   &= \mathbb{E}(T | X_{1}=a)\mathbb{P}(Z_{1}=-1)+\mathbb{E}(T|X_{1}=a+2)\mathbb{P}(Z_{1}=1)\\
   &= (1+\mathbb{E}(T|X_{0}=a))q+(1+\mathbb{E}(T|X_{0}=a+2))p\\
   &= (1+E(a-1))q + (1+E(a+1))p\\
   &= E(a-1) + E(a+1) + 1
   \end{align*}$$
>Note that $\mathbb{E}(X_{t}=i|X_{1}=a)=1+\mathbb{E}(X_{t}=i|X_{0}=a)$ is assumed to be true.
>
>Using the fact that $p+q=1$ we have
>$$\begin{align*}
   E(a)(p+q) &= E(a-1)q+E(a+1)p+1\\
   \iff pE(a)+qE(a) &= E(a-1)q+E(a+1)p+1\\
   \iff q(E(a)-E(a-1))-1 &= p(E(a+1)-E(a))\\
   \iff E(a+1)-E(a) &= (E(a)-E(a-1)-1)\frac{q}{p}\\
   \iff E(a+1)-E(a) &= (E(a)-E(a-1))\frac{q}{p}- \frac{1}{p}\\
   \end{align*}$$
>
>And in particular
>$E(2)-E(1)=(E(1)-E(0)) \frac{q}{p} - \frac{1}{p} = E(1) \frac{q}{p} - \frac{1}{p}$
>$E(3)-E(2)=(E(2)-E(1)) \frac{q}{p} - \frac{1}{p} = \left(E(1) \frac{q}{p} - \frac{1}{p}\right) \frac{q}{p}- \frac{1}{p} = E(1)\left(\frac{q}{p}\right)^{2}- \frac{q}{p^{2}}- \frac{1}{p}$
>$E(4)-E(3)=(E(3)-E(2)) \frac{q}{p}-\frac{1}{p}=\left(E(1)\left(\frac{q}{p}\right)^{2}- \frac{q}{p^{2}}- \frac{1}{p}\right) \frac{q}{p} -\frac{1}{p}=E(1) \left(\frac{q}{p}\right)^{3}- \frac{q^{2}}{p^{3}} - \frac{q}{p^{2}} - \frac{1}{p}$
>$\vdots$
>$E(a+1)-E(a)=E(1) \left(\frac{q}{p}\right)^{a} - \frac{1}{p} \sum\limits_{k=0}^{a-1} \left(\frac{q}{p}\right)^{k}$ (for $0<a<N$)
>
>Now adding up all the above equations, we have that
>See lecture notes
>
>Case 1: $p=q=0.5$:
>See lecture notes
>
>Case 2: $p\neq q$:
>Omitted