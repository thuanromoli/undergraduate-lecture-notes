---
tags:
  - MT4551
aliases:
---
> [!gen] Method
> To determine the strike price of a [[Forward contracts|forward contract]], we apply the law of no [[Arbitrage|arbitrage]].
> Let $S$ be the spot price of a stock. Then if we wish to take out a [[Forward contracts|FC]] to buy a stock at a later time $T>0$, the strike price is
> $$E=S(0)e^{rT}$$
> where $r$ is the [[Risk-free assets|risk-free]] [[Interest rates|interest rate]] over $T$ years.

> [!gen] Avoiding arbitrage
> Suppose we have a 1 year FC such that $E=104$ and $S(0)=100$ ($r=1.04$).
> If the price of a FC > 104, say 110, then the short party can take a profit:
> 1. Borrow 100 from a bank at rate $r$.
> 2. Buy the shares at 100.
> 3. Enter the FC, wait 1 year.
> 4. Hand over the shares and get in return 110.
> 5. Repay the loan of 104.
> 6. Profit 6.
> 
> If the price of a FC < 104, say 102, then the long party can take a profit:
> 1. Borrow shares worth 100 and sell it short.
> 2. Bank the 100 at rate $r$.
> 3. Enter the FC, wait 1 year.
> 4. Buy the shares at 102 using the banked money 104.
> 5. Hand over the shares to the owner.
> 6. Profit 2.
> 
> To remember what to borrow, think what commodity you end up with.
> For example if I am short, I sell an apple, end up with cash. So borrow cash.
