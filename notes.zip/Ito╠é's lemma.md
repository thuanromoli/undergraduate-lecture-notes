---
tags:
  - MT4551
aliases:
---
> [!thm] Theorem
> Let $x$ be a [[Random variables|rv]] obeying to the stochastic differential equation
> $$dx = a(x,t) dt + b(x,t) dW$$
> where $dW$ is the [[Wiener process]].
> 
> If $G(x,t)$ is a function of the random variable $x$ and time $t$, then
> $$\begin{align*}
   dG &=  \underbrace{\left( \frac{\partial G}{\partial t}  + a \frac{\partial G}{\partial x} + \frac{1}{2} b^{2} \frac{\partial ^{2}G}{\partial x^{2}}\right)dt}_\text{deterministic term} + \underbrace{b \frac{\partial G}{\partial x} dW}_\text{random term}\\
   &= \left(\frac{\partial G}{\partial t} + \frac{1}{2}b^{2} \frac{\partial^{2} G}{\partial x^{2}}\right)dt + \frac{\partial G}{\partial x}dx\\
   \end{align*}$$

> [!gen] Intuition (non rigorous)
> Using a 2D [[Taylor's Theorem|Taylor expansion]], we have
> $$dG = \frac{\partial G}{\partial t}dt + \frac{\partial G}{\partial x}dx + \frac{1}{2} \frac{\partial^{2}G}{\partial x^{2}}dx^{2} + \ldots$$
> Then we need to find $dx$, and $dx^{2}$ to find an expression for $dG$.
> $$dx = a dt + bdW \implies dx^{2} = a^{2}dt^{2}+2ab \cdot dt\cdot dW + b^{2} dW^{2}$$
> and since $dW = \varepsilon \sqrt{dt}$,
> $$\begin{align*}
   dx^{2} &=  a^{2}dt^{2}+2ab \cdot dt \cdot (\varepsilon \sqrt{dt}) + b^{2}\varepsilon^{2}dt\\
   &= a^{2}dt^{2}+2ab \varepsilon \cdot dt^{\frac{3}{2}}+b^{2}\varepsilon^{2}dt.
   \end{align*}$$
> We now proceed to drop higher than linear order terms and using the fact that $\varepsilon \sim N(0,1)$ and $\text{Var} (\varepsilon)= \mathbb E(\varepsilon^{2})- \mathbb E(\varepsilon)^{2}\implies1=\mathbb E(\varepsilon^{2})-0^{2}\implies \mathbb E(\varepsilon^{2})=1 \implies \varepsilon^{2}=1$, we obtain
> $$dx^{2} = b^{2}dt.$$
> By substituting into the original expression for $dG$ and by re-arranging we achieve the wanted result.
