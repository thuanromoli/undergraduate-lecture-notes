---
tags:
  - MT2502
aliases:
---
Let $(X,<)$ be an [[Ordered sets|ordered set]],

> [!def] Definition
> $(X,<)$ is called complete if every non-empty set which is [[Boundedness|bounded above]] has a [[Supremum and infimum|supremum]].
