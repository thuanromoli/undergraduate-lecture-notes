---
tags:
  - MT4528
type: def
aliases:
  - homogeneous Markov chain
---
>[!def] Discrete-time
>A [[Markov chains and processes|Markov chain]] $\set{X_{t}:t=0,1,...}$ with [[State spaces|state space]] $S$ is called homogeneous if $$p_{ij}^{(t)}=p_{ij}$$ for all $t\in \mathbb{N}$ and $i,j\in S$.
>That is, we postulate that the [[One-step transition probabilities|transition probabilities]] are time-[[Independent events|independent]].

>[!def] Continuous-time
>A [[Markov chains and processes|Markov process]] $\set{X(t):t \geqslant 0}$ with [[State spaces|state space]] $S$ is called homogeneous if for $t \geqslant s$,
>$$\mathbb P(X(t)=i_{t}|X(s)=i_{s})=\mathbb P(X(t-s)=i_{t}|X(0)=i_{s})$$
>for all $t\in \mathbb R_{\geqslant 0}$ and $i_{t},i_{s}\in S$.
