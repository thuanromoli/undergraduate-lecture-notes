---
tags:
  - MT2502
aliases:
---
Let $(x_{n})_{n}$ be a [[Boundedness|bounded]] [[Sequences|sequence]] of real numbers.

> [!thm] Theorem
> There exists a subsequence $(x_{m_{k}})_{k}$ and a real number $x$ such that $x_{m_{k}} \to x$ as $n \to \infty$.
