---
type: def
tag: MT2507
alias: [kinetic energy,potential,potential energy]
---
>[!def] Definition
>The energy conservation equation states that the total energy of an object is conserved, and can be expressed as the sum of its kinetic energy and its potential energy: $$K+V = \text{constant}= \text{total energy }$$

PROOF:
	From [[Newton's Laws of motion]] we know that the [[Equation of Motion]] is $\boldsymbol{F}=m\frac{d\boldsymbol{v}}{dt}$
	Then $\boldsymbol{F}=m\frac{d\boldsymbol{v}}{dt}$ $\implies$ $$\boldsymbol{F}\cdot\boldsymbol{v}= m\frac{d\boldsymbol{v}}{dt}\cdot\boldsymbol{v}=\frac{1}{2}m\left(2\boldsymbol{v}\cdot \frac{d \boldsymbol{v}}{dt}\right)=\frac{1}{2}m\left(\frac{d}{dt}(v^{2})\right)=\frac{d}{dt}\left(\frac{1}{2}mv^{2}\right)$$
		since $\frac{d}{dt}(v^{2})=2v \frac{dv}{dt}$ and $\left(2\boldsymbol{v}\cdot \frac{d \boldsymbol{v}}{dt}\right)$ = $(2v_{x}\boldsymbol{i}+2v_{y}\boldsymbol{j}+2v_{z}\boldsymbol{k})\cdot\left(\frac{dv_{x}}{dt}\boldsymbol{i}+\frac{dv_{y}}{dt}\boldsymbol{j}+\frac{dv_{z}}{dt}\boldsymbol{k}\right)$ = $\left(2v_{x} \frac{dv_{x}}{dt}+2v_{y} \frac{dv_{y}}{dt}+2v_{z} \frac{dv_{z}}{dt}\right)$ = $\frac{d}{dt}(v_{x}^{2}+v_{y}^{2}+v_{z}^{2})$ = $\frac{d}{dt}\left(\frac{1}{2}m|\boldsymbol{v}|^{2}\right)$
	The quantity $K=\frac{1}{2}(mv^{2})$ is the kinetic energy
	The quantity $\boldsymbol{F} \cdot \boldsymbol{v}= \frac{dK}{dt}$ is the rate at which the energy $K$ is transferred to the object by the force.
	If the force moves the object from $A$ to $B$ in a time interval $[t_0,t_1]$ then $$\frac{dK}{dt} = \boldsymbol{F} \cdot \boldsymbol{v} \implies K(t_{1})-K(t_{0}) = \int_{t_{0}}^{t_{1}} \boldsymbol{F} \cdot \boldsymbol{v} \text{ dt} = \int_{A}^{B} \boldsymbol{F} \cdot d \boldsymbol{r}$$
		since $\int_{t_{0}}^{t_{1}} \text{LHS }dt = \int_{t_{0}}^{t_{1}} \frac{dK}{dt}dt=K(t_{1})-K(t_{0})$ and $\int_{t_{0}}^{t_{1}} \text{RHS }dt = \int_{t_{0}}^{t_{1}} \boldsymbol{F}\cdot \boldsymbol{v} \ dt=\int_{t_{0}}^{t_{1}} \boldsymbol{F}\cdot \frac{d \boldsymbol{r}}{dt} dt=\int_{A}^{B} \boldsymbol{F} \cdot d \boldsymbol{r}$
	If the force $\boldsymbol{F}$ is conservative (it's [[Independence of path|path independent]]) then we can write $\boldsymbol{F}=-\nabla V=- \frac{dV}{d \boldsymbol{r}}$ for some scalar $V$ called the potential, and $$K(t_{1})-K(t_{0})=-\int_{A}^{B} \nabla V \cdot d \boldsymbol{r}=V(A)-V(B)$$
	In particular $$K(t_1)+V(B)=K(t_{0})+V(A)$$
	Hence the value of $E=K+V$ does not change over time.

>[!def] Definition
>The kinetic energy $K=\frac{1}{2}mv^{2}$ is the energy an object has due to it's motion

>[!def] Definition
>The potential (energy) $V$ is a [[Scalar fields|scalar]] [[Functions|function]] that satisfies the energy conservation equation (see [[General motion in a 1D potential]])

>[!def] Definition
>The work done by the force on an object to move it from position $A$ to $B$ is $$\int_{A}^{B} \boldsymbol{F} \cdot d \boldsymbol{r}$$
