---
tags:
  - MT3508
aliases:
---
Suppose we have carried out a [[One-way ANOVA|one-way Anova]] and we rejected the null hypothesis that $\mu_{1}= \cdots = \mu_{p}=\mu$.

> [!gen] [[Statistical hypothesis|Hypothesis]]
> $H_{0}$: $\mu_{j} = \mu \;\;\forall j \in \set{1,...,p}$.
> $H_{1}$: $\mu_{j} \neq \mu_{j^{*}}$ for some $j^{*}\in \set{1,...,p} \setminus \set{j}$.

> [!gen] [[Test statistics]]
> $$\begin{align*}
   T &= \frac{\overline {Y_{j}} - \overline {Y_{j^{*}}}}{\sqrt{s^{2}\left(\frac{1}{n_{j}} + \frac{1}{n_{j^{*}}}\right)}}\\
   &= \frac{\overline {Y_{j}} - \overline {Y_{j^{*}}}}{\sqrt{s^{2}\left(\frac{1}{n_{j}} + \frac{1}{n_{j^{*}}}\right)}}\cdot \sqrt{\frac{\frac{(n-p)s^{2}}{\sigma^{2}}}{\frac{(n-p)s^{2}}{\sigma^{2}}}}\\
   &= \frac{\overline {Y_{j}} - \overline {Y_{j^{*}}}}{\sqrt{s^{2}\left(\frac{1}{n_{j}} + \frac{1}{n_{j^{*}}}\right)}}\cdot \frac{\frac{\sqrt{(n-p)}s}{\sigma}}{\sqrt{D_{1}^{*}}}\\
   &= \frac{(\overline {Y_{j}} - \overline {Y_{j^{*}}})/{\sqrt{\sigma^{2}\left(\frac{1}{n_{j}} + \frac{1}{n_{j^{*}}}\right)}}}{\sqrt{D_{1}^{*}/(n-p)}} \sim t_{n-p}
   \end{align*}$$

> [!gen] Method
> We calculate a [[Normal confidence intervals|t confidence interval]] with $\alpha_{B}$ or $\alpha_{S}$ from [[Bonferroni and Sidak corrections]].
> We assume that $n_{1}= \cdots = n_{p}=m$.
> Then $T = \frac{\overline {Y_{j}} - \overline {Y_{j^{*}}}}{\sqrt{s^{2}\left(\frac{1}{m} + \frac{1}{m}\right)}} = \frac{\overline {Y_{j}} - \overline {Y_{j^{*}}}}{\sqrt{2s^{2}/m}}$.
> And the confidence interval for $T$, denoted by $t_{n-p;1-\alpha_{B}/2}$ is
> $$\begin{align*}
   & -t_{n-p;1-\alpha_{B}/2} < T < t_{n-p;1-\alpha_{B}/2}\\
   \implies& -t_{n-p;1-\alpha_{B}/2} < \frac{\overline {Y_{j}} - \overline {Y_{j^{*}}}}{\sqrt{2s^{2}/m}} < t_{n-p;1-\alpha_{B}/2}\\
   \implies& -\sqrt{\frac{2s^{2}}{m}}t_{n-p;1-\alpha_{B}/2} < \overline {Y_{j}} - \overline {Y_{j^{*}}} < \sqrt{\frac{2s^{2}}{m}}t_{n-p;1-\alpha_{B}/2}\\
   \implies& \left| \overline {Y_{j}} - \overline {Y_{j^{*}}} \right |<\sqrt{\frac{2s^{2}}{m}}t_{n-p;1-\alpha_{B}/2}.
   \end{align*}$$
> Then in `R` we calculate the distances $\left|\overline {Y_{j}} - \overline {Y_{j^{*}}}\right|$ and if they are greater than the critical value $\sqrt{\frac{2s^{2}}{m}}t_{n-p;1-\alpha_{B}/2}$, we reject the null hypothesis.
