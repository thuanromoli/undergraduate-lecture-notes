---
tags:
  - MT3506
aliases:
---
Let $\nabla^{2} \phi = - \rho(x,y,z)$ be [[Poisson's equation]].

>[!def] Definition
>The Green's function $G(\boldsymbol{r},\boldsymbol{r}')$ is a 3-dimensional version of [[Green's function]] such that
>$$\nabla^{2} G(\boldsymbol{r},\boldsymbol{r}')=-\delta^{3}(\boldsymbol{r},\boldsymbol{r}')=- \delta(x-x')\delta(y-y')\delta(z-z')$$
> where $\delta^{3}(\boldsymbol{x}-\boldsymbol{x}')=0$ if $\boldsymbol{r}\neq\boldsymbol{r}'$ is a generalisation of [[Delta and Heaviside functions|the Dirac delta function]].
> 
>This ensures that $\phi(\boldsymbol{r}) = \iiint_{V'}G(\boldsymbol{r},\boldsymbol{r}')\rho(\boldsymbol{r'})dV'$ is a solution to [[Poisson's equation]].

> [!gen] Motivation
> If $\phi(\boldsymbol{r}) = \iiint_{V'}G(\boldsymbol{r},\boldsymbol{r}')\rho(\boldsymbol{r'})dV'$ is the solution to Poisson's equation, we expect $\nabla^{2}\phi=-\rho$.
> In fact
> $$\begin{align*}
   \nabla^{2}\phi(\boldsymbol{r}) &= \iiint \nabla^{2}G(\boldsymbol{r},\boldsymbol{r}') \rho(\boldsymbol{r}')dV'\\
   &= \iiint -\delta^{3}(\boldsymbol{r}-\boldsymbol{r}') \rho(\boldsymbol{r}')dV'\\
   &= -\iiint \delta(x-x')\delta(y-y')\delta(z-z')\rho(x',y',z')dx'dy'dz'\\
   &= -\iint \delta(x-x')\delta(y-y') \int_{z'}^{}\delta(z-z')\rho(x',y',z')dz'dy'dx'\\
   &= -\iint \delta(x-x')\delta(y-y') \rho(x',y',z)dy'dx'\\
   &= -\int\delta(x-x')\int_{y'}^{}\delta(y-y')\rho(x',y',z)dy'dx'\\
   &= -\int\delta(x-x')\rho(x',y,z)dx'\\
   &= -\rho(x,y,z).
   \end{align*}$$
