---
tags:
  - MT3503
aliases:
---
Let $\gamma$ be a positively oriented [[Contours|contour]] and let $f: U \to \mathbb C$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] defined on an [[Open sets|open subset]] $U$ such that $\gamma^{*} \cup I(\gamma) \subset U$

> [!thm] Theorem
> Suppose that $f$ is [[Holomorphic functions|holomorphic]] on $U$, except that $f$ has $P$ poles (including multiplicities) inside $\gamma$.
> Assume that $f$ is non-zero on $\gamma$ and has $Z$ zeros (including multiplicities) inside $\gamma$. Then
> $$\frac{1}{2\pi i} \int_{\gamma} \frac{f'(z)}{f(z)} \, \mathrm{d}z = Z - P.$$
