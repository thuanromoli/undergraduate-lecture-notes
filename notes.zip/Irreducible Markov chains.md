---
tags:
  - MT4528
type: def
aliases:
  - irreducible
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S$.

>[!def] Definition
>A Markov chain is called irreducible if there is only one [[communication]] class.
