---
tags:
  - MT4003
aliases:
  - automorphism
  - inner automorphism
---
Let $G$ be a [[Groups|group]].

> [!def] Definition
> An automorphism of $G$ is an [[Isomorphisms|isomorphism]] $\phi: G \to G$.

> [!def] Definition
> An inner automorphism of $G$ is a [[Conjugacy|conjugation]] [[Functions|map]]
> $$\begin{align*}
   \tau_{g} : G &\to G\\
   x &\mapsto x^{g}
   \end{align*}$$
> for some $g \in G$.
