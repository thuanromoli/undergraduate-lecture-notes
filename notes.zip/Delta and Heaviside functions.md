---
tags:
  - MT3504
type: def
aliases:
  - the Dirac delta function
---
>[!def] Explicit definition
>$\delta(x-x_{0})$ is a [[Functions|function]] defined as
>$$\delta(x-x_{0}) = \begin{cases}
   0, \; \; x \neq x_{0}\\
   \infty, \; \; x = x_{0}
  \end{cases} $$
>with the normalisation $$\int\limits_{-\infty}^{\infty} \delta(x-x_{0})dx=1$$
>
>That is, if we have an interval $I=[a,b]$ and $x_{0} \in I$, then
>$$\int_{I} \delta(x-x_{0}) dx = \begin{cases}
   1, \;\; x_{0} \in I \\
   0, \;\; x_{0} \notin I
   \end{cases}$$
>This is true as if $x_{0}$ lies in $I$, then $1 = \int\limits_{-\infty}^{\infty} \delta(x-x_{0}) dx=\int\limits_{-\infty}^{a} \delta(x-x_{0}) dx + \int\limits_{a}^{b} \delta(x-x_{0}) dx \int\limits_{b}^{\infty} \delta(x-x_{0}) dx = \int\limits_{a}^{b} \delta(x-x_{0}) dx$

>[!def] Function definition
>$\delta(x-x_{0})$ is a [[Functions|function]] such that
>$$\int_{-\infty}^{\infty} f(x)\delta(x-x_{0})dx=f(x_{0}) \;\;\forall f(x)$$

>[!def] Limit definition
>$\delta_{\varepsilon} (x-x_{0})$ is a [[Functions|function]] defined as
>$$\delta_{\varepsilon}(x-x_{0})=\begin{cases}
   0  & \;\; |x-x_{0}|>\varepsilon/2 \\
   \frac{1}{\varepsilon} & \;\; |x-x_{0}| \leqslant \varepsilon/2
   \end{cases}$$
>or as a [[Continuity|continuous]] function
>$$\delta_{\varepsilon}(x-x_{0})=\frac{1}{\sqrt{\pi \varepsilon}}e^{-(x-x_{0})^{2}/\varepsilon}$$
>Both of these satisfy
>$$\int_{-\infty}^{\infty}\delta_{\varepsilon}(x-x_{0})dx=1$$
>and for any $\varepsilon>0$ and in both cases we define
>$$\delta(x-x_{0})=\lim_{\varepsilon\to 0}\delta_\varepsilon(x-x_{0})$$

>[!def] Heaviside step function definition
>$\delta(x-x_{0})$ is a [[Functions|function]] such that
>$$\delta(x-x_{0})=\frac{d}{dx}(H(x-x_{0}))$$
>where $H(x-x_{0})$ is the Heaviside function defined by
>$$H(x-x_{0})=\begin{cases}
   0 & \;\; x<x_{0} \\
   1 & \;\; x>x_{0}
   \end{cases}$$

Limit definition is
$h_{\varepsilon}(x) = \int_{-\infty}^{x} \delta_\varepsilon (x)dx$