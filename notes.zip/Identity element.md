---
type: def
tag: MT2505
alias: [identity element,identity]
---
Let $A$ be a set and $*$ be a [[Binary operations|binary operation]] on $A$.

>[!def] Definition
>An identity is an element $e \in A$ such that: $e*a = a*e = a \ \ \forall a \in A$.
