---
type: mthd
tag: MT2506
---
Given the integral $I= \iint_{S}f(x,y)\ \text{d}x \ \text{d}y$, reduce it to $I= \oint_{C}p \ \text{d}x +q \ \text{d}y$.
Recall [[Green's Theorem]]. We need to find two [[functions]] $p(x,y)$ and $q(x,y)$ that satisfiy $\frac{\partial q}{\partial x}- \frac{\partial p}{\partial y}=f(x,y)$.
We can do any of the following:
1. Let $p(x,y)=0$ and find $q(x,y)$ by integrating $f(x,y)$ with respect to $x$.
2. Let $q(x,y)=0$ and find $p(x,y)$ by integrating $-f(x,y)$ with respect to $y$.
3. Take any appropriate linear combination of the above two solutions that satisfy $\frac{\partial q}{\partial x}- \frac{\partial p}{\partial y}=f(x,y)$.

---

#### Spaced repetition

How do you reduce a planar integral to a line integral using Green's Theorem?
?
We can do any of the following:
1. Let $p(x,y)=0$ and find $q(x,y)$ by integrating $f(x,y)$ with respect to $x$.
2. Let $q(x,y)=0$ and find $p(x,y)$ by integrating $-f(x,y)$ with respect to $y$.
3. Take any appropriate linear combination of the above two solutions that satisfy $\frac{\partial q}{\partial x}- \frac{\partial p}{\partial y}=f(x,y)$.