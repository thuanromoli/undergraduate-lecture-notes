---
tags:
  - MT4003
aliases:
---
Let $G$ be a [[Groups|group]].

> [!thm] Theorem
> $G$ is isomorphic to a [[Permutations and Cycles|permutation]] group.

Proof:
This is a consequence of [[Permutation representation|permutation representations]].
