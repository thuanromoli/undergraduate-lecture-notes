---
tags:
  - MT4551
aliases:
---
> [!def] Definition
> A foreign currency exchange [[Forward contracts|forward contract]] is used to protect against any risk associated with exchange rate changes.
> - FC is used to fix the price of a currency and therefore know how much it costs.
> - Value of FC does not depend on exchange rate movements (which is unknown).

> [!gen] Determining the strike price
> Consider the following FC: "Buying and selling €10M in 1 year at the strike price $E$". 
> The exchange rate today is €1.00 = £0.75, the UK [[Risk-free assets|risk-free]] rate is $r=4\%$, and the EU [[Risk-free assets|risk-free]] rate is $r=3\%$.
> Use the following method to determine the strike price:
> 
> ![[fxfc_att.png]]
> 

> [!gen] Avoiding arbitrage 
> If the price of the FC > E, say £8M, then the short party can take a profit:
> 1. Borrow £7.282M and then convert it to €9.709M.
> 2. Bank € at $r=3\%$.
> 3. Sell FC for €10M and wait 1 year.
> 4. After 1 year the bank has €10M so hand over and get £8M.
> 5. Repay the bank £7.573M.
> 6.Profit is £0.43M.
> 
> If the price of the FC < E, say £7M, then the long party can take a profit:
> 1. Borrow €9.709M and convert it to £7.282M.
> 2. Bank £ at $r=4\%$.
> 3. Buy FC for £7M and wait 1 year.
> 4. After 1 year the bank has £7.573M so fulfil the contract and obtain €10M.
> 5. Repay the bank €10M.
> 6. Profit is £0.573M.
