---
type: def
tag: MT2506
---
Let $\boldsymbol F(\boldsymbol x)$ be a [[Vector fields|vector field]] and let $\boldsymbol r(s)$ be a curve.

>[!def] Definition
>The closed [[Line integral of a vector field|line integral]] of the vector field is: 
>$$\oint_{C}\boldsymbol F(\boldsymbol r) \cdot \text{d}\boldsymbol r = \int_{s_1}^{s_2}\boldsymbol F(\boldsymbol r(s)) \cdot\frac{\text{d}\boldsymbol r(s)}{\text{d}s} \text{d}s=\int_{s_1}^{s_2}g(s) \ \text{d}s$$
>where $g(s) \equiv \boldsymbol F(\boldsymbol r(s)) \cdot\frac{\text{d}\boldsymbol r(s)}{\text{d}s}$ and crucially $\boldsymbol r(s_1) = \boldsymbol r(s_2)$.

