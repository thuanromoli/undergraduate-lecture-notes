---
tags:
  - MT3501
  - MT3506
aliases:
---
See [[Legendre's equation]]