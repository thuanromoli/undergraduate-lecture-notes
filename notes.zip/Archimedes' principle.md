---
tags:
  - MT4509
aliases:
---
Consider a stationary volume, impermeable, and completely submerged in a fluid of uniform density.

> [!thm] Theorem
> The buoyant force is
> $$\boldsymbol{F}= \rho g V \boldsymbol{k}$$

The force into the body is the pressure and recall from [[Euler's equation]] that
$$\boldsymbol{F}=- \iint_{S \text{ closed}}p \boldsymbol{n}\;dS = -\iiint_{V} \nabla p\;dV$$
This result depends only on the boundary pressure and on the outside of the body the pressure is $p=p_{0}-\rho gz$. So upon substituting the boundary pressure into the equation, we obtain

$$\boldsymbol{F}=-\iiint_{V}\nabla (p_{0}-\rho gz)dV=+\iiint_{V}\rho g \boldsymbol{k} \;dV=\rho g V \boldsymbol{k}>0$$
Upthrust! Note $\rho$ is the density of the fluid, this calculation is fully independent of the $\rho$ of the object, which need not be uniform.
