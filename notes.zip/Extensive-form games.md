---
tags:
  - MT4554
type: def
aliases:
---
>[!def] Definition
>A extensive-form game is a scenario which has the following six elements:
>1. A finite set of players, $i \in \mathcal{N}=\set{1,...,N}$.
>2. An ordering of play, usually specified by a game tree, in which each node has exactly one predecessor, such that each terminal node corresponds to a unique history $H$ of events occurring during the game.
>3. A payoff function, $u_{i}$ for each player which is a function of the history $H$ of each terminal node.
>4. The information available to each player at each node in the game tree.
>5. The set of actions $A_{i}$ available to each player $i$ at a given node.
>6. The probability distributions over exogenous events.
