---
tags:
  - MT3506
aliases:
---
Let $f(x)$ and $g(x)$ be two [[Functions|functions]] with well-defined [[Fourier Transform|Fourier Transforms]] $\tilde f(k)$ and $\tilde g(k)$.

> [!def] Definition
> The convolution of $f(x)$ and $g(x)$ is
> $$(f * g)(x) = \int_{-\infty}^{\infty}f(x')g(x-x')dx'.$$
