---
tags:
  - MT4527
aliases:
---
Let $(X_{t})_{t \in \mathbb Z}$ be a [[Stochastic processes|stochastic process]].

> [!def] Definition
> The lag-$d$ difference operator $\nabla_{d}$ is defined by
> $$\nabla_{d} X_{t} = X_{t}-X_{t-d} = (1-B^{d})X_{t}$$
> where $B$ is the backward shift operator
> $$B^{d}X_{t} = X_{t-d}.$$
