---
type: def
tags: MT2505
---
Let $a,b\in \mathbb{Z}$ such that at least one of $a$ and $b$ is non-zero.

>[!def] Definition
>$a$ and $b$ are coprimes if $\gcd(a,b)=1$

