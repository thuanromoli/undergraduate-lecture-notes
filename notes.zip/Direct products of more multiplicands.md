---
tags:
  - MT4003
aliases:
---
Let $G_{1}, G_{2},..., G_{k}$ be [[Groups|groups]].

> [!def] Definition
> The direct product of groups $G_{1}, G_{2},..., G_{k}$ is
> $$G_{1} \times G_{2} \times \cdots \times G_{k} = \set{(g_{1},g_{2},...,g_{k}):g_{i}\in G_{i}\;\text{ for each }i},$$
> the set of ordered $n$-tuples of elements in $G_{1},G_{2},...,G_{k}$ with multiplication given by
> $$(g_{1},g_{2},...,g_{k})(h_{1},h_{2},...,h_{k}) = (g_{1}h_{1},g_{2}h_{2},...,g_{k}h_{k}).$$

> [!thm] Theorem
> The direct product $G_{1} \times G_{2} \times \cdots \times G_{k}$ under the above multiplication is a group.
> Proof is straight forward and is omitted.
