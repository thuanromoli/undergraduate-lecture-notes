---
tags:
  - MT4551
aliases:
---
> [!def] Definition
> There are two types of barrier options. For each, two quantities are specified, $E$ the strike price and $X$ the barrier price.
> The two types are:
> - Out: worthless IF share price crosses barrier before expiry.
> - IN: worthless UNLESS share price crosses barrier before expiry.
