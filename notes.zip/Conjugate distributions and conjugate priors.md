---
tags:
  - MT3507
  - MT4531
aliases:
---
> [!def] Conjugate distributions
> A family of probability distributions, $\mathcal F$, is conjugate to a family of sampling distributions $\mathcal P$, if whenever the prior belongs to the family $\mathcal F$, then for any sample size and any value of observations, the posterior also belongs to the family $\mathcal F$.

>[!def] Conjugate priors
> A **_conjugate_** prior distribution is one for which the posterior must belong to the same family of distributions.
