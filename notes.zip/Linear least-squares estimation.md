---
tags:
  - MT3501
type: thm
aliases:
---
Let $A$ be a real $m\times n$ [[Matrices|matrix]] and suppose that $\ker A=\set{\boldsymbol{0}}$.
Note that if $\boldsymbol{u}=\begin{pmatrix}x_{1}\\\vdots\\x_{m} \end{pmatrix},\boldsymbol{v}=\begin{pmatrix}y_{1}\\\vdots\\y_{m} \end{pmatrix}\in \mathbb R^{m},$ the [[Inner product spaces|inner product]] on $\mathbb R^{m}$ is the dot product:
$$\langle \boldsymbol{u},\boldsymbol{v} \rangle = \boldsymbol{u}\cdot \boldsymbol{v}=\sum\limits_{i=1}^{n}x_{i}y_{i}=\boldsymbol{u}^{T}\boldsymbol{v}$$
Then:

>[!thm]- The matrix $A^{T}A$ is [[The inverse of a matrix|invertible]]
>Note that $A^{T}$ is a $n \times m$ matrix so the product $A^{T}A$ is an $n \times n$ matrix.
>Suppose $\boldsymbol{v}\in ker A^{T}A$. Then $A^{T}A \boldsymbol{v}=\boldsymbol{0}$. Then
>$\langle A \boldsymbol{v},A \boldsymbol{v} \rangle$ = $(A \boldsymbol{v})^{T}\cdot A \boldsymbol{v}=\boldsymbol{v}^{T}A^{T}A \boldsymbol{v}=\boldsymbol{v}^{T}\boldsymbol{0}=\langle \boldsymbol{v},\boldsymbol{0} \rangle=0$.
>Hence $A \boldsymbol{v}=\boldsymbol{0}$, so $\boldsymbol{v}=0$ since $\ker A=\set{\boldsymbol{0}}$.
>This shows that $\ker A^{T}A=\set{\boldsymbol{0}}$ and that $A^{T}A$ is an invertible matrix.

>[!thm]- The matrix $P=A(A^{T}A)^{-1}A^{T}$ is the [[Projection maps|projection map]] on to the [[Image|image]] $U=\text{im }A$ associated to the [[Direct sums|direct sum]] decomposition $\mathbb R^{m}=U \oplus U^{\perp}$
>Note that $A^{T}A$ is an invertible $n \times n$ matrix, and so we may form $P$ and this is an $m \times m$ matrix.
>Let $\boldsymbol{v}\in \mathbb R^{m}$. Then
>$$P \boldsymbol{v}=(A(A^{T}A)^{-1}A^{T} )\boldsymbol{v}=A((A^{T}A)^{-1}A^{T} \boldsymbol{v})\in \text{im }A=U$$
>Now consider $\boldsymbol{y}=\boldsymbol{v}-P \boldsymbol{v}\in \mathbb R^{m}$. If $\boldsymbol{w}$ is any vector in $\mathbb R^{n}$, then
>$$\begin{align*}
   \langle A \boldsymbol{w},\boldsymbol{y} \rangle &= \langle A \boldsymbol{w},\boldsymbol{v}-P \boldsymbol{v} \rangle\\
   &= \langle A \boldsymbol{w},\boldsymbol{v} \rangle - \langle A \boldsymbol{w},P \boldsymbol{v} \rangle\\
   &= (A \boldsymbol{w})^{T}\boldsymbol{v} - (A \boldsymbol{w})^{T}P\boldsymbol{v}\\
   &= \boldsymbol{w}^{T}A^{T}\boldsymbol{v} - \boldsymbol{w}^{T}A^{T}P\boldsymbol{v}\\
   &= \boldsymbol{w}^{T}A^{T}\boldsymbol{v} - \boldsymbol{w}^{T}A^{T}(A(A^{T}A)^{-1}A^{T} )\boldsymbol{v}\\
   &= \boldsymbol{w}^{T}A^{T}\boldsymbol{v} - \boldsymbol{w}^{T}(A^{T}A)(A^{T}A)^{-1}A^{T} \boldsymbol{v}\\
   &= \boldsymbol{w}^{T}A^{T}\boldsymbol{v} - \boldsymbol{w}^{T}A^{T}\boldsymbol{v}\\
   &= 0\\
   \end{align*}$$
>Hence $\boldsymbol{y}$ is [[Orthogonality|orthogonal]] to $A \boldsymbol{w}$ for every $\boldsymbol{w}\in \mathbb R^{n}$; that is, $\boldsymbol{y}\in (\text{im }A)^{\perp}=U^{\perp}$, the [[Orthogonal complements|orthogonal complement]] of $U$. Now
>$$\boldsymbol{v}=P \boldsymbol{v}+(v-P \boldsymbol{v})=P \boldsymbol{v}+\boldsymbol{y}$$
>expresses $\boldsymbol{v}$ as the sum of a vector in $\text{im }A$ and a vector in its orthogonal complement.
>This must therefore be the unique expression for $\boldsymbol{v}$ in terms of the direct sum decomposition $\mathbb R^{m}=\text{im }A \oplus (\text{im A})^{\perp}$.
>Consequently $P \boldsymbol{v}$ is the image of $\boldsymbol{v}$ under the projection map onto $\text{im }A$ associated to this direct sum decomposition.

>[!thm]- If $\boldsymbol{v}\in \mathbb R^{m}$, then $A(A^{T}A)^{-1}A^{T}\boldsymbol{v}$ is the closest vector in $\text{im }A$ to $\boldsymbol{v}$
>By [[Theorems about orthogonal complements#^ddf001|this theorem]], $P \boldsymbol{v}$ is the closest vector in $\text{im }A$ to $\boldsymbol{v}$.

>[!thm] Linear least squares approximation
>Suppose that we are trying to determine how some real-valued function $y=y(t)$ depends on the real variable $t$.
>We shall fit a linear model. That is, we wish to find $\alpha,\beta$ such that $y(t)\approx \alpha t+ \beta$ is a good fit to our data.
>We measure various values of $y$ for values of $t$:
>$$(t_{1},y_{1}),(t_{2},y_{2}),...,(t_{m},y_{m})$$
>Define $A=\begin{pmatrix}t_{1} & 1\\t_{2} & 1 \\ \vdots  & \vdots \\ t_{m} & 1\end{pmatrix}$ and $\boldsymbol{y}=\begin{pmatrix}y_{1} \\ y_{2} \\ \vdots \\ y_{m}\end{pmatrix}$.
>We therefore wish to find $\begin{pmatrix}\alpha \\ \beta\end{pmatrix}$ such that $A \begin{pmatrix}\alpha \\ \beta\end{pmatrix}= \boldsymbol{y}$.
>As long as $t_{1},t_{2},...,t_{m}$ are distinct, $A$ has [[Rank|rank]] 2 and [[Nullity|nullity]] 0.
>So $\ker A=\set{\boldsymbol{0}}$ and the closest vector $\boldsymbol{x}$ in $\text{im }A$ to $\boldsymbol{y}$ is
>$$\boldsymbol{x}=P \boldsymbol{y}=A(A^{T}A)^{-1}A^{T} \boldsymbol{y}$$
>and $\begin{pmatrix}\alpha \\ \beta\end{pmatrix}$ is the unique vector satisfying $A\begin{pmatrix}\alpha \\ \beta\end{pmatrix}= \boldsymbol{x}$
>hence
>$$\begin{pmatrix}\alpha \\ \beta\end{pmatrix}=A^{-1}\boldsymbol{x}=A^{-1}A(A^{T}A)^{-1}A^{T}\boldsymbol{y}=(A^{T}A)^{-1}A^{T}\boldsymbol{y}$$
