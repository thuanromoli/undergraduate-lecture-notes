---
type: mthd
tags: MT2508
---
Let $X$ be a continuous [[Random variables|rv]] and let $Y$ be the corresponding approximate [[Normal distribution|normal]] rv.

Clearly $\mathbb P(Y=x) =0 \neq \mathbb(X=x)$. So we apply a continuity correction:
- $\mathbb P(X=x) \approx \mathbb P(x-0.5\leqslant Y\leqslant x+0.5)$
- $\mathbb P(X \geqslant x) \approx \mathbb P(Y\geqslant x-0.5)$
- $\mathbb P(X \leqslant x) \approx \mathbb P(Y\leqslant x+0.5)$
- $\mathbb P(x_1\leqslant X\leqslant x_2) \approx \mathbb P(x_1-0.5\leqslant Y\leqslant x_2+0.5)$
