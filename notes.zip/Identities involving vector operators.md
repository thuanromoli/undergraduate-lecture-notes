---
type: thm
tag: MT2506
---
>[!gen]+ Identities
>$\nabla\times(\nabla f)=\boldsymbol 0$
>$\nabla\boldsymbol\cdot(\nabla \times\boldsymbol F)=0$
>$\nabla(fg)=f\nabla g +g\nabla f$
>$\nabla(\boldsymbol{F\cdot G})$
>$\nabla\boldsymbol\cdot(f\boldsymbol F)$
>$\nabla\boldsymbol\times(f\boldsymbol F)$
>$\nabla\boldsymbol\cdot(\boldsymbol{F\times G})$

---

#### Spaced repetition

Show that $$\nabla\times(\nabla f)=\boldsymbol 0$$
?
proof omitted

Show that $$\nabla\boldsymbol\cdot(\nabla \times\boldsymbol F)=0$$
?
proof omitted

Show that $$\nabla(fg)=f\nabla g +g\nabla f$$
?
proof omitted