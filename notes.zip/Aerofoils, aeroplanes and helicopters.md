wings are designed so that viscous effects produce vortex
![[wingaerofoil_att.png|300]]
rhs has circulation > 0
so lhs must have $\Gamma<0$ as overall circulation must be 0.
So lift is created.
