---
tags:
  - MT3504
type: mthd
aliases:
---
>[!thm] Method of characteristics (intuition)
>Consider a [[Classification of First-Order PDEs|First-Order PDE]]
>$$au_{x}+bu_{y}=0 \text{ with }u(x,0)=f({x_{0}})$$
>Then this can be written as
>$$\begin{pmatrix}a  \\ b\end{pmatrix}\cdot \begin{pmatrix}u_{x}  \\ u_{y}\end{pmatrix}=\boldsymbol{l}\cdot \nabla \boldsymbol{u}=\boldsymbol{0}$$
>This means that in the direction of $\boldsymbol{l}$, $\boldsymbol{u}$ is constant.
>We seek to find such direction and to do so we simply use the equation of a line or calculus.
>Once we find the direction (this yields an infinite number of lines called characteristics) we apply the initial conditions to fix a line.
>This line has the feature that anywhere along it, $u$ is constant and we do know what $u$ is at this initial conditions. So if we are given any point on the line we can work out what the value of $u$ is.
>
>This process can be generalised by parametrisation which allows for non-constant $a,b,c$.
>We let the characteristic be $[x(s),y(s)]$ and then we let $\frac{dx}{ds}=a$, $\frac{dy}{ds}=b$, $\frac{du}{ds}=c$. This is done such that the following holds:
>$$\begin{align*}
   \frac{du}{ds} &= \frac{\partial u}{\partial x} \frac{dx}{ds}+\frac{\partial u}{\partial y} \frac{dy}{ds}\\
   &= \;\;\; au_{x}\;\;\;+\;\;bu_{y}\;\;=c
   \end{align*}$$

>[!gen] Method 1 
>1. Separate the PDE into three ODEs.
>2. Solve all equations in terms of $s$ and three constants of integration.
>3. Apply initial conditions, wlog let $s=0$ and then $x=x_{0},y=y_{0},u=u_{0}$.
>4. Find $u$ and the characteristics by eliminating variables.

>[!gen] Method 2
>1. Separate the PDE into three ODEs.
>2. Combine the ODEs to obtain two equations in terms of $x,y,u$ and the constant of integration.
>3. Rearrange to have constant of integration as subject.
>4. Apply initial conditions.
>5. Find a single equation (of characteristics) in terms of the constants of integration only by eliminating all variables.
>6. Sub back the previous values obtain for the constants of integration.
