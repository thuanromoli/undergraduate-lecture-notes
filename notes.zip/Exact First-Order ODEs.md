---
type: mthd
tags:
  - MT3504
---
>[!gen] ODE
>$$M(x,y)+N(x,y)y'=0$$
>where $M(x,y)$ and $N(x,y)$ satisfy
>$$\frac{\partial M}{\partial y} = \frac{\partial N}{\partial x}$$

>[!thm] Two functions $M(x,y)$ and $N(x,y)$ satisfy $\frac{\partial M}{\partial y} = \frac{\partial N}{\partial x}$ if and only if there exists a function $F(x,y)$ that satisfies $\frac{\partial F}{\partial x} = M$ and $\frac{\partial F}{\partial y}=N$
>Proof 1: Assume that there exists a function $F(x,y)$ that satisfies $\frac{\partial F}{\partial x} = M$ and $\frac{\partial F}{\partial y}=N$.
>Then $\frac{\partial M}{\partial y} = \frac{\partial^{2} F}{\partial x\partial y}$ and  $\frac{\partial N}{\partial x} = \frac{\partial^{2} F}{\partial y\partial x}$.
>Hence result holds.
>
>Proof 2: Assume that two functions $M(x,y)$ and $N(x,y)$ satisfy $\frac{\partial M}{\partial y} = \frac{\partial N}{\partial x}$.
>We start by defining $\phi(x,y)$ by the definite integral $\phi = \int^{x}M dx$ so that $\frac{\partial \phi}{\partial x}= M$.
>Differentiate wrt $y$: $\frac{\partial \phi}{\partial y}=\int^{x}\frac{\partial M}{\partial y}dx=\int^{x}\frac{\partial N}{\partial x}dx=N(x,y)+f(y)$.
>Now define $F(x,y)$ by $F(x,y)=\phi-\int^{y}f(\eta)d \eta$ where $\eta$ is just a dummy variable.
>Such function has the required properties.

>[!gen] Solution
>$$M(x,y)+N(x,y)y'=0$$
>Firstly, check that $\frac{\partial M}{\partial y}= \frac{\partial N}{\partial x}$
>We seek a function $F(x,y)$ that satisfies $M=\frac{\partial F}{\partial x}$ and $N=\frac{\partial F}{\partial y}$.
>To do this we integrate this pair of equations with respect to $x$ and $y$:
>$F=\int Mdx+f(y)$ and $F=\int N dy + g(x)$.
>Now the ODE may be rewritten as $\frac{\partial F}{\partial x}+\frac{\partial F}{\partial y} \frac{dy}{dx} =0$.
>By the chain rule, $\frac{dF}{dx}=\frac{\partial F}{\partial x}+\frac{\partial F}{\partial y} \frac{dy}{dx} =0$.
>Hence the ODE is equivalent to $\frac{dF}{dx}=0$

>[!gen] Integrating factor
>If $M(x,y)+N(x,y)y'=0$ is not exact, that is$\frac{\partial M}{\partial y} \neq \frac{\partial N}{\partial x}$, then we can sometime use an integrate factor to make it exact:
>$$\mu M(x,y)+\mu N(x,y)y'=0$$
>There are some particularly easy cases:
>- if $\frac{1}{N}\left(\frac{\partial M}{\partial y}-\frac{\partial N}{\partial x}\right)= \zeta(x)$ use $\mu(x)=\exp\left(\int \zeta(x)dx\right)$
>- if $\frac{1}{M}\left(\frac{\partial M}{\partial y}-\frac{\partial N}{\partial x}\right)= \chi(y)$ use $\mu(y)=\exp\left(\int \chi(y)dy\right)$
>
>Proof: we will prove the first one and second one is similar.
>Let $\mu(x) M=\tilde M$ and let $\mu(x) N=\tilde M$.
>Now our equation is $\tilde M(x,y)+\tilde N(x,y)y'=0$ and is exact if $\frac{\partial \tilde M}{\partial y} = \frac{\partial \tilde N}{\partial x}$.
>So we need $\frac{\partial}{\partial y}(\mu M)=\frac{\partial}{\partial x}(\mu N)$ $\iff$ $\mu \frac{\partial M}{\partial y}-N\frac{\partial \mu}{\partial x}-\mu \frac{\partial N}{\partial x}=0$ $\iff$ $\mu\left(\frac{\partial M}{\partial y}-\frac{\partial N}{\partial x}\right)-N \frac{\partial \mu}{\partial x}=0$.
>Using the substitution $\frac{1}{N}\left(\frac{\partial M}{\partial y}-\frac{\partial N}{\partial x}\right)= \zeta(x)$, we obtain $\mu(N \zeta)-N \frac{\partial \mu}{\partial x}=0$ $\implies$ $\frac{d\mu}{dx}=\mu \zeta$ $\implies$ $\mu=\exp\left(\int \zeta dx\right)$

---

#### Spaced repetition

What is the form of an exact first-order ODE?
?
>$$M(x,y)+N(x,y)y'=0$$
>where $M(x,y)$ and $N(x,y)$ satisfy
>$$\frac{\partial M}{\partial y} = \frac{\partial N}{\partial x}$$

Prove that two functions $M(x,y)$ and $N(x,y)$ satisfy $\frac{\partial M}{\partial y} = \frac{\partial N}{\partial x}$ if and only if there exists a function $F(x,y)$ that satisfies $\frac{\partial F}{\partial x} = M$ and $\frac{\partial F}{\partial y}=N$.
?
>Proof 1: Assume that there exists a function $F(x,y)$ that satisfies $\frac{\partial F}{\partial x} = M$ and $\frac{\partial F}{\partial y}=N$.
>Then $\frac{\partial M}{\partial y} = \frac{\partial^{2} F}{\partial x\partial y}$ and  $\frac{\partial N}{\partial x} = \frac{\partial^{2} F}{\partial y\partial x}$.
>Hence result holds.
>
>Proof 2: Assume that two functions $M(x,y)$ and $N(x,y)$ satisfy $\frac{\partial M}{\partial y} = \frac{\partial N}{\partial x}$.
>We start by defining $\phi(x,y)$ by the definite integral $\phi = \int^{x}M dx$ so that $\frac{\partial \phi}{\partial x}= M$.
>Differentiate wrt $y$: $\frac{\partial \phi}{\partial y}=\int^{x}\frac{\partial M}{\partial y}dx=\int^{x}\frac{\partial N}{\partial x}dx=N(x,y)+f(y)$.
>Now define $F(x,y)$ by $F(x,y)=\phi-\int^{y}f(\eta)d \eta$ where $\eta$ is just a dummy variable.
>Such function has the required properties.

How do you solve $M(x,y)+N(x,y)y'=0$?
?
>Firstly, check that $\frac{\partial M}{\partial y}= \frac{\partial N}{\partial x}$
>We seek a function $F(x,y)$ that satisfies $M=\frac{\partial F}{\partial x}$ and $N=\frac{\partial F}{\partial y}$.
>To do this we integrate this pair of equations with respect to $x$ and $y$:
>$F=\int Mdx+f(y)$ and $F=\int N dy + g(x)$.
>Now the ODE may be rewritten as $\frac{\partial F}{\partial x}+\frac{\partial F}{\partial y} \frac{dy}{dx} =0$.
>By the chain rule, $\frac{dF}{dx}=\frac{\partial F}{\partial x}+\frac{\partial F}{\partial y} \frac{dy}{dx} =0$.
>Hence the ODE is equivalent to $\frac{dF}{dx}=0$

>If $M(x,y)+N(x,y)y'=0$ is not exact, that is$\frac{\partial M}{\partial y} \neq \frac{\partial N}{\partial x}$, then we can sometime use an integrate factor to make it exact. What do we do? (Include proof).
>?
>- if $\frac{1}{N}\left(\frac{\partial M}{\partial y}-\frac{\partial N}{\partial x}\right)= \zeta(x)$ use $\mu(x)=\exp\left(\int \zeta(x)dx\right)$
>- if $\frac{1}{M}\left(\frac{\partial M}{\partial y}-\frac{\partial N}{\partial x}\right)= \chi(y)$ use $\mu(y)=\exp\left(\int \chi(y)dy\right)$
>Proof: we will prove the first one and second one is similar.
>Let $\mu(x) M=\tilde M$ and let $\mu(x) N=\tilde M$.
>Now our equation is $\tilde M(x,y)+\tilde N(x,y)y'=0$ and is exact if $\frac{\partial \tilde M}{\partial y} = \frac{\partial \tilde N}{\partial x}$.
>So we need $\frac{\partial}{\partial y}(\mu M)=\frac{\partial}{\partial x}(\mu N)$ $\iff$ $\mu \frac{\partial M}{\partial y}-N\frac{\partial \mu}{\partial x}-\mu \frac{\partial N}{\partial x}=0$ $\iff$ $\mu\left(\frac{\partial M}{\partial y}-\frac{\partial N}{\partial x}\right)-N \frac{\partial \mu}{\partial x}=0$.
>Using the substitution $\frac{1}{N}\left(\frac{\partial M}{\partial y}-\frac{\partial N}{\partial x}\right)= \zeta(x)$, we obtain $\mu(N \zeta)-N \frac{\partial \mu}{\partial x}=0$ $\implies$ $\frac{d\mu}{dx}=\mu \zeta$ $\implies$ $\mu=\exp\left(\int \zeta dx\right)$