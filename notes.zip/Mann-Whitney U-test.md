---
type: mthd
tag: MT2508
---
Given the two sets of [[Random variables|rvs]] $X_1,...,X_n$ and $Y_1,...,Y_m$, carry out a Mann-Whitney U-test.

>[!gen]+ CONDITIONS:
>$X_1,...,X_n$ and $Y_1,...,Y_m$ must be two sets of [[Independent events|independent]] and at least [[Measurement scales of data|ordinal]] rvs, with medians $M_X$ and $M_Y$

>[!gen]+ [[Statistical hypothesis|HYPOTHESIS]]:
>$H_0:M_X=M_Y$ vs $H_1$ can be either one-tailed or two-tailed

>[!gen]+ [[Test statistics|TEST STATISTIC]]:
>$U_X=\sum V_i$

>[!gen]+ METHOD:
>- PRELIMINARY STEPS:
>	1. Pool the two samples toghether and list the observations in increasing order
>	2. replace each observation with an $x$ or a $y$ depending on which sample it came from
>	3. for each $x_i$ evaluate $v_{i}$, the number of $y$ observations which are smaller than $x_i$
>- OBTAINING THE TEST STATISTIC:
>	1. Calculate the observed test statistic ${u_X}_0 = \sum {v_i}_0$
>	2. permute the rvs freely
>	3. evaluate $U_X$ for each permutation
>- PERMUTATION TEST:
>	1. Find the # of [[Permutations and Cycles]] $p$ whose $U_X$ is at least as extreme as ${u_X}_0$
>	2. the $p$-value will be $\frac p {\text{\# all permutations}}$ where ${\text{\# all permutations} = {\text{size of }\boldsymbol X + \boldsymbol Y \choose \text{size of }\boldsymbol X}}$

---

#### Spaced repetition

Given the two sets of [[Random variables|rvs]] $X_1,...,X_n$ and $Y_1,...,Y_m$, carry out a Mann-Whitney U-test.
?
CONDITIONS:
	$X_1,...,X_n$ and $Y_1,...,Y_m$ must be two sets of [[Independent events|independent]] and at least [[Measurement scales of data|ordinal]] rvs, with medians $M_X$ and $M_Y$
[[Statistical hypothesis|HYPOTHESIS]]:
	$H_0:M_X=M_Y$ vs $H_1$ can be either one-tailed or two-tailed
[[Test statistics|TEST STATISTIC]]:
	$U_X=\sum V_i$
METHOD:
	PRELIMINARY STEPS:
		1. Pool the two samples toghether and list the observations in increasing order
		2. replace each observation with an $x$ or a $y$ depending on which sample it came from
		3. for each $x_i$ evaluate $v_{i}$, the number of $y$ observations which are smaller than $x_i$
	OBTAINING THE TEST STATISTIC:
		1. Calculate the observed test statistic ${u_X}_0 = \sum {v_i}_0$
		2. permute the rvs freely
		3. evaluate $U_X$ for each permutation
	PERMUTATION TEST:
		1. Find the # of [[Permutations and Cycles]] $p$ whose $U_X$ is at least as extreme as ${u_X}_0$
		2. the $p$-value will be $\frac p {\text{\# all permutations}}$ where ${\text{\# all permutations} = {\text{size of }\boldsymbol X + \boldsymbol Y \choose \text{size of }\boldsymbol X}}$
