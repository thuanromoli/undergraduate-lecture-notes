---
tags:
  - MT4509
aliases:
---
Let $V$ be a volume fixed in space with surface $S$ and outward normal $\boldsymbol{n}$.

> [!thm] Theorem
> Suppose that a long-range body force $\boldsymbol{F}$ and a short-range molecular force $-p \boldsymbol{n}$ act on $dV$. Then
> $$\iiint_{V} \rho \frac{D \boldsymbol{u}}{Dt}dV = \iiint_{V}(\rho \boldsymbol{F}- \boldsymbol{\nabla }p)dV$$
> where, in particular,
> $$\rho \frac{D \boldsymbol{u}}{Dt}=\rho \boldsymbol{F}- \boldsymbol{\nabla }p$$
> is Euler's equation of motion, which expresses momentum.

![[eulereqn_att.png|400]]

In general,
$$\frac{d}{dt} \text{momentum} = \text{sum of all forces}\quad \text{where} \quad \text{momentum}= \iiint_{V}\rho \boldsymbol{u}\;dV$$

There are two types of forces that act on a volume element.
- Body forces from long-range influences, e.g. gravity, electric field. Proportional to $dV$ and $\rho$. We write "body forces" = $\rho \boldsymbol{F}dV$ where $\boldsymbol F$ = force per unit mass (e.g. gravity, electric field).
- Surface forces of molecular origin, e.g. tangential stress (friction), normal stress, pressure. Proportional to the surface area of an element (not its volume). We write "surface forces" = $-p \boldsymbol{n}dS$ where $-p \boldsymbol{n}$ = force per unit area (e.g. friction, pressure), for some scalar field $p(\boldsymbol{x},t)$.

So the total force on a fluid volume $V$ is
$$\begin{align*}
F_{\text{total}}&=\iiint_{V}\rho \boldsymbol{F}dV+\iint_{S \text{ closed}}-p \boldsymbol{n}dS\\
&=\iiint_{V}\rho \boldsymbol{F}dV+\iiint_{V}- \nabla p dV,
\end{align*}$$
where the second term is obtained by dotting an arbitrary constant vector $\boldsymbol{e}$ and applying Gauss' theorem.

Now we put together all the above information to obtain the momentum equation
$$\begin{align*}
&\frac{D}{Dt}\iiint_{V} \rho \boldsymbol{u}\;dV=\iiint_{V}(\rho \boldsymbol{F-\nabla }p)\;dV\\
\implies& \quad\iiint_{V}\rho \frac{D \boldsymbol{u}}{Dt}dV =\iiint_{V}(\rho \boldsymbol{F-\nabla }p)\;dV
\end{align*}$$
where the LHS is obtained by following [[Derivatives of material integrals#^2d21b2|this note]].

By noting that $V$ is arbitrary and can be infinitesimally small, we have Euler's equation of motion
$$\rho \frac{D \boldsymbol{u}}{Dt}= \rho \boldsymbol{F}- \nabla p.$$

Boundary conditions:
- No normal flow, velocity of a generally moving boundary satisfies $\boldsymbol{u \cdot n}= \boldsymbol{ V \cdot n}$.
- No flow parallel to a boundary (this only applies if viscosity is present).
- Pressure $p$ is continuous across any boundary (as if it weren't, then $\nabla p \to \infty$).
