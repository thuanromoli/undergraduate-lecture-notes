---
tags:
  - MT4527
aliases:
  - classical decomposition model
---
Let $(X_{t})_{t \in \mathbb Z}$ be a [[Stochastic processes|stochastic process]].

> [!def] Classical decomposition model
> $X$ is a classical decomposition model if
> $$X_{t} = m_{t}+s_{t}+Y_{t}, \quad t \in \mathbb Z$$
> where
> - $m_{t}$ is the trend component, a slowly changing function.
> - $s_{t}$ is the seasonal component, a function with known period $d$. Note that $s_{t}=s_{t+d}$ and we assume $\sum\limits_{j=1}^{d}s_{j} = 0$.
> - $Y_{t}$ is the random component, [[Stationarity|stationary]] with zero-mean.

> [!gen]- Remarks
> - Sometimes preliminary transformation of the data is needed (e.g.logarithmic transformation) to make the data more compatible with the classical decomposition model.
> - $m_{t}$ and $s_{t}$ are deterministic components of the model (signals), whereas $Y_{t}$ is the stochastic component (residual or noise).
> - There are two methods to remove eliminate the signals to learn more about the noise. These are (1) estimation of $m_{t}$ and $s_{t}$ and (2) differencing.

> [!gen]- General approach to time series modeling
> 1. Plot the series and examine the main features of the graph, checking in particular whether there is
> 	1. a trend;
> 	2. a seasonal component;
> 	3. any apparent sharp changes in behaviour;
> 	4. any outlying observations.
> 2. Remove the trend and seasonal component to get [[Stationarity|stationary]] residuals.
> 3. Choose a model to fit the remaining model component.
> 4. Forecasting will be achieved by forecasting the remaining component and then inverting any transformations to arrive at forecasts of the original series.

> [!def] Constant mean model
> $$X_{t} = m + Y_{t}.$$

> [!def] Nonseasonal with trend model
> $$X_{t} = m_{t} + Y_{t}.$$

> [!def] Polynomial trend of order $k$ model
> $$X_{t}=\sum\limits_{i=0}^{k}a_{i}t^{i}+Y_{t}.$$
