---
tags:
  - MT4528
type: model
aliases:
---
>[!def] Definition
>The M/M/$\infty$ queue has:
>- [[Poisson processes|Poisson process]] arrivals with rate $\lambda$
>- service times $\overset{iid}{\sim}\text{Exp}(\mu)$
>- (effectively) infinite servers and capacity is $\infty$
>
>This is a [[Birth and death processes|Birth/death process]] where:
>$$\lambda_{n}=\begin{cases}
   \lambda & \text{for all }n
   \end{cases}$$
>$$\mu_{n}=\begin{cases}
   n \mu & \text{for all } n
   \end{cases}$$

>[!thm] Theorem
>For an M/M/1 queue with $\mu>\lambda$, the [[Stationary distributions|stationary distribution]] of the process $\set{X(t):t\geqslant 0}$ is given by
>$$\begin{align*}
   \pi_{n} &= e^{- \frac{\lambda}{\mu}} \frac{1}{n!}\left(\frac{\lambda}{\mu}\right)^{m}
   \end{align*}$$
>
>Proof: see [[Equilibrium distribution of a birth death process|this proposition]], and then use algebra.

>[!thm] Corollary
>$$X(t)\to \text{Poisson}\left( \frac{\lambda}{\mu}\right) \text{ as } t\to \infty$$
