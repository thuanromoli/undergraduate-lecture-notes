---
tags:
  - MT3503
aliases:
---
Let $\gamma:[a,b] \to \mathbb C$ be a piecewise smooth [[Curves|curve]] and $f$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] whose domain contains $\gamma^{*}$ such that $f$ is [[Continuity|continuous]] on $\gamma^{*}$.

> [!def] Definition
> The integral of $f$ along $\gamma$ is defined to be
> $$\int_{\gamma}^{}f(z)dz = \int_{a}^{b} f(\gamma(t))\; \gamma'(t) \; dt.$$

Intuition:
Differentiating a function $F$ parametrised along a curve $\gamma(t)$ would yield
$$F(\gamma(t))'=F'(\gamma(t)) \gamma'(t)$$
where we can relabel $F'(\gamma(t))$ as $f(\gamma(t))$.
We show below that indeed the antiderivative can also be found. That is, integrating $f(z)$ along a curve does give you back $F(\gamma(t))$ when we parametrise $f(z)$ as $f(\gamma(t)) \gamma'(t)$.

Motivation:
Firstly, we want to show that $f(\gamma(t)) \gamma'(t)$ is continuous.
We start by noting that $\gamma$ is piecewise smooth.
So there is a partition of $[a,b]$, say $a = a_{0} < a_{1} < a_{2} < \ldots < a_{n} = b$ such that $\gamma$ is smooth on each $[a_{i},a_{i+1}]$ for $0 \leqslant i \leqslant n-1$.
So $\gamma'$ exists on $[a_{i},a_{i+1}]$ and is continuous on this subinterval.
Now we note that $f$ is continuous on $\gamma^{*}$, so $f(\gamma(t))$ is continuous.
Hence $t \mapsto f(\gamma(t)) \gamma'(t)$ is a continuous function on $[a_{i},a_{i+1}]$.

We write the above function as the [[Real decomposition of complex functions|real decomposition of complex functions|]]
$$f(\gamma(t)) \gamma'(t) = u(t) + iv(t)$$
where $u$ and $v$ are continuous real-valued functions on $[a_{i},a_{i+1}]$.

These are just continuous real functions and so they are integrable on a closed and bounded interval and we conclude
$$\int_{a_{i}}^{a_{i+1}}f(\gamma(t)) \; \gamma'(t)\; dt = \int_{a_{i}}^{a_{i+1}}u(t) dt+ i\int_{a_{i}}^{a_{i+1}}v(t)dt.$$
And so the integral 
$$\int_{\gamma}^{}f(z)dz = \int_{a}^{b} f(\gamma(t))\; \gamma'(t) \; dt = \sum\limits_{i=0}^{n-1}\int_{a_{i}}^{a_{i+1}} f(\gamma(t))\; \gamma'(t) \; dt$$
has some value.

However, this is not enough. We want to know what this value is. We will use the fact that we know how to integrate real functions.

Suppose that $U(t)$ and $V(t)$ are the antiderivatives of $u(t)$ and $v(t)$.
We can construct $F(t) = U(t) +i V(t)$, such that
$$u(t) = (\text{Re }F)'(t) \;\;\;\; \text{and} \;\;\;\;v(t) = (\text{Im }F)'(t).$$
We can now apply the [[The Fundamental Theorem of Calculus]] for real-valued functions:
$$\begin{align*}
\int_{\gamma}^{}f(z)\;dz &= \int_{a}^{b} f(\gamma(t))\;\gamma'(t)\;dt\\
&= \int_{a}^{b} u(t)\;dt + i \int_{a}^{b} v(t)\;dt\\
&= \int_{a}^{b} (\text{Re F})'(t)\;dt + i \int_{a}^{b} (\text{Im }F)'(t)\;dt\\
&= \text{Re }F(t) \;\bigg\vert_{t=a}^{b} + i \;\;\text{Im }F(t) \;\bigg\vert_{t=a}^{b}\\
&= F(t) \;\bigg\vert_{t=a}^{b}\\
&= F(b) - F(a).
\end{align*}$$
In conclusion, we did not actually need to break $f(\gamma(t))\gamma'(t)$ into real and imaginary parts.
Once we recognise it as the derivative of some function $F$, we can simply perform reverse differentiation and then evaluate $F(t)$ between these limits.