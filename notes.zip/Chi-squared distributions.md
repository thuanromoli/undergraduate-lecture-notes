---
tags:
  - MT2508
  - MT3508
  - MT3507
aliases: 
---
> [!gen] Relationships to other distributions
> - [[Gamma distributions]] $\Gamma\left(\frac{k}{2},\frac{1}{2}\right)$

> [!gen] Parameters
> $n \in \mathbb N$ - degrees of freedom

> [!gen] Support
> $x\in (0, \infty)$ - continuous [[Random variables|rv]] 

>[!gen] [[Probability density function]]
> $$f(x) = \frac{ \left( \frac{1}{2} \right)^\frac{k}{2}}{ \Gamma( \frac{k}{2})} x^{\frac{k}{2} - 1} e^{- \frac{x}{2}}$$

> [!gen] Typical use
> Related to the [[Normal distribution|normal distribution]].

>[!thm] Properties
> - $X \sim \Gamma\left(\frac{k}{2},\frac{1}{2}\right) \implies X \sim \chi^{2}_{k}$
>   Proof: use definitions.
> - $\mathbb E(X) = k$, $\text{Var }(X) = 2k$
>   Proof: use [[Gamma distributions|gamma distribution]] properties with $\alpha=\frac{k}{2}$ and $\lambda= \frac{1}{2}$.
> - $X_{i}\sim \chi^{2}_{k_{i}}$, where $X_{i}$ are independent rvs $\implies \sum\limits_{i=1}^{n}X_{i} \sim \Gamma\left(\frac{\sum_{i=1}^{n}k_{i}}{2},\frac{1}{2}\right) \equiv \chi^{2}_{\sum_{i=1}^{n}k_{i}}$
>   Proof: use [[Gamma distributions|gamma distribution]] properties with $\alpha=\frac{k}{2}$ and $\lambda= \frac{1}{2}$.
> - $Z \sim N(0,1)$ $\implies$ $Z^{2} \sim \Gamma\left(\frac{1}{2},\frac{1}{2}\right) \equiv \chi^2_{1}$
>   Proof: use mgfs.
> - $Z_{i}\sim N(0,1)$, where $Z_{i}$ are iid rvs $\implies \sum\limits_{i=1}^{n}Z^{2}_{i} \sim \chi^{2}_{n}$
>   Proof: use (3) with $k_{i}=1$.