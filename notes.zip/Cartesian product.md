---
tags:
  - MT3502
aliases:
---
Let $A$ and $B$ be sets.

> [!def] Definition
> The Cartesian product $A \times B$ is the set of all ordered paris
> $$A \times B = \set{(a,b):a \in A, b \in B}.$$
