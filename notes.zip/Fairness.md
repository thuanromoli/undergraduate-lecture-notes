---
tags:
  - MT4554
type: def
aliases:
---
>[!def] Definition
>Fairness as a concept is more nebulous than [[cooperation]], and what constitutes a “fair” outcome from a social interaction varies with context.
>To study fairness using game theory, we move away from static games and we will start analysing [[Static and dynamic games|sequential games]].
