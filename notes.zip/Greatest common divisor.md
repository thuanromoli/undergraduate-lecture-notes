---
type: def
tag: MT2505
---
Let $a,b\in \mathbb{Z}$ such that at least one of $a$ and $b$ is non-zero.

>[!def] Definition
>The _greatest common divisor_ of $a$ and $b$ is the largest integer $d$ which divides both $a$ and $b$. Notation: $\gcd(a,b)$.
