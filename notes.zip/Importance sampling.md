---
tags:
  - MT4531
aliases:
---
Suppose we wish to generate observations $\theta^{1},...,\theta^n$ from $\pi(\theta|\boldsymbol{x})$, which we assume is difficult to do directly.

Suppose that we can easily sample from some other distribution $g(\theta)$, such that if $\pi(\theta|\boldsymbol{x})>0$, then $g(\theta)>0$.

Suppose further that we are interested in obtaining an estimate of $\mathbb E_\pi(f(\theta))$. We would normally estimate $\mathbb E_\pi(f(\theta))$ by the usual Monte Carlo estimate, $\widehat E_\pi(f(\theta))= \frac{1}{n} \sum\limits_{i=1}^{n}f(\theta^{i})$, where $\theta^{i}$ would be samples from $\pi(\theta|\boldsymbol{x})$. However, sampling from $\pi(\theta|\boldsymbol{x})$ is not easy! Note that,
$$\mathbb E_\pi(f(\theta))=\int\limits_{}^{}f(\theta)\pi(\theta|\boldsymbol{x})\;d \theta = \int_{}^{} \frac{f(\theta)\pi(\theta|\boldsymbol{x})}{g(\theta)}g(\theta)\;d \theta.$$
So the expectation with respect to $\pi(\theta|\boldsymbol{x})$ can also be seen as an expectation with respect to $g(\theta)$. Let $\theta^{1},...,\theta^{n}$ be a sample from $g(\theta)$. Then we can estimate $\mathbb E_\pi(f(\theta))$ by
$$\mathbb E_\pi(f(\theta))=\mathbb E_{g}\left(\frac{f(\theta)\pi(\theta|\boldsymbol{x})}{g(\theta)}\right)=\frac{1}{n}\sum\limits_{i=1}^{n}\frac{\pi(\theta^{i}|\boldsymbol{x})}{g(\theta^{i})}f(\theta^{i})=\frac{1}{n} \sum\limits_{i=1}^{n} w(\theta^{i})f(\theta^{i})$$
where we have now defined importance weights, for the $\theta^{i}$ sampled from $g(\theta)$,
$$w(\theta^{i})= \frac{\pi(\theta^{i}|\boldsymbol{x})}{g(\theta^{i})}.$$
