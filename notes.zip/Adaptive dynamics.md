---
tags:
  - MT4554
type: def
aliases:
---
>[!def] Definition
>Adaptive dynamics is one of the most basic models of evolution.
>Under this model, a population updates its mixes strategy under the following assumptions:
>- populations are large and monomorphic.
>- the population experiences rare, infrequent "invaders" (also called mutants) in which a single player adopts a novel strategy.
>- invader strategies are slight deviations from the resident strategy.
>- an invader with higher population payoff (often called "fitness") will successfully invade and replace the current resident strategy.
