---
tag: MT2508
type: def
alias: explanatory variable
---
>[!def] Definition
>The explanatory variable is the [[Independent events|independent]] variable, they are assumed to be measured without error.
