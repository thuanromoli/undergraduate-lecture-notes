---
tags:
  - MT3504
type: mthd
aliases:
---
>[!gen] ODE
>$$ay''+by'+cy=g(x)$$
>where $g(x)$ is a [[Polynomials|polynomial]], sine, cosine, or exponential function or a sum or product of these functions.
>The key property of these functions is that their derivatives all have the same form as the function itself.

>[!gen] Solution
>Guess a trial function $y_{PI}$ with the same functional form of $g(x)$ but with undetermined coefficients.

>[!gen] Remarks
>- If $L[y]=g_{1}(x)+g_{2}(x)$ then we can find separately the particular integrals $y_{PI1}$ to $L[y]=g_{1}(x)$ and $y_{PI2}$ to $L[y]=g_{2}(x)$. Then linearity of $L$ means that we can take $y_{PI}=y_{PI1}+y_{PI2}$
>- If a term appearing in $g(x)$ is included in the complimentary function, then the usual trial function must be multiplied by $x^n$ where $n$ is the least integer that removes the duplication.
