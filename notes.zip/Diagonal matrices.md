---
tag: MT2501
type: def
alias:
- diagonal matrix
---
>[!def] Definition
>A diagonal [[Matrices|matrix]] is a [[Square matrices|square matrix]] in which all non-diagonal entries are 0:
>$$A=\begin{pmatrix}
 a_{11} & 0 & \cdots & 0 \\
 0 & a_{22} & \cdots & 0 \\
 \vdots & \vdots & \ddots & \vdots \\
 0 & 0 & \cdots & a_{nn} \\
 \end{pmatrix} = \text{diag}(a_{11},\ldots,a_{nn})$$

---

#### Spaced repetition
