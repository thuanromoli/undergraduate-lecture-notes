---
tags:
  - MT4554
type: def
aliases:
  - mixed strategy
  - mixed strategies
  - strategy profile
---
>[!def] Mixed strategy
>A mixed strategy $\sigma_{i}$ of a player $i$ is a probability distribution over [[Pure strategies|pure strategies]]: $\sigma_{i}=\left[\sigma_{i}(s_{i}^{1}),\sigma_{i}(s_{i}^{2}),...,\sigma_{i}(s_{i}^{j})\right]$ where $\sigma_{i}(s_{i}^{j})$ is the probability that $\sigma_{i}$ assigns to $s_{i}^{j}$.
>This probability is assumed to be [[Independent events|independent]] of those adopted by $i$'s opponents.

>[!def] Space of mixed strategies
>The space of mixed strategies is the set of all possible mixed strategies for player $i$, denoted by $\Sigma_{i}$.
>$$\Sigma_{i}=\left\{\sigma_{i}(s_{i}):\sum\limits_{s_{i}\in S_{i}}\sigma_{i}(s_{i})=1\right\}$$

>[!def] Mixed strategy profile
>A mixed strategy profile $\boldsymbol{\sigma}$ describes the mixed strategy adopted by each player in the game: $\boldsymbol{\sigma}=(\sigma_{1},...,\sigma_{N})$ where $N$ is the number of players.

>[!def] Expected payoff
>The expected payoff to player $i$ given the mixed strategy profile $\boldsymbol{\sigma}$ is
>$$u_{i}(\boldsymbol{\sigma})= \sum\limits_{s \in S}\left(\prod_{j=1}^{N} \sigma_{j}(s_{j}) \right)u_{i}(s) $$
