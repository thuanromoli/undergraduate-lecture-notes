---
tags:
  - MT3504
type: mthd
aliases:
---
Let $y'=f(x,y) \;\; \text{with } \;\; y(x_{0})= y_{0}$ be an [[Initial values and IVP]].

>[!gen] Discussing existence and uniqueness of an IVP
>1. Identify $f$, $x_{0}$, and $y_{0}$.
>2. Determine for which values of $x$. $f$ and $\frac{\partial f}{\partial y}$ are [[Continuity|continuous]].
>3. Set an appropriate rectangle $R$ as in [[Picard's Theorem]] by choosing values of $a$ and $b$ that ensure continuity of $f$ and $\frac{\partial f}{\partial y}$.
>4. Evaluate $\max_{R}|f|\equiv K$
>5. State the interval for which a solution to the IVP exists and is unique: $[x_{0},x_{0}+\alpha]$ where $\alpha=\min(a,\frac{b}{K})$.
