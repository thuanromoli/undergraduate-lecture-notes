---
tags:
  - MT3508
aliases:
---
> [!gen] [[Statistical hypothesis|Hypothesis]]
> $H_{0}$: the data follow a specified distribution.
> $H_{1}$: the data do not follow a specified distribution.

> [!gen] [[Test statistics]]
> $$\begin{align*}
   \chi^{2} = \sum\limits_{i=1}^{k} \frac{(O_{i}-E_{i})^{2}}{E_{i}}
   \end{align*}\sim \chi^{2}_{k-q-1}$$
> where
> - $O_{i}$ is the observed frequency for bin $i$.
> - $E_{i}$ is the expected frequency for bin $i$.
> - $k$ is the total number of bins.
> - $q$ is the number of independent parameters that have to be estimated.

> [!gen] Finding the expected frequencies
> Depends on the specified distribution.
> 
> If multinomial then data come from the model $(O_{1},...,O_{k})\sim \text{Multi}(N,p_{1},...,p_{k})$.
> Hence $\mathbb E(O_i)=E_{i}=N p_{i}$ where $p_{i}$ could be estimated by $q$ parameters $\widehat{\boldsymbol{\theta}}=(\boldsymbol{\theta}_{1},...,\boldsymbol{\theta}_{k})$.
> 
> If multinormal then data come from the model $\boldsymbol{Y} \sim N(\mu,\sigma^{2})$ with [[Sample mean|sample mean]] $\widehat \mu$ and [[Sample variance|sample variance]] $\widehat{\sigma^{2}}$ (?? book says sample variance but uses variance instead).
> Hence $E_{i}= n[\Phi(c_{i})-\Phi(c_{i-1})]$ where $\Phi(c_{i})$ is the CDF at $c_{i}$.

> [!gen] Method
> 1. (Continuous only) Choose intervals such that the expected counts for each bin are greater than 5.
> 1. Find the expected values for each bin $i$ using $q$ parameters and draw a table
> 
| bin $i$ | $1$     | 2       | ... | $k$     |
| ------- | ------- | ------- | --- | ------- |
| $O_{i}$ | $O_{1}$ | $O_{2}$ |     | $O_{k}$ |
| $E_i$   | $E_{1}$ | $E_{2}$ |     | $E_{k}$ |
> 2. For each bin $i$ find $\frac{(O_{i}-E_{i})^{2}}{E_{i}}$ and add each result for $i=1,2,...,k$ to find the test statistic $\chi^2$.
> 3. Find the $p$-value.

```R
# number of observations
n <- length(y)

# MLEs
muhat <- mean(y)
varhat <- var(y)*(n-1)/n

# Choose the intervals (may need some trial and error)
breaks <- c(-100, 8.5, 9.5, 10, 10.5, 10.9, 11.5, 100)

# find the expected counts using the CDF
expect <- diff(pnorm(breaks, muhat, sqrt(varhat)))*50

# a quick way to find the observed counts
observe <- hist(y, breaks = breaks, plot = F)$counts

# contributions to test statistic
chi2 <- (observe - expect)^2/expect

# test statistics
sum(chi2)

# p-value
1 - pchisq(sum(chi2), k-q-1)
```
