---
tags:
  - MT4528
type: def
aliases:
  - communicate
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S$.

>[!def] Definition
>Two states $i,j \in S$ communicate if $i$ is [[Accessible states|accessible]] from $j$ and vice-versa:
>$$i\to j \text{ and } j\to i$$
>That is, the probability to get to state $j$ from $i$ and from $i$ to $j$ in any time is non-zero and we write $i \leftrightarrow j$.
