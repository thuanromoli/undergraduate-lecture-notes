---
tags:
  - MT2501
  - MT3501
type: thm
aliases: []
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$. Let $v \in V$ and $\alpha\in F$.

>[!thm]- $\alpha \boldsymbol{0} = \boldsymbol{0}$
>Let $w=\alpha \boldsymbol{0}$.
>Then $\alpha \boldsymbol{0}=\alpha(\boldsymbol{0}+\boldsymbol{0})=\alpha \boldsymbol{0}+\alpha \boldsymbol{0}$ by the [[Distributivity|distributive]] property.
>Thus $w=w+w$ $\implies$ $w=\alpha \boldsymbol{0}=\boldsymbol{0}$.

>[!thm]- $0v= \boldsymbol{0}$
>Let $w=0v$.
>Then $0v=({0}+{0})v=0v+0v$ by the [[Distributivity|distributive]] property.
>Thus $w=w+w$ $\implies$ $w=0v=\boldsymbol{0}$.

>[!thm]- $\alpha v = \boldsymbol{0} \implies \alpha=0 \;\lor\; v=\boldsymbol{0}$
>Case 1: Suppose $\alpha \neq 0$.
>If $\alpha \neq 0$ then $\alpha v = \boldsymbol{0}$ $\implies$ $\frac{1}{\alpha} \cdot \alpha v=\frac{1}{\alpha}\boldsymbol{0}$ $\implies$ $v= \boldsymbol{0}$
>
>Case 2: Suppose $\alpha = 0$.
>Trivial.

>[!thm]- $(-\alpha)v=-\alpha v=\alpha(-v)$
>Proof 1:  $(-\alpha)v=-\alpha v$.
>Consider the following identity: $(\alpha)v + (-\alpha) v=(\alpha+(-\alpha))v=0v=\boldsymbol{0}$.
>Then $\alpha v + (-\alpha)v=\boldsymbol{0}$ $\implies$ $(-\alpha)v=-\alpha v$.
>
>Proof 2: $\alpha(-v)=-\alpha v$.
>Consider the following identity: $\alpha v+\alpha(-v)=\alpha(v+(-v))=\alpha \boldsymbol{0}= \boldsymbol{0}$.
>Then $\alpha v+\alpha(-v)= \boldsymbol{0}$ $\implies$ $\alpha(-v)=-\alpha v$

---

#### Spaced repetition

Prove that $\alpha \boldsymbol{0} = \boldsymbol{0}$.
?
>Let $w=\alpha \boldsymbol{0}$.
>Then $\alpha \boldsymbol{0}=\alpha(\boldsymbol{0}+\boldsymbol{0})=\alpha \boldsymbol{0}+\alpha \boldsymbol{0}$ by the [[Distributivity|distributive]] property.
>Thus $w=w+w$ $\implies$ $w=\alpha \boldsymbol{0}=\boldsymbol{0}$.

Prove that $0v= \boldsymbol{0}$.
?
>Let $w=0v$.
>Then $0v=({0}+{0})v=0v+0v$ by the [[Distributivity|distributive]] property.
>Thus $w=w+w$ $\implies$ $w=0v=\boldsymbol{0}$.

Prove that $\alpha v = \boldsymbol{0} \implies \alpha=0 \;\lor\; v=\boldsymbol{0}$.
?
>Case 1: Suppose $\alpha \neq 0$.
>If $\alpha \neq 0$ then $\alpha v = \boldsymbol{0}$ $\implies$ $\frac{1}{\alpha} \cdot \alpha v=\frac{1}{\alpha}\boldsymbol{0}$ $\implies$ $v= \boldsymbol{0}$
>
>Case 2: Suppose $\alpha = 0$.
>Trivial.

Prove that $(-\alpha)v=-\alpha v=\alpha(-v)$
?
>Proof 1:  $(-\alpha)v=-\alpha v$.
>Consider the following identity: $(\alpha)v + (-\alpha) v=(\alpha+(-\alpha))v=0v=\boldsymbol{0}$.
>Then $\alpha v + (-\alpha)v=\boldsymbol{0}$ $\implies$ $(-\alpha)v=-\alpha v$.
>
>Proof 2: $\alpha(-v)=-\alpha v$.
>Consider the following identity: $\alpha v+\alpha(-v)=\alpha(v+(-v))=\alpha \boldsymbol{0}= \boldsymbol{0}$.
>Then $\alpha v+\alpha(-v)= \boldsymbol{0}$ $\implies$ $\alpha(-v)=-\alpha v$