---
tags:
  - MT3508
aliases:
---
Let $\boldsymbol{y} \sim N(\boldsymbol{X}\boldsymbol{\beta}, \boldsymbol{I}\sigma^{2})$.

> [!thm]- $\widehat{\boldsymbol{\beta}} = (\mathbf{X}^T \mathbf{X})^{-1} \mathbf{X}^T \mathbf{y}$

> [!thm]- $\mathbb{E}[\widehat{\boldsymbol{\beta}}] = \boldsymbol{\beta}$

> [!thm]- $\hbox{Var}[\widehat{\boldsymbol{\beta}}] = (\mathbf{X}^T \mathbf{X})^{-1} \sigma^2$

> [!thm]- $\widehat{\boldsymbol{\beta}} \sim N(\boldsymbol{\beta}, \ (\mathbf{X}^T \mathbf{X})^{-1} \sigma^2)$

Below is for regression. Note: $\widehat{\boldsymbol{\mu}} = \widehat{\boldsymbol{y}}$.

> [!thm]- $\hat{\boldsymbol{\mu}}={\bf{X}}\hat{\beta}\;=\;{\bf{X}}\left({\bf{X}}^T{\bf{X}}\right)^{-1}{\bf{X}}^T {\bf{y}} = {\bf{A}} {\bf{y}}$

> [!thm]- $Var[\hat{\boldsymbol{\mu}}]=Var[{\bf{X}}\hat{\beta}]={\bf{X}}({\bf{X}}^T{\bf{X}})^{-1}{\bf{X}}^T\sigma^2= {\bf{A}}\sigma^2$

> [!thm]- $tr({\bf{A}})=p$ where $p$ is the number of parameters







> [!gen] Remarks
> - $\widehat {\boldsymbol{\beta}}$ has a closed-form expression.
> - $\widehat {\boldsymbol{\beta}}$ is unbiased, not just asymptotically unbiased.
> - $\widehat {\boldsymbol{\beta}}$ is exactly normally distributed, not just asymptotically normal.
> - If $\sigma^{2}$ is known, then $(\mathbf{X}^T \mathbf{X})^{-1} \sigma^2$ is exactly the inverse [[Fisher information]] matrix.
> - The [[Deviance and scaled deviance|deviance]] which is the [[Residual sum of squares|residual sum of squares]].
> - $D^{*}\sim \chi^{2}_{n-p}$ for any sample size (useful if $\sigma^{2}$ is known)
> - $\frac{\widehat \beta_{k}-\beta_{k}}{\sqrt{\widehat{\sigma^{2}_{k}}}}\sim t_{n-p}$ where $\widehat {\sigma^{2}_{k}}$ is the $k$th element of $(\boldsymbol{X}^{T}\boldsymbol{X})^{-1}\sigma^{2}$, and $\widehat {\sigma^{2}} = \frac{D}{n-p}$.
> - $F = \frac{(D_0 - D_1)/(p_1 - p_0)}{D_1/(n - p_1)} = \frac{(\hbox{RSS}_0 - \hbox{RSS}_1)/(p_1 - p_0)}{\hbox{RSS}_1/(n - p_1)} \sim F_{(p_1 - p_0),(n - p_1)}$ for any sample size.
