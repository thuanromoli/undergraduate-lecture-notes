---
type: def
tag: MT2506
---
>[!def] Definition
>The gradient is a vector operator s.t $\nabla f: \mathbb{R} \to \mathbb{R}^{3}$ and it represents the maximum increase in $f$ or the normal to the surface $f(\boldsymbol x)=C$.

>[!gen]+ General coordinates:
>$$\nabla f = \boldsymbol e_u \frac{1}{g_u}\frac{\partial f}{\partial u}+\boldsymbol e_v \frac{1}{g_v}\frac{\partial f}{\partial v}+\boldsymbol e_w \frac{1}{g_w}\frac{\partial f}{\partial w}$$

>[!gen]+ [[Cartesian coordinates]]:
>$$\nabla f = \boldsymbol i\frac{\partial f}{\partial x}+\boldsymbol j\frac{\partial f}{\partial y}+\boldsymbol k\frac{\partial f}{\partial z}$$

>[!gen]+ [[Cylindrical polar coordinates]]:
>$$\nabla f = \boldsymbol e_R\frac{\partial f}{\partial R}+\boldsymbol e_\phi\frac{1}{R}\frac{\partial f}{\partial \phi}+\boldsymbol e_z\frac{\partial f}{\partial z}$$

>[!gen]+ [[Spherical coordinates]]:
>$$\nabla f = \boldsymbol e_r\frac{\partial f}{\partial r}+\boldsymbol e_\theta\frac{1}{r}\frac{\partial f}{\partial \theta}+\boldsymbol e_\phi\frac{1}{r\sin\theta}\frac{\partial f}{\partial \phi}$$

---

#### Spaced repetition

What is the meaning of $\nabla f$ ?
?
The gradient is a vector operator s.t $\nabla f: \mathbb{R} \to \mathbb{R}^{3}$ and it represents the maximum increase in $f$ or the normal to the surface $f(\boldsymbol x)=C$.

What is $\nabla f$ in general coordinates?
?
$$\nabla f = \boldsymbol e_u \frac{1}{g_u}\frac{\partial f}{\partial u}+\boldsymbol e_v \frac{1}{g_v}\frac{\partial f}{\partial v}+\boldsymbol e_w \frac{1}{g_w}\frac{\partial f}{\partial w}$$

What is $\nabla f$ in Cartesian Coordinates?
?
$$\nabla f = \boldsymbol i\frac{\partial f}{\partial x}+\boldsymbol j\frac{\partial f}{\partial y}+\boldsymbol k\frac{\partial f}{\partial z}
$$

What is $\nabla f$ in Cylindrical polar coordinates?
?
$$\nabla f = \boldsymbol e_R\frac{\partial f}{\partial R}+\boldsymbol e_\phi\frac{1}{R}\frac{\partial f}{\partial \phi}+\boldsymbol e_z\frac{\partial f}{\partial z}$$

What is $\nabla f$ in Spherical coordinates?
?
$$\nabla f = \boldsymbol e_r\frac{\partial f}{\partial r}+\boldsymbol e_\theta\frac{1}{r}\frac{\partial f}{\partial \theta}+\boldsymbol e_\phi\frac{1}{r\sin\theta}\frac{\partial f}{\partial \phi}$$