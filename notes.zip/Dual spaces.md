---
tags:
  - MT3501
type: def
aliases:
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$.

>[!def] Definition
>The dual space $V^{*}$ is the space of all [[Linear functionals|linear functionals]] $V\to F$ with addition and scalar multiplication given by
>$$(f+g)(v)=f(v)+g(v) \text{ and }(\alpha f)(v)=\alpha f(v)$$
>for linear functionals $f,g:V\to F$, scalars $\alpha \in F$ and vectors $v\in V$.
>This is the same as $\mathcal L(V,F)$.

>[!thm] Theorem
>The dual space $V^{*}$ is a vector space over $F$ and $\dim V^{*}=\dim V$.
