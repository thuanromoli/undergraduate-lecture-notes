---
tags:
  - MT4554
type: 
aliases:
---
>[!def] Feasible payoffs
>A feasible payoff is any equilibrium payoff for the repeated game that can be achieved via some strategy.
>Provided that the discount factor is near enough to $1$, the set of feasible payoffs is
>$$\mathcal  U=\text{convex hull}\set{r:\exists a\in A \text{ with }u^{t}(a)=r}$$
>that is, the set of feasible payoffs is the convex hill of the payoffs that are produced by playing each possible action $a\in A$ for the stage game.
>
>![[feaspayoff_att.png|500]]

>[!def] Feasible, individually rational payoffs
>Feasible, individually rational payoffs are feasible payoffs which also exceed the [[reservation utility]].
