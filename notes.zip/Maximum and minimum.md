---
tags:
  - MT2502
aliases:
  - maximum
  - minimum
---
Let $(X,<)$ be an [[Ordered sets|ordered set]] and $A \subseteq X$.

> [!def] Maximum
> $M \in A$ is called a maximum for $A$ if $M$ is an [[Boundedness|upper bound]] for $A$, that is
> $$\forall a \in A, \;\; a \leqslant M \text{ and } M \in A.$$

> [!def] Minimum
> $m \in A$ is called a minimum for $A$ if $m$ is a [[Boundedness|lower bound]] for $A$, that is
> $$\forall a \in A, \;\; m \leqslant a \text{ and } m \in A.$$
