---
tag: MT2505
type: def
alias: commutative ring
---
Let $R$ be a [[Rings|ring]].

>[!def] Definition
>A commutative ring is a [[Rings|ring]] that satisfies the [[Commutativity|commutative]] property: $$\text{M1: } ab=ba \ \ \forall a,b \in R$$

