---
tag: MT2506
type: mthd
alias: directed surface area element
---
Let $S$ be a surface defined by $f(\boldsymbol{x})=C$.
1. Define the position vector $\boldsymbol r(u,v) = g(u,v)\boldsymbol e_u+h(u,v)\boldsymbol e_v$;
2. find two tangent vectors to $\boldsymbol{S}$: $\boldsymbol t_u=\frac{\partial\boldsymbol{r}}{\partial u \ }$ and $\boldsymbol t_v=\frac{\partial\boldsymbol{r}}{\partial v}$;
3. then $\text{d}\boldsymbol S=(\boldsymbol t_u \times \boldsymbol t_v)\text{ d}u\,\text{d}v= \lvert\boldsymbol t_u \times\boldsymbol t_v\rvert\text{ d}u\,\text{d}v \,\boldsymbol{\hat n}$;
4. so $\text{d}\boldsymbol S=(\frac{\partial\boldsymbol{r}}{\partial u}\times \frac{\partial\boldsymbol{r}}{\partial v})\text{ d}u\,\text{d}v$.