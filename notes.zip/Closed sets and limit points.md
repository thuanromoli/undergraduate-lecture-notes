---
tags:
  - MT3502
aliases:
  - closed set
  - limit point
  - closed
---
Let $X$ be a set, with a point $x \in X$ and a subset $A \subseteq X$.

> [!def] Limit point
> The point $x \in X$ is called a limit point of $A$ if there exists a [[Sequences|sequence]] $(x_{n})_{n}$ in $A$ whose limit is in $X$. That is,
> $$\exists \text{ a sequence }(x_{n})_{n} \text{ in } A \text{ and point } x \in X \text{ such that } x_{n} \to x$$
> where $(x_{n})_{n}$ in $A$ means $x_{n} \in A \;\;\forall n \in \mathbb N$.

> [!def] Closed set
> A set is closed if it contains all its limit points.
