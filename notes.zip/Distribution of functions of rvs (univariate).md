---
tags:
  - MT3507
aliases:
---
Let $X$ be a continuous [[Random variables|rv]] with [[Probability density function|pdf]] $f_{X}(x)$ and [[Cumulative distribution function|cdf]] $F_{X}(x)$.
Let $y = g(x)$ be a strictly [[Monotonicity|increasing]] or decreasing function of $x$.

> [!thm] Theorem
> The distribution of $Y = g(X)$ is
> $$f_{Y}(y) = f_{X}(h(y)) \left | \frac{d}{dy}h(y) \right |$$
> where $h(y)$ is the inverse function of $g(x)$.

Suppose first that $g$ is strictly increasing, such that its inverse $h(y)=x$ exists (we assume it has a continuous derivative).

Then the cdf of $Y=g(X)$ is
$$\begin{align*}
F_{Y}(y) &= \mathbb P(Y \leqslant y)\\
&= \mathbb P(h(Y) \leqslant h(y))\\
&= \mathbb P(X \leqslant h(y))\\
&= F_{X}(h(y)).
\end{align*}$$
Hence, using the [[The Fundamental Theorem of Calculus|fundamental theorem of calculus]],
$$\begin{align*}
f_{Y}(y) &= \frac{d}{dy}(F_{X}(h(y))\\
&=F_{X}'(h(y)) h'(y)\\
&= f_{X}(h(y)) h'(y).
\end{align*}$$
Similarly, if $g$ is strictly decreasing, we get
$$\begin{align*}
F_{Y}(y) &= \mathbb P(Y \leqslant y)\\
&= \mathbb P(h(Y) \geqslant  h(y))\\
&= \mathbb P(X \geqslant  h(y))\\
&= 1- \mathbb P(X \leqslant   h(y))\\
&= 1 - F_{X}(h(y)).
\end{align*}$$
Hence, using the [[The Fundamental Theorem of Calculus|fundamental theorem of calculus]],
$$\begin{align*}
f_{Y}(y) &= \frac{d}{dy}(1-F_{X}(h(y))\\
&=-F_{X}'(h(y)) h'(y)\\
&= -f_{X}(h(y)) h'(y)
\end{align*}$$
where $h'(y)$ is also negative, since $h$ is also decreasing.
So putting this together, we obtain the required result.