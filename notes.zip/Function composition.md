---
type: def
tags:
  - MT2505
  - MT4003
aliases:
  - composite
  - function composition
---
Let $f: X\to Y$ and $g:Y\to Z$ be [[Functions|functions]].

>[!def] Definition
>The composite $fg: X\to Z$ is a [[Functions|function]] defined by $$x(fg)=(xf)g \ \ \forall x\in X.$$note: we apply $f$ first and then $g$; this is different from $f*g=g(f(x))$.
