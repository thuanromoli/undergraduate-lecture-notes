---
tags:
  - MT4509
aliases:
  - incompressible
---
> [!def] Definition
> A fluid is incompressible if the density $\rho$ is constant on each fluid particle. In other words,
> $$\frac{D \rho}{Dt} = 0.$$
> Note: this is not the same as saying that the density is constant everywhere, in which case we would say a fluid is homogeneous.

> [!thm] Theorem
> A fluid is incompressible if and only if the flow is divergence free (solenoidal). That is,
> $$\frac{D \rho}{Dt}=0 \iff \nabla \cdot \boldsymbol{u}=0.$$

Proof:
Use the alternative form of the [[Continuity equation|continuity equation]].
