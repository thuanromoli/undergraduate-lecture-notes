---
tags:
  - MT3508
aliases:
---
> [!def] Definition
> The [[Hessian matrix]] is the negative of the matrix of second derivatives of $l(\boldsymbol{\theta})$, evaluated at the [[Maximum Likelihood Estimator|MLE]] $\widehat{\boldsymbol{\theta}}$. That is,
> $$  -\mathbf{H}( \widehat{\boldsymbol{\theta}})= - \left( \frac{\partial^2 l}{\partial \boldsymbol{\theta}\partial \boldsymbol{\theta}^T} \Bigg. \Bigg|_{\widehat{\boldsymbol{\theta}}} \right)$$
> where the $ij$th element of $-\mathbf{H}( \widehat{\boldsymbol{\theta}})$ is
> $$  H_{ij} (\widehat{\boldsymbol{\theta}}) = -\left( \frac{\partial^2 l}{\partial \boldsymbol{\theta}_i \partial \boldsymbol{\theta}_j} \Bigg. \Bigg|_{ (\widehat{\boldsymbol{\theta}_i}, \widehat{\boldsymbol{\theta}_j} )} \right)$$

> [!gen] Remarks
> 1. This is used as an [[Estimators|estimator]] of $\mathbf{I}(\boldsymbol{\theta})$, the [[Fisher information]].
> 2. The function `optim` gives you the negative Hessian if you use `hessian = TRUE`
