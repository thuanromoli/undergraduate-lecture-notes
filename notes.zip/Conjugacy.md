---
tags:
  - MT4003
aliases:
  - conjugate
  - conjugation
---
Let $G$ be a [[Groups|group]].

> [!def] Conjugates
> Two elements $x$ and $y$ are conjugate in $G$ if there exists a $g\in G$ such that $y=g^{-1}xg$. We write $y=x^{g}$.

> [!thm] [[Group actions]]
> Conjugation of $G$ on $X$ is a group [[Group actions|action]] from $X\times G$ to $X$ via $(x,g)\mapsto g^{-1}xg=x^{g}$.

> [!thm] [[Equivalence relations]]
> Define the relation $\sim$ on $G$ by $x \sim y$ if and only if $y=x^{g}$ for some $g\in G$.
> Then $\sim$ is an [[Equivalence relations|equivalence relation]] on $G$.

Proof:
Reflexivity: $1^{-1}x1=x \;\;\forall x \in G$, so $x\sim x$.

Symmetry: Suppose $x \sim y$.
Then there exists a $g\in G$ such that $y=x^{g}=g^{-1}xg$.
By right multiplying by $g$ and left multiplying by $g^{-1}$, we have $x=gyg^{-1}=(g^{-1})^{-1}y(g^{-1})=y^{g^{-1}}$.
Hence $y\sim x$ and $\sim$ is symmetric.

Transitivity: Suppose $x\sim y$ and $y \sim z$.
Then $y=x^{g}$ for some $g\in G$ and $z=y^{h}$ for some $h\in G$.
Now $z=y^{h}=h^{-1}yh=h^{-1}(x^{g})h=h^{-1}(g^{-1}xg)h=(h^{-1}g^{-1})x(gh)=(gh)^{-1}x(gh)=x^{gh}$.
Hence $x\sim z$ and $\sim$ is transitive.
