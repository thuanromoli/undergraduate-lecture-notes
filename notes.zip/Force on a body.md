---
tags:
  - MT4509
aliases:
---
![[forcebody_att.png|400]]

Mass conservation tells us $u_{1}A_{1} = u_{2}A_{2}$.
[[Integral momentum equation]] for steady flow, using $S = S_{B} \cup S_{A} \cup S_{1} \cup S_{2}$ 
$$\iint_{S \text{ closed}}(p-p_{0})\boldsymbol{n} \;dS + \iint_{S \text{ closed}}\rho(\boldsymbol{u \cdot n})\boldsymbol{u}\;dS =0 \tag{eq 1}$$
Now take the approximation $p=p_{0}$ on $S_{A},S_{1},S_{2}$ and note that along $S_{A}$ and $S_{B}$, $\boldsymbol{u \cdot n} = 0$.
$$\begin{vmatrix}
\hline
 & \iint_{S}(p-p_{0})\boldsymbol{n} \;dS & \iint_{S}\rho(\boldsymbol{u \cdot n})\boldsymbol{u}\;dS \\ \hline
 S=S_{1} & 0 & \iint_{S_{1}}\rho(\boldsymbol{u \cdot n})\boldsymbol{u}\;dS \\ \hline
 S=S_{2} & 0 & \iint_{S_{2}}\rho(\boldsymbol{u \cdot n})\boldsymbol{u}\;dS \\ \hline
 S=S_{A} & 0 & 0 \\ \hline
 S=S_{B} & \iint_{S_{B}}(p-p_{0})\boldsymbol{n} \;dS & 0 \\ \hline
\end{vmatrix}$$
Equation becomes
$$\iint_{S_{1}}\rho(\boldsymbol{u \cdot n})\boldsymbol{u}\;dS+\iint_{S_{2}}\rho(\boldsymbol{u \cdot n})\boldsymbol{u}\;dS+\iint_{S_{B}}(p-p_{0})\boldsymbol{n} \;dS=0$$
So the force on the body is
$$\boldsymbol{F}_{B}=\iint_{S_{B}}(p-p_{0}) \boldsymbol{n}\;dS=-\iint_{S_{1}}\rho(\boldsymbol{u \cdot n})\boldsymbol{u}\;dS - \iint_{S_{2}}\rho(\boldsymbol{u \cdot n})\boldsymbol{u}\;dS$$
On $S_{1}$ and $S_{2}$, $\boldsymbol{n}= -\boldsymbol{i}$.
So take $\boldsymbol{F}_{B}= (F_{B},0,0)$, and we can write
$$\begin{align*}
F_{B}&= \boldsymbol{i} \cdot \iint_{S_{B}}(p-p_{0})\boldsymbol{n}\;dS\\
&= -\iint_{S_{1}}\rho(\boldsymbol{u \cdot n})(\boldsymbol{u \cdot i})\;dS - \iint_{S_{2}}\rho(\boldsymbol{u \cdot n})(\boldsymbol{u \cdot i})\;dS\\
&= -\iint_{S_{1}}\rho(-u_{1})(u_{1})\;dS -\iint_{S_{1}}\rho(u_{2})(-u_{2})\;dS\\
&= \rho u_{1}^{2}A_{1}+\rho u_{2}^{2}A_{2}.
\end{align*}$$

Now use Bernoulli's theorem on a streamline on $S_{A}$ with end points between velocities $u_{1}$ and $u_{2}$ and with $p=p_{0}$ and $\boldsymbol{g}$ neglected
$$\frac{1}{2}u_{1}^{2}+\frac{p_{0}}{\rho}=\frac{1}{2}u_{2}^{2}+\frac{p_{0}}{\rho} \implies u_{1}=u_{2}.$$
To summarise, we have used three conditions
- Mass conservation $u_{1}A_{1} = u_{2}A_{2}$.
- Integral momentum equation $F_{B} = \rho u_{1}^{2}A_{1}+\rho u_{2}^{2}A_{2}$.
- Bernoulli's theorem $u_{1}=u_{2}$.

Putting this all together, we have that $A_{1}=A_{2}$ and so
$F_{B} = 2 \rho u_{1}^{2}A_{1}$.