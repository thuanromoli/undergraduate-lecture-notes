---
tags:
  - MT3503
aliases:
  - analytic
---
$f: U \to \mathbb C$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] defined on an [[Open sets|open subset]] $U$.

> [!def] Definition
> $f$ is analytic on $U$ if $f$ is given by a [[Power series|power series]] in every [[Open balls|open ball]] inside $U$.

> [!thm] Theorem
> $f:U \to \mathbb C$ is [[Holomorphic functions|holomorphic]] on $U$ $\iff$ $f$ is analytic on $U$.
