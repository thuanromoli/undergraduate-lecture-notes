---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A [[Stochastic processes|stochastic process]] $(X_{t})_{t \in \mathbb Z}$ is causal if there exists real numbers $(\psi_{j})_{j \in \mathbb N_{0}}$ with $\sum\limits_{j=0}^{\infty}|\psi_{j}|< \infty$ and we can write $$X_{t}=\sum\limits_{j=0}^{\infty}\psi_{j}\varepsilon_{t-j} \quad \forall t \in \mathbb Z.$$

> [!def] Definition
> A [[Stochastic processes|stochastic process]] $(X_{t})_{t \in \mathbb Z}$ is causal if there exists a polynomial function $\varphi(B)$ with a well-defined inverse $\varphi^{-1}(B)$ and we can write
> $$X_{t}=\varphi^{-1}(B)\varepsilon_{t} \quad \forall t \in \mathbb Z.$$
> In other words, the process is causal if the roots of the complex polynomial $\varphi(z)$ lie outside of the unit circle, that is $|z|>1$.