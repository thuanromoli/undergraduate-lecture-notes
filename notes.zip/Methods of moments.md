---
tags:
  - MT4527
aliases:
---
Let $X_{t} = m + Y_{t}$ be the [[Classical decomposition model|constant mean model]], with observations $x_{1},...,x_{t}$ for $t \in \mathbb N_{0}$.

> [!def] Definition
> The method of moments consists in matching sample moments with moments, i.e. sample mean with the mean, the sample variance with the variance, etc. This yields the following estimate for the constant mean m:
> $$\widehat m_{t}^{c} = \frac{1}{t} \sum\limits_{i=t}^{t}x_{i}.$$

- **Flaw**: The CMM reacts slowly to process changes because it assigns equal weights to all the available observations, including outdated ones.
- **Idea**: Change the weights of each observation so that earlier observations are weighted less.
