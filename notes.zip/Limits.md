---
tags:
  - MT2502
aliases:
---
Let $A \subseteq \mathbb R$ and $f: A \to \mathbb R$ be a [[Functions|function]] on $A$.

> [!def] Definition
> The limit $\lim\limits_{x \to a}f(x)$ exists and equals $\mathscr l \in \mathbb R$ if
> $$\forall \varepsilon>0\;\; \exists \delta>0\;\;\text{s.t}\;\; x \in A\setminus \set{a} \text{ with } |x-a| \leqslant \delta \implies |f(x) - \mathscr l| \leqslant \varepsilon.$$

> [!def] Left-limit
> The left-limit $\lim\limits_{x \to a^{-}}f(x)$ exists and equals $\mathscr l \in \mathbb R$ if
> $$\forall \varepsilon>0\;\; \exists \delta>0\;\;\text{s.t}\;\; x \in A\setminus \set{a} \text{ with } x<a \text{ and }|x-a| \leqslant \delta \implies |f(x) - \mathscr l| \leqslant \varepsilon.$$

> [!def] Right-limit
> The right-limit $\lim\limits_{x \to a^{+}}f(x)$ exists and equals $\mathscr l \in \mathbb R$ if
> $$\forall \varepsilon>0\;\; \exists \delta>0\;\;\text{s.t}\;\; x \in A\setminus \set{a} \text{ with } x>a \text{ and }|x-a| \leqslant \delta \implies |f(x) - \mathscr l| \leqslant \varepsilon.$$

> [!thm] Theorem
> $\lim\limits_{x \to a}f(x)$ exists if and only if $\lim\limits_{x \to a^{-}}f(x)$ and $\lim\limits_{x \to a^{+}}f(x)$ both exists and are equal.
> 
> In other words,
> $$\lim\limits_{x \to a^{-}}f(x) = \lim\limits_{x \to a^{+}}f(x) = \mathscr l \implies \lim\limits_{x \to a}f(x) = \mathscr l.$$
