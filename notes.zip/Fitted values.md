---
alias:
  - fitted value
  - fitted values
type: def
tag: MT2508
---
Consider a [[Simple linear regression|simple linear regression]] model $Y_i=\alpha+\beta x_i + \varepsilon_i$ for $i=1,...,n$, and the [[Least-squares estimation|least-squares estimates]] $\hat{\alpha}$ and $\hat{\beta}$.

>[!def] Definition
>The fitted value $\hat y_i$ corresponding to $x_i$ is the value predicted by the regression line: $$\hat{y}_{i}=\hat{\alpha}+\hat{ \beta}x_{i}$$
