---
alias: even function
type: def
tags: MT2507
---
Let $f: X\to Y$ be a [[Functions|function]].

>[!def] Definition
>$f$ is even if $$f(-x)=f(x)$$
