---
tags:
  - MT4551
aliases:
---
> [!thm] Price modelling
> We model share prices with a geometric Brownian stochastic differential equation
> $$dS = \mu S dt + \sigma S dW$$
> where $\mu$ is the average growth rate and $\sigma$ is the volatility.

> [!gen] Remarks
> - We have two assumptions:
> 	1. Price ($S$) increases over time.
> 	2. Price exhibits random fluctuations $(\sigma dW)$ and price exhibits the same return $(dS/S)$ (that is, the fluctuation of the price depends on the price e.g. £10 will have £1 fluctuations but £1 will have £0.10 fluctuations).
> - The above leads to two components of the equation
> 	1. The deterministic part
> 	   $$dS = \mu S dt \implies S(t) = S_{0}e^{\mu t}$$
> 	2. The random part
> 	   $$dS= \sigma S dW \implies \frac{dS}{S}=\sigma dW$$
> - This is similar to the [[Wiener process]], the difference is that now we add dependency on $S,$ which scales everything by the present share price.
