---
tag: MT2507
type: mthd
alias:
- 
---
Consider an ODE of the form $\frac{dx}{dt}=f(t,x)$.

>[!def]  Definition
>Heun's method is the following iteration: $$\matrix{t_{n+1}=t_{n}+h \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \   \\ x^{*}_{n+1}=x_{n}+hf(t_{n},x_{n})\ \ \ \ \ \ \ \ \  \\ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ x_{n+1}= x_{n}+ \frac{h}{2}\left(f(t_{n},x_{n})+f(t_{n+1},x^{*}_{n+1})\right)}$$
>where $(t_{0},x_{0})$ is the initial condition and $(t_{1},x_{1}),(t_{2},x_{2}),...,(t_{n},x_{n})$ are approximation for the curve solution.

---

#### Spaced repetition
