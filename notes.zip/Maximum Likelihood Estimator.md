---
type: mthd
tags:
  - MT2508
  - MT3507
aliases:
  - MLE
---
Let $\boldsymbol x=\set{x_1,...,x_n}$ be a set of observations each with [[Probability mass function|pmf]]/[[Probability density function|pdf]] $f(x_i;\boldsymbol\theta)$ which depends on some parameters $\boldsymbol{\theta} \in \Theta$.

> [!def] Definition
> A maximum likelihood estimator of a parameter $\boldsymbol{\theta}$ is a [[Estimators|estimator]] $\widehat {\boldsymbol{\theta}}(\boldsymbol{x})$ for the sample $\boldsymbol{x}$, such that
> $$L(\widehat {\boldsymbol{\theta}}(\boldsymbol{x});\boldsymbol{x})=\max_{\boldsymbol{\theta} \in \Theta}L(\boldsymbol{\theta};\boldsymbol{x}).$$
> Such estimator need not be uniquely defined.

>[!gen]+ Method to find the MLE
>1. find the [[Log-likelihood]] or [[Likelihood]]
>2. set $\frac{\text dL(\boldsymbol\theta;\boldsymbol x)}{\text d \boldsymbol\theta}=\frac{\text dl(\boldsymbol\theta;\boldsymbol x)}{\text d \boldsymbol\theta}=0$
>3. verify that the second derivative is negative
>4. solve for $\boldsymbol{\theta}$.
