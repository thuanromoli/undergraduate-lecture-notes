---
tags:
  - MT3503
aliases:
---
Let $\gamma:[a,b] \to \mathbb C$ be a [[Contours|contour]] and let $F: U \to \mathbb C$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] defined on an [[Open sets|open subset]] $U$ containing $\gamma^{*}$.

> [!thm] Easy version
> Suppose that $F$ is [[Holomorphic functions|holomorphic]] on $U$ with derivative $f = F'$ that is [[Continuity|continuous]] on $\gamma^{*}$. Then
> $$\int_{\gamma}^{}f(z)\;dz =0.$$

Let $\gamma:[a,b] \to \mathbb C$ be a [[Contours|contour]] and let $f: U \to \mathbb C$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] defined on an [[Open sets|open subset]] $U$ such that $\gamma^{*} \cup I(\gamma) \subseteq U$.

> [!thm] Cauchy's Theorem (general)
> Suppose that $f$ is [[Holomorphic functions|holomorphic]] on $U$. Then
> $$\int_{\gamma}^{}f(z)\;dz =0.$$

> [!thm] Cauchy's Theorem (for continuous derivatives)
> Suppose that $f$ is [[Holomorphic functions|holomorphic]] on $U$ and in addition that $f'$ is continuous on $U$. Then
> $$\int_{\gamma}^{}f(z)\;dz =0.$$

> [!thm] Cauchy's Theorem (for a triangle)
> Suppose that $\gamma$ is a triangular contour. Suppose that $f$ is [[Holomorphic functions|holomorphic]] on an open set containing $\gamma$ and its interior. Then
> $$\int_{\gamma}^{}f(z)\;dz =0.$$

> [!thm] Cauchy's Theorem (for a polygon)
> Suppose that $\gamma$ is a polygonal contour. Suppose that $f$ is [[Holomorphic functions|holomorphic]] on an open set containing $\gamma$ and its interior. Then
> $$\int_{\gamma}^{}f(z)\;dz =0.$$

Proof (Easy version):
By [[The Fundamental Theorem of Calculus]] for path integrals,
$$\int_{\gamma}^{}f(z)\;dz=F(\gamma(b))-F(\gamma(a)) =0$$
since $\gamma$ is closed, i.e. $\gamma(b) = \gamma(a)$.

Proof (for continuous derivatives):
The first step is to replace $\gamma$, if necessary, by its reverse $\overleftarrow \gamma$ so that (using [[Theorems about integrals along a curve#^8c3e80|this theorem]]) we can assume that $\gamma$ is positively oriented (i.e. is traced anti-clockwise).

Write the [[Real decomposition of complex functions|real decomposition]] $f(x+iy) = u(x,y) + i v(x,y)$.
Similarly write $\gamma(t) = x(t) +iy(t)$.
Now we have $u,w:\tilde U \to \mathbb R$ and $x,y:[a,b] \to \mathbb R$ where $\tilde U = \set{(x,y) \in \mathbb R^{2}:x+iy}$.

Then we have
$$\begin{align*}
\int_{\gamma}^{}f(z)\;dz &= \int_{a}^{b} f(\gamma(t))\;\gamma'(t)\;dt\\
&= \int_{a}^{b} f\Big(x(t)+iy(t)\Big)\;\Big(x(t)+iy(t)\Big)'\;dt\\
&= \int_{a}^{b} \bigg [u\Big(x(t),y(t)\Big)+iv\Big(x(t),y(t)\Big)\bigg]\;\Big(x'(t)+iy'(t)\Big)\;dt\\
&= \int_{a}^{b} \bigg [u\Big(x,y\Big)+iv\Big(x,y\Big)\bigg]\;\Big(x'+iy'\Big)\;dt &\text{removed $(t)$ for legibility}\\
&= \int_{a}^{b} \bigg[ \Big( u(x,y)x'-v(x,y)y' \Big) +i \Big( u(x,y)y'+v(x,y)x'     \Big) \bigg]\;dt\\
&= \int_{a}^{b}  \Big( u(x,y)x'-v(x,y)y' \Big)\;dt +i \int_{a}^{b} \Big( u(x,y)y'+v(x,y)x'     \Big)\;dt\\
\end{align*}$$
Consider the first term and recall [[Green's Theorem]].
$$\begin{align*}
\int_{a}^{b}  \Big( u(x(t),y(t))\frac{dx}{dt}-v(x(t),y(t))\frac{dy}{dt} \Big)\;dt &= \oint_{\tilde\gamma}^{}  \Big( u(x,y)dx-v(x,y)dy \Big)\\
&= \iint_{\tilde \gamma}^{} \left(-\frac{\partial v}{\partial x} - \frac{\partial u}{\partial y}\right) dy\;dx\\
&= -\iint_{\tilde \gamma}^{} \left(\frac{\partial v}{\partial x} + \frac{\partial u}{\partial y}\right) dy\;dx
\end{align*}$$
By the [[The Cauchy-Riemann equations|Cauchy-Riemann equations]], we have that $\frac{\partial v}{\partial x} = -\frac{\partial u}{\partial y}$ and so the above integral is 0. The same argument can be made for the other integral and so we conclude that $\int_{\gamma}^{}f(z)dz = 0$.

Proof (for a triangular contour):
The first step is to subdivide $\gamma$, by dividing each edge of $\gamma$ is half, into four smaller triangular contours which, temporarily, we label $\delta_{1},..., \delta_{4}$.
![[cauchy_att.png|400]]
Now using [[Theorems about integrals along a curve|this theorems]], by noting that the integrals along each interior edge cancel as they are traversed in opposite directions, we have
$$\int_{\gamma}^{}f(z)\;dz = \sum\limits_{i=1}^{4}\int_{\delta_{i}}^{}f(z)\;dz.$$
And using the [[Triangle inequality|triangle inequalities]], 
$$\left|\int_{\gamma}^{}f(z)\;dz \right|= \left|\sum\limits_{i=1}^{4}\int_{\delta_{i}}^{}f(z)\;dz\right| \leqslant \sum\limits_{i=1}^{4}\left |\int_{\delta_{i}}^{}f(z)\;dz \right|.$$
Now we divide both sides by 4 and obtain
$$\frac{1}{4}\left|\int_{\gamma}^{}f(z)\;dz \right| \leqslant \frac{1}{4}\sum\limits_{i=1}^{4}\left |\int_{\delta_{i}}^{}f(z)\;dz \right|,$$
where we can view the right hand side as the mean value of the moduli of the integrals.

At least one of these moduli of the integrals has to be larger than said mean, say $\delta_{j}$ for $j \in \set{1,2,3,4}$. That is,
$$\frac{1}{4}\sum\limits_{i=1}^{4}\left |\int_{\delta_{i}}^{}f(z)\;dz \right| \leqslant \left|\int_{\delta_{j}}^{}f(z)\;dz\right|$$
Putting this with the above, we have
$$\frac{1}{4}\left|\int_{\gamma}^{}f(z)\;dz \right|\leqslant \left|\int_{\delta_{j}}^{}f(z)\;dz\right|$$
We define $\gamma_{1}$ to be the contour that satisfies the above inequality, relabel $\gamma_{1}= \delta_{j}$.
We note that each edge of $\gamma_{1}$ has half the length of the corresponding edge of $\gamma$, so $L(\gamma_{1}) = \frac{1}{2} L(\gamma)$.

We now repeat the process with the triangular contour $\gamma_{1}$, to find a new contour $\gamma_{2}$ that satisfies
$$\frac{1}{4} \left|\int_{\gamma_{1}}^{}f(z)\;dz\right| \leqslant \left|\int_{\gamma_{2}}^{}f(z)\;dz\right|$$
and so
$$\frac{1}{16}\left|\int_{\gamma}^{}f(z)\;dz \right|\leqslant \frac{1}{4} \left|\int_{\gamma_{1}}^{}f(z)\;dz\right| \leqslant \left|\int_{\gamma_{2}}^{}f(z)\;dz\right|.$$
Continuing this process, we construct a sequence of triangular contours $\gamma_{1},\gamma_{2},...$ such that
$$\frac{1}{4^{n}} \left|\int_{\gamma_{}}^{}f(z)\;dz\right| \leqslant \left|\int_{\gamma_{n}}^{}f(z)\;dz\right|\qquad\text{and}\qquad \frac{1}{2^{n}}L(\gamma) = L(\gamma_{n})$$ ^988c7a

Now for each $n \in \mathbb N$, pick a point $c_{n}$ in the interior of the triangular contour $\gamma_{n}$.
At each stage we choose $\gamma_{n+1}$ via subdivision of the interior of $\gamma_{n}$ and so $I(\gamma_{n+1})\subseteq I(\gamma_{n})$.
If $m \geqslant n$, then both $c_{m}$ and $c_{n}$ lie inside the triangular contour $\gamma_{n}$. Hence
$$|c_{m}-c_{n}| \leqslant L(\gamma_{n}) = \frac{1}{2^{n}} L(\gamma)$$
since the distance between two points in a triangle is less than its perimeter. Hence
$$|c_{m}-c_{n}|\to 0 \qquad \text{as }\;m,n \to \infty.$$
This means that $(c_{n})_{n}$ is a [[Cauchy sequence]] and since [[Complex numbers|complex number]] form a [[Complete sets|complete set]], it necessarily convergent to some point $c \in \mathbb C$.
For every choice of $n$, this limit $c$ lies in the union $\gamma^{*}_{n} \cup I(\gamma_{n})$.

Now $f$ is [[Differentiability|differentiable]] at $c$ and so
$$\forall \varepsilon>0 \;\exists \delta>0 \;\text{s.t}\; |h|\leqslant \delta \implies \left|\frac{f(c+h)-f(c)}{h}-f'(c)\right| \leqslant \varepsilon.$$
For such $\delta$, consider the [[Open balls|open ball]] $B(c,\delta)$.
If we keep subdividing triangles, eventually a triangle will be small enough to be contained in such ball.
$$\exists N \in \mathbb N \;\text{s.t}\;I(\gamma_{N})\cup \gamma_{N}^{*} \subseteq B(c,\gamma).$$
By letting $z=c+h$, where $z$ lies on $\gamma^{*}_{n}$, we have
$$\begin{align*}
&\left|\frac{f(c+h)-f(c)}{h}-f'(c)\right|\leqslant \varepsilon\\
\iff & \left|\frac{f(z)-f(c)}{z-c}-f'(c)\right| \leqslant \varepsilon\\
\iff & \left|\frac{f(z)-f(c)-f'(c)(z-c)}{z-c}\right| \leqslant \varepsilon\\
\iff & \left|{f(z)-f(c)-f'(c)(z-c)}\right| \leqslant \varepsilon |z-c|
\end{align*}$$
We also note using the easy version of Cauchy's theorem (we can use it as we know $z \in \gamma^{*}$) that
$$\int_{\gamma_{n}}^{}1dz=\int_{\gamma_{n}}^{}z dz=0.$$
Now, finally, we can write
$$\begin{align*}
\int_{\gamma_{n}}^{}f(z)dz &= \int_{\gamma_{n}}^{} \Big (f(z)-f(c)-f'(c)(z-c) + f(c) + f'(c)(z-c)\Big )dz \\
&= \int_{\gamma_{n}}^{} \Big (f(z)-f(c)-f'(c)(z-c) \Big )dz + \int_{\gamma_{n}}^{}f(c)+f'(c)(z-c)dz\\
&= \int_{\gamma_{n}}^{} \Big (f(z)-f(c)-f'(c)(z-c) \Big )dz + \int_{\gamma_{n}}^{}f(c)+zf'(c)-cf'(c)\;dz\\
&= \int_{\gamma_{n}}^{} \Big (f(z)-f(c)-f'(c)(z-c) \Big )dz + \int_{\gamma_{n}}^{}f(c)-cf'(c)\;dz+ \int_{\gamma_{n}}^{}zf'(c)\;dz\\
&= \int_{\gamma_{n}}^{} \Big (f(z)-f(c)-f'(c)(z-c) \Big )dz + \Big (f(c)-cf'(c)\Big) \int_{\gamma_{n}}^{} 1\;dz+ f'(c)\int_{\gamma_{n}}^{}z\;dz\\
&= \int_{\gamma_{n}}^{} \Big (f(z)-f(c)-f'(c)(z-c) \Big )dz.
\end{align*}$$
Applying the [[Crude Estimation Theorem]] with $|f(z)-f(c)-f'(c)(z-c)| \leqslant \varepsilon|z-c| \leqslant \varepsilon L(\gamma_{n})$ yields.
$$\begin{align*}
\left|\int_{\gamma_{n}}^{}f(z)dz\right | &= \left|\int_{\gamma_{n}}^{} \Big (f(z)-f(c)-f'(c)(z-c) \Big )dz\right|\\
&\leqslant \varepsilon L(\gamma_{n}) \cdot L(\gamma_{n})\\
&= \frac{\varepsilon}{4^{n}}L(\gamma)^{2}.
\end{align*}$$
So now using the (much earlier) [[Cauchy's Theorem#^988c7a|above equaiton]],
$$\begin{align*}
\left|\int_{\gamma_{}}^{}f(z)\;dz\right| &\leqslant 4^{n}\left|\int_{\gamma_{n}}^{}f(z)\;dz\right|\\
&\leqslant 4^{n}\cdot \frac{\varepsilon}{4^{n}}L(\gamma)^{2}\\
&= \varepsilon L(\gamma)^{2}
\end{align*}$$
And since $\varepsilon>0$ is arbitrary, we are done.

Proof (for a polygonal contour):
Triangulate $\gamma$; that is, subdivide the interior of $\gamma$ into triangles.
In this way, we construct a collection $\gamma_{1},\gamma_{2},...,\gamma_{k}$ of triangular contours such that
$$\int_{\gamma}^{}f(z)dz= \sum\limits_{i=1}^{k}\int_{\gamma_{i}}^{}f(z)dz$$
and hence by Cauchy's theorem for a triangle, the proof is complete.

Proof (general):
A full proof of Cauchy’s Theorem, as stated in Theorem is beyond this lecture course.
In fact, the work done so far takes us quite a long way towards a full proof.
A strategy (which can actually be fully implemented) is the following: If $f$ is holomorphic on an open set containing an arbitrary contour $\gamma$ and its interior, approximate $\gamma$ by a polygonal contour $\tilde \gamma$ in such a way that the integrals
$$\int_{\gamma} f(z) \, \mathrm{d}z \qquad\textsf{and}\qquad\int_{\tilde{\gamma}} f(z) \, \mathrm{d}z$$
are close (i.e., within some given $\varepsilon>0$).
Then $\int_{\tilde{\gamma}} f(z) \, \mathrm{d}z = 0$ by the case already established.
From this, one deduces the general version of Cauchy’s Theorem.
The main challenge remaining in this approach is obtaining the polygonal approximation $\tilde \gamma$ such that the integrals are within $\varepsilon$ of each other.
This requires much care and that is the reason we omit this aspect of the proof of the general result.