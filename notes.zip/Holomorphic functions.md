---
tags:
  - MT3503
aliases:
  - holomorphic function
  - holomorphic
---
Let $U$ be an [[Open sets|open subset]] of $\mathbb C$ and $f: U \to \mathbb C$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] defined on $U$.

> [!def] Definition
> $f$ is holomorphic on $U$ if it is [[Differentiability|differentiable]] at every point of $U$.
