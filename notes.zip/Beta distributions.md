---
tags:
  - MT3507
aliases: gamma distribution
---
> [!gen] Relationships to other distributions
> - [[t distributions]]

> [!gen] Parameters
> $\alpha \in (0,\infty)$ - 
> $\beta \in (0,\infty)$ - 

> [!gen] Support
> $x\in (0, 1)$ - continuous [[Random variables|rv]] 

>[!gen] [[Probability density function]]
> $$f(x) = \frac{1}{B(\alpha,\beta)}x^{\alpha-1}(1-x)^{\beta-1}$$

> [!gen] Typical use
> Beta distribution can be understood as representing a distribution _of probabilities_, that is, it represents all the possible values of a probability when we don't know what that probability is.

>[!thm] Properties
> - $\mathbb E(X^{r})= \frac{\Gamma(\alpha+\beta)\Gamma(\alpha+r)}{\Gamma(\alpha+r + \beta)\Gamma(\alpha)}$
>   Proof: by definition.
> - $\mathbb E(X) = \frac{\alpha}{\alpha+\beta}$, $\text{Var }(X) = \frac{\alpha \beta}{(\alpha+ \beta+1)(\alpha+ \beta)^{2}}$
>   Proof: use (1) and properties of the gamma function.
