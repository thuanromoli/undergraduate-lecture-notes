---
tags:
  - MT4531
aliases:
---
![[mcmc1_att.png]]

Idea part 1
    1. We want to simulate from a posterior $\pi(\boldsymbol{\theta}|x)$.
    2. Build a Markov Chain that has $\pi(\boldsymbol{\theta}|x)$ as its stationary distribution.
    3. After convergence, $\theta^{(j)}$ and $\theta^{(j+1)}$ are dependent samples from the posterior (i.e. a sample of $\pi(\boldsymbol{\theta}|x)$).

Idea part 2
See [[Monte Carlo integration]]

FAQ
1. How do we generate such MC? See [[Gibbs sampler]], [[Metropolis-Hasting Algorithm]], and direct sampling.
2. How long do we need to run the chain for before it converges? See [[Burn-in and convergence diagnostic|burn-in and convergence diagnostic]].
3. How many samples do we need to collect for accurate inference? See [[Monte Carlo error]].