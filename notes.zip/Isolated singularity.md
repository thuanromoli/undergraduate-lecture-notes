---
tags:
  - MT3503
aliases:
  - isolated singularity
---
Let $D$ be some subset of $\mathbb C$ and $f: D \to \mathbb C$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] defined on $D$.

> [!def] Definition
> A point $a \in \mathbb C$ is an isolated singularity of $f$ if there exists some $r>0$ such that $f$ is defined and [[Holomorphic functions|holomorphic]] on the punctured disc $B'(a,r)= \set{z \in \mathbb C : |z-a|<r}$ but $f$ is not differentiable at $a$.
