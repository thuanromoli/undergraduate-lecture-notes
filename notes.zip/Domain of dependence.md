---
tags:
  - MT3504
type: 
aliases:
---
>[!def] Definition
>The domain of dependence of a point is the part of the [[The Cauchy initial value problem|initial data]] curve between two characteristics going through the given point.
