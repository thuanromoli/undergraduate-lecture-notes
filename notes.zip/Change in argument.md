---
tags:
  - MT3503
aliases:
---
Let $\gamma$ be a piecewise smooth [[Curves|curve]] and $f$ be a [[Holomorphic functions|holomorphic]] [[Functions|function]] that is non-zero on $\gamma^{*}$.

> [!def] Definition
> Write $\Delta_{\gamma}(\arg f)$ for the overall change in the argument of $f(z)$ as $z$ traces the curve $\gamma$. That is, using the [[Argument Principle]],
> $$\Delta_{\gamma}( \arg f ) = \frac{1}{i} \int_{\gamma} \frac{f'(z)}{f(z)} \, \mathrm{d}z.$$
