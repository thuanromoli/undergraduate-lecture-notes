---
type: def
tags:
  - MT2505
  - MT4003
aliases:
  - homomorphisms
  - homomorphism
---
Let $G$ and $H$ be [[groups]] and we assume that the [[binary operations]] are written as multiplication in both these groups.

>[!def] Definition
>A homomorphism $\phi : G \to H$ is a [[Functions|function]] such that $$(g_{1}g_{2})\phi=(g_{1}\phi)(g_{2}\phi) \ \ \forall g_{1},g_{2} \in G$$
