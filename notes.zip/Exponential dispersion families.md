---
tags:
  - MT3508
aliases:
  - exponential dispersion family
---
![[expdispfam_att.png]]

> [!gen] Remarks
> - For [[Binomial distributions|binomial]] and multinomial models, the outcome must be the proportion of successes $y=T/N$, not the number of successes $T \sim \text{Bin}(N,p)$ and $N$ must be known.
> - For [[Geometric distribution|geometric]] models, $Y$ must be the number of trials before the first success, not the number of trials until the first success.
