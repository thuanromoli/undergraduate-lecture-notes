---
type: def
tags:
  - MT2505
  - MT3501
aliases:
  - field
---
>[!def] Definition
>A field is a [[Commutative rings|commutative ring]] $R$ with two additional properties:
>$\text{M3: } \exists \text{ some }1\ne 0 \in F \ \text{ s.t } \ 1a=a1=a \ \ \forall a\in F$
>$\text{M4: } \forall a\ne0 \in F, \ \exists \text{ some} a^{-1} \in F \ \text{ s.t } \ aa^{-1}=a^{-1}a=1$
