---
tags:
  - MT3502
aliases:
---
> [!thm] Theorem
> The set $\mathbb R \cap (0,1)$ is [[Countable sets|uncountable]] and so $\mathbb R$ is uncountable.

Proof:
Suppose, for a contradiction, that $\mathbb R \cap (0,1)$ is countable.
Then we may enumerate its elements as a list $(a_{1},a_{2},a_{3},...)$ which must contain every number in $(0,1)$.
We may express these numbers in decimal form
$$\begin{align*}
a_{1} &= 0\;.\; \underline{a_{11}} \; a_{12} \; a_{13} \; a_{14} \; \cdots\\
a_{2} &= 0\;.\; a_{21} \; \underline{a_{12}} \; a_{13} \; a_{14} \; \cdots\\
a_{3} &= 0\;.\; a_{31} \; a_{32} \; \underline{a_{33}} \; a_{34} \; \cdots\\
a_{4} &= 0\;.\; a_{41} \; a_{42} \; a_{43} \; \underline{a_{44}} \; \cdots\\
\vdots & \;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\vdots
\end{align*}$$
so that $a_{ij}$ is the $j$th decimal digit of $a_{i}$. (If $a_{i}$ is a number with two decimal expansions, take the one ending in a string of 0s rather than that ending in a string of 9s).

Define
$$b=0\; . \; b_{1}\;b_{2}\;b_{3}\;b_{4}\ldots \;\text{ where } \;\;
b_{i}=\begin{cases}
5 & \text{if }\;a_{ii} \neq 5 \\
7 & \text{if }\;a_{ii} = 7
\end{cases}$$
Then $b \neq a_{i}$ for all $i$, since $b_{i}\neq a_{ii}$; that is, $b$ differs from $a_{i}$ in the $i$th decimal place.
Thus $b$ is not in the list, which contradicts the assumption that the list contains all real numbers in $(0,1)$.
Hence $\mathbb R \cap (0,1)$ is uncountable.