---
tags:
  - MT3503
aliases:
---
Let $\alpha \in \mathbb C$.

> [!def] Definition
> To define $z^\alpha$ for $z$ in an appropriate subset of $\mathbb C$, proceed as follows:
> 1. Cut the plane to define a suitable branch of logarithm.
> 2. Define $$z^{\alpha}= e^{\alpha \log z}.$$
