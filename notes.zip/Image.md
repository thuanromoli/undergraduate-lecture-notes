---
type: def
tags:
  - MT2505
  - MT3501
  - MT4003
aliases:
  - image
---
#### For group theory:
Let $\phi: G \to H$ be a [[Homomorphisms|homomorphism]] from a [[Groups|group]] $G$ to a [[Groups|group]] $H$.

>[!def] Group Theory
>The image of $\phi$ is the set of elements of $H$ that arise as the image of some element of $G$: $$\text{im }\phi=\set{x \phi : x \in G}$$

#### For linear algebra:
Let $T : V \to W$ be a [[Linear transformations|linear transformation]] between [[Vector spaces|vector spaces]] $V$ and $W$ over the [[Fields (Algebra)|field]] $F$.

>[!def] Linear Algebra
>The image of $T$ is the set of elements of $W$ that arise as the image of some element of $V$: $$\text{im }T=\set{T(v): v \in V}$$
