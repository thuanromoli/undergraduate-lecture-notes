---
tags:
  - MT3504
type: def
aliases:
  - boundary conditions
---
Let $C^{2}(a,b)$ be the [[Inner product space of twice-differentiable functions|inner product space of twice-differentiable functions]].
Let $L$ be in [[Sturm-Liouville form]].
Let $L[y]=\lambda w y$ be a [[Sturm-Liouville problems|Sturm-Liouville problem]].

>[!thm] Theorem
>To satisfy the [[Self-adjoint transformations|self-adjoint property]], we need to satisfy [[Lagrange's Identity]].
>
>This can be achieved in one of three ways:
>- Regular boundary conditions: $p(a)\neq 0$ and $p(b) \neq 0$
>	- $\alpha_{1}y(a)+\alpha_{2}y'(a)=0$
>	- $\beta_{1}y(b)+\beta_{2}y'(b)=0$
>	- With at least one of the constants $\alpha_{1},\alpha_{2}$ and one of the constants $\beta_{1},\beta_{2}$ non-zero.
>- Singular boundary conditions: $p(a)=0$ and/or $p(b)=0$
>	- $p(x)y^{2}$ is [[Boundedness|bounded]] as $x\to a$ or $x\to b$
>- Periodic boundary conditions:
>	- $y(a)=y(b)$
>	- $y'(a)=y'(b)$
