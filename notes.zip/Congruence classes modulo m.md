---
type: thm
alias: congruence classes modulo m
tag: MT2505
---
>[!def] Definition
>The [[Equivalence relations|equivalence relation]] "[[Congruence modulo m|congruence modulo m]]" has precisely $m$ [[Equivalence classes|equivalence classes]], namely $[r]=\set{km+r : k \in \mathbb{Z}}$ for $r=0,1,...,m-1$. These are called "congruence classes modulo $m$"

PROOF:
Claim 1: The elements of $[r]$ are of the form $km+r$, $k\in \mathbb{Z}$
	Let $a \in \mathbb{Z}$ be an arbitrary, then $a\in [r]$ $\iff$ $r\equiv a \pmod m$ $\iff$ $m \mid a-r$ $\iff$ $a-r = km$ for some $k\in \mathbb{Z}$ $\iff$ $a=km+r$ 
	Hence $[r]=\set{km+r:k\in \mathbb{Z}}$
Claim 2: There are $m$ equivalence classes: $[0],[1],...,[m-1]$
	Let $a \in \mathbb{Z}$ be an arbitrary. Let us divide $a$ by $m$ to obtain a quotient and a reminder: $a=qm+r$, $0 \leqslant r < m$ $\implies$ $r\equiv a \pmod m$. Then $a\in [r]$.
	This shows every integer lies in one of $[0],[1],...,[m-1]$
Claim 3: The equivalence classes $[0],[1],...,[m-1]$ are distinct
	Suppose $[r]=[s]$ where $0 \leqslant r,s < m$.
	Then $r\in [r]=[s]$ $\implies$ $s\equiv r \pmod m$ $\implies$ $m \mid r-s$ $\implies$ $r-s = km$ for some $k \in \mathbb{Z}$.
	Note: $0\leqslant r<m \;\wedge\; 0 \leqslant  s<m$ $\implies$ $0 \leqslant r<m \;\wedge\; 0 \geqslant -s > -m$ $\implies$ $0 \leqslant r<m \;\wedge\; -m < -s \leqslant  0$ $\implies$ $-m <r-s  < m$
	Example: let $r-s = 12$ and $m=4$ then we need $12$ to be between $(-4,4)$ and this fixes the value of $k$ to 0 and hence $r-s$ is also 0.
	Hence $r-s=0$ and $r=s$.
