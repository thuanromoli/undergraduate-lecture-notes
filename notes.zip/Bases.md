---
tags:
  - MT2501
  - MT3501
type: def
aliases:
  - basis
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$.

>[!def] Definition
>A set of vectors $\mathscr{B}=\set{v_{1},...,v_{k}}$ is a basis for $V$ if they are both a [[Span|spanning set]] for $V$ and are [[Linear independence|linearly independent]].

---

#### Spaced repetition
What is a basis for a vector space $V$?
?
>A set of vectors $\mathscr{B}=\set{v_{1},...,v_{k}}$ is a basis for $V$ if they are both a [[Span|spanning set]] for $V$ and are [[Linear independence|linearly independent]].