---
tags:
  - MT3503
aliases:
  - harmonic
---
Let $V$ be an [[Open sets|open subset]] of $\mathbb R^{2}$. Let $u:V \to \mathbb R$ be a [[Functions|function]] defined on $V$.

> [!def] Definition
> $u$ is harmonic on $V$ if
> 1. $u$ has [[Continuity|continuous]] second-order partial derivatives on $V$.
> 2. $u$ satisfies [[Laplace's equation]] $\frac{\partial ^{2}u}{\partial x^{2}}+\frac{\partial ^{2}u}{\partial y^{2}}=0$.

Motivation:
Consider a [[Holomorphic functions|holomorphic]] $f:U \to \mathbb C$ as its [[Real decomposition of complex functions|real decomposition]] $f(z)=f(x+iy)=u(x,y) + i v(x,y)$.
Then by [[The Cauchy-Riemann equations|the Cauchy-Riemann equations]], at every point of $\tilde U$
$$\begin{align}
&(1): \frac{\partial u}{\partial x} = \frac{\partial v}{\partial y} \\
&(2): \frac{\partial v}{\partial x} = - \frac{\partial u}{\partial y}.
\end{align}$$
Now, we also observe that $f$ possesses $n$th derivatives by [[Cauchy's Formula for Derivatives]], so $f'$ is [[Differentiability|differentiable]].
$$\begin{align}
&\frac{\partial }{\partial x}(1) \implies \frac{\partial^{2} u}{\partial x^{2}} = \frac{\partial^{2} v}{\partial x\partial y} \\
&\frac{\partial }{\partial y}(2) \implies \frac{\partial^{2} v}{\partial y\partial x} = - \frac{\partial^{2} u}{\partial y^{2}}.
\end{align}$$
Moreover, since $f''$ is differentiable, then it is continuous. And so $\frac{\partial^{2} v}{\partial x\partial y}$ and $\frac{\partial^{2} v}{\partial y\partial x}$ both exists and are continuous. This is a sufficient condition for $\frac{\partial^{2} v}{\partial x\partial y} =\frac{\partial^{2} v}{\partial y\partial x}$.

Putting this together, we have
$$\frac{\partial ^{2}u}{\partial x^{2}} + \frac{\partial ^{2}u}{\partial y^{2}} = 0$$
that is, $u$ satisfies Laplace's equation.

The same argument applies to the imaginary part $v$ of the holomorphic function $f$.