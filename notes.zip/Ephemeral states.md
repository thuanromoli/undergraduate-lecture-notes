---
tags:
  - MT4528
type: def
aliases:
  - ephemeral
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S$.

>[!def] Definition
>A state $j \in S$ is called ephemeral if
>$$p_{ij}=\mathbb{P}(X_{t+1}=j | X_{t}=i)=0 \;\;\forall i\in S$$
>That is, the process may begin in $j$, but it cannot stay in the state or enter the state thereafter.
