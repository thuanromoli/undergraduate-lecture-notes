---
tags:
  - MT4528
type: model
aliases:
---
>[!def] Definition
>The probability for player $A$ to win the series of games is defined as
>$$W(a)=\mathbb{P}(X_{t}=a+b+1 \text{ for some } t \geqslant 0 | X_{0}=a+1)$$

>[!thm] Theorem
>We can calculate the probability $W(a)$:
>$$W(a)=\begin{cases}
   \frac{1-(q/p)^{a}}{1-(q/p)^{N}} & \text{if }p\neq q \\
   \frac{a}{N} & \text{if } p=q
   \end{cases}$$
>
>Proof:
>First of all, we have that $W(0)=0$ and that $W(N)=1$. Then
>$$\begin{align*}
   W(a) &= \mathbb{P}(X_{t}=N+1 \text{ for some } t \geqslant 0 | X_{0}=a+1)\\
   &= \sum\limits_{k\in\set{-1,1}}^{}\mathbb{P}(X_{t}=N+1 \text{ for some } t \geqslant 0 | Z_{1}=k,X_{0}=a+1)\mathbb{P}(Z_{1}=k|X_{0}=a+1)\\
   \end{align*}$$
>since $Z_{1}=k$ for $K=-1,1$ forms a [[Partitions|partition]] of the [[Sample space, Sample points, and Events|sample space]] and we can use [[The Law of Total Conditional Probability]].
>
>Now note that
>$$\begin{cases}
   Z_{1}=1 \implies X_{1}=(a+1)+1 \\
   Z_{1}=-1 \implies X_{1}=(a+1)-1 \\
   \end{cases}$$
>hence $Z_{1}=k \implies X_{1}=(a+1)+k$. Therefore
>$W(a)=\sum\limits_{k\in\set{-1,1}}^{}\mathbb{P}(X_{t}=N+1 \text{ for some } t \geqslant 0 | X_{1}=a+k+1,X_{0}=a+1)\mathbb{P}(Z_{1}=k)$
>
>Now using the [[Markov chains and processes|memoryless property]],
>$$\begin{align*}
   W(a) &= \sum\limits_{k\in\set{-1,1}}^{}\mathbb{P}(X_{t}=N+1 \text{ for some } t \geqslant 0 | X_{1}=a+k+1)\mathbb{P}(Z_{1}=k)\\
   &= \mathbb{P}(X_{t}=N+1 \text{ for some } t \geqslant 0 )|X_{1}=a)\mathbb{P}(Z_{1}=-1)+\mathbb{P}(X_{t}=N+1 \text{ for some } t \geqslant 0 )|X_{1}=a+2)\mathbb{P}(Z_{1}=1)\\
   &= \mathbb{P}(X_{t}=N+1 \text{ for some } t \geqslant 0 )|X_{0}=a)q+\mathbb{P}(X_{t}=N+1 \text{ for some } t \geqslant 0 |X_{0}=a+2)p\\
   &= W(a-1)q + W(a+1)p
   \end{align*}$$
>Note that $\mathbb{P}(X_{t}=i|X_{1}=a)=\mathbb{P}(X_{t}=i|X_{0}=a)$ is assumed to be true.
>
>Using the fact that $p+q=1$ we have
>$$\begin{align*}
   W(a)(p+q) &= W(a-1)q+W(a+1)p\\
   \iff pW(a)+qW(a) &= W(a-1)q+W(a+1)p\\
   \iff q(W(a)-W(a-1)) &= p(W(a+1)-W(a))\\
   \iff W(a+1)-W(a) &= (W(a)-W(a-1))\frac{q}{p}
   \end{align*}$$
>
>And in particular
>$W(2)-W(1)=(W(1)-W(0)) \frac{q}{p}=W(1) \frac{q}{p}$
>$W(3)-W(2)=(W(2)-W(1)) \frac{q}{p}=W(1) \left(\frac{q}{p}\right)^{2}$
>$W(4)-W(3)=(W(3)-W(2)) \frac{q}{p}=W(1) \left(\frac{q}{p}\right)^{3}$
>$\vdots$
>$W(a+1)-W(a)=W(1) \left(\frac{q}{p}\right)^{a}$ (for $0<a<N$)
>
>Now adding up all the above equations, we have that
>$W(a+1)-W(1)=\sum\limits_{k=1 }^{a}W(1)\left(\frac{q}{p}\right)^{k}$
>$W(a+1)=W(1)+W(1)\sum\limits_{k=1 }^{a}\left(\frac{q}{p}\right)^{k}$
>$W(a+1)=W(1)\sum\limits_{k=0}^{a}\left(\frac{q}{p}\right)^{k}$
>
>Case 1: $p=q=0.5$:
>$W(a+1)=W(1)(a+1)$.
>Evaluating at $a+1=N$ we have that $W(a+1)=W(N)=1$ and $(a+1)=N$. Therefore,
>$W(1)=\frac{1}{N}$
>and finally $W(a)=W(1)a=\frac{a}{N}$
>
>Case 2: $p\neq q$:
>We use the geometric series expansion $\sum\limits_{k=0}^{b}x^{k}=\frac{1-x^{b+1}}{1-x}$.
>$W(a+1)=W(1)\frac{1- \left(\frac{q}{p}\right)^{a+1}}{1- \frac{q}{p}}$
>Evaluating at $a+1 = N$ we have that $W(a+1)=W(N)=1$ and $(a+1)=N$. Therefore,
>$W(1)=\frac{1- \frac{q}{p}}{1- \left(\frac{q}{p}\right)^{N}}$
>and finally $W(a)=W(1)\frac{1- \left(\frac{q}{p}\right)^{a}}{1- \frac{q}{p}}$ = $\frac{1- \frac{q}{p}}{1- \left(\frac{q}{p}\right)^{N}}\frac{1- \left(\frac{q}{p}\right)^{a}}{1- \frac{q}{p}}$ = $\frac{1- \left(\frac{q}{p}\right)^{a}}{1- \left(\frac{q}{p}\right)^{N}}$.

>[!thm] Theorem
>We can calculate the probability $R(a)$ of ruin:
>$$R(a)=1-W(a)=\begin{cases}
   \frac{(q/p)^{a}-(q/p)^{N}}{1-(q/p)^{N}} & \text{if }p\neq q \\
   1- \frac{a}{N} & \text{if } p=q
   \end{cases}$$
