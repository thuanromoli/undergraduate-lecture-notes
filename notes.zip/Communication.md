---
tags:
  - MT4528
type: thm
aliases:
  - communication
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S$.

>[!thm] Theorem
>[[Communicative states|Communication]] is an [[Equivalence relations|equivalence relation]] on $S$.
>1. [[Reflexivity]] $i \leftrightarrow i$
>2. [[Symmetry]] $i \leftrightarrow j \implies j\leftrightarrow i$
>3. [[Transitivity]] $i \leftrightarrow j \text{ and } j\leftrightarrow k \implies i \leftrightarrow k$

>[!gen] Remarks
>- States can be partitioned into disjoint [[Equivalence classes|equivalence classes]], $\mathcal D_{1},\mathcal D_{2},\mathcal D_{3},...$ where $\mathcal D_{i}=\set{j \in S: i \leftrightarrow j}$. That is, the set $\mathcal D_{i}$ is the set of all states that communicate with $i$.
>- If $i \leftrightarrow j$, then we say that $i$ and $j$ are in the same communication class.

>[!thm] Class solidarity
>Suppose that $i\leftrightarrow j$
>1. $i$ is a [[Recurrent states|recurrent state]] $\iff$ $j$ is a [[Recurrent states|recurrent state]]
>2. $i$ is [[Recurrent states|null recurrent]] $\iff$ $j$ is [[Recurrent states|null recurrent]]
>3. $i$ is [[Recurrent states|positive recurrent]] $\iff$ $j$ is [[Recurrent states|positive recurrent]]
>4. $i$ has [[Periodic and aperiodic states|period]] $\tau$ $\iff$ $j$ has [[Periodic and aperiodic states|period]] $\tau$
>
>The upshot of these propositions is that the decomposition into equivalence classes yields classes of the same type. So we can use the state classification terminology to refer to classes (e.g. transient class, positive recurrence class, etc...)

Proofs are omitted.
