---
tags:
  - MT3508
aliases:
---
> [!def] Leverage
> The quantity $\boldsymbol{A}_{ii}$ is the leverage of the $i$th observation.

> [!gen] Remarks
> - It arises by considering the variance of the $i$th residual.
> - Low leverage is a generally preferred.
> - The total leverage is $\sum\limits_{i}^{}\boldsymbol{A}_{ii}=tr(A)=p$.
> - The average leverage is $p/n$.
> - If $\boldsymbol{A}_{ii} > 2p/n$, try repeating the analysis without the observations.

> [!def] Cooke's distance
> Cooke's distance is defined as
> $$C_{i} = \frac{r_{i}^{2}\boldsymbol{A}_{ii}}{p(1-\boldsymbol{A}_{ii})^{2}}$$
> where $r_{i}$ is the $i$th [[Residuals|Pearson residual]].

> [!gen] Remarks
> Large values of $C_{i}$ arise when
> - Observation $i$ has high leverage.
> - Observation $i$ has high standard residual.
> 
> If $|r_{i}|>2$ or $\boldsymbol{A}_{ii}>2p/n$ or $C_{i}> \frac{8}{n-2p}$, then the observation deserves attention.
