---
type: thm
tag: MT2508
alias: invariance property
---
Let $\widehat{\boldsymbol{\theta}}$ be the [[Maximum Likelihood Estimator|MLE]] of $\boldsymbol{\theta}$ and let $g(\boldsymbol{\theta})$ be any [[Functions|function]] of $\boldsymbol{\theta}$.

>[!thm]- Invariance: $\widehat{g(\boldsymbol{\theta})}=g(\widehat{\boldsymbol{\theta}})$
>The invariance property of MLEs states that the MLE of $g(\boldsymbol{\theta})$ is $g(\widehat{\boldsymbol{\theta}})$.

> [!thm]- [[Consistent estimators|Consistency]]: $\lim\limits_{n \to \infty} \widehat{\boldsymbol{\theta}} = \boldsymbol{\theta}_{t}$

> [!thm] Efficiency: $\lim\limits_{n \to \infty} \text{Var}(\widehat{\boldsymbol{\theta}}) = \text{Cramer-Rao lower bound}$

> [!thm]- [[Normal distribution|Normality]]: $\widehat{\boldsymbol{\theta}} \sim N(\boldsymbol{\theta}_{t};\mathbf{I}(\boldsymbol{\theta})^{-1})$

^c2d912


> [!thm] Assumptions
> The above results hold when the following assumptions are satisfied:
> - The densities defined by distinct values of $\boldsymbol{\theta}$ are distinct. If this were not the case, the parameters need not be identifiable and there is no guarantee of consistency.
> - $\boldsymbol{\theta}_{t}$ is interior to the space of possible parameter values. This is necessary in order to be able to approximate the [[Log-likelihood]] by a [[Taylor's Theorem|Taylor expansion]] in the vicinity of $\boldsymbol{\theta}_{t}$ - which is required to obtain the large-sample properties above.
> - Within some neighbourhood of $\boldsymbol{\theta}_{t}$, the first three derivatives of the [[Log-likelihood]] exist and are [[Boundedness|bounded]], while the [[Fisher information]] matrix satisfies the variance equations and is positive definite and finite.
