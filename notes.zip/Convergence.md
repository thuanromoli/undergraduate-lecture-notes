---
tags:
  - MT2502
  - MT3502
aliases:
  - convergence
  - convergent
  - uniformly convergent
---
#### For real analysis in any [[Metric spaces|metric]] or [[Normed spaces|normed]] space

> [!def] Convergence of [[Sequences|sequences]] (formal)
> In a metric space $(X,d)$, the sequence $(x_{n})_{n}$ converges to $x$ if
> $$\forall \varepsilon > 0 \;\; \exists N \in N \;\; \text{s.t.} \;\;\forall n \in \mathbb N, n \geqslant N \implies d(x_{n}-x) \leqslant \varepsilon.$$
> Equivalently, in a normed space $(X,{\Vert \cdot \Vert})$, the sequence $(x_{n})_{n}$ converges to $x$ if
> $$\forall \varepsilon > 0 \;\; \exists N \in N \;\; \text{s.t.} \;\;\forall n \in \mathbb N, n \geqslant N \implies {\Vert x_{n}-x \Vert}\leqslant \varepsilon.$$

This definition is precisely the definition that the sequence of real numbers $\Big(d(x_{n},x) \Big)_{n}$ or $\Big({\Vert x_{n}-x \Vert} \Big)_{n}$ converges to 0. Thus we may reformulate the above as

> [!def] Convergence of [[Sequences|sequences]] (limits)
> In a metric space $(X,d)$, the sequence $(x_{n})_{n}$ converges to $x$ if
> $$d(x_{n},x) \to 0 \text{ as } n \to \infty.$$
> Equivalently, in a normed space $(X,{\Vert \cdot \Vert})$, the sequence $(x_{n})_{n}$ converges to $x$ if
> $${\Vert x_{n}-x \Vert} \to 0 \text{ as } n \to \infty.$$

#### For real analysis in the metric $(C[a,b]\text,|\cdot |)$

> [!def] Pointwise convergence
> A sequence $(f_{n})_{n}$ converges to $f$ if for all $x \in [a,b]$
> $$\forall \varepsilon > 0 \;\; \exists N \in \mathbb N \;\; \text{s.t.} \;\;\forall n \in \mathbb N, n \geqslant N \implies |f_{n}-f| \leqslant \varepsilon.$$

> [!def] Uniform convergence
> A sequence $(f_{n})_{n}$ uniformly converges to $f$ if
> $$\forall \varepsilon > 0 \;\; \exists N \in \mathbb N \;\; \text{s.t.} \;\;\forall n \in \mathbb N,\forall x \in [a,b], \quad n \geqslant N \implies |f_{n}-f| \leqslant \varepsilon.$$

> [!def] Uniform convergence of series
> A series $\sum\limits_{n=1}^{\infty}f_{n}$ convereges uniformly on $[a,b]$ with sum $S$ if
> the [[Series|partial sum]] $S_{N}(x) = \sum\limits_{n=1}^{N}f_{n}(x)$ tends to a function $S$ uniformly on $[a,b]$.
#### For real analysis in the metric $(\mathbb R,|\cdot |)$

> [!def] Convergence of [[Sequences|sequences]]
> A sequence $(x_{n})_{n}$ converges to $x$ (as $n$ tends to infinity) if
> $$\forall \varepsilon > 0 \;\; \exists N \in N \;\; \text{s.t.} \;\;\forall n \in \mathbb N, n \geqslant N \implies |x_{n}-x| \leqslant \varepsilon.$$
> 
> A sequence $(x_{n})_{n}$ tends to infinit (as $n$ tends to infinity) if
> $$\forall K \in \mathbb R \;\; \exists N \in \mathbb N \;\; \text{s.t.} \;\;\forall n \in \mathbb N, n \geqslant N \implies x_{n} \geqslant K.$$

> [!def] Convergence of [[Series|series]]
> A series $\sum\limits_{n=1}^{\infty}x_{n}$ converges if its [[Series|partial sum]] converges, i.e.
> $$\lim\limits_{n \to \infty}s_{n} = \lim\limits_{n \to \infty}\sum\limits_{k=1}^{n}x_{k}  \text{ exists}.$$

> [!def] Absolute convergence of [[Series|series]]
> A series is called $\sum\limits_{n=1}^{\infty}x_{n}$ absolutely convergent if $\sum\limits_{n=1}^{\infty}|x_{n}|$ is convergent.

> [!thm] Every absolutely convergent series converges
> If a series is absolutely convergent, then it converges.
