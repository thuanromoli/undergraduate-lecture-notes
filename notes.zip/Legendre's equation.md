---
tags:
  - MT3506
aliases:
---
>[!gen] ODE
>$$(1-x^{2})y''-2xy'+\lambda y=0$$
>where $\lambda$ is an unknown constant that has to be determined from the condition that the solution is bounded on $-1 \leqslant x \leqslant 1$.

> [!gen] Motivation
> This equation arises from the separation of variables of [[Laplace's equation]] in spherical coordinates. In fact $x= \cos \theta$ where $\theta$ is the polar angle and the condition comes from $0 \leqslant \theta \leqslant  \pi$.

> [!gen] Solution (at $x=0$)
> Step 0: classification of point.
> The ode in standard form is $y''-\frac{2x}{(1-x^{2})}y'+\frac{\lambda}{(1-x^{2})} y=0$. And at $x=0$, $p(x)=0$ and $q(x) = \lambda$, both bounded so $x=0$ is an ordinary point.
> 
> Step 1,2.
> Consider a solution of the form $y = \sum\limits_{n=0}^{\infty}a_{n}x^{n}$.
> Then $y' = \sum\limits_{n=0}^{\infty}a_{n}(n)x^{n-1}$ and $y'' = \sum\limits_{n=0 }^{\infty}a_{n}(n)(n-1)x^{n-2}$.
> 
> Step 3: sub into the ODE.
> $$\sum\limits_{n=0}^{\infty}\Big[ (n+2)(n+1)a_{n+2}+(-n^{2}-n+\lambda)a_{n}   \Big] x^{n}=0$$
> 
> Step 4: obtain recurrence relation.
> $$a_{n+2}= \frac{n^{2}+n - \lambda}{(n+2)(n+1)}$$
> 
> Step 5: solve for $a_{n}$,
> In this case, we can't find a closed solution. We obtain two [[Linear independence|linearly independent]] solutions corresponding to the even and odd coefficients.

> [!gen] Convergence
> $\rho=\lim\limits_{n \to \infty}\left|\frac{a_{n}}{a_{n+1}}\right| = \lim\limits_{n \to \infty}\left|\frac{a_{n+1}}{a_{n+2}}\right|$ $\implies$ $\rho^{2}= \lim\limits_{n \to \infty} \left| \frac{a_{n}}{a_{n+2}} \right|$.
> So, in our case the [[Radius of convergence|radius of convergence]] is $\rho=1$ and [[The ratio test|the ratio test]] tells us that the series [[Convergence|converges]] for $-1<x<1$. However it can be shown that, in general it divergence at $x=\pm 1$.

> [!gen] [[Legendre polynomials]]
> To fix the above problem, we choose $\lambda=l(l+1)$.
> This yields
> $$a_{n+2}=a_{n}\frac{n(n+1)-l(l+1)}{(n+2)(n+1)}$$
> which gives $a_{l+2}=0$, and so $a_{l+2}=a_{l+4}=\cdots=0$ and the series truncates as a polynomial of degree $l$ which is bounded on $-1 \leqslant x \leqslant 1$.
> 
> The values $\lambda= l (l+1)$ are the [[Eigenvectors and Eigenvalues|eigenvalues]] of the problem with corresponding solutions $y(x)=P_{l}(x)$ where $P_{l}(x)$ is the Legendre polynomial of degree $l$.
