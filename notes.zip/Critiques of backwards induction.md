---
tags:
  - MT4554
type: model
aliases:
---
>[!gen] [[The prisoner's dilemma|Prisoner's Dilemma]]
>Consider a [[Pure strategies|pure strategy]] $s^{*}$ = cooperate until opponent defects.
>Then the payoffs to player $i$ is $u_{i}(s^{*},s^{*})= \frac{1}{T}\sum\limits_{t=0}^{T-1}u_{i,t}(C,C)=u_{CC}$.
>Now suppose that player $1$ adopts a strategy $\hat s$ which defects at round $t'<T$, then the payoff to player 1 is $u_{1}(\hat s, s^{*})=\frac{1}{T}\left(\sum\limits_{t=0}^{T'-1}u_{CC}+\sum\limits_{t=t'}^{t'}u_{DC}+\sum\limits_{t=t'+1}^{T-1}u_{DD}\right)= \frac{t'}{T}u_{CC}+ \frac{1}{T}u_{DC} + \frac{T-t'-1}{T}u_{DD}$.
>The gain from this "cheating" will be outweighed by the losses in subsequent rounds if
>$$\begin{align*}
   u_{1}(s^{*},s^{*})>u_{1}(\hat s, s^{*}) &\iff Tu_{CC}>t'u_{CC}+u_{DC}+(T-t'-1)u_{DD}\\
   &\iff Tu_{CC}-Tu_{DD}-t'u_{CC}+t'u_{DD}>u_{DC}-u_{DD}\\
   &\iff T(u_{CC}-u_{DD})-t'(u_{CC}-u_{DD})>u_{DC}-u_{DD}\\
   &\iff (T-t')(u_{CC}-u_{DD})>u_{DC}-u_{DD}\\
   \end{align*}$$
>Suppose we cheat at the last round $t=T-1$. Then this cheating will be outweighed by the losses if $u_{CC}-u_{DD}>u_{DC}-u_{DD} \implies u_{CC}>u_{DC}$, but this is a contradiction so the cheating will never be punished. And if player 2 knows that player 1 will defect at round $t'=T-1$, they will defect also.
>The argument is then repeated leading to defection always.

>[!gen] Finite games with multiple equilibria
>![[fingamulteq_att.png|300]]
>
>By [[Iterated strict dominance|ISD]], player 1 will never play $R$ and player 2 will never play $B$.
>So two pure strategy [[Nash equilibrium|Nash Equilibria]] are $(C,T)$ and $(L,M)$.
>And also there is a mixed strategy [[Nash equilibrium]] $p^{*}=\frac{b-3c}{2b-5c}$.
>
>Now consider a repeated game with exactly two rounds.
>What we want to show is that there is a [[Subgame perfection|subgame perfect]] [[Nash equilibrium]] which does not involve playing the stage game [[Nash equilibrium]] at every round. Such strategy is for example
>1. In the first round play $(R,B)$.
>2. If the outcome of the first round is $(R,B)$, play $(C,T)$ in the next round.
>   If the outcome of the first round is not $(R,B)$, play $\sigma_{1}^{1}(L)=p^{*}=\sigma_{2}^{1}(T)$, $\sigma_{1}^{1}(C)=1-p^{*}=\sigma_{2}^{1}(M)$ in the next round.
>
>The strategies in the final round are Nash equilibria by construction.
>The total payoff is $u_{1}^{*}=2b-3c$ and $u_{2}^{*}=2b-4c$.
>
>Suppose player 1 "cheats" and deviates in the first round and instead plays $L$.
>Their payoff is $\hat u_{1}=b+(b-2c) \frac{b-3c}{2b-5c}$. For this to be beneficial we need $\hat u_{1}>u_{1}^{*}$ which occurs if $b<3c$. This is a contradiction since the game states $b>3c$. So he will never benefit by switching to $L$.
>
>Suppose player 2 "cheats" and deviates in the first round and instead plays $T$.
>Their payoff is $\hat u_{2}=b+(b-2c) \frac{b-3c}{2b-5c}$. For this to be beneficial we need $\hat u_{2}>u_{2}^{*}$ which occurs if $b<(4+\sqrt{2})c$.
>A Nash equilibrium occurs if $b \geqslant (4+\sqrt{2})c$.
