---
type: thm
tags:
  - MT2505
  - MT4003
---
Let $G$ be a [[Groups|group]].

>[!thm] Theorem
>Every element of $G$ occurs precisely once in each row and precisely once in each column of the Cayley table of $G$.
>
>Proof:
>Fix an element $g\in G$. Then $g$ occurs in a row $a$ of the Cayley table if $\exists \ x\in G \  \text{ s.t } \ a*x=g$.
>Since this equation has a [[Uniqueness of the solutions|unique solution]], namely $x=a^{-1}g$, then $g$ occurs precisely once in row $a$.
>Since the choice of $a$ was arbitrary, this holds or all rows in the Cayley Table.

> [!gen] Remarks
>Advantages of Cayley tables:
>1. Easy to understand.
>2. [[Identity element|Identity]] and [[The inverse of a matrix|inverses]] easy to spot.
>3. Easy to decide whether the group is [[Abelian groups|abelian]].
>
>Disadvantages of Cayley tables:
>1. Only usable for finite groups that are small enough to fit in a piece of paper.
>2. [[Associativity]] is hard to recognise.
>3. Can be difficult to extract useful information about the group.
