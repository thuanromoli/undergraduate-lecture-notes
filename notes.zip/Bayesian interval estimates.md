---
tags:
  - MT3507
aliases:
---
Let $\theta$ be a continuous parameter with a unimodal [[Posterior distributions|posterior]] pdf $\pi(\theta|\mathbf{x})$ defined on $(-\infty,\infty)$.

> [!def] Credible Interval
> The interval $(a,b)$ is a $100(1-\alpha)\%$ credible interval if
> $$\int_{a}^{b}\pi(\theta|\mathbf{x})\;d \theta=1- \alpha.$$

> [!def] CP Interval
> The interval $(a,b)$ is a $100(1-\alpha)\%$ central posterior interval if
> $$\int_{-\infty}^a \pi(\theta | \mathbf{x}) \ d\theta = \frac{\alpha}{2} = \int_b^\infty \pi(\theta | \mathbf{x}) \ d\theta.$$

> [!def] HPD Interval
> The interval $(a,b)$ is a $100(1-\alpha)\%$ highest posterior density interval if
> 1. $\int_a^b \pi(\theta | \mathbf{x}) \ d\theta = 1 - \alpha$.
> 2. for $\theta_{1} \in (a,b), \quad \theta_{2} \notin (a, b)$, we have $\pi(\theta_1 | \mathbf{x}) \geqslant \pi(\theta_2 | \mathbf{x})$.
