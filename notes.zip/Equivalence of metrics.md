---
tags:
  - MT3502
aliases:
  - equivalent
---
Let $d$ and $d'$ be two [[Metric spaces|metrics]] on the same set $X$.

> [!def] Equivalence of metrics
> $d$ and $d'$ are equivalent if there are positive constants $0 < a \leqslant b$ such that
> $$ad(x,y) \leqslant d'(x,y) \leqslant bd(x,y) \;\;\forall x,y \in X.$$

Let ${\Vert \cdot \Vert}$ and ${\Vert \cdot \Vert}'$ be two [[Inner Product Norm|norms]] on the same [[Vector spaces|vector space]] $X$.

> [!def] Equivalence of norms
> ${\Vert \cdot \Vert}$ and ${\Vert \cdot \Vert}'$ are equivalent if there are positive constants $0 < a \leqslant b$ such that
> $$a{\Vert x \Vert} \leqslant {\Vert x \Vert}' \leqslant b{\Vert x \Vert} \;\;\forall x \in X.$$
