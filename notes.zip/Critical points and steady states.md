---
alias:
  - critical points
  - critical point
  - steady states
  - steady state
type: def
tag: MT2507
---
#### System of ODEs:
Consider a system of ODEs:
$$\matrix{\frac{dx}{dt}=F(t,x(t),y(t)) \\ \frac{dy}{dt}= G(t,x(t),y(t))}$$
>[!def] Definition
>A critical point/steady state is a point for which $\frac{dy}{dt}=\frac{dx}{dt}=0$.

#### 1st Order ODEs:
Consider a 1st order ODE:
$$\frac{\text dN}{\text dt}=F(N)$$
>[!def] Definition
>A critical point/steady state is a point for which $\frac{dN}{dt}=F(N)=0$.