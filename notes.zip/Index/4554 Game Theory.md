### Chapter 1: Games and rationality
Nomenclature
	[[Players and opponents]]
	[[Cooperation]]
	[[Rationality]]
	[[Common knowledge]]
	[[Static and dynamic games]]
	[[Pure strategies]]
	[[Mixed strategies]]
Game types
	[[Normal-form games]]
	[[Two-strategy, two-player, zero-sum games]]
Solution concepts
	[[Iterated strict dominance]]
		[[Strictly dominated strategy]]
	[[Rationalizability]]
		[[Best response function]]
	[[Nash equilibrium]]
	[[The Nash equilibrium theorem]]
	[[The minimax theorem]]

### Chapter 2: Basic applications of game theory
[[Cooperation]]
	[[The prisoner's dilemma]]
	[[The donation game (charitable helping)]]
	[[The public goods game (sharing the benefits)]]
	[[The modified public goods game (caring for each other's welfare)]]
	[[The snowdrift game (sharing the costs)]]
[[Fairness]]
	[[The ultimatum game]]
	[[Extensive-form games]]
	[[Subgame perfection]]
Nuclear Brinkmanship
	[[The chicken game]]
	[[The escalating chicken game]]

### Chapter 3: Iterated games
Section I: Finite Horizons
	[[One-step-deviation principle]]
	[[Critiques of backwards induction]]
Section II: Infinite Horizons
	[[The limit of means]]
	[[Payoff discounting]]
	[[One-step-deviation principle]]
	[[Solving the prisoner's dilemma]]
	[[Finite punishment]]
Section III: Folk theorems
	[[Trigger strategy]]
	[[Reservation utility]]
	[[Feasible payoffs]]
	[[Nash Folk theorem]]
	[[Subgame perfect trigger strategies]]

### Chapter 4: Less than rational processes
Evolutionary Game Theory
	[[Population level payoff]]
	[[Population level equilibria]]
		[[Matching pennies game]]
		[[The donation game (charitable helping)]]
		[[The snowdrift game (sharing the costs)]]
	[[Stability to invasion]]
	[[Adaptive dynamics]]
	[[Replicator dynamics]]
	[[Evolutionary stable strategies]]
Simple Models of Learning
	[[Imitation dynamics]]
		[[Robustness to invasion]]
		[[Robustness to fixation]]
	[[Introspection dynamics]]
	[[The price of anarchy]]
