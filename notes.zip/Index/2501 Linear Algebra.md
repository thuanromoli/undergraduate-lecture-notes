### Chapter 1: Matrices and systems of equations
[[Matrices]]
Nomenclature of special matrices
	[[Square matrices]]
	[[Diagonal matrices]]
	[[Identity matrices]]
	[[Zero matrices]]
Matrix operations
	[[Matrix addition]]
	[[Matrix multiplication]]
	[[Theorems about matrix addition]]
	[[Theorems about matrix multiplication]]
Row-operations
	[[Elementary row operations]]
	[[Elementary matrices]]
	[[Theorems about e.r.o.s]]
	[[Echelon form]]
	[[Theorems about echelon matrices]]
Matrix actions
	[[The transpose of a matrix]]
	[[Theorems about transpose matrices]]
	[[The inverse of a matrix]]
		[[Theorems about inverse matrices (as the inverse element)]]
		[[Theorems about inverse matrices (as an object and its form)]]
	[[The trace of a matrix]]
	[[The minor of a matrix]]
	[[The cofactor of a matrix]]
	[[The determinant of a matrix]]
		[[Theorems about determinants]]
	[[The adjugate of a matrix]]

### Chapter 2: Vector Spaces
[[Vector spaces]]
[[Basic properties of vector spaces]]
[[Subspaces]]
[[Theorems about subspaces]]

### Chapter 3: Spanning Sets, Linear Independence and Bases
[[Linear combinations]]
[[Span]]
	[[Theorems about Span]]
[[Row-spaces]]
	[[Theorems about row-spaces]]
[[Linear independence]]
	[[Theorems about linear independence]]
[[Bases]]
	[[Theorems about bases]]
[[Dimension]]
	[[Theorems about dimension]]
[[Row-ranks]]
	[[Theorems about row-ranks]]

### Chapter 4: Linear Transformations
[[Linear transformations]]
[[Theorems about linear transformations]]

### Chapter 5: Eigenvalues, Eigenvectors and Diagonalisation
