### Chapter 1: Probability Generating Functions and Moment Generating Functions
[[Probability generating functions]]
[[Theorems about pgfs]]
[[Moment generating functions]]
[[Theorems about mgfs]]
[[Moments]]

### Chapter 2: Continuous distributions
[[Distribution of functions of rvs (univariate)]]
[[Distribution of functions of rvs (multivariate)]]
[[Gamma function]]
[[Gamma distributions]]
[[Exponential distributions]]
[[Chi-squared distributions]]
[[Beta function]]
[[Beta distributions]]
[[t distributions]]
[[Multivariate normal distributions]]

### Chapter 3: Discrete distributions
[[Binomial distributions]]
[[Poisson distributions]]
[[Negative binomial distributions]]
[[Multinomial distributions]]

### Chapter 4: Maximum likelihood distributions
[[Test statistics]]
[[Likelihood]]
[[Log-likelihood]]
[[Maximum Likelihood Estimator]]
[[MLE Properties and assumptions]]
[[Fisher information]]
[[Sufficient statistics]]
[[Fisher's factorisation theorem]]

### Chapter 5: Interval estimation
[[Confidence intervals]]
[[Wald confidence intervals]]
[[Likelihood confidence intervals]]
[[Normal confidence intervals]]

### Chapter 6: Hypothesis testing
[[Statistical hypothesis]]
[[Test statistics]]
[[Critical regions]]
[[Type I error]] and [[Significance level]]
[[Type II error]] and [[Power of a test]]
[[p-value]]
See examples of tests in lecture notes

### Chapter 7: Bayesian Inference
[[Prior distributions]]
[[Posterior distributions]]
[[Bayes' Theorem]]
[[Conjugate distributions and conjugate priors]]
[[Exponential families]]
[[Bayesian interval estimates]]

### Chapter 8: The General Linear Model
[[General linear models]]
[[Normal equations]]
