### Chapter 1: Bayesian Statistics
[[Conditional probability]]
    [[The Law of Total Probability]]
[[Bayes' Theorem]]
[[Conjugate distributions and conjugate priors]]
[[Jeffreys' prior]]
[[Bayesian point estimates]]
[[Bayesian interval estimates]]
[[Prior predictive distribution]]
[[Posterior predictive distribution]]

### Chapter 2: Bayesian Computation
[[Monte Carlo integration]]
[[Markov chain Monte Carlo]]
[[Markov chains and processes]]
Run lengths
    [[Burn-in and convergence diagnostic]]
    [[Monte Carlo error]]

### Chapter 3: MCMC Algorithms
[[Gibbs sampler]]
[[Metropolis-Hasting algorithm]]
    [[Random walk Metropolis]]
    [[The independent sampler]]
    [[Single-update Metropolis]]
[[Direct sampling]]
    [[Method of inversion]]
    [[Rejection sampling]]
    [[Importance sampling]]

### Chapter 4: Bayesian Inference, Prediction, and Model selection
[[Data Augmentation]]
[[Hierarchical models]]
[[Bayes factors]]
[[Deviance information criterion]]
[[The Watanabe - Akaike criterion]]
