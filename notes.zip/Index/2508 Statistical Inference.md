### Chapter 1: Statistical Inference
[[Estimators]]
	[[Unbiased estimators]]
	[[Consistent estimators]]
[[Sample mean]]
[[Sample variance]]
[[Confidence intervals]]
[[Statistical hypothesis]]
	[[Test statistics]]
	[[Hypothesis test]]
	[[Critical regions]]
	[[Type I error]]
	[[Type II error]]
	[[Significance level]]
	[[p-value]]
	[[Power of a test]]
	[[Method to find the power of a test]]

### Chapter 2: Normal approximations and t-tests
[[Normal distribution]]
Normal approximations:
	[[Central Limit Theorem]]
	[[Normal approximation of the binomial distribution]]
	[[Normal approximation of the Poisson distribution]]
	[[Continuity correction]]
Distributions from the normal distribution:
	[[Chi-squared distributions]]
	[[F distribution]]
	[[t distributions]]
		[[Sample variance and t distribution]]
		[[Normal confidence intervals]]
Parametric tests:
	[[Normal test]]
	[[t-test]]
	[[Matched-pairs t-test]]
	[[Two-sample t-test]]
		[[Pooled sample variance]]
	[[F-test]]

### Chapter 3: Nonparametric methods
[[Measurement scales of data]]
Nonparametric tests:
	[[Two-sample permutation test]]
	[[Mann-Whitney U-test]]
	[[Matched-pairs permutation test]]
	[[Wilcoxon's signed rank test]]
	[[Sign test]]
	[[One-sample permutation test]]
Computational tests:
	[[Computational tests]]

### Chapter 4: Maximum likelihood estimation
[[Joint pmf or pdf]]
[[Likelihood]]
[[Log-likelihood]]
[[Maximum Likelihood Estimator]]
[[MLE Properties and assumptions]]

### Chapter 5: Regression
[[Simple linear regression]]
[[Least-squares estimation]]
[[Normal linear regression]]
[[MLEs of the parameters in linear regression]]
[[Regression using R]]
[[Checking the linear regression assumptions]]
[[Multiple regression]]
[[Polynomial regression]]
[[ANOVA]]
