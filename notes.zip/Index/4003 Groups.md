### Chapter 1: Definition and examples of groups
Definitions
	[[Binary operations]]
	[[Groups]]
	[[Abelian groups]]
	[[Order]]
		[[Theorems about the order]]
	[[Function composition]]
		[[Theorems about function composition]]
	[[Isomorphisms]]
	[[Cayley tables]]
Basic properties of a group:
	[[Uniqueness of the identity]]
	[[Uniqueness of the inverse]]
	[[Theorems about the inverse]]
	[[Power laws]]
Examples of groups:
	[[The symmetric group]] and [[Permutations and Cycles]]
		[[Theorems about symmetric groups]] and [[Theorems about permutations and cycles]]
	[[The alternating group]]
		[[Theorems about alternating groups]]
	[[Klein 4-group]]
	[[Dihedral groups]]
		[[Theorems about dihedral groups]]
	[[General linear group]]
	[[Special linear group]]

### Chapter 2: Subgroups
[[Subgroups]]
	[[Theorems about subgroups]]
[[Generating set]]
	[[Theorems about generating sets]]
	[[Cyclic groups]]
	[[Theorems about the order]]
	[[The generating algorithm]]
[[Cosets]]
	[[Theorems about cosets]]
[[Index]]
[[Lagrange's Theorem]]

### Chapter 3: Normal subgroups, quotients, and homomorphisms
[[Conjugacy]]
[[Conjugacy classes]]
[[Normal subgroups]]
	[[Theorems about normal subgroups]]
[[Quotients groups]]
[[Homomorphisms]]
	[[Theorems about homomorphisms]]
[[Kernel]] and [[Image]]
	[[Theorems about the kernel and the image]]
[[Natural homomorphism]]
[[The First Isomorphism Theorem]]
[[The Correspondence Theorem]]
[[The Second Isomorphism Theorem]]
[[The Third Isomorphism Theorem]]

### Chapter 4: Cyclic groups
[[Theorems about cyclic groups]]

### Chapter 5: Direct products and finite abelian groups
[[Direct products]]
	[[Theorems about direct products]]
	[[Direct decompositions]]
	[[Direct products of more multiplicands]]
	[[Theorems about direct products of more multiplicands]]
Finite abelian groups
	[[Theorems about finite abelian groups]]
	[[The fundamental theorem of finite abelian groups]]

### Chapter 6: Simple groups
[[Simple groups]]
[[Theorems about simple groups]]
[[Simplicity of the alternating groups]]

### Chapter 7: Group actions and permutation groups
[[Group actions]]
[[Orbits]]
[[Stabilisers]]
[[Centralisers]]
[[The orbit-stabiliser theorem]]
[[p-groups]]
[[Theorems about p-groups]]
[[Permutation representation]]
[[Cayley's Theorem]]

### Chapter 8: The centre, commutators, and normalisers
[[The centre]]
	[[Theorems about the centre]]
[[The class equation]]
[[Commutators]]
	[[Theorems about commutators]]
[[The derived subgroup]]
	[[Theorems about derived subgroup]]
	[[Soluble groups]]
[[Automorphisms]]
[[Subgroup conjugacy]]
[[Normalisers]]
[[Theorems about normalisers]]

### Chapter 9: Sylow's Theorem
[[p-groups]]
[[p-subgroups]]
[[Sylow p-subgroups]]
[[Sylow's Theorem]]

### Chapter 10: Classification of small groups
[[Classification of small groups]]
