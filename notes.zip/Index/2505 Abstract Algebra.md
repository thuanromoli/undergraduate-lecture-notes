### Chapter 1: Rings and Fields
[[Binary operations]]
[[Rings]]
Properties of binary operations:
	[[Commutativity]]
	[[Associativity]]
	[[Identity element]]
	[[Inverse element]]
[[Generalised Associative Law]]
[[Matrix rings]]
[[Commutative rings]]
[[Polynomial rings]]
[[Fields (Algebra)]]
[[Subrings]]

### Chapter 2: Greatest Common Divisors and the Euclidean Algorithm
[[Divisors]]
[[Greatest common divisor]]
	[[Coprime integers]]
[[Bêzout's Identity]]
[[Euclidean algorithm]]

### Chapter 3: Equivalence Relations
[[Relations]]
Properties of relations:
	[[Reflexivity]]
	[[Symmetry]]
	[[Transitivity]]
[[Equivalence relations]]
[[Equivalence classes]]
	[[Theorems about equivalence classes]]
[[Partitions]]
	[[Theorems about partitions]]

### Chapter 4: Congruences and Modular Arithmetic
[[Congruence modulo m]]
	[[Theorems about congruence modulo m]]
[[Congruence classes modulo m]]
	[[Theorems about congruence classes modulo m]]

### Chapter 5: Groups
[[Groups]]
[[Abelian groups]]
[[General linear group]]
[[Multiplicative group of a field]]
[[Klein 4-group]]
Basic properties of a group:
	[[Uniqueness of the identity]]
	[[Uniqueness of the inverse]]
	[[Theorems about the inverse]]
	[[Cancellativity]]
	[[Uniqueness of the solutions]]
[[Cayley tables]]
[[Power laws]]

### Chapter 6: Permutations and Symmetric Groups
[[Function composition]]
	[[Theorems about function composition]]
[[Injective functions|Injective]], [[Surjective functions|Surjective]], and [[Bijective functions|Bijective]] [[Functions]]
	[[Theorems about bijective functions]]
[[Permutations and Cycles]]
[[The symmetric group]]
	[[Theorems about symmetric groups]]
	[[Theorems about permutations and cycles]]

### Chapter 7: Isometries
[[Distance]]
[[Isometries of the real plane]]
[[The isometry group]]
	[[Theorems about the isometry group]]
[[Group of isometries of a fixed figure]]
[[Dihedral groups]]
	[[Theorems about dihedral groups]]

### Chapter 8: Subgroups
[[Subgroups]]
	[[Theorems about subgroups]]
[[Cyclic groups]]
	[[Theorems about cyclic groups]]
[[Order]]
	[[Theorems about the order]]
[[The alternating group]]
	[[Theorems about alternating groups]]

### Chapter 9: Lagrange's Theorem
[[Cosets]]
	[[Theorems about cosets]]
[[Index]]
[[Lagrange's Theorem]]

### Chapter 10: Homomorphisms, Normal Subgroups, Quotients Groups
[[Homomorphisms]]
	[[Theorems about homomorphisms]]
[[Isomorphisms]]
[[Kernel]]
[[Image]]
	[[Theorems about the kernel and the image]]
[[Normal subgroups]]
	[[Theorems about normal subgroups]]
[[Quotients groups]]
	[[Theorems about quotients groups]]
[[The First Isomorphism Theorem]]
