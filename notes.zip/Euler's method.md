---
tag: MT2507
type: mthd
alias:
- 
---
Consider an ODE of the form $\frac{dx}{dt}=f(t,x)$.

>[!def] Definition
>Euler's method is the following iteration:
>$$\matrix{t_{n+1}=t_{n}+h \ \ \ \ \ \ \ \ \ \ \ \ \ \ \ \  \\ x_{n+1}=x_{n}+hf(t_{n},x_{n})}$$
>where $(t_{0},x_{0})$ is the initial condition and $(t_{1},x_{1}),(t_{2},x_{2}),...,(t_{n},x_{n})$ are approximation for the curve solution.

>[!gen]+ Intuition
>![[numericaleuler_att.png|400]]
>Our aim to find $x_{n+1}$.
>By the definition of slope:
>$$\left(\frac{dx}{dt}\right)_{t_{n}}=\frac{\Delta X}{\Delta t}=\frac{x_{n+1}-x_{n}}{h}$$
>Rearranging this yields:
>$$x_{n+1}=x_{n}+ h\left(\frac{dx}{dt}\right)_{t_{n}}=x_{n}+hf(t_{n},x_{n})$$

---

#### Spaced repetition
