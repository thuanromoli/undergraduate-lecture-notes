---
tags:
  - MT4528
type: thm
aliases:
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S=\set{1,2,...}$ and [[n-step transition probabilities]] $p_{ij}(n)=\mathbb{P}(X_{t+n}=j \vert X_{t}=i)$.

>[!thm] $p_{ij}(m+n)=\sum\limits_{k\in S}p_{ik}(n)p_{kj}(m)$
>Proof:
>$p_{ij}(m+n)$ = $\mathbb{P}(X_{m+n+t}=j|X_{t}=i)$ by definition.
>$p_{ij}(m+n)$ = $\sum\limits_{k\in S}\mathbb{P}(X_{m+n+t}=j|X_{n+t}=k,X_{t}=i)\mathbb{P}(X_{n+t}=k|X_{t}=i)$, by [[The Law of Total Conditional Probability]]
>$p_{ij}(m+n)$ = $\sum\limits_{k\in S}\mathbb{P}(X_{m+n+t}=j|X_{n+t}=k)\mathbb{P}(X_{n+t}=k|X_{t}=i)$, by the [[Markov chains and processes|Markov property]].
>$p_{ij}(m+n)$ = $\sum\limits_{k\in S}{p_{kj}(m)p_{ik}(n)}$

>[!thm] $\boldsymbol{P}^{(m+n)}=\boldsymbol{P}^{(n)}\boldsymbol{P}^{(m)}$
>By the definition of [[Matrix multiplication]], $\boldsymbol{P}^{n}\boldsymbol{P}^{m}=[p_{ij}(n)][p_{ij}(m)]$ = $\left[\sum\limits_{k\in S}^{}p_{ik}(n)p_{kj}(m)\right]$ = $[p_{ij}(m+n)]$ = $\boldsymbol{P}^{(m+n)}$.

>[!thm] $\boldsymbol{P}^{(n)}=\boldsymbol{P}^{n}$
>$\boldsymbol{P}^{(n)}=\boldsymbol{P}^{(1)}\boldsymbol{P}^{(n-1)}$
>$\boldsymbol{P}^{(n)}=\boldsymbol{P}^{1}\boldsymbol{P}^{(n-1)}$
>$\boldsymbol{P}^{(n)}=\boldsymbol{P}^{2}\boldsymbol{P}^{(n-2)}$
>$\vdots$
>$\boldsymbol{P}^{(n)}=\boldsymbol{P}^{n}$
