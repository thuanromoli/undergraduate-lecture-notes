---
type: thm
tag: MT2505
---
Let $G$ be a [[Groups|group]] and $H$ be a [[Subgroups|subgroup]] of $G$.

>[!thm] Theorem
>Lagrange's Theorem states that
>$$|G|=|G:H|\cdot|H|$$
>in particular, if $G$ is a finite group, then the order of $H$ divides the order of $G$.

Proof:
By [[Theorems about cosets]] we shown that the group $G$ is the disjoint union of the right [[Cosets|cosets]] of the subgroup $H$ and each coset contains $|H|$ elements. We can represent this by the following diagram:
![[cosets_att.png|400]]

> [!gen] If $G$ is finite and $x\in G$, then the [[Order|order]] of $x$ divides $|G|$
> $|x|=|\langle x \rangle|$ by [[Theorems about the order#^02710d|this theorem]], which divides $|G|$ by Lagrange's Theorem.

> [!gen] If $p$ is prime and $|G|=p$, then $G$ is [[Cyclic groups|cyclic]].
> Let $x\in G \setminus \set{1}$. Then $|\langle x \rangle|$ divides $p$, so $|\langle x \rangle| = p = |G|$. Hence $G = \langle x \rangle$.

^816d54
