---
tags:
  - MT3507
aliases:
---
> [!def] Definition
> The beta function is defined as
> $$B(\alpha,\beta) = \int_{0}^{1}x^{\alpha-1}(1-x)^{\beta-1}\;dx.$$

> [!thm]- $$B(\alpha,\beta)= \frac{\Gamma(\alpha)\Gamma(\beta)}{\Gamma(\alpha+\beta)}$$
> Let $U \sim \Gamma(\alpha, \lambda)$ and $V = \Gamma(\beta, \lambda)$.
> Then the pdf of $X = \frac{U}{U+V}$ is
> $$f(x) = \frac{\Gamma(\alpha)\Gamma(\beta)}{\Gamma(\alpha+\beta)}x^{\alpha-1}(1-x)^{\beta-1}.$$
> By the honesty condition, we obtain our result.
