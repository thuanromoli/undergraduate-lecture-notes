---
tags:
  - MT3502
aliases:
  - integrable
---
Let $f:[a,b] \to \mathbb R$ be a [[Boundedness|bounded]] [[Functions|function]].

> [!def] Definition
> $f$ is Riemann integrable, or the integral of $f$ exists, if
> $$\sup_\mathcal D \underline S_{f} (\mathcal D) =\inf_\mathcal D \overline S_{f}(\mathcal D)$$
> in which case, we call the common value the integral of $f$, denoted by the usual symbol
> $$\int_{a}^{b}f(x)dx = \sup_\mathcal D \underline S_{f} (\mathcal D) =\inf_\mathcal D \overline S_{f}(\mathcal D).$$

> [!thm] Theorem
> $f$ is Riemann integrable with $\int_{a}^{b}f=l$ if and only if there is a [[Sequences|sequence]] of [[Dissections|dissections]] $\mathcal D_{n}$ such that $\underline S (\mathcal D_{n}) \to l$ and $\overline S (\mathcal D_{n})\to l$.
> In other words, $f$ is integrable if and only if
> $$\forall \varepsilon > 0 \;\exists \mathcal D \;\; \text{such that} \;\;\overline S (\mathcal D) - \underline S (\mathcal D) < \varepsilon.$$

Proof:
Suppose that $f$ is integrable.
Then for each $n \in \mathbb N$, we may find dissections
$$\begin{align*}
\mathcal D_{n}' \;\text{with}\; \underline S (\mathcal D'_{n}) \geqslant \sup\limits_{\mathcal D}\underline S (\mathcal D)-\frac{1}{n} = l - \frac{1}{n}\\
\mathcal D_{n}'' \;\text{with}\; \overline S (\mathcal D''_{n}) \leqslant  \inf\limits_{\mathcal D}\overline S (\mathcal D)+\frac{1}{n} = l + \frac{1}{n}
\end{align*}$$
Let $\mathcal D_{n} = \mathcal D_{n}' \cup \mathcal D_{n}''$. Then
$$\begin{align*}
l-\frac{1}{n} & \leqslant \underline S (\mathcal D'_{n}) \qquad \text{by the above}\\
&\leqslant \underline S (\mathcal D_{n})\qquad \text{as $\mathcal D_{n}$ is a refinement of $\mathcal D_{n}'$}\\
&\leqslant \overline S (\mathcal D_{n})\qquad \text{as a lower sum $\leqslant$ an upper sum}\\
&\leqslant \overline S (\mathcal D''_{n})\qquad \text{as $\mathcal D_{n}$ is a refinement of $\mathcal D_{n}''$}\\
&\leqslant l+ \frac{1}{n} \qquad \text{by the above}.
\end{align*}$$
Hence $\underline S (\mathcal D_{n}) \to l$ and $\overline S (\mathcal D_{n}) \to l$.

Conversely, suppose that there exists a sequence of dissections $\mathcal D_{n}$ such that $\underline S (\mathcal D_{n}) \to l$ and $\overline S (\mathcal D_{n})\to l$.
Note that $\underline S (\mathcal D_{n}) \leqslant \sup\limits_{\mathcal D}\underline S (\mathcal D) \leqslant \inf\limits_{\mathcal D}\overline S (\mathcal D)\leqslant \overline S (\mathcal D_{n})$.
So as $\underline S (\mathcal D_{n}) \to l$ and $\overline S (\mathcal D_{n})\to l$, then the above becomes
$$l\leqslant \sup\limits_{\mathcal D}\underline S (\mathcal D) \leqslant \inf\limits_{\mathcal D}\overline S (\mathcal D)\leqslant l$$
hence, $\sup\limits_{\mathcal D}\underline S (\mathcal D) = \inf\limits_{\mathcal D}\overline S (\mathcal D) = l$ and $f$ is integrable.