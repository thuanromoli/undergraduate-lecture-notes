---
type: mthd
tag: MT2506
---
Given $\int_C \boldsymbol F(\boldsymbol r)\cdot \text{d}\boldsymbol r$ where $C$ is a curve, $\boldsymbol r(s)$ is the [[Position vectors|position vector]] defining all points on $C$ and $\boldsymbol F$ is the vector field, evaluate the [[Line integral of a vector field|line integral]].

1. [[Parametrisation|Parametrise]] $C$;
2. find $\boldsymbol F (\boldsymbol r(s))$ on $C$;
3. find $\frac{\text{d}\boldsymbol r}{\text{d}s}$;
4. take the inner product $\boldsymbol F (\boldsymbol r(s))\cdot \frac{\text{d}\boldsymbol r}{\text{d}s}=h(s)$;
5. evaluate $\int_C \boldsymbol F(\boldsymbol r)\cdot \text{d}\boldsymbol r=\int_{s_0}^{s_1}(\boldsymbol F (\boldsymbol r(s))\cdot \frac{\text{d}\boldsymbol r} {\text{d}s}) \text{ d}s=\int_{s_0}^{s_1}h(s)\text{ d}s$.

---

#### Spaced repetition

Show the algorithm to compute $$\int_C \boldsymbol F(\boldsymbol r)\cdot \text{d}\boldsymbol r$$
?
1. [[Parametrisation|Parametrise]] $C$;
2. find $\boldsymbol F (\boldsymbol r(s))$ on $C$;
3. find $\frac{\text{d}\boldsymbol r}{\text{d}s}$;
4. take the inner product $\boldsymbol F (\boldsymbol r(s))\cdot \frac{\text{d}\boldsymbol r}{\text{d}s}=h(s)$;
5. evaluate $\int_C \boldsymbol F(\boldsymbol r)\cdot \text{d}\boldsymbol r=\int_{s_0}^{s_1}(\boldsymbol F (\boldsymbol r(s))\cdot \frac{\text{d}\boldsymbol r} {\text{d}s}) \text{ d}s=\int_{s_0}^{s_1}h(s)\text{ d}s$.