---
tags:
  - MT4509
aliases:
---
Consider a curve $C$, that might change over time, i.e. $C(t)$.
Consider a scalar field evaluated on $C$, i.e. $F(\boldsymbol{x} \in  C)$.
Recall, for below, the [[Evolution of material elements|material derivatives of material elements]].

> [!thm] Line element (scalar)
> $$\begin{align*}
\frac{D}{Dt}\int_{\mathcal C}^{}F \boldsymbol{dl} &= \int_{\mathcal C}^{}\frac{D}{Dt}(F \boldsymbol{dl})\\
&= \int_{\mathcal C} \frac{DF}{Dt}\boldsymbol{\boldsymbol{dl}}+\int_{\mathcal C}^{}F\left(\frac{D}{Dt}\boldsymbol{dl}\right)\\
&= \int_{\mathcal C} \frac{DF}{Dt}\boldsymbol{\boldsymbol{dl}}+\int_{\mathcal C}^{}F\left(\boldsymbol{dl \cdot \nabla }\right)\boldsymbol{u.}
\end{align*}$$

> [!thm] Line element (vector field)
> $$\begin{align*}
\frac{D}{Dt}\int_{\mathcal C}^{}\boldsymbol{F}\cdot \boldsymbol{dl} &= \int_{\mathcal C}^{}\frac{D}{Dt}(\boldsymbol{F}\cdot \boldsymbol{dl})\\
&= \int_{\mathcal C} \frac{D \boldsymbol{F}}{Dt} \cdot {\boldsymbol{dl}}+\int_{\mathcal C}^{}\boldsymbol{F}\cdot\left(\frac{D}{Dt}\boldsymbol{dl}\right)\\
&= \int_{\mathcal C} \frac{D \boldsymbol{F}}{Dt}\cdot{\boldsymbol{dl}} +\int_{\mathcal C}^{} \boldsymbol{F} \cdot\Big[\left(\boldsymbol{dl \cdot \nabla }\right)\boldsymbol{u}\Big].
\end{align*}$$

> [!thm] Volume element
> $$\begin{align*}
\frac{D}{Dt}\iiint_{V}^{}F \;dV &= \iiint_{V}\frac{D}{Dt}(F\;dV)\\
&= \iiint_{V} \frac{DF}{Dt}dV+\iiint_{V}^{}F\left(\frac{D}{Dt}dV\right)\\
&= \iiint_{V} \frac{DF}{Dt}dV+\iiint_{V}^{}F \boldsymbol{\nabla \cdot u}\;dV.
\end{align*}$$

This generalises directly for vector fields.

Note that, if $F = \rho Q$, where $\rho$ is the fluid density and $Q$ is any fluid quantity, then ^2d21b2
$$\begin{align*}
\frac{D}{Dt}\iiint_{V} \rho Q dV &= \iiint_{V} \frac{D}{Dt}(\rho)QdV+ \rho \frac{D}{Dt}(Q)dV+\rho Q \frac{D}{Dt}(dV)\\
&= \iiint_{V} (- \rho Q \nabla  \cdot \boldsymbol{u} dV) + \rho \frac{DQ}{Dt}dV+(\rho Q \nabla \cdot \boldsymbol{u} dV)\\
&= \iiint_{V} \rho \frac{DQ}{Dt}dV\\
&= \iiint_{V}  \frac{DQ}{Dt}\rho dV\\
&= \iiint_{V}  \frac{DQ}{Dt}dM.
\end{align*}$$
