---
type: def
tags:
  - MT2505
  - MT4003
aliases:
  - subgroups
  - subgroup
---
Let $G$ be a [[Groups|group]].

>[!def] Definition 1
>A subgroup of $G$ is a subset $H$ of $G$ which is itself a [[Groups|group]] under the [[Binary operations|binary operation]] of $G$. We write $H \leqslant G$ to denote that $H$ is a subgroup of $G$.

>[!def] Definition 2
>$H$ is a subgroup of $G$ if and only if 
>1. $H$ is a non-empty subset of $G$.
>2. $H$ is closed under addition: $xy\in H \;\;\forall x,y\in H$.
>3. $H$ is closed under inverses: $x^{-1}\in H \;\;\forall x\in H$.

>[!def] Definition 3
>$H$ is a subgroup of $G$ if and only if
>1. $H$ is a non empty subset of $G$.
>2. $H$ is sich that: $xy^{-1}\in H \;\;\forall x,y \in H$.

>[!thm] Theorem
>The above definitions are the same.
>
>Proof: see [[Theorems about subgroups]]
