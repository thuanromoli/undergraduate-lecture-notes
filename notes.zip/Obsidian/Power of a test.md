---
type: def
tags:
  - MT2508
  - MT3507
---
>[!def] Power of a hypothesis test
>The power of a [[Hypothesis test|hypothesis test]] is the probability of rejecting the [[Statistical hypothesis|null hypothesis]] when it is false:
>$$\beta=\mathbb P(\text{reject } H_0 \ \vert \ H_0 \text{ is false})$$
>note: this is $1-\mathbb{P}(\text{Type II error})$ and $\beta$ + [[Type II error]] = 1

>[!def] Power function
>The power [[Functions|function]] is the probability of rejecting the [[Statistical hypothesis|null hypothesis]] when the true value is $\theta$.
