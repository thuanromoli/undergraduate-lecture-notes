---
tags:
  - MT4554
type: model
aliases:
---
In the proof of the [[Nash Folk theorem]] we used a [[Trigger strategy|trigger strategy]] that had the minimax strategy as the [[Reservation utility|reservation utility]]. However, the minimax strategy might not itself be subgame perfect so the trigger strategy is not necessarily [[Subgame perfection|subgame perfect]].

So does the conclusion of the [[Nash Folk theorem]] apply to the payoffs of subgame perfect equilibrium in general?

The answer is yes but the proof is omitted.

>[!gen] Intuitions
>1. Use Nash equilibrium of the static game instead of the minimax strategies as the punishment for deviation. This limits the space of enforceable payoffs.
>2. Use "forgiving" trigger strategies (see below).

>[!thm] Theorem (not rigorous)
>Assume that the set of [[Feasible payoffs|feasible payoffs]] is the same dimension as the number of players, and that the minimax payoff profile lies in its interior.
>The subgame perfect trigger strategy is then as follows:
>1. All player start by playing action profile $a$ and continue to play $a$ if no deviation occurs.
>2. If any player $i$ deviates, play the strategy profile which minimaxes $i$ (i.e the strategy that gives player $i$ payoff at most $w_{i}$) for $P$ periods. Note that we must choose $P$ and $\delta$ to be large enough so that no player has incentive to deviate from phase 1.
>3. If no players deviated from phase 2, all player $j\neq i$ are rewarded $\varepsilon$ above their minimax payoff $w_{j}$ forever after, while player $i$ continues receiving their minimax payoff. (In order for this to be possible we must use both our assumptions).
>4. If player $j$ deviates from phase $2$, all players restart phase 2 with $j$ as their target.
>5. Ignore multilateral deviation.
