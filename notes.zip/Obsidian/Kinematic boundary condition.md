---
tags:
  - MT4509
aliases:
---
Let $F(\boldsymbol{x},t)= C$ be a [[Material surface|material surface]].

> [!thm] Theorem
> $F$ retains its constant value $C$ as the surface moves through the fluid under the action of the velocity field $\boldsymbol{u}$. Furthermore, we must have
> $$\frac{DF}{Dt}=0.$$

Consider the important special case $F(\boldsymbol{x},t) = z- \eta(x,y,t) = 0$
Note that this means that $z=\eta(x,y,t)$ is the height above the surface from $z=0$.

Necessarily, we must have$\frac{dF}{dt}=0$. Then
$$\begin{align*}
&\frac{D}{Dt}(z- \eta)= 0 \\
\implies& \frac{\partial (z- \eta)}{\partial t} + (\boldsymbol{u} \cdot \nabla ) (z- \eta) =0\\
\implies& -\frac{\partial \eta}{\partial t} + u\frac{\partial (z- \eta)}{\partial x} + v\frac{\partial (z- \eta)}{\partial y} + w\frac{\partial (z- \eta)}{\partial z} =0\\
\implies& - \left(\frac{\partial \eta}{\partial t} +u \frac{\partial \eta}{\partial x} + v\frac{\partial \eta}{\partial y} \right)+ w(1-0)=0\\
\implies&w = \frac{\partial \eta}{\partial t} +u \frac{\partial \eta}{\partial x} + v\frac{\partial \eta}{\partial y}.
\end{align*}$$
