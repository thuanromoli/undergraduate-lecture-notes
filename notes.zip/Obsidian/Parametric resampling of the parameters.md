---
tags:
  - MT3508
aliases:
---
``` R
# Step 1: find the MLEs and Hessian from the original sample.
MLEs.OG <- optim(start, nll, y = y.OG, x = x.OG, hessian = TRUE)

# Step 2: use the multivariate normality of MLEs to resample them.
MLEs.boot <- mvrnorm(n = nboot, mu = MLEs.OG$par, Sigma = solve(MLEs.OG$hessian))

# Step 3: if necessary, calculate parameter of interest (this is a vector).
myparam <- f(MLEs.boot,x)

# Step 4: find percentails (say 95% for example).
low <- round((nboot + 1) * 0.025))
high <- round((nboot + 1) * 0.975)

sorted.myparam <- sort(myparam)

CI.myparam <- c(sorted.myparam[low], sorted.myparam[high])
```
