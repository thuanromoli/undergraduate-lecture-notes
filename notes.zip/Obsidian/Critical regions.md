---
aliases:
  - critical region
type: def
tags:
  - MT2508
  - MT3507
---
>[!def] Definition
>A critical region is a set of values of the [[Test statistics]] for which the [[Statistical hypothesis|null hypothesis]] is rejected
