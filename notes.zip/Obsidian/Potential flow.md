---
tags:
  - MT4509
aliases:
---
> [!def] Potential flow
> A potential flow is a flow that satisfies
> $$\boldsymbol{\omega}= \boldsymbol{\nabla \times u}= \boldsymbol{0}.$$

In our case, we consider a potential and homogenous flow. So our flow satisfies $\boldsymbol{\nabla \cdot u}= 0$ and $\boldsymbol{\nabla \times u} = \boldsymbol{0}$.

> [!thm] Persistence of potential flow
> See [[Kelvin's circulation theorem]].

> [!def] Velocity potenital
> The velocity potential is a scalar field $\phi$ such that
> $$\boldsymbol{u}= \nabla \phi.$$

> [!gen] Remarks
> - We are assured that $\phi$ exists as $\nabla \times \boldsymbol{u}=0 \implies \exists \phi \quad \text{s.t}\quad  \boldsymbol{u \times \nabla}\phi$.
> - $\phi=$ constant lines are perpendicular to streamlines.

> [!thm] Relation to [[Laplace's equation]]
> $$\boldsymbol{\nabla \cdot u}=0 \iff \boldsymbol{\nabla}^{2}\phi=0$$
> Proof: let $\boldsymbol{u}= \nabla  \phi$.

> [!thm] Superposition principle
> If $\phi_{1}$ and $\phi_{2}$ are two potentials, then $\phi=\alpha \phi_{1}+\beta \phi_{2}$ is also a potential.
> 
> Proof: show that $\nabla ^{2}\phi=0$ is satisfied.
