---
tags:
  - MT4551
aliases:
  - financial derivative
---
> [!def] Definition
> A derivative is a financial instrument whose value depends upon the value of some more basic underlying commodity (e.g. metals, livestock, food).
> So a financial derivative is a value that depends on share prices.
