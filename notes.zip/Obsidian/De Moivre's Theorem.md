---
tags:
  - MT3503
aliases:
---
Let $z$ be a [[Complex numbers|complex number]].

> [!thm] Theorem
> If $|z| = r$ and $\arg z = \theta$, then
> $$z^{n} = r^{n}(\cos n \theta + i \sin n \theta)$$
> for all integers $n$.

Proof: omitted, use induction.
