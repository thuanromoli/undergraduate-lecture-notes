---
tags:
  - MT3508
aliases:
  - GLM
---
Let $Y$ be an outcome and $X$ be a vector of explanatory variables.

> [!def] Definition
> A generalised linear model (GLM) is a [[Statistical modelling and inference|statistical model]] that has three components:
> - The random component: the possible distributions of $Y|X$ form an [[Exponential dispersion families|exponential dispersion family]].
> - The linear predictor: $\eta = \boldsymbol{x} \boldsymbol{\beta}$, where $\boldsymbol{x}$ is a row vector of explanatory variables and $\boldsymbol{\beta}$ is a column vector with same length.
> - The link function: $g$ such that $g(\mu) = \eta$ where $\mu= \mathbb E(Y|X=\boldsymbol{x})$ is the conditional expectation.
