---
tags:
  - MT4551
aliases:
---
Consider the [[Geometric Brownian motion|geometric Brownian share price model]] $dS = \mu S dt + \sigma S dW$.

> [!thm] Computing the share price
> The discrete version of the geometric Brownian share price model  $dS = \mu S dt + \sigma S dW$ is
> $$\Delta S = \mu S \Delta t + \sigma S \varepsilon \Delta t^\frac{1}{2}.$$
> Now we compute a time series for $S(t)$:
> $$\begin{align*}
   t = 0 \implies & S=S_{0}\\\\
   t_{1} = \Delta t \implies & S = S_{0} + \Delta S\\
   & S = S_{0} + \mu S_{0} \Delta t + \sigma S_{0} \varepsilon \Delta t^\frac{1}{2}\\\\
   t_{2} = 2\Delta t \implies & S = S_{1} + \Delta S\\
   & S = S_{1} + \mu S_{1} \Delta t + \sigma S_{1} \varepsilon \Delta t^\frac{1}{2}\\\\
   \vdots
   \end{align*}$$
