---
tags:
  - MT4003
aliases:
  - p-subgroup
---
Let $p$ be a prime number.

> [!def] Definition
> A $p$-subgroup is a [[Subgroups|subgroup]] of a [[Order|finite]] [[Groups|group]] with order a power of $p$.
