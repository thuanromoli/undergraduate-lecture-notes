---
type: thm
tags:
  - MT2505
  - MT4003
---
Let $G$ be a [[Groups|group]] with $x^ {-1}$ as its [[Inverse element|inverse]].

>[!thm]+ $(x^{-1})^{-1}=x \ \ \forall x \in G$
>PROOF:
>$x^{-1}*(x^{-1})^{-1}= e$$\implies$$x* x^{-1}*(x^{-1})^{-1}= x*e$$\implies$$(x^{-1})^{-1}= x$

>[!thm]+ $(x*y)^{-1} = y^{-1}*x^{-1} \ \ \forall x,y \in G$
>PROOF:
>$(x*y)*(x*y)^{-1}=e$$\implies$$x^{-1}*(x*y)*(x*y)^{-1}=x^{-1}*e$$\implies$$y*(x*y)^{-1}=x^{-1}$$\implies$$y^{-1}*y*(x*y)^{-1}=y^{-1}*x^{-1}$$\implies$$(x*y)^{-1}=y^{-1}*x^{-1}$

>[!thm]+ If $x_1,x_2,\ldots,x_n \in G$ then $(x_1x_2\ldots x_n)^{-1}=x_n^{-1}\ldots x_2^{-1}x_1^{-1}$
>PROOF:
>Proof is by induction and omitted.