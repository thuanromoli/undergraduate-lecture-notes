---
tags:
  - MT4554
type: def
aliases:
  - cooperate
---
>[!def] Cooperation
>Cooperation means people work together towards a shared goal, the benefits of which are greater than any one individual could achieve alone. Cooperation is at the heart of a great deal of human and animal behaviour.

>[!def] Non-cooperative games
>A non-cooperative game is a game in which all players are competing and cannot make binding agreements with each other, so that any cooperation must be self-enforcing within the context of the game. Games in which binding agreements are possible are called cooperative games