---
type: def
tags:
  - MT2508
  - MT3507
---
>[!def] Definition
>A Type I error occurs when we reject the [[Statistical hypothesis|null hypothesis]] when it is true.
