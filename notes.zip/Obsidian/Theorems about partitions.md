---
type: thm
tag: MT2505
---
Let $\mathcal{P} = \set{B_{i}:i\in I}$ be a [[Partitions|partition]] of $A$. 

>[!thm]- If $\sim$ is a [[Relations|relation]] on the set $A$ by $a\sim b$ when $a$ and $b$ lie in the same part $B_i$ of the partition, then $\sim$ is an [[Equivalence relations|equivalence relation]] on $A$ and the [[Equivalence classes|equivalence classes]] of $\sim$ are the subsets $B_i$ in the partition $\mathcal P$.