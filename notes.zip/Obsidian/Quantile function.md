---
tags:
  - MT3508
aliases:
  - quantile
---
Let $Y$ denote a continuous [[Random variables|rv]] that can take values in the range $[a,b]$.

> [!def] Definition
> The quantile function is the inverse of the [[Cumulative distribution function|cumulative distribution function]]
> $$Q(p) = \Phi^{-1}(p) = y$$
> that is, a function which returns a threshold value $y$ such that $\Phi(y) = \mathbb P(Y \leqslant y) = p$.
