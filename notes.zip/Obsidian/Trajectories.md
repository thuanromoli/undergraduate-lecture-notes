---
alias:
  - trajectories
  - trajectory
type: def
tag: MT2507
---
>[!def] Definition
>A trajectory is a single curve on the [[Phase plane|phase plane]].
