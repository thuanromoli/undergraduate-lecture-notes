---
type: def
tag: MT2507
---
Allow $x=x(t)$ and $y=y(t)$.

>[!def] Definition
> The form of the general system is: $$\matrix{\frac{dx}{dt}=F(t,x(t),y(t)) \\ \frac{dy}{dt}= G(t,x(t),y(t))}$$

If the system does not depend on time explicitly, we have an [[Autonomous system of first order ODEs|autonomous system of first order ODEs|]].