---
tags:
  - MT4531
aliases:
  - Bayes estimate
---
Let $\theta \in \Theta$ be a parameter and $\boldsymbol{x}$ be the data.
Let $L(\theta,\widehat \theta)$ be the loss [[Functions|function]] for the [[Estimators|estimate]] $\widehat \theta$, when the true estimate is $\theta$.

> [!def] Definition
> The Bayes estimate is chosen to minimise the expectation of the loss function with respect to the [[Posterior distributions|posterior]]. That is,
> $$\widehat \theta_{B}=\arg \min_{\widehat \theta  \in \Theta}\mathbb E_{\pi}\Big[L(\theta, \widehat \theta)\Big]=\arg\min_{\widehat \theta  \in \Theta}\left[\int_{\theta \in \Theta}^{}L(\theta, \widehat \theta)\pi(\theta|\boldsymbol{x})\;d \theta\right].$$

> [!thm] The mean of the posterior distribution is the Bayes estimate with respect to the quadratic loss function $L(\theta,a)=(\theta-a)^{2}$. $$\mathbb E_{\pi}(\theta)=\int_{\theta \in \Theta}^{}\theta \pi(\theta|\boldsymbol{x})\;d \theta.$$

> [!thm] The median of the posterior distribution is the Bayes estimate with respect to the absolute error loss function $L(\theta,a)=|\theta-a|$. $$\int_{- \infty}^{a}\pi(\theta|\boldsymbol{x})=\frac{1}{2}.$$

> [!thm] The mode of the posterior distribution is the Bayes estimate with respect to the zero-one loss function $L(\theta,a)=-\delta_{a,\theta}$. $$\text{Minimise }\sum\limits_{\theta \in \Theta\setminus \theta^{*}}^{}\pi(\theta|\boldsymbol{x})=1-\pi(\theta^{*}|\boldsymbol{x}) \implies \text{maximise } \pi(\theta^{*}|\boldsymbol{x}) \implies \text{take most likely }\widehat \theta.$$
