---
tags:
  - MT4551
aliases:
---
Consider the [[The Black-Scholes equation - derivation|Black-Scholes equation]] $\frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2}V}{\partial S^{2}} + rS \frac{\partial V}{\partial S} -rV =0$ with [[The Black-Scholes equation - general solution|general solution]]
$$V(S,t) = e^{-r(T-t)}\int_{0}^{\infty} V(S',T)P(S')dS'$$
where
$$P(S') = \frac{1}{\sqrt{2 \pi \sigma^{2}(T-t)}} \frac{1}{S'} \exp \left\{ - \frac{[\ln S' - \ln S - (r - \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} \right\}.$$

> [!thm] Theorem
> The particular solution to the [[The Black-Scholes equation - derivation|Black-Scholes equation]], using the European Call boundary conditions
> $$V(S',T) = \begin{cases}
   0 & \text{if } S' < E \\
   S' - E & \text{if } S' \geqslant E
   \end{cases}$$
> and by letting $C(S,t)$ be the value of the Call option at an earlier time, is
> $$\begin{align*}
   C(S,t) &= SN(d_{1}) - Ee^{-r(T-t)}N(d_{2})\\
   d_{1} &= \frac{\ln S/E + (r + \frac{1}{2} \sigma^{2})(T-t) }{ \sigma(T-t)^{\frac{1}{2}}}\\
   d_{2} &= \frac{\ln S/E + (r - \frac{1}{2} \sigma^{2})(T-t) }{ \sigma(T-t)^{\frac{1}{2}}}
   \end{align*}$$
> where $N(d)$ is the [[Cumulative distribution function|CDF]] of the [[Normal distribution|normal distribution]] at $d$.

Proof:
We apply the boundary conditions for a European Call.
$$\begin{align*}
C(S,t) &= e^{-r(T-t)}\int_{0}^{\infty} V(S',T)P(S')dS'\\
&= e^{-r(T-t)} \left(\int_{0}^{E} 0 \cdot P(S')dS' + \int_{E}^{\infty} (S'-E)P(S')dS'\right)\\
&= e^{-r(T-t)} \int_{E}^{\infty} (S'-E)P(S')dS'\\
&= e^{-r(T-t)} \int_{E}^{\infty} (S'-E)\frac{1}{\sqrt{2 \pi \sigma^{2}(T-t)}} \frac{1}{S'} \exp \left\{ - \frac{[\ln S' - \ln S - (r - \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} \right\}dS'\\
&= \frac{e^{-r(T-t)}}{\sqrt{2 \pi \sigma^{2}(T-t)}} \int_{E}^{\infty} \frac{(S'-E)}{S'} \cdot \exp \left\{ - \frac{[\ln S' - \ln S - (r - \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} \right\}dS'.
\end{align*}$$

aim is to write this as a normal cumulative distribution function $N(x)=\frac{1}{\sqrt{2 \pi}}\int_{-\infty}^{x}e^{-y^{2}/2}dy$.

Therefore we use the substitution $x = \ln (S'/S)$, hence $dx = \frac{1}{S'}dS'$ and $S'=Se^{x}$ to obtain
$$\begin{align*}
C(S,t) &= \frac{e^{-r(T-t)}}{\sqrt{2 \pi \sigma^{2}(T-t)}} \int_{\ln (E/S)}^{\infty} \frac{(Se^{x}-E)}{S'} \cdot \exp \left\{ - \frac{[x- (r - \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} \right\} S'dx\\
&= \frac{e^{-r(T-t)}}{\sqrt{2 \pi \sigma^{2}(T-t)}} \int_{\ln (E/S)}^{\infty}(Se^{x}-E) \exp \left\{ - \frac{[x- (r - \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} \right\} dx\\
&= C_{1}(S,t)-C_{2}(S,t).
\end{align*}$$

We proceed to evaluate the two integrals separately, starting from the harder $C_{1}(S,t)$.
$$\begin{align*}
C_{1}(S,t) &= \frac{e^{-r(T-t)}}{\sqrt{2 \pi \sigma^{2}(T-t)}} \int_{\ln (E/S)}^{\infty}Se^{x} \exp \left\{ - \frac{[x- (r - \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} \right\} dx\\
\end{align*}$$
and now by completing the square in the exponent of $e$ like in [[Share prices - expectation|this proof]], we obtain that
$$ x - \frac{[x - (r - \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} = -\frac{[x - (r + \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} +r(T-t).$$

Hence
$$\begin{align*}
C_{1}(S,t) &= \frac{e^{-r(T-t)}}{\sqrt{2 \pi \sigma^{2}(T-t)}} \int_{\ln (E/S)}^{\infty}Se^{x} \exp \left\{ - \frac{[x- (r - \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} \right\} dx\\
&= \frac{e^{-r(T-t)}}{\sqrt{2 \pi \sigma^{2}(T-t)}} \int_{\ln (E/S)}^{\infty}S \exp \left\{ -\frac{[x - (r + \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} +r(T-t) \right\} dx\\
&= \frac{e^{-r(T-t)}}{\sqrt{2 \pi \sigma^{2}(T-t)}} \int_{\ln (E/S)}^{\infty}S \exp \left\{ -\frac{[x - (r + \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} \right\}e^{r(T-t)}dx\\
&= \frac{S}{\sqrt{2 \pi \sigma^{2}(T-t)}} \int_{\ln (E/S)}^{\infty} \exp \left\{ -\frac{[x - (r + \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} \right\}dx.
\end{align*}$$

And we can now make a further substitution $y =  \frac{x - (r + \frac{1}{2} \sigma^{2})(T-t)}{\sigma(T-t)^{\frac{1}{2}}}$, therefore $dy = \frac{1}{\sigma(T-t)^\frac{1}{2}}dx$ and so
$$\begin{align*}
C_{1}(S,t) &= \frac{S}{\sqrt{2 \pi \sigma^{2}(T-t)}} \int_{\ln (E/S)}^{\infty} \exp \left\{ -\frac{[x - (r + \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} \right\}dx\\
&= \frac{S}{\sqrt{2 \pi \sigma^{2}(T-t)}} \int_{\ln (E/S)}^{\infty} \exp \left\{ - \frac{1}{2}\frac{[x - (r + \frac{1}{2} \sigma^{2})(T-t)]^{2}}{\sigma^{2}(T-t)} \right\}dx\\
&= \frac{S}{\sqrt{2 \pi \sigma^{2}(T-t)}} \int_{a}^{\infty} \exp \left\{ - \frac{1}{2} y^{2} \right\} \left(\sigma(T-t)^{\frac{1}{2}}\right)dy \\
&= \frac{S}{\sqrt{2 \pi }} \int_{a}^{\infty} e^{-y^{2}/2}dy
\end{align*}$$
where $a = \frac{\ln (E/S) - (r + \frac{1}{2} \sigma^{2})(T-t)}{\sigma(T-t)^{\frac{1}{2}}}$.

Now we use the symmetrical property of the normal distribution which either graphically or using a substitution $x=-y$ tells us that
$$\begin{align*}
C_{1}(S,t) &= \frac{S}{\sqrt{2 \pi }} \int_{a}^{\infty} e^{-y^{2}/2}dy\\
&= \frac{S}{\sqrt{2 \pi }} \int_{-\infty}^{-a} e^{-y^{2}/2}dy\\
&= SN(-a)\\
&= SN(d_{1})
\end{align*}$$
where
$$d_{1} = -a = -\frac{\ln (E/S) - (r + \frac{1}{2} \sigma^{2})(T-t)}{\sigma(T-t)^{\frac{1}{2}}} = \frac{\ln (S/E) + (r + \frac{1}{2} \sigma^{2})(T-t)}{\sigma(T-t)^{\frac{1}{2}}}.$$

Finally, we evaluate the second easier integral $C_{2}(S,t)$.
$$\begin{align*}
C_{2}(S,t) &= \frac{e^{-r(T-t)}}{\sqrt{2 \pi \sigma^{2}(T-t)}} \int_{\ln (E/S)}^{\infty} E\exp \left\{ - \frac{[x- (r - \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} \right\} dx\\
\end{align*}$$
By repeating the above process, make a substitution $y =  \frac{x - (r - \frac{1}{2} \sigma^{2})(T-t)}{\sigma(T-t)^{\frac{1}{2}}}$, therefore $dy = \frac{1}{\sigma(T-t)^\frac{1}{2}}dx$ and so
$$\begin{align*}
C_{2}(S,t) &= \frac{Ee^{-r(T-t)}}{\sqrt{2 \pi \sigma^{2}(T-t)}} \int_{\ln (E/S)}^{\infty} \exp \left\{ -\frac{[x - (r - \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} \right\}dx\\
&= \frac{Ee^{-r(T-t)}}{\sqrt{2 \pi \sigma^{2}(T-t)}} \int_{\ln (E/S)}^{\infty} \exp \left\{ - \frac{1}{2}\frac{[x - (r - \frac{1}{2} \sigma^{2})(T-t)]^{2}}{\sigma^{2}(T-t)} \right\}dx\\
&= \frac{Ee^{-r(T-t)}}{\sqrt{2 \pi \sigma^{2}(T-t)}} \int_{a}^{\infty} \exp \left\{ - \frac{1}{2} y^{2} \right\} \left(\sigma(T-t)^{\frac{1}{2}}\right)dy \\
&= \frac{Ee^{-r(T-t)}}{\sqrt{2 \pi }} \int_{a}^{\infty} e^{-y^{2}/2}dy
\end{align*}$$
where $a = \frac{\ln (E/S) - (r - \frac{1}{2} \sigma^{2})(T-t)}{\sigma(T-t)^{\frac{1}{2}}}$.

Now we use the symmetrical property of the normal distribution which either graphically or using a substitution $x=-y$ tells us that
$$\begin{align*}
C_{2}(S,t) &= \frac{Ee^{-r(T-t)}}{\sqrt{2 \pi }} \int_{a}^{\infty} e^{-y^{2}/2}dy\\
&= \frac{Ee^{-r(T-t)}}{\sqrt{2 \pi }} \int_{-\infty}^{-a} e^{-y^{2}/2}dy\\
&= Ee^{-r(T-t)}N(-a)\\
&= Ee^{-r(T-t)}N(d_{2})
\end{align*}$$
where
$$d_{2} = -a = -\frac{\ln (E/S) - (r - \frac{1}{2} \sigma^{2})(T-t)}{\sigma(T-t)^{\frac{1}{2}}} = \frac{\ln (S/E) + (r - \frac{1}{2} \sigma^{2})(T-t)}{\sigma(T-t)^{\frac{1}{2}}}.$$

We put this together to obtain the solution
$$\begin{align*}
C(S,t) &= C_{1}(S,t)-C_{2}(S,t)\\
&= SN(d_{1})-Ee^{-r(T-t)}N(d_{2})
\end{align*}$$
with $d_{1} = \frac{\ln S/E + (r + \frac{1}{2} \sigma^{2})(T-t) }{ \sigma(T-t)^{\frac{1}{2}}}$ and $d_{2} = \frac{\ln S/E + (r - \frac{1}{2} \sigma^{2})(T-t) }{ \sigma(T-t)^{\frac{1}{2}}}$ where $N(d)$ is the [[Cumulative distribution function|CDF]] of the [[Normal distribution|normal distribution]] at $d$.