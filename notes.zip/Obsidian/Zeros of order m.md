---
tags:
  - MT3503
aliases:
---
Let $f$ be a [[Holomorphic functions|holomorphic]] [[Functions|function]] in some [[Open balls|open ball]] $B(a,r)$.

> [!def] Definition
> $f$ has a zero of order $m$ at $a$ if the [[Taylor's Theorem|Taylor series]] for $f$ has the form
> $$f(z) = c_{m}(z-a)^{m} + c_{m+1}(z-a)^{m+1}+\cdots,$$
> valid in $B(a,r)$, where $c_{m} \neq 0$.
