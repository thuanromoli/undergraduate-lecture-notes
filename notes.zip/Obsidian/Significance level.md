---
aliases:
  - significance level
type: def
tags:
  - MT2508
  - MT3507
---
>[!def] Definition
>The significance level of a [[Hypothesis test|hypothesis test]] is the probability of a [[Type I error]]:
>$$\mathbb P(\text{Type I error})=\mathbb P(T\in C \ \vert \ H_0 \text{ is true}) = \alpha$$
