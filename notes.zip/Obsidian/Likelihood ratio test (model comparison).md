---
tags:
  - MT3508
aliases:
---
> [!gen] [[Statistical hypothesis|Hypothesis]]
> $H_{0}$: the model with less parameters is correct.
> $H_{1}$: the model with more parameters is correct.

> [!gen] [[Test statistics]]
> $$\begin{align*}
   \hbox{LRT} & = 2 \log \left\{\frac{L(\widehat{\boldsymbol{\theta}_1})}{L(\widehat{\boldsymbol{\theta}_0})} \right\} \\
   & = 2 \left[ \log\{ L(\widehat{\boldsymbol{\theta}_1}) \} - \log \{ L(\widehat{\boldsymbol{\theta}_0}) \} \right]\\
   &= 2\left\{l(\widehat{\boldsymbol{\theta}_{1}})-l(\widehat{\boldsymbol{\theta}_{0}})\right\} \sim \chi^{2}_{r}\end{align*}$$
> where
> - $\widehat{\boldsymbol{\theta}_{0}}$ are the [[Maximum Likelihood Estimator|MLEs]] of the parameters under the null hypothesis.
> - $\widehat{\boldsymbol{\theta}_{1}}$ are the [[Maximum Likelihood Estimator|MLEs]] of the parameters under the alternative hypothesis.
> - $L(\widehat{\boldsymbol{\theta}})$ is the [[Likelihood|likelihood]] evaluated at the [[Maximum Likelihood Estimator|MLE]].
> - $r$ is the difference in the number of parameters.
