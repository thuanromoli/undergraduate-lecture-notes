---
tags:
  - MT3503
aliases:
---
#### For complex analysis:
Let $U$ be an [[Open sets|open subset]] of $\mathbb C$.

> [!thm]- If the function $f: U \to \mathbb C$ is [[Differentiability|differentiable]] at $c \in U$, then it is [[Continuity|continuous]] at $c$
