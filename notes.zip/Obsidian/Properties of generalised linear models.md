---
tags:
  - MT3508
aliases:
---
> [!thm] Statistical properties
> - A distribution-based analysis of covariate effects is possible (see analysis of deviance).
> - The [[Generalised linear models|GLM]] framework unifies many common regression approaches.

> [!thm] Computational properties
> - The [[Log-likelihood|log-likelihoods]] have a single unique maximum.
> - Very fast algorithms are available that probably converge to the maximum.
