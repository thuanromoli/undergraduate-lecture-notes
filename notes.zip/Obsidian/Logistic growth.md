---
type: model
tag: MT2507
---
This is a type of [[exponential growth]].

>[!gen]+ Building the logistic model
>Consider models of the form $$\frac{\text dN}{\text dt}=R(N)N$$ where the growth rate $R$ is a [[Functions|function]] of $N$. We choose $R(N)$ such that:
>- $R(N)\approx r>0$: when $N$ is small;
>- $R(N) > 0$: and decreasing as $N$ increases;
>- $R(N) < 0$: when $N$ is very large.

One such [[Functions|function]] is $$R(N)=r-aN$$where $r>0$ is the natural growth and $a>0$ is the injibition of growth when the population is large, hence: $$\frac{\text dN}{\text dt}=(r-aN)N$$This model can be rewritten as $$\frac{\text dN}{\text dt}=(r-aN)N=r(1-\frac arN)N=r(1-\frac 1 {\frac ra}N)N=r(1-\frac NK)N$$where $K$ is the carrying-capacity of the population.

This is used to model population growth and we usually assess the [[Critical points and steady states|steady states]] and [[Stability|stability]] rather than using an analytical solution.