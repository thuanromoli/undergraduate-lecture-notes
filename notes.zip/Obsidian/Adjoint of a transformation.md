---
tags:
  - MT3501
type: def
aliases:
  - adjoint
---
Let $V$ and $W$ be [[Inner product spaces|inner product spaces]] with inner products $\langle \cdot , \cdot \rangle$.
Let $T:V\to W$ be a [[Linear transformations|linear transformation]].

>[!def] Definition
>The adjoint of $T$ is a map $T^{*}:W\to V$ such that
>$$\langle T(v),w \rangle=\langle v,T^{*}(w) \rangle \;\;\forall v\in V \;\land \;\forall w \in W$$

>[!thm] Theorem
>The adjoin of a [[Linear transformations|linear transformation]] exists, is unique, and is a linear transformation.
>
>Proof: see [[theorems about the adjoint of a transformation]]
