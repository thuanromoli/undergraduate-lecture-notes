---
tags:
  - MT4528
type: def
aliases:
  - recurrent
  - positive recurrent
  - null recurrent
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S$.

>[!def] Definition
>A state $i \in S$ is called recurrent if
>$$f_{ii}=1$$
>That is, the [[The first return probability|first return probability]] is 1 and we are certain to return to $i$.

>[!def] Positive and null recurrent states
>Let $\mu_{i}$ be the [[Recurrence time|mean recurrence time]].
>- Positive recurrent states if $\mu_{i}<\infty$.
>- Null recurrent states if $\mu_{i}=\infty$.
