---
type: def
tags:
  - MT2505
  - MT4003
aliases:
  - alternating group
---
Let $n$ be a positive integer.

>[!def] Definition
>The alternating group $A_n$ of degree $n$ is the set of [[Permutations and Cycles|even permutations]] viewed as a [[Groups|group]] under [[Function composition|function composition]].

> [!thm] Theorem
> The alternating group is a subgroup of the [[The symmetric group|symmetric group]] $S_{n}$.
> 
> The identity is a product of 0 transpositions, so $A_{n}$ is non-empty.
> Let $\alpha, \beta \in A_{n}$, say $\alpha=\sigma_{1}\sigma_{2}\cdots \sigma_{2k}$ and $\beta= \tau_{1}\tau_{2}\cdots \tau_{2l}$.
> Then $\alpha \beta = \sigma_{1}\sigma_{2}\cdots \sigma_{2k}\tau_{1}\tau_{2}\cdots \tau_{2l}$ is a product of $2(k+l)$ transpositions, so is even.
> $\alpha^{-1} = (\sigma_{1}\sigma_{2}\cdots \sigma_{2k})^{-1}=\sigma_{2k}^{-1}\sigma^{-1}_{2k-1}\cdots \sigma^{-1}_{2} \sigma^{-1}_{1}=\sigma_{2k}\sigma_{2k-1}\cdots \sigma_{2} \sigma_{1}$ since the inverse of a transposition is its own inverse.
> Hence $\alpha^{-1}$ is even, so $A_{n} \leqslant S_{n}$.