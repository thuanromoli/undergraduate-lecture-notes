---
tags:
  - MT3502
aliases:
---
Let $A,B$ be [[Cardinality|finite sets]].

> [!thm] $A$ is [[Similarity|similar]] to $B$ if and only if $A$ and $B$ have the same cardinality, that is $A \simeq B \iff |A| = |B|$
> Firstly, suppose that $A \simeq B$.
> Since $A$ is finite, $A \simeq \set{1,2,...,n}$ for some $n \in N$.
> But $A \simeq B \implies B\simeq A \implies B\simeq A \simeq \set{1,...,n}$.
> By transitivity, $B\simeq \set{1,...,n}$.
> Hence $|A| = n = |B|$.
> 
> Conversely, suppose that $|A| = |B| = n$.
> Then $A \simeq \set{1,...,n}$.
> Similarly, $B \simeq \set{1,...,n}$.
> By transitivity, $A \simeq B$.

Let $A$ be a non-empty set.

> [!thm] $A \not\simeq \mathcal P(A)$
> Suppose for a contradiction that $A \simeq \mathcal P(A)$.
> Then there exists a [[Bijective functions|bijection]] $f:A \to \mathcal P(A)$.
> Let $B = \set{x \in A : x \notin f(x)}$. That is, the set of all elements $x$ in $A$ that are not elements of the subset of $A$ that $f$ maps $x$ to.
>>$B$ is a self-referential set.
>>By construction, for each element $x \in A$, we ask the question: "Is $x$ an element of the subset of $A$, namely $f(x)$?".
>>If $x$ is not an element of $f(x)$, then you put $x$ into $B$. Otherwise if $x$ is an element of $f(x)$, then you leave it out of $B$.
>
> Since $f$ is a bijection from $A$ to $\mathcal P(A)$, then every subset of $A$, including $B$, must be the image of some element of $A$.
> There must be some $a \in A$ such that $f(a)= B$.
> Let us now check whether $a \in B$.
> - If $a \in B$, then by definition $a \notin f(a) = B$, which is a contradiction.
> - If $a \notin B$, then by definition $a \in f(a) = B$, which is a contradiction.
>
> Hence there is no such bijection $f$, so $\mathcal P(A)$ has a strictly greater cardinality than $A$.