---
tags:
  - MT3502
aliases:
---
Let $f_{n}:[a,b] \to \mathbb R$ be a [[Functions|function]].

> [!thm] Theorem
> Suppose that there is a [[Sequences|sequence]] of non-negative numbers $(M_{n})_{n}$ such that $\sum\limits_{n=1}^{\infty}M_{n}<\infty$ and $|f_{n}(x)| \leqslant M_{n}$ for all $n \in \mathbb N$ and $x \in [a,b]$.
> Then the [[Series|series]] $\sum\limits_{n=1}^{\infty}f_{n}(x)$ [[Convergence|converges uniformly]] on $[a,b]$.
