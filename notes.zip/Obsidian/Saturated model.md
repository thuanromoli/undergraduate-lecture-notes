---
tags:
  - MT3508
aliases:
  - saturated model
---
> [!def] Definition
> A saturated model is one in which there are as many estimated parameters as data points.
> By definition, this will lead to a perfect fit, but will be of little use statistically, as you have no data left to estimate variance.
