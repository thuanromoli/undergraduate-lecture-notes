---
tags:
  - MT3508
aliases:
---
We use [[MLE Properties and assumptions#^c2d912|normality]] to find the [[Confidence intervals|confidence interval]] of a parameter $\theta$.

> [!thm] Theorem
> The confidence interval of a parameter $\theta$ can be obtained by
> $$\widehat{\theta}\in (\widehat{\theta}- z_{1-\alpha/2}\sigma,\widehat{\theta}+z_{1-\alpha/2}\sigma)$$
> where $\widehat{\theta}$ is the [[Maximum Likelihood Estimator|MLE]], $\alpha$ is the confidence level, and $\sigma$ is the [[Variance and standard deviation|standard deviation]] of $\widehat{\theta}$.

If we have parametrised $\theta$ in terms of $\beta$:
1. Use [[Optim]] to find $\widehat\beta$.
2. Assume normality on $\widehat \beta$.
3. Find the confidence interval for $\widehat \beta$ using the above result.
4. Use [[MLE Properties and assumptions|invariance property]] to find the confidence interval of $\widehat \theta$.
