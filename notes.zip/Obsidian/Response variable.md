---
type: def
tag: MT2508
alias: response variable
---
>[!def] Definition
>The response variable is the dependent variable, this is assumed to be a [[Random variables|random variable]].
>The distribution of this [[Random variables|rv]] is dependent on the [[Explanatory variable|explanatory variable]].
