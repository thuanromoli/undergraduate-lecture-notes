---
tags:
  - MT3508
aliases:
  - cdf
---
Let $Y$ denote a continuous [[Random variables|rv]] that can take values in the range $[a,b]$.

> [!def] Definition
> The cumulative distribution [[Functions|function]] for $Y$ is the [[Functions|function]] $\Phi(y)$ such that
> $$\Phi(y) = \mathbb{P}(Y \leqslant y) = \int_{-\infty}^{y}f(x)\ \text{d}x$$
> where $f(x)$ is the [[Probability density function|probability density function]] of $Y$.
