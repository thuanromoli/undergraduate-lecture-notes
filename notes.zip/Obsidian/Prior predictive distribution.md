---
tags:
  - MT4531
aliases:
---
Let $\mathbf{X}$ be a random vector of future observations with likelihood $f(\mathbf{x}|\theta)$, but unknown parameter $\theta \in \Theta$.

> [!def] Definition
> The prior predictive distribution (or marginal likelihood) is the pdf of $\boldsymbol{X}$. That is,
> $$f(\mathbf{x})=\int_{\theta \in  \Theta}^{}f(\mathbf{x},\theta)\;d \theta=\int_{\theta \in \Theta}^{}f(\mathbf{x}|\theta)p(\theta)\;d \theta.$$

> [!gen] Remarks
> - We use this when we haven't observed data yet.
> - We are weighting the likelihood $f(\mathbf{x}|\theta)$ with the best description of our beliefs for $\theta$.
