---
tags:
  - MT4551
aliases:
---
> [!thm] Theorem
> The modified Black-Scholes equation to account for dividends is the partial differential equation
> $$\frac{\partial V_{1}}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2}V_{1}}{\partial S^{2}} + (r-D_{0})S \frac{\partial V_{1}}{\partial S} -(r-D_{0})V_{1} =0$$
> where $V_{1}(S,t) = Ve^{D_{0}(T-t)}$ and $D_{0}$ is the rate of [[Continuity|continuous]] payment of a dividend.

Proof:
We adapt the [[Geometric Brownian motion]] to account for the dividend payment by noting that the cash payment in a time step $dt$ is $D_{0}Sdt$. Hence the share price can be modelled as
$$\begin{align*}
dS &= \mu Sdt+\sigma SdW-D_{0}S dt\\
&= (\mu -D_{0})Sdt  + \sigma S dW
\end{align*}$$
where $\mu - D_{0}$ is the reduced growth rate.

We know wish to re-derive using the same concepts the [[The Black-Scholes equation - derivation|Black-Scholes equation]]. So we construct a portfolio $\Pi$ of
- 1 unit of the financial derivative
- $- \Delta$ of the underlying asset
with value $\Pi = V - \Delta S$. Now the change in the value $d \Pi$ in time $dt$ is
$$d \Pi = dV - \Delta dS - D_{0}S \Delta dt.$$
We now quickly check all signs make sense when considering cash flow. Consider a call option.

| Long party              | Meaning                                       | Short party             | Meaning                         |
| ----------------------- | --------------------------------------------- | ----------------------- | ------------------------------- |
| $V > 0$                 | long call                                     | $V < 0$                 | short call                      |
| $\Delta > 0$            |                                               | $\Delta < 0$            |                                 |
| $-\Delta dS < 0$        | short share                                   | $-\Delta dS > 0$        | long share                      |
| $-D_{0}S \Delta dt < 0$ | loose cash from not getting dividend payments | $-D_{0}S \Delta dt < 0$ | get cash from dividend payments |

Now by using [[Itô's lemma]] with $x=S$, $a = (\mu - D_{0}) S$, $b = \sigma S$, and $G(S,t) = V(S,t)$.
$$dV = \left(\frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2} V}{\partial S^{2}}\right)dt + \frac{\partial V}{\partial S} dS.$$
And subbing in the $d \Pi$ equation, we obtain
$$\begin{align*}
d \Pi &= dV - \Delta dS - D_{0}S \Delta dt\\
&=  \underbrace{\left(\frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2} V}{\partial S^{2}}\right)dt}_{\text{deterministic}} + \underbrace{\frac{\partial V}{\partial S} dS - \Delta dS}_\text{random} -  \underbrace{D_{0}S \Delta dt}_\text{deterministic}.
\end{align*}$$
Now we wish to eliminate the random part of the equation so we set
$$\frac{\partial V}{\partial S}dS - \Delta dS =0 \implies \Delta dS= \frac{\partial V}{\partial S}dS \implies \Delta= \frac{\partial V}{\partial S}.$$
Now we have
$$\begin{align*}
d \Pi &=  \left(\frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2} V}{\partial S^{2}} -D_{0}S \frac{\partial V}{\partial S}\right)dt
\end{align*}$$
But now this portfolio gives a [[Risk-free assets|risk-free]] return as there is no randomness.
By the law of no [[Arbitrage|arbitrage]], the portfolio $\Pi$ must give a return at the [[Risk-free assets|risk-free]] rate. Hence
$$\begin{align*}
& d \Pi=r \Pi dt\\
\implies & \left(\frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2} V}{\partial S^{2}} -D_{0}S \frac{\partial V}{\partial S}\right)dt = r (V-\Delta S)dt\\
\implies & \frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2} V}{\partial S^{2}}-D_{0}S \frac{\partial V}{\partial S} = rV - r \frac{\partial V}{\partial S} S\\
\implies & \frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2} V}{\partial S^{2}}-D_{0}S \frac{\partial V}{\partial S} - rV + r \frac{\partial V}{\partial S} S=0\\
\implies & \frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2} V}{\partial S^{2}}+(r-D_{0})S \frac{\partial V}{\partial S} - rV = 0.
\end{align*}$$
This is similar to the original [[The Black-Scholes equation - derivation|Black-Scholes equation]] but we have lost symmetry as the third and fourth terms are not equal. To reproduce symmetry we apply the substitution
$$\begin{align*}
&V(S,t) = V_{1}(S,t)e^{-D_{0}(T-t)}\\
\implies & (1):\frac{\partial V}{\partial S} = \frac{\partial V_{1}}{\partial S} e^{-D_{0}(T-t)}\\
\implies & (2):\frac{\partial^{2} V}{\partial S^{2}} = \frac{\partial^{2} V_{1}}{\partial S^{2}} e^{-D_{0}(T-t)}\\
\implies & (3): \frac{\partial V}{\partial t} = \frac{\partial V_{1}}{\partial t}e^{-D_{0}(T-t)}+D_{0}V_{1}e^{-D_{0}(T-t)} = \left(\frac{\partial V_{1}}{\partial t}+D_{0}V_{1}\right)e^{-D_{0}(T-t)}.
\end{align*}$$
And now
$$\begin{align*}
& \frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2} V}{\partial S^{2}}+(r-D_{0})S \frac{\partial V}{\partial S} - rV = 0\\
\implies & \left(\frac{\partial V_{1}}{\partial t}+D_{0}V_{1}\right)e^{-D_{0}(T-t)} + \frac{1}{2}\sigma^{2}S^{2} \frac{\partial ^{2}V_{1}}{\partial S^{2}}e^{-D_{0}(T-t)} + (r-D_{0})S \frac{\partial V_{1}}{\partial S}e^{-D_{0}(T-t)} -r V_{1}e^{-D_{0}(T-t)} = 0\\
\implies & \frac{\partial V_{1}}{\partial t}+D_{0}V_{1}+ \frac{1}{2}\sigma^{2}S^{2} \frac{\partial ^{2}V_{1}}{\partial S^{2}}+ (r-D_{0})S \frac{\partial V_{1}}{\partial S} -r V_{1}= 0\\
\implies & \frac{\partial V_{1}}{\partial t} + \frac{1}{2}\sigma^{2}S^{2} \frac{\partial ^{2}V_{1}}{\partial S^{2}}+ (r-D_{0})S \frac{\partial V_{1}}{\partial S} - (r-D_{0}) V_{1}= 0.\\
\end{align*}$$
