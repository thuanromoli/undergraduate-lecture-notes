---
tags:
  - MT4509
aliases:
---
We assume $\rho=$ constant (homogeneous).

> [!thm] Theorem
> The evolution equation for the vorticity $\boldsymbol{\omega}$ is
> $$\frac{D}{Dt}\boldsymbol{\omega}=(\boldsymbol{\omega \cdot \nabla })\boldsymbol{u}.$$

> [!thm] Theorem
> For streamlines $d \boldsymbol{l}$ is parallel to $\boldsymbol{u}=(u,v,w)$ so we solve $\frac{dx}{u}=\frac{dy}{v}=\frac{dz}{w}$.
> For vortex lines $d \boldsymbol{l}$ is parallel to $\boldsymbol{\omega}=(\xi,\eta,\zeta)$  so we solve $\frac{dx}{\xi}=\frac{dy}{\eta}=\frac{dz}{\zeta}$.

Proof 1.
Note the duality of the evolution of line elements $\frac{D}{Dt}\boldsymbol{dl}=(\boldsymbol{dl \cdot \nabla })\boldsymbol{u}$ and the evolution of vorticity $$\frac{D}{Dt}\boldsymbol{\omega}=(\boldsymbol{\omega \cdot \nabla })\boldsymbol{u}.$$

Proof 2.
Direct proof by taking the curl of Euler's equation.
We use the handy identity $\boldsymbol{u \cdot \nabla u} = \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \boldsymbol{u} \times (\boldsymbol{\nabla \times u})$.
$$\begin{align*}
&\frac{D \boldsymbol{u}}{Dt} = - \frac{\nabla p}{\rho} + \boldsymbol{F}\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} +\boldsymbol{u} \cdot \nabla  \boldsymbol{u} = - \frac{\nabla p}{\rho} + \boldsymbol{F}\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} + \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) = - \frac{\nabla p}{\rho} + \boldsymbol{F}\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) =  - \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \frac{\nabla p}{\rho} + \boldsymbol{F}
\end{align*}$$
and assume that $\boldsymbol{F}=-\nabla V$ where $V$ is some potential.
$$\begin{align*}
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) =  - \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \frac{\nabla p}{\rho} - \nabla V \\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) =  - \nabla \left(\frac{1}{2} |\boldsymbol{u}|^{2} + \frac{ p}{\rho} + V\right)\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times \boldsymbol{\omega} =  - \nabla H
\end{align*}$$
now take the curl
$$\begin{align*}
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times \boldsymbol{\omega} =  - \nabla H \\
\implies& \nabla \times\left(\frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times \boldsymbol{\omega}\right) =  \nabla \times(- \nabla H)\\
\implies& \frac{\partial }{\partial t}(\nabla \times \boldsymbol{u}) - \nabla  \times(\boldsymbol{u \times \omega}) = 0\\
\implies& \frac{\partial \boldsymbol{\omega}}{\partial t} = \nabla  \times(\boldsymbol{u \times \omega})\\
\implies& \frac{\partial \boldsymbol{\omega}}{\partial t} = \boldsymbol{u \nabla \cdot \omega} - \boldsymbol{u \cdot \nabla w} - \boldsymbol{w \nabla \cdot u} + \boldsymbol{\omega \cdot \nabla  u}.
\end{align*}$$
Note that $\boldsymbol{\nabla \cdot u }=0$ by incompressibility, and $\boldsymbol{\nabla \cdot \omega}=\boldsymbol{\nabla}\cdot(\boldsymbol{\nabla \times u})=0$, so the above simplifies to
$$\begin{align*}
\implies& \frac{\partial \boldsymbol{\omega}}{\partial t} = - \boldsymbol{u \cdot \nabla w} + \boldsymbol{\omega \cdot \nabla u}\\
\implies& \frac{\partial \boldsymbol{\omega}}{\partial t}+ \boldsymbol{u \cdot \nabla w} = \boldsymbol{\omega \cdot \nabla u}\\
\implies& \frac{D \boldsymbol{\omega}}{Dt}= \boldsymbol{\omega \cdot \nabla u}.
\end{align*}$$
As required.

Sometimes, given $\nabla \times \boldsymbol{u}= \boldsymbol{\omega}$, we wish to obtain $\boldsymbol{u}$. We use a method called "inversion".
Note that since $\boldsymbol{\nabla \cdot u}=0$, then there exists an $\boldsymbol{A}$ such that $\boldsymbol{u}= \nabla \times \boldsymbol{A}$.
Now, $\nabla \times (\nabla \times \boldsymbol{A}) = \nabla (\nabla \cdot A)-\nabla^{2}\boldsymbol{A}=-\nabla ^{2} \boldsymbol{A}$ as $\nabla \cdot \boldsymbol{A}=0$ as $\nabla \cdot \boldsymbol{u}=0$ implies that $u,v,w$ are not independent.
So we obtain $\nabla ^{2} \boldsymbol{A}=-\boldsymbol{\omega}$.
