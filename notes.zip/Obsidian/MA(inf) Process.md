---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is called a moving average process of infinite order if there exists a [[White noise|white noise]] $(\varepsilon_{t})_{t \in \mathbb Z}$ and real numbers $\theta_{1},\theta_{2},... \in \mathbb R$ with $\sum\limits_{i=1}^{\infty}|\theta_{i}|< \infty$ (i.e. the series $\Big(\sum\limits_{i=1}^{n}\theta_{i}\Big)_{n \in \mathbb N}$ is [[Convergence|absolutely convergent]]) such that for all $t \in \mathbb Z$,
> $$X_{t}=\varepsilon_{t}+ \theta_{1} \varepsilon_{t-1}+\theta_{2}\varepsilon_{t-2}+\cdots$$
> 
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is a moving average of infinite order with mean $\mu$ if $X_{t}-\mu$ is a MA($\infty$) process.

> [!thm] Properties
> - $(X_{t})_{t \in \mathbb Z}$ is [[Stationarity|weakly stationary]].
> - $$\gamma_X (h) =  \sigma^2_{\varepsilon} \sum_{l=0}^{\infty} \theta_l\theta_{l+|h|}$$
> - $$\rho_X (h) =    \frac{ \sum_{l=0}^{\infty} \theta_l\theta_{l+|h|}}{\sum_{l=0}^{\infty} \theta^2_l}$$

> [!gen] Remarks
> - The MA($\infty$) process is also called the general linear process.
> - MA($\infty$) processes encompass certain [[AR(1) Process|AR(1) processes]] subject to  constraints.
