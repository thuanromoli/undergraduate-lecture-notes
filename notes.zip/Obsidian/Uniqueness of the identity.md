---
type: thm
tags:
  - MT2505
  - MT4003
---
Let $*$ be a [[Binary operations|binary operation]] of a set $A$.

>[!thm] Theorem
>If there is an [[Identity element|identity]] for $*$, then it is unique.

PROOF:
	By contradiction assume that if there is an identity for $*$ then it is not unique.
	Suppose that $e$ and $f$ are both identities for $*$ and $e\ne f$;
	Claim: $e=f$
		(1) $e*a=a*e=a$ and (2) $f*a=a*f=a$;
		setting $a = f\implies e*f=f$ by (1);
		setting $a = e\implies e*f=e$ by (2);
		hence $e=f$;
	this is a contradiction, hence if there is an identity for $*$ then it is unique.