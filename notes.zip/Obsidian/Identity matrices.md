---
tag: MT2501
type: def
alias:
- identity matrix
---
>[!def]+ Identity matrices
>The $n\times n$ identity [[Matrices|matrix]] $I_{n}$ is a [[Diagonal matrices|diagonal matrix]] of $1$'s:
>$$I_{n}=\begin{pmatrix}
 1 & 0 & \cdots & 0 \\
 0 & 1 & \cdots & 0 \\
 \vdots & \vdots & \ddots & \vdots \\
 0 & 0 & \cdots & 1 \\
 \end{pmatrix} = \text{diag}(1,\ldots,1)$$

---

#### Spaced repetition
