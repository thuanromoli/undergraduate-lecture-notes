---
tags:
  - MT4003
aliases:
  - the second isomorphism theorem
---
Let $G$ be a [[Groups|group]], $H$ be a [[Subgroups|subgroup]] of $G$, and $N$ be a [[Normal subgroups|normal subgroup]] of $G$.

>[!thm] Theorem
>The Second Isomorphism Theorem states that $H \cap N$ is a normal subgroup of $H$, $NH$ is a subgroup of $G$, and
> $$\frac{H}{H\cap N} \cong \frac{NH}{N}$$
> where $NH = \set{nh:n\in N, h\in H}$.

Proof:
By assumption $N \mathrel{\unlhd} G$, so we can construct $G/N$ and the associated [[Natural homomorphism|natural]] [[Homomorphisms|homomorphism]] $\pi:G\to G/N$. Let $\phi=\left.\pi\right\vert_{H}$ be the restriction of $\pi$ to $H$. That is,
$$\begin{align*}
\phi: H &\to G/N \\
h & \mapsto Nh
\end{align*}$$
and since $\pi$ is a homomorphism, so is $\phi$.

We now proceed to apply the [[The First Isomorphism Theorem|the first isomorphism theorem]] by finding $\ker \phi$ and $\text{im }\phi$.
$$\begin{align*}
\ker \phi &= \set{h\in H: h \phi=N1}\\
&= \set{h\in H : Nh =N}\\
&= \set{h\in H:h\in N}\\
&= H \cap N
\end{align*}$$
$$\begin{align*}
\text{im } \phi &= \set{Nh:h\in H}.
\end{align*}$$
Now [[Theorems about the kernel and the image#^b80cab|this theorems]] tell us that $H \cap N$ is a normal subgroup of $H$, and that $\text{im } \phi$ is a subgroup of $G/N$.

By [[The Correspondence Theorem|the correspondence theorem]], since $\text{im }\phi$ is a subgroup of $G/N$, then $\text{im } \phi$ is a quotient group, say $K/N$. So there exists a $K$ such that $\text{im } \phi=K/N$ and $N \leqslant K$.
$$\begin{align*}
K &=  \set{g \in G : Ng \in \text{im } \phi}\\
&= \set{g \in G: Ng=Nh \;\text{ for some }h \in H}\\
&= \set{g \in G: gh^{-1} \in N\;\text{ for some }h \in H}\\
&= \set{g \in G: gh^{-1}=n \;\text{ for some }h \in H,n\in N}\\
&= \set{g \in G: g=nh\;\text{ for some }h \in H,n\in N}\\
&= NH
\end{align*}$$
thus, $NH$ is a subgroup of $G$ and by the first isomorphism theorem,
$$\frac{H}{H\cap N} = \frac{H}{\ker \phi}\cong \text{im } \phi = \frac{K}{N}= \frac{NH}{N}.$$