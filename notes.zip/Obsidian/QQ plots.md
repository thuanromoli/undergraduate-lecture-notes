---
tags:
  - MT3508
aliases:
---
> [!def] Definition
> A quantile-quantile, or $QQ$-plot, is a plot of sample quantiles from the [[Empirical distribution function|EDF]] against the theoretical quantiles from the [[Cumulative distribution function|CDF]].

```R
# The theoretical quantiles
ord.CDF <- sort(pdistro(y, parameters)) # CDF at observed data values

# The sample quantiles
emp.EDF <- (rank(ord.CDF) - 0.5)/n # The empirical distribution function for each observation

# make the QQ-plot
plot(ord.CDF, emp.DF, pch = 16, xlim = c(0, 1), ylim = c(0, 1), xlab = 'theoretical', ylab = 'sample')
abline(0, 1)
```
