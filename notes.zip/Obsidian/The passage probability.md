---
tags:
  - MT4528
type: def
aliases:
  - passage probability
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S$ and states $i,j \in S$.

>[!def] Definition
>The passage probability is
>$$f_{ij}=\mathbb{P}(X_{n}=j \text{ for some } n \geqslant 1 | X_{0}=i)$$
>That is, the probability that, starting at $i$, we ever going to $j$.
>Note: $f_{ij}=\sum\limits_{n=1}^{\infty}f_{ij}(n)$.
