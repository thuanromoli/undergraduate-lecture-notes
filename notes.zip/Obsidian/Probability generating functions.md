---
tags:
  - MT2504
  - MT4528
  - MT3507
type: def
aliases:
  - pgf
---
Let $X$ be a discrete [[Random variables|random variable]] taking non-negative integer values with [[Probability mass function|pmf]] $p_{x} = \mathbb{P}(X=x)$.

>[!def] Definition
>A probability generating function is the generating function of the [[Probability mass function|pmf]] of a discrete [[Random variables|random variable]].
>It is a [[power series]] representation of the [[Probability mass function|pmf]]:
>$$G_{X}(s)=\mathbb{E}(s^{X})=\sum\limits_{x=0}^{\infty}s^{x}p_{x}.$$