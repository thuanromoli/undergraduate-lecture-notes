---
tags:
  - MT3502
aliases:
  - contraction
---
Let $(X,d)$ be a [[Metric spaces|metric space]].

> [!def] Definition
> A [[Functions|function]] $f:X \to X$ is a contraction if there exists a constant $0<c<1$ such that
> $$d\Big(f(x),f(y)\Big) \leqslant c \; d(x,y) \qquad \text{for all }x,y \in X.$$
