---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is called an autoregressive moving average process of order $(p,q)$ if it is [[Stationarity|weakly stationary]] and there exists a [[White noise|white noise]] $(\varepsilon_{t})_{t \in \mathbb Z}$ and real numbers $\phi,...,\phi_{p} \text{ and }\theta_{1},...,\theta_{q} \in \mathbb R$ with $\phi+ \theta\neq 0$ such that the AR polynomial
> $$\varphi(z)=1-\phi_{1}z-\cdots-\phi_{p}z^{p}$$
> and the MA polynomial
> $$\vartheta(z)= 1+\theta_{1}z+\cdots +\theta_{q}z^{q}$$
> have no common complex roots and for all $t \in \mathbb Z$,
> $$X_{t}= \phi_{1} X_{t-1}+\cdots+\phi_{p}X_{t-p}+\varepsilon_{t}+\theta_{1} \varepsilon_{t-1}+ \cdots + \theta_{q} \varepsilon_{t-q}$$
> or alternatively
> $$\varphi(B)X_{t}=\vartheta(B)\varepsilon_{t}.$$
> 
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is an autoregressive moving average process of order $(p,q)$ with mean $\mu$ if $X_{t}-\mu$ is an ARMA($p,q$) process.

> [!thm] Properties (under certain [[Stationarity of AR(p) Processes|regularity conditions]])
> - The ACF mimics that of an AR($p$) process (though only after $q-p$ lags when $q \geqslant p$).
> - The PACF mimics that of on MA($q$) process (though only after $p-q$ lags when $p \geqslant q$).

> [!gen] Remarks
> - The requirement $\varphi(z)$ and $\vartheta(z)$ have no common roots ensures that the process is written in its simplest form.
> - If all the roots of $\varphi(z)$ lie outside the unit circle, we can find a [[Causality|causal]], [[Stationarity|weakly stationary]] process. That is, the ARMA process has an [[MA(inf) Process|MA(inf)]] representation and we write $\varphi^{-1}(z) = \sum\limits_{i=0}^{\infty}\psi_{i}z^{i}$.
> - If all the roots of $\vartheta(z)$ lie outside the unit circle, the process is [[Invertibility|invertible]] with respect to $(\varepsilon_{t})_{t \in \mathbb Z}$. That is, the ARMA process has an [[AR(p) Process|AR(inf)]] representation and we write $\vartheta^{-1}(z) = \sum\limits_{i=0}^{\infty}\pi_{i}z^{i}$.

