---
tags:
  - MT4003
aliases:
  - stabiliser
---
Let $G$ be a [[Groups|group]] [[Group actions|acting]] on a non-empty set $X$ and let $x \in X$.

> [!def] Definition
> The stabiliser of $x$ in $G$ is
> $$G_{x} = \set{g \in G : x^{g} = x}$$

> [!thm] Theorem
> The stabiliser of $x$ in $G$ is a [[Subgroups|subgroup]] of $G$.
> 
> Proof: book-work, omitted.

^5bb31b

