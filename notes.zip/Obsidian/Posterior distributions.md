---
tags:
  - MT3507
aliases:
  - posterior
---
Let $\boldsymbol{\theta}$ be a parameter of a distribution which we want to estimate.

> [!def] Definition
> The posterior distribution (or posterior) of $\boldsymbol{\theta}$ is the distribution of $(\boldsymbol{\theta}\;|\;\mathbf{x})$ obtained after observing the data.
> 
> The posterior is based on the [[Prior distributions|prior]], and is obtained using [[Bayes' Theorem]].
> 
> The pdf/pmf of the posterior is $\pi(\boldsymbol{\theta}|\mathbf{x})$.
