---
tags:
  - MT4551
aliases:
  - diffusion equation
---
Consider a large number of particles, each following a [[Particles random walk - standard settings|random walk]].

> [!thm] Theorem
> The diffusion equation is 
> $$\frac{\partial \rho}{\partial t}= D\frac{\partial^{2}p}{\partial x^{2}}$$
> where $D=\frac{1}{2} \frac{\sigma^{2}_{v}}{t}$

> [!thm] Derivation
> We define, in one dimension, $\rho(x,t)$ to be the density of particles at time $t$ and position $x$. In other words, the number of particles per unit length at $(x,t)$.
> 
> We wish to investigate how $\rho$ changes with time.
> $$\rho(x, t+ \Delta t)=\int_{-\infty}^{\infty} \rho(x-\Delta x ,t) \mathbb P(\Delta x, \Delta t)d(\Delta x)$$
> where $\mathbb P(\Delta x, \Delta t)$ is the probability of a jump of size $\Delta x$ in time $\Delta t$ integrated over all possible jumps $d(\Delta x)$.
> 
> We assume $\Delta x$ and $\Delta t$ to be small and we use a [[Taylor's Theorem|Taylor expansion]] to simplify the right and left hand side of the equation. We start with the right hand side.
> $$\rho( x - \Delta x) = \rho(x,t) - \frac{\partial \rho(x,t)}{\partial x} \Delta x + \frac{1}{2} \frac{\partial ^{2} p(x,t)}{\partial x} \Delta x^{2}-\ldots$$
> So by substituting into the integral, we obtain
> $$\begin{align*}
   \rho(x, t+ \Delta t) &= \rho(x,t) \int_{-\infty}^{\infty} \mathbb P(\Delta x, \Delta t) d(\Delta x)\\
   &- \frac{\partial p}{\partial x} \int_{-\infty}^{\infty} (\Delta x) \mathbb P(\Delta x, \Delta t) d(\Delta x)\\
   &+ \frac{1}{2}\frac{\partial^{2} p}{\partial x^{2}} \int_{-\infty}^{\infty} (\Delta x)^{2} \mathbb P(\Delta x, \Delta t) d(\Delta x)
   \end{align*}$$
> where we recall $\mathbb P(x)$ is the [[Probability density function|pdf]] of a normal distribution and so
> - The first integral is equal to 1 by the honesty condition.
> - The second integral is the expectation of $\Delta x$, which is 0.
> - The third integral is the variance of $\Delta x$, which is $2D \Delta t$ (see [[Particles random walk - time dependant process|here]]).
> 
> Hence
> $$\rho(x,t+\Delta t) = \rho(x,t) + D \Delta t \frac{\partial^{2}p}{\partial x^{2}}.$$
> What we are left to do now is to [[Taylor's Theorem|Taylor expand]] the LHS:
> $$\rho(x,t + \Delta t) = \rho(x,t) + \frac{\partial \rho}{\partial t} \Delta t + \ldots$$
> And finally,
> $$\begin{align*}
   &\rho(x,t) + \frac{\partial \rho}{\partial t} \Delta t =\rho(x,t) + D \Delta t \frac{\partial^{2}p}{\partial x^{2}}\\
   \implies & \frac{\partial \rho}{\partial t} \Delta t = D \Delta t \frac{\partial^{2}p}{\partial x^{2}}\\
   \implies & \frac{\partial \rho}{\partial t}= D\frac{\partial^{2}p}{\partial x^{2}}
   \end{align*}$$
   that is, the diffusion equation with diffusion coefficient $D=\frac{1}{2} \frac{\sigma^{2}_{v}}{t}$.
