---
tags:
  - MT3501
type: 
aliases:
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Inner product spaces|inner product space]] with inner product $\langle \cdot , \cdot \rangle$.
Let $T:V\to V$ be a [[Linear transformations|linear transformation]].

>[!thm]- The [[Adjoint of a transformation|adjoint]] $T^{*}$ of a [[Linear transformations|linear transformation]] exists, is unique, and is a linear transformation
>Firstly, we show that if $T^{*}$ exists, then it is unique.
>Suppose that $S: V\to V$ is also an adjoint of $T$. Then
>$$\begin{align*}
   &\;\;\;\;\;\;\;\;\;\;\langle v,T^{*}(w) \rangle= \langle T(v),w \rangle = \langle v, S(w) \rangle \;\;\forall v,w \in V\\
   &\iff \langle v,T^{*}(w) \rangle-\langle v,S(w) \rangle=0\\
   &\iff \langle v,T^{*}(w)-S(w) \rangle = 0
   \end{align*}$$
>Let us fix $w\in V$ and take $v=T^{*}(w)-S(w)$. Then
>$$\langle T^{*}(w)-S(w),T^{*}(w)-S(w)  \rangle=0$$
>And by the axioms of an inner product space, $T^{*}(w)-S(w)=\boldsymbol{0}$.
>So $S(w)=T^{*}(w)$ for all $w\in V$.
>
>Now it remains to show that such a linear map $T^{*}$ actually exists.
>Let $\mathscr B=\set{e_{1},...,e_{n}}$ be an [[Orthogonality|orthonormal]] [[Bases|basis]] for $V$. The [[Gram-Schmidt process]] guarantees that this exists.
>Let $A=[\alpha_{ij}]=\text{Mat}_{\mathscr B,\mathscr B}(T)$ be the matrix of $T$ with respect to $\mathscr B$.
>Let $T^{*}:V\to V$ be the linear map defined by $\bar A^{\mathsf T}=[\overline \alpha_{ji}]$. Thus
>$$T^{*}(e_{j})=\sum\limits_{i=1}^{n}\overline\alpha_{ji}e_{i} \;\text{ for }j=1,2,...,n$$
>$$T(e_{j})=\sum\limits_{i=1}^{n}\alpha_{ij}e_{i} \;\text{ for }j=1,2,...,n$$
>Claim: $\langle T(v),w \rangle=\langle v,T^{*}(w) \rangle$ for all $v,w\in V$.
>Write $v=\sum\limits_{j=1}^{n}\beta_{j}e_{j}$ and $w=\sum\limits_{k=1}^{n}\gamma_{k}e_{k}$ in terms of the basis $\mathscr B$. Then
>$$\begin{align*}
   \langle T(v),w \rangle &= \Big\langle T\left(\sum\limits_{j=1}^{n}\beta_{j}e_{j}\right),\sum\limits_{k=1}^{n}\gamma_{k}e_{k}\Big\rangle\\
   &= \Big \langle \sum\limits_{j=1}^{n}\beta_{j}T(e_{j}),\sum\limits_{k=1}^{n}\gamma_{k}e_{k} \Big \rangle\\
   &= \Big \langle \sum\limits_{j=1}^{n}\beta_{j}\sum\limits_{i=1}^{n}\alpha_{ij}e_{i},\sum\limits_{k=1}^{n}\gamma_{k}e_{k} \Big \rangle\\
   &= \sum\limits_{j=1}^{n} \sum\limits_{i=1}^{n} \sum\limits_{k=1}^{n} \beta_{j} \alpha_{ij} \overline \gamma_{k} \langle e_{i},e_{k} \rangle\\
   &= \sum\limits_{j=1}^{n} \sum\limits_{i=1}^{n} \beta_{j} \alpha_{ij} \overline \gamma_{i}
   \end{align*}$$
>$$\begin{align*}
   \langle v,T^{*}(w) \rangle &= \Big\langle \sum\limits_{j=1}^{n}\beta_{j}e_{j},T^{*}\left(\sum\limits_{k=1}^{n}\gamma_{k}e_{k}\right)\Big\rangle\\
   &= \Big\langle \sum\limits_{j=1}^{n}\beta_{j}e_{j},\sum\limits_{k=1}^{n}\gamma_{k}T(e_{k})\Big\rangle\\
   &= \Big\langle \sum\limits_{j=1}^{n}\beta_{j}e_{j},\sum\limits_{k=1}^{n}\gamma_{k}\sum\limits_{i=1}^{n}\overline\alpha_{ki}e_{i}\Big\rangle\\
   &= \sum\limits_{j=1}^{n}\sum\limits_{k=1}^{n}\sum\limits_{i=1}^{n}\beta_{j}\overline\gamma_{k} \alpha_{ki} \langle e_{j},e_{i} \rangle\\
   &= \sum\limits_{j=1}^{n}\sum\limits_{k=1}^{n}\beta_{j}\overline\gamma_{k} \alpha_{kj}
   \end{align*}$$
>The two above expressions are identical but with $i$ and $k$ swapped.
>Hence $T^{*}$ is indeed the adjoint of $T$.

>[!thm]- If $A=\text{Mat}_{\mathscr B,\mathscr B}(T)$ is the matrix of the linear map $T:V\to V$ with respect to an orthonormal basis $\mathscr B$ for $V$, then $\text{Mat}_{\mathscr B,\mathscr B}(T^{*})= \bar A^{\mathsf{T}}$
>Proof: see above theorem

^b48005

