---
tags:
  - MT3501
type: thm
aliases:
---
Let $V=U_{1} \oplus U_{2}$ be a [[Direct sums|direct sum]] of [[Subspaces|subspaces]] with [[Projection maps|projection maps]] $P_{1}:V\to V$ and $P_{2}:V\to V$.

>[!thm]- $P_{1}$ and $P_{2}$ are [[Linear transformations|linear transformations]].
>Let $u,v\in V$. Then we can expressed $u=u_{1}+u_{2}$ and $v=v_{1}+v_{2}$ where $u_{1},v_{1}\in U_{1}$ and $u_{2},v_{2}\in U_{2}$.
>Hence $P_{1}(u+v)=P_{1}(u_{1}+u_{2}+v_{1}+v_{2})$ = $(u_{1}+v_{1})$ = $P_{1}(u)+P_{1}(v)$.
>Let $\alpha \in F$ then $P_{1}(\alpha v)=P_{1}(\alpha (v_{1}+v_{2}))$ = $P_{1}(\alpha v_{1} + \alpha v_{2})$ = $\alpha v_{1}=\alpha P_{1}(v)$.
>So $P_{1}$ is a linear transformation and a similar argument applies for $P_{2}$.

>[!thm]- $P_{1}(u)=u \;\;\forall u\in U_{1}$ and $P_{1}(w)=\boldsymbol{0} \;\;\forall w\in U_{2}$
>Note that $u=u+\boldsymbol{0}$ and $w=\boldsymbol{0}+w$.
>Hence $P_{1}(u+\boldsymbol{0})=u$ and $P_{1}(\boldsymbol{0}+w)=\boldsymbol{0}$.

>[!thm]- $P_{2}(u)=\boldsymbol{0} \;\;\forall u\in U_{1}$ and $P_{1}(w)=w \;\;\forall w\in U_{2}$
>Similar as above

>[!thm]- $\ker P_{1}=U_{2}$ and $\text{im }P_{1}=U_{1}$
>For any vector $v$, $P_{1}(v)$ is the $U_{1}$ part of the decomposition, so $\text{im }P_{1}\subseteq U_{1}$. On the other hand, if $u\in U_{1}$ then $u=P_{1}(u)\in \text{im }P_{1}$. Hence $\text{im }P_{1}=U_{1}$
>Now, $P_{1}(w)=\boldsymbol{0}$ for all $w\in U_{2}$, so $U_{2} \subseteq \ker P_{1}$. On the other hand, if $v=u_{1}+u_{2}$ lies in $\ker P_{1}$, then $P_{1}(v)=u_{1}=\boldsymbol{0}$, so $v=u_{2}\in U_{2}$. Hence $\ker P = U_{2}$.

>[!thm]- $\ker P_{2}=U_{1}$ and $\text{im }P_{2}=U_{2}$
>Similar as above

WLOG, let $P_{1}=P$ (hence applies to $P_{2}$ as well).

>[!thm]- $P^{2}=P$
>If $v=u_{1}+u_{2}\in V$, then $P^{2}(v)=P(P(v))=P(P(u_{1}+u_{2}))$ = $P(u_{1})$ = $u_{1}$ = $P(v)$

>[!thm]- $V=\ker P \oplus \text{im }P$
>Note: $\ker P=U_{2}$ and $\text{im }P=U_{1}$.
>Hence $V=U_{1} \oplus U_{2}=\ker P \oplus \text{im }P$

>[!thm]- $I-P$ is also a projection
>Let $Q:V\to V$ denote a projection onto $U_{2}$. If $v=u_{1}+u_{2}\in V$, then $Q(v)=u_{2}=v-u_{1}=v-P(v)=(I-P)(v)$.
>Hence $(I-P)$ is also a projection.

>[!thm]- $V=\ker P \oplus \ker (I-P)$
>Note: $\ker P=U_{2}$ and $\ker(I-P)=\ker Q=U_{1}$
>Hence $V=U_{1} \oplus U_{2}=\ker P \oplus \ker (I-P)$

---

#### Spaced repetition

Prove that the projection maps $P_{1}$ and $P_{2}$ are [[Linear transformations|linear transformations]].
?
>Let $u,v\in V$. Then we can expressed $u=u_{1}+u_{2}$ and $v=v_{1}+v_{2}$ where $u_{1},v_{1}\in U_{1}$ and $u_{2},v_{2}\in U_{2}$.
>Hence $P_{1}(u+v)=P_{1}(u_{1}+u_{2}+v_{1}+v_{2})$ = $(u_{1}+v_{1})$ = $P_{1}(u)+P_{1}(v)$.
>Let $\alpha \in F$ then $P_{1}(\alpha v)=P_{1}(\alpha (v_{1}+v_{2}))$ = $P_{1}(\alpha v_{1} + \alpha v_{2})$ = $\alpha v_{1}=\alpha P_{1}(v)$.
>So $P_{1}$ is a linear transformation and a similar argument applies for $P_{2}$.

Prove that $P_{1}(u)=u \;\;\forall u\in U_{1}$ and $P_{1}(w)=\boldsymbol{0} \;\;\forall w\in U_{2}$
?
>Note that $u=u+\boldsymbol{0}$ and $w=\boldsymbol{0}+w$.
>Hence $P_{1}(u+\boldsymbol{0})=u$ and $P_{1}(\boldsymbol{0}+w)=\boldsymbol{0}$.

Prove that $\ker P_{1}=U_{2}$ and $\text{im }P_{1}=U_{1}$.
?
>For any vector $v$, $P_{1}(v)$ is the $U_{1}$ part of the decomposition, so $\text{im }P_{1}\subseteq U_{1}$. On the other hand, if $u\in U_{1}$ then $u=P_{1}(u)\in \text{im }P_{1}$. Hence $\text{im }P_{1}=U_{1}$
>Now, $P_{1}(w)=\boldsymbol{0}$ for all $w\in U_{2}$, so $U_{2} \subseteq \ker P_{1}$. On the other hand, if $v=u_{1}+u_{2}$ lies in $\ker P_{1}$, then $P_{1}(v)=u_{1}=\boldsymbol{0}$, so $v=u_{2}\in U_{2}$. Hence $\ker P = U_{2}$.

Prove that $P^{2}=P$.
?
>If $v=u_{1}+u_{2}\in V$, then $P^{2}(v)=P(P(v))=P(P(u_{1}+u_{2}))$ = $P(u_{1})$ = $u_{1}$ = $P(v)$

Prove that $V=\ker P \oplus \text{im }P$.
?
>Note: $\ker P=U_{2}$ and $\text{im }P=U_{1}$.
>Hence $V=U_{1} \oplus U_{2}=\ker P \oplus \text{im }P$

Prove that $I-P$ is also a projection.
?
>Let $Q:V\to V$ denote a projection onto $U_{2}$. If $v=u_{1}+u_{2}\in V$, then $Q(v)=u_{2}=v-u_{1}=v-P(v)=(I-P)(v)$.
>Hence $(I-P)$ is also a projection.

Prove that $V=\ker P \oplus \ker (I-P)$.
?
>Note: $\ker P=U_{2}$ and $\ker(I-P)=\ker Q=U_{1}$
>Hence $V=U_{1} \oplus U_{2}=\ker P \oplus \ker (I-P)$
