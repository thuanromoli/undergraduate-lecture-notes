---
tags:
  - MT2502
aliases:
---
Let $a<b$ and $f:[a,b] \to \mathbb R$ be a [[Continuity|continuous]] [[Functions|function]].

> [!thm] Theorem
> 1. $f$ is [[Boundedness|bounded]].
> 2. $f$ attains its maximum, i.e. there exists $x_{0} \in [a,b]$ s.t. $f(x) \leqslant f(x_{0})$ for all $x \in [a,b]$.
> 3. $f$ attains its minimum, i.e. there exists $y_{0} \in [a,b]$ s.t. $f(x) \geqslant  f(y_{0})$ for all $x \in [a,b]$.
