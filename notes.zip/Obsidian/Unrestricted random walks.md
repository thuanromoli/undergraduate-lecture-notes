---
tags:
  - MT4528
type: model
aliases:
---
>[!gen] Preamble (assumed to be true)
>Consider the [[n-step transition probabilities]] $p_{ij}(n)$ and the [[The first passage probability|first passage probabilities]] $f_{ij}(n)$.
>Let $\mathbb{P}_{ij}(s)=\sum\limits_{n=0}^{\infty}p_{ij}(n)s^{n}$ and $\mathbb{F}_{ij}(s)=\sum\limits_{n=1}^{\infty}f_{ij}(n)s^{n}$ be the generating functions of $p_{ij}(n)$ and $f_{ij}(n)$ respectively.
>Note that:
>(i) $p_{ij}=\delta_{ij}$ where $\delta_{ij}=1$ if $i=j$ and $\delta_{ij}=0$ if $i\neq j$ (Kronecker delta function)
>(ii) in general, these are not [[Probability generating functions|pgfs]].
>(iii) $\mathbb{}{F}_{ii}(s)$ is a [[Probability generating functions|pgf]] if $i$ is a [[Recurrent states|recurrent]] state.
>
>>[!thm] Theorem
>>$\mathbb{P}_{ij}(s)=\delta_{ij}+\mathbb{F}_{ij}(s)\mathbb{P}_{jj}(s)$
>>Proof: omitted

>[!gen] Standard setting
>Consider a [[1-D Random walks|random walk]] with no boundaries, where we start at $0$ but there is no state which stops the walk:
>$X_{0}=0$, $X_{t}=X_{t-1}+Z_{t}$ for $t \geqslant 1$ where
>$$Z_{t}=\begin{cases}
   1 & \text{with probability }p \\
   -1 & \text{with probability }q=1-p
   \end{cases}$$

>[!thm] Proposition
>Let $f_{0}(n)=f_{00}(n)$ and $p_{0}(n)=p_{00}(n)$ with generating functions $\mathbb{F}_{0}(s)$ and $\mathbb{P}_{0}(s)$ respectively. Further note that:
>(i) $f_{0}(n)=\mathbb{P}(X_{1}\neq 0,...,x_{n}=0|X_{0}=0)=\mathbb{P}(X_{1}\neq 0,...,X_{n}=0)$ since we assume that $X_{0}=0$ globally.
>(ii) similarly $p_{0}(n)=\mathbb{P}(X_{n}=0|X_{0}=0)=\mathbb{P}(X_{n}=0)$.
>
>The theorem is the following:
>- $\mathbb{P}_{0}(s)=1+\mathbb{P}_{0}(s)\mathbb{F}_{0}(s)$
>- $\mathbb{P}_{0}(s)=(1-4pqs^{2})^{-\frac{1}{2}}$
>- $\mathbb{F}_{0}(s)=1-(1-4pqs^{2})^{\frac{1}{2}}$
>  
>Proof:
>(i) This is the theorem in the preamble where $i=j=0$.
>
>(ii) Firstly note that $X_{n}\neq 0$ for $n$ odd as the random walk cannot return to the origin in an odd number of steps. In addition:
>$X_{2m}=0$ $\iff$ half of the $Z_{1},...,Z_{2m}$ are $+1$ and half of them are $-1$.
>The number of $Z_{i}$'s that are $+1$ has a [[Binomial distributions|binomial distribution]] $Bin(2m,p)$. Thus,
>$$\mathbb{P}(X_{2m}=0)=\mathbb{P}(\text{num. of }Z_{i} \text{ are} +1 = m)={2m \choose m}p^{m}q^{m}$$
>Then the generating function is given by
>$$\begin{align*}
   \mathbb{P}_{0}(s) &= \sum\limits_{n=0}^{\infty} p_{0}(n)s^{n}\\
   &= \sum\limits_{m=0}^{\infty} p_{0}(2m)s^{2m}\\
   &= \sum\limits_{m=0}^{\infty} {2m \choose m} (pqs^{2})^{m}\\
   &= (1-4pqs^{2})^{-\frac{1}{2}}
   \end{align*}$$
>
>(iii) This is obtained by re-arranging the result in (i).

>[!thm] Corollary
>- The probability that the unrestricted random walk ever returns to $0$ given that $X_{0}=0$ is given by
>$$f_{0}=\begin{cases}
   2q & \text{if } p > q \\
   2p & \text{if } p < q \\
   1 & \text{if } p = q
   \end{cases}$$
>- For $p=q$, all integers correspond to [[Recurrent states|null recurrent]] states.
>
>Proof:
>(i) Note that $f_{0}=\sum\limits_{n=1}^{\infty}f_{0}(n)=\mathbb{F}_{0}(1)=1-(1-4pq)^{\frac{1}{2}}$.
>Then by using $p=1-q$ we get $1-4pq=(p-q)^{2}$.
>Thus, $f_{0}=1-((p-q)^{2})^{- \frac{1}{2}}=1-|p-q|$.
>
>(ii) To show that a state is [[Recurrent states|null recurrent]] we need to show that its [[Recurrence time|mean recurrence time]] is infinite. Let $T$ denote the time of first return.
>Then recall that $\mathbb{P}(T=n)=f_{0}(n)$ and the [[Probability mass function|pmf]] is $\set{f_{0}(n):n=1,2,...}$.
>We know that the [[Probability generating functions|pgf]] of $T$ is $\mathbb{F}_{0}(s)=1-(1-s^{2})^{\frac{1}{2}}$ and therefore $\mathbb{E}(T)=\mathbb{F}'_{0}(1)=\lim\limits_{s\to 1^{-}} \frac{s}{\sqrt{1-s^{2}}}=\infty$
