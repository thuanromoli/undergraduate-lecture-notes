---
tags:
  - MT4531
aliases:
---
Let $\mathbf{x}$ be an observed sample. Let $\mathbf{Y}$ be a random vector of future observations from the same process. Assume that conditional on $\theta$ in the process, $\mathbf{X}$ and $\mathbf{Y}$ are independent.

> [!def] Definition
> The posterior predictive distribution of $\boldsymbol{X}$. That is,
> $$f(\mathbf{y}|\mathbf{x})=\int_{\theta \in  \Theta}^{}f(\mathbf{y},\theta|\mathbf{x})\;d \theta=\int_{\theta \in \Theta}^{}f(\mathbf{y}|\mathbf{x},\theta)\pi(\theta|\mathbf{x})\;d \theta=\int_{\theta \in \Theta}^{}f(\mathbf{y}|\theta)\pi(\theta|\mathbf{x}).$$

> [!gen] Remarks
> - We use this when we already have observed data.
> - We are weighting the likelihood $f(\mathbf{y}|\theta)$ with the best description of our beliefs for $\theta$.
