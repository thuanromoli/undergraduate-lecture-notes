---
tags:
  - MT4528
  - MT4527
aliases:
  - state space
---
Let $\set{X(t):t\in T}$ be a [[Stochastic processes|stochastic process]].

>[!def] Definition
>The state space is the set of possible values of $X(t)$
