---
tags:
  - MT4003
aliases:
  - normaliser
---
Let $G$ be a [[Groups|group]], and let $H$ be a [[Subgroups|subgroup]] of $G$.

> [!def] Definition
> The normaliser of $H$ in $G$ is denoted $N_{G}(H)$, and it is the set
> $$N_{G}(H) = \set{g \in G : H^{g} = H}.$$
