---
tags:
  - MT2502
  - MT3503
aliases:
---
#### For real analysis:
Let $\sum\limits_{n=0}^{\infty}a_{n}x^{n}$ be a [[Power series|power series]].

> [!def] Definition
> Label, using the [[The ratio test|ratio test]] or the [[The root test|root test]], $\lim\limits_{n \to \infty}|a_{n}|^{\frac{1}{n}} = \lim\limits_{n \to \infty} \left |\frac{a_{n+1}}{a_{n}} \right| = \beta$.
> The radius of converges is defined as $R = \frac{1}{\beta}$.

> [!thm] Theorem
> The power series [[Convergence|converges]] for $|x| < R$ and diverges for $|x| > R$.

> [!thm] [[Integration and differentiation of power series]]
> The power series is [[Continuity|continuous]], [[Differentiability|differentiable]], and [[Integrability|integrable]] at every $|x|<R$.
> Moreover, the latter power series has the same radius of convergence $R$ as the original series.

Proof:
Consider the sequence $(b_{n})_{n} = (a_{n}x^{n})_{n}$ and the series that it generates $\sum\limits_{n=0}^{\infty}b_{n}$ (i.e. our power series).
Then by the ratio test, the series converges if there exists an $r<1$ such that
$$\begin{align*}
&\lim\limits_{n \to \infty} \left |\frac{b_{n+1}}{b_{n}} \right|<r\\
\iff&\lim\limits_{n \to \infty} \left |\frac{b_{n+1}}{b_{n}} \right|<1\\
\iff&\lim\limits_{n \to \infty} \left |\frac{a_{n+1}x^{n+1}}{a_{n}x^{n}} \right|<1\\
\iff&\lim\limits_{n \to \infty} \left |\frac{a_{n+1}x}{a_{n}} \right|<1\\
\iff& |x|\lim\limits_{n \to \infty} \left |\frac{a_{n+1}}{a_{n}} \right|<1\\
\iff& |x|\beta<1\\
\iff& |x| < \frac{1}{\beta}=R\\
\end{align*}$$

#### For complex analysis:
Let $f(z) = \sum\limits_{n=0}^{\infty}c_{n}(z-a)^{n}$ be a complex [[Power series|power series]].

> [!def] Definition
> Label, using the [[The ratio test|ratio test]] $\lim\limits_{n \to \infty} \frac{|c_{n+1}|}{|c_{n}|} = \beta$.
> The radius of converges is defined as $R = \frac{1}{\beta}=\lim\limits_{n \to \infty}\left|\frac{c_{n}}{c_{n+1}}\right|$.

> [!thm] Theorem
> The power series $f(z)$ converges absolutely for $|z-a|<R$ and diverges for $|z-a|>R$.

> [!gen] Remarks
> 1. If $R=0$ then the series only converges at $z=a$.
> 2. If $R= \infty$ then the series converges for all $z \in \mathbb C$.
> 3. "The power series $f(z)$ converges absolutely" means $\sum\limits_{n=0}^{\infty}|c_{n}(z-a)^{n}|$ is convergent.
> 4. If $\sum\limits_{n=0}^{\infty}|c_{n}(z-a)^{n}|$ is convergent then $f(z)$ is convergent.

> [!thm] Theorem
> The power series is differentiable at every $z$ satisfying $|z-a|<R$ with derivative
> $$f'(z) = \sum\limits_{n=1}^{\infty}nc_{n}(z-a)^{n-1}.$$
> Moreover, the latter power series has the same radius of convergence $R$ as the original series.
