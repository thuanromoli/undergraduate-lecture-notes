---
tags:
  - MT4003
aliases:
---
Let $G$ be a [[Groups|group]] and $Z(G)$ be its [[The centre|centre]].

> [!thm]- $Z(G)$ is a [[Normal subgroups|normal]] [[Subgroups|subgroup]] of $G$
> Firstly, we show that $Z(G)$ is a subgroup.
> We note that for all $g \in G$, $1g=g=g1$ so $1 \in Z(G)$, in particular it's non-empty.
> Then let $x,y \in Z(G)$. Then $gxy =xgy=gxy \;\;\forall g \in G$, so $xy \in Z(G)$.
> And finally right multiplying $xg=gx$ by $x^{-1}$ gives $xgx^{-1}=gxx^{-1} \implies xgx^{-1}=g \implies gx^{-1}=x^{-1}g\;\;\forall g \in G$, so $x^{-1} \in Z(G)$.
> 
> Now we show that $Z(G)$ is normal.
> If $x \in Z(G), g \in G$, then $x^{g} = g^{-1}xg =g^{-1}gx=1x=x \in Z(G)$.

> [!thm]- $G$ is [[Abelian groups|abelian]] if and only if $Z(G) = G$.
> True by definition.

> [!thm]- An element $x$ lies in a conjugacy class of size 1 if and only if $x \in Z(G)$
> Let $x^{G}$ be a conjugacy class of size 1.
> Then it must be that $x^{G}= \set{x^{g}:g \in G}=\set{x^{g}}$ such that for all (and hence the only one) elements $x \in x^{G}$, $x = x^{g}$ for all $g \in G$.
> In other words, an element $x$ has one conjugate if and only if $x^{g}=x$ for all $g \in G$.
> That is, $xg=gx$ for all $g \in G$.
> That is, $x \in Z(G)$.

^55ac96
