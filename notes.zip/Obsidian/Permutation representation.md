---
tags:
  - MT4003
aliases:
---
Let $G$ be a group and $S_{X}$ be a [[The symmetric group|symmetric group]]. 

> [!def] Definition
> A permutation representation is a [[Homomorphisms|homomorphism]] from $G$ to $S_{X}$.

> [!thm] Group actions are permutations representations
> If $G$ is [[Group actions|acting]] on $X$, then the mapping
> $$\begin{align*}
   \phi : G &\to S_{X}\\
   g &\mapsto \rho_{g} \text{ where }x \rho_{g}=x^{g}\;\;\forall x \in X,\;\forall g \in G
   \end{align*}$$
> is a homomorphism from $G$ to $S_{X}$.

> [!thm] Permutations representations are group actions 
> If $\phi : G \to S_{X}$ is a homomorphism, then the mapping
> $$\begin{align*}
   X \times G &\to X\\
   (x,g) &\mapsto x(g \phi) \text{ where }x \rho_{g}=x^{g}\;\;\forall x \in X,\;\forall g \in G
   \end{align*}$$
> is an action of $G$ to $X$

Proof 1: suppose that $G$ is acting on $X$.
$\phi$ is a valid map.
We want to show that $\rho_{g}$ is always a permutation of $X$. That is, $\rho_{g}$ is a bijection $X \to X$.
For all $x \in X$
$$\begin{align*}
(x\rho_{g})\rho_{g^{-1}} &= (x^{g})^{g^{-1}}\\
&= x^{gg^{-1}}\\
&= x^{1}\\
&=1.
\end{align*}$$
Hence $\rho_{g}\rho_{g^{-1}}$ is equal to the identity permutation in $S_{X}$. Similarly, $\rho_{g^{-1}}\rho_{g}=1_{S_{X}}$, and so $\rho_{g}$ is invertible. Therefore $\rho_{g}$ is a bijection from $X \to X$. So $\phi$ does indeed map $G$ to $S_{X}$,

$\phi$ is a homomorphism.
$$\begin{align*}
x((g \phi)(h \phi)) &= x(\rho_{g}\rho_{h})\\
&= (x \rho_{g})\rho_{h}\\
&= (x^{g})^{h}\\
&= x^{gh}\\
&= x \rho_{gh}\\
&= x((gh )\phi).
\end{align*}$$

Proof 2: suppose that $\phi:G\to S_{X}$ is a homomorphism.
We check group action axioms.
A1: $x^{1_{G}}=x(1_{G}\phi)=x(1_{S_{X}})=x$ for all $x \in X$.
A2: $(x^{g})^{h} = x((g \phi)(h \phi)) = x((gh)\phi) = x^{gh}$.
