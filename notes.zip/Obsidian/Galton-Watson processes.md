---
tags:
  - MT4528
type: def
aliases:
  - Galton-Watson process
---
Let $X_{n}$ be the number of individuals in generation $n$ and let $Z_{i}^{(n)}$ be the number of offsprings of individual $i$ at generation $n$.
Suppose that each individual produces $k$ offsprings with probability $p_{k}$ ($k=0,1,...$).

>[!def] Definition
>A Galton-Watson process $\set{X_{n}:n=0,1,2,...}$ with offspring distribution $p_{k}$ ($k=0,1,...$) is a discrete-time [[Markov chains and processes|Markov chain]] taking values in $\mathbb{Z_{\geqslant 0}}$ such that the conditional distribution of $X_{n}$, given $X_{n-1}$, is the distribution of the sum of $X_{n-1}$ [[Random variables|random variables]], called offspring, each with [[Probability mass function|pmf]] $p_{k}$ ($k=0,1,...$).
>In other words, $X_{n}=\sum\limits_{i=1}^{X_{n-1}}Z_{i}^{(n-1)}$.
>The offspring counts in generation $n$ are mutually [[Independent events|independent]] and also independent of the offspring counts from earlier generations. Unless otherwise stated, we set $X_{0}=1$.
