---
tags:
  - MT3501
type: thm
aliases:
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $T:V\to V$ be a [[Linear transformations|linear transformation]].

>[!thm]- If $f(x)$ is any [[Polynomials|polynomial]] such that $f(T)=0$, then the [[Minimum polynomial|minimum polynomial]] $m_{T}(x)$ divides $f(x)$
>Suppose we divide $f(x)$ by $m_{T}(x)$. Then
>$$f(x)=m_{T}(x)q(x)+r(x)$$
>for some polynomials $q(x)$ and $r(x)$ with either $r(x)=0$ or $\deg r(x)<\deg m_{T}(x)$.
>Then $f(T)=0$ $\implies$ $m_{T}(T)q(T)+r(T)=0$ $\implies$ $r(T)=0$ since $m_{T}(T)=0$ by definition.
>Since $m_{T}$ has the smallest degree among the non-zero polynomials which vanish when $T$ is substituted, we conclude $r(x)=0$. Hence
>$$f(x)=m_{T}(x)q(x)$$
>that is, $m_{T}(x)$ divides $f(x)$.

>[!thm]- $m_{T}(x)$ divides $c_{T}(x)$
>This follows from combining the [[Cayley-Hamilton theorem]] and the above theorem.

>[!thm]- The roots of the [[Minimum polynomial|minimum polynomial]] and the roots of the [[Characteristic polynomials|characteristic polynomial]] coincide
>Suppose $\lambda$ is a root of $m_{T}(x)$, so $(x-\lambda)$ is a factor of $m_{T}(x)$. It then follows by the above theorem that $(x-\lambda)$ divides $c_{T}(x)$.
>
>Conversely suppose that $\lambda$ is a root of $c_{T}(x)$, so $\lambda$ is an [[Eigenvectors and Eigenvalues|eigenvalue]] of $T$.
>Hence there is an [[Eigenvectors and Eigenvalues|eigenvector]] ${v}\neq 0$ with eigenvalue $\lambda$ such that $T(v)=\lambda v$,
>$T^{2}(v)=T(T(v))=T(\lambda v)=\lambda T(v)=\lambda^{2}v$, and in general $T^{i}(v)=\lambda^{i}v \;\;\forall i\in \mathbb Z$.
>Suppose $m_{T}(x)=\sum\limits_{n=0}^{k}\alpha_{n}x^{n}$, $\alpha_{k}=0$.
>Then $m_{T}(T)=0$ $\implies$ $m_{T}(T)v=\boldsymbol{0}$ $\implies$
>$$\begin{align*}
   & m_{T}(T)=0\\
   \implies & m_{T}(T)v=\boldsymbol{0}\\
   \implies & \left(\sum\limits_{n=0}^{k}\alpha_{n}T^{n}\right)v=\boldsymbol{0}\\
   \implies & \sum\limits_{n=0}^{k}\alpha_{n}T^{n}(v)=\boldsymbol{0}\\
   \implies & \sum\limits_{n=0}^{k}\alpha_{n}\lambda^{n}v=\boldsymbol{0}\\
   \implies & \left(\sum\limits_{n=0}^{k}\alpha_{n}\lambda^{n}\right)v=\boldsymbol{0}\\
   \implies & m_{T}(\lambda)v=\boldsymbol{0}\\
   \end{align*}$$
>Since $v\neq \boldsymbol{0}$, we conclude $m_{T}(\lambda)=0$; i.e., $\lambda$ is a root of $m_{T}(x)$.

>[!thm]- $T$ is [[Diagonalisability|diagonalisable]] if and only if the [[Minimum polynomial|minimum polynomial]] $m_{T}(x)$ is a product of distinct linear factors
>See lecture notes.
