---
type: thm
tags:
  - MT2505
  - MT4003
---
Let $G$ be a [[Groups|group]].

>[!thm] Theorem
>The [[Inverse element|inverse]] of each element $x\in G$ is unique.

PROOF:
By contradiction assume that if there is an inverse for $*$ then it is not unique;
suppose that $a$ and $b$ are both inverses for $G$ and $a\ne b$;
Claim: $a=b$
(1) $x*a =a*x=e$ and (2) $x*b=b*x=e \ \ \forall x \in G$;
we calculate the product $a*x*b$:
multiplying (1) by $b$: $a*x =e$ $\implies$ $a*x*b=e*b$ $\implies$ $a*x*b=b$;
multiplying (2) by $a$: $x*b =e$ $\implies$ $a*x*b=a*e$ $\implies$ $a*x*b=a$;
since $a*x*b$ is uniquely defined by the [[Generalised Associative Law]], then $a=b$;
since this is a contradiction, if there is an inverse for $*$ then it is unique.