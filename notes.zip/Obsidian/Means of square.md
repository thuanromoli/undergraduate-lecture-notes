---
tags:
  - MT3508
aliases:
---
Recall that the [[Residual sum of squares|residual sum of squares]] is the [[Deviance and scaled deviance|deviance]].

> [!def] Within-group mean of square
> The within-group mean of square is
> $$\text{MS}_{W} = \frac{\text{SS}_{W}}{n-p} = \frac{D_{1}}{n-p}$$

> [!def] Between-groups mean of square
> The between-groups mean of square is
> $$\text{MS}_{B} = \frac{\text{SS}_{B}} {p-1}= \frac{D_{0} - D_{1}}{p-1}$$

> [!thm] $F$-statistic
> $$\begin{align*}
   F &= \frac{\text{MS}_{B}}{\text{MS}_{W}}\\
   &= \frac{\text{SS}_{B}/(p-1)}{\text{SS}_{W}/(n-p)}\\
   &= \frac{D_{0}-D_{1}/(p-1)}{D_{1}/(n-p)} \sim F_{p-1,n-p}
   \end{align*}$$
