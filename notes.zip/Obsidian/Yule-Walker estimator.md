---
tags:
  - MT4527
aliases:
---
Let $(X_{t})_{t \in \mathbb Z}$ be an [[AR(p) Process]] such that
$$X_{t}=\phi_{1} X_{t-1}+\cdots+\phi_{p}X_{t-p}+\varepsilon_{t}.$$

> [!def] Definition
> The Yule-Walker estimator $\widehat{\boldsymbol{\phi}}=(\widehat \phi_{1},...,\widehat \phi_{p})$ for the coefficients $\boldsymbol{\phi}=(\phi_{1},...,\phi_{p})$ are obtained by inserting $\widehat \rho_{X}(h),...,\widehat \rho_{X}(h-p)$ in place of $\rho_{X}(h),...,\rho_{X}(h-p)$ in the [[Yule-Walker equations]].

> [!thm] Theorem
> $\widehat{\boldsymbol{\phi}}=(\widehat \phi_{1},...,\widehat \phi_{p})$ is asymptotically efficient and we have
> $$\widehat{\boldsymbol{\phi}}\stackrel{\text{asy}}{\sim}N_{p}(\boldsymbol{\phi},\frac{\sigma^{2}_\varepsilon}{T}\boldsymbol{\Gamma}^{-1}_{p})$$
> where $\boldsymbol{\phi}=(\phi_{1},...,\phi_{p})$ and $\boldsymbol{\Gamma}_{p}=\big[\gamma_{X}(i-j)\big]_{i,j=1,...,p}$ is the $p \times p$ autocovariance matrix.

> [!thm] Theorem
> The consistent estimator of the white noise variance $\sigma^{2}_\varepsilon$ is
> $$\widehat{\sigma^{2}_\varepsilon} = \widehat \gamma_{X}(0)(1- \widehat{\boldsymbol{\phi}}^{T}\widehat{\boldsymbol{\rho}}_{p})$$
> where $\widehat{\boldsymbol{\rho}}_{p}=(\widehat \rho_{X}(1),...,\widehat \rho_{X}(p))^{T}$.
