---
tags:
  - MT4554
type: model
aliases:
---
>[!gen] Why are we studying this?
>This is to get familiar with notation, how to calculate payoffs, and investigated dominated strategies.

>[!def] Zero-sum games
>In a zero-sum game, any payoff gain to one player is precisely balanced by a loss to the other. In the case of a two-player game: $u_{1}(s_{1},s_{2})= - u_{2}(s_{2},s_{1})$ for all strategy profiles.
>
>![[2s2p0s_att.png|300]]

>[!gen]+ Model
>- $u_{1}(A,A)=u_{AA}$, $u_{2}(A,A)=-u_{AA}$, ...
>- $\sigma_{1}(A)=p_{1}$ and $\sigma_{1}(B)=(1-p_{1})$ hence $\sigma_{1} = (p_{1},(1-p_{1}))$
>- $\sigma_{2}(A)=p_{2}$ and $\sigma_{2}(B)=(1-p_{2})$ hence $\sigma_{2} = (p_{2},(1-p_{2}))$
>- $u_{1}(\sigma)=u_{1}(\sigma_{1},\sigma_{2})$ = $p_{1}p_{2}u_{AA}+p_{1}(1-p_{2})u_{AB}+(1-p_{1})p_{2}u_{BA}+(1-p_{1})(1-p_{2})u_{BB}$

>[!gen]+ Case 1: One strategy dominates the other one
>WLOG, let's assume that strategy $A$ dominates strategy $B$ for player 1.
>That is, $u_{AA}>u_{BA}$ and $u_{AB}>u_{BB}$ (case where $p_{1}=1$).
>The payoff for player 2 is $u_{2}(\sigma_{2},A)=p_{2}(u_{AB}-u_{AA})-u_{AB}$.
>Now, if $u_{AB}>u_{AA}$ then $u_{2}$ will grow proportionally to $p_{2}$ and since we want to maximise $u_{2},$ we will take $p_{2}=1$, this is strategy $A$.
>Otherwise the opposite argument holds.
>In conclusion if one strategy dominates the other for one player, then the solution for both players is to adopt a pure strategy.

>[!gen]+ Case 2: No strategy dominates for either player.
>WLOG, let's assume that strategy $u_{AA}>u_{BA}$. For no strategy to dominated we need $u_{AB}<u_{BB}$.
>For player 2 we need $u_{AA}>u_{AB}$ and $u_{BA}<u_{BB}$
>
>Let $f(p_{1},p_{2})$ = $p_{1}p_{2}u_{AA}+p_{1}(1-p_{2})u_{AB}+(1-p_{1})p_{2}u_{BA}+(1-p_{1})(1-p_{2})u_{BB}$ such that $u_{1}=f(p_{1},p_{2})$ and $u_{2}=f(p_{1},p_{2})$.
>
>Player 1 wants to (and is only able to) change $p_{1}$ to maximise $f(p_{1},p_{2})$.
>Player 2 wants to (and is only able to) change $p_{2}$ to minimise $f(p_{1},p_{2})$.
>This can only happen if the function $f(p_{1},p_{2})$ has a saddle point.
>(Proof and working out is omitted. See how to find a saddle point.)
