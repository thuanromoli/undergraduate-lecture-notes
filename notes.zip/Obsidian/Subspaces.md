---
tags:
  - MT2501
  - MT3501
type: def
aliases:
  - subspace
  - subspaces
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$.

>[!def] Definition 1
>A subspace of $V$ is a non-empty subset $W$ of $V$ which is itself a vector space under the [[Binary operations|binary operations]] of $V$.

>[!def] Definition 2
>$W$ is a subspace of $V$ if and only if 
>1. $W$ is a non-empty subset of $V$
>2. $W$ is closed under addition that is, if $v,w \in W$, then $v+w \in W$
>3. $W$ is closed under scalar multiplication that is, if $v \in W$ then $\alpha v \in W \;\;\forall \alpha \in F$

>[!thm] Theorem
>The two above definitions are the same.
>Proof: [[Theorems about subspaces#^b152ec|see here]].