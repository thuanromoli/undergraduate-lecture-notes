---
tags:
  - MT4528
type: def
aliases:
  - state occupation distribution
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S$ and let $u_{j}(t)= \mathbb{P}(X_{t}= j)$.

>[!def] Definition
>The state occupation distribution of the Markov chain is given by the row vector
>$$\boldsymbol{u}(t)=(u_{1}(t),u_{2}(t),...)=(\mathbb{P}(X_{t}=1),\mathbb{P}(X_{t}=2),...)$$
