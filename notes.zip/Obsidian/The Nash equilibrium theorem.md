---
tags:
  - MT4554
type: thm
aliases:
---
>[!thm] Nash Equilibrium theorem
>Every $N$-player game with a finite number of [[Pure strategies|pure strategies]] has a [[Nash equilibrium]].

Proof:
The proof consists of showing that the [[best response function]] always has a fixed point. Since a Nash equilibrium is a fixed point of the best response function, this would ensure that every game has a Nash equilibrium.
 
Here is our plan:
1. Show that all 'nice' and [[Continuity|continuous]] and 1-dimensional functions have a fixed point (Brouwer's Fixed Point Theorem).
2. Extend this concept to work for $n$-dimensions (Sperner's Lemma).
3. Find a continuous version of the best response function.

We omit Step 1 and 2 as the proofs are from analysis and graph theory respectively. We will proceed to find a function that satisfies step 3.

For a [[Mixed strategies|mixed strategy profile]] $\sigma$, $\phi_{ij}$ quantifies the increase in payoff to player $i$ from switching to pure strategy $s_{i}^{j}\in S_{i}$:
$$\phi_{ij}(\sigma)=\max(0,u_{i}(s_{i}^{j},\sigma_{-i}) - u_{i}(\sigma))$$

We then define $r_{i}:\Sigma \to \Sigma_{i}$ as follows:
$$r_{i}(\sigma_{i})=\left\{
\frac{\sigma_{i}(s_{i}^{1})+\phi_{i1}(\sigma)}{1+\sum\limits_{s_{i}^{j}\in S_{i}}\phi_{ij}(\sigma)},
\frac{\sigma_{i}(s_{i}^{2})+\phi_{i2}(\sigma)}{1+\sum\limits_{s_{i}^{j}\in S_{i}}\phi_{ij}(\sigma)},
\ldots,
\frac{\sigma_{i}(s_{i}^{\lvert S_{i} \rvert})+\phi_{i{\lvert S_{i} \rvert}}(\sigma)}{1+\sum\limits_{s_{i}^{j}\in S_{i}}\phi_{ij}(\sigma)},
\right\}$$
that is, given a mixed strategy of player $i$, this function returns an improved mixed strategy for player $i$ by adjusting the probabilities. This works because if there is an increase in the payoff by switching to strategy $s_{i}^{j}$, then the probability of playing such strategy will increase.

We finally define $r_{i}:\Sigma \to \Sigma$ as follows:
$$r(\sigma)=[r_{i}(\sigma)]_{i\in\mathcal N}$$
that is, the composite of all players moving towards better strategies.

Now, since $\Sigma$ is compact and convex, by Brouwer's fixed point theorem and Sperner's Lemma, the function $r(\sigma)$ must contain a fixed point $\sigma^{*}=r(\sigma^{*})$.
For such strategy profile $\phi_{ij}(\sigma^{*})=0 \;\;\forall i \in \mathcal N \;\land\; \forall j\in S_{i}$. Thus no pure strategy gives a higher payoff than $\sigma_{i}^{*}$ for any $i\in\mathcal N$. And so $\sigma_{i}^{*} \in B_{i}(\sigma_{-i}^{*}) \;\;\forall i\in \mathcal N$, i.e a fixed point of $r$ is a Nash equilibrium.