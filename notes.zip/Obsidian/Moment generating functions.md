---
tags:
  - MT2504
  - MT3507
type: def
aliases:
  - mgf
---
Let $X$ be any [[Random variables|rv]].

>[!def] Definition
>The moment generating function of $X$ is defined as
>$$M_{X}(t)=\mathbb{E} \left[e^{tX} \right] = \int_{-\infty}^{\infty}e^{tx}f(x)dx$$
>(defined for all $t$ for which the expectation is finite).
