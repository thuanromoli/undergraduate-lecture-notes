---
tags:
  - MT2504
type: def
aliases:
  - trial
---
>[!def] Definition
>An experiment (or trial) is any process with a random outcome.

---

#### Spaced repetition
