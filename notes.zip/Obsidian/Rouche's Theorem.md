---
tags:
  - MT3503
aliases:
---
Let $f$ and $g$ be [[Holomorphic functions|holomorphic]] [[Functions|functions]] on an [[Open sets|open set]] containing a [[Contours|contour]] $\gamma$ and its interior.

> [!thm] Theorem
> Suppose that $|f(z)| > |g(z)|$ for $z$ on $\gamma^{*}$.
> Then $f$ and $f+g$ have the same number of zeros inside $\gamma$.
