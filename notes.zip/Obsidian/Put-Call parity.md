---
tags:
  - MT4551
aliases:
---

> [!thm] Theorem
> The Put-Call parity gives the relationship between European Put and Call [[Options|options]] of same strike price $E$ and expiry date $T$:
> $$P_{E}+S = Ee^{-rT}+C_{E}$$

Proof:
Consider two portfolios:
1. One call option and cash $Ee^{-rT}$ (long party).
2. One put option and one share $S$ (long party).

At the expiry time $T$, the portfolios are worth:

1. $\max(S,E)$.
2. $\max(S,E)$.

And so at time $T$, $\text{portfolio}(1) = \text{portfolio}(2)$ and to avoid arbitrage, this is true $\forall t$. Hence,
$$P_{E}+S = Ee^{-rT} +C_{E}.$$
