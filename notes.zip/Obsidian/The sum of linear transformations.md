---
tags:
  - MT3501
type: def
aliases:
---
Let $V$ and $W$ be [[Vector spaces|vector spaces]] over a field $F$. Let $S$ and $T$ be [[Linear transformations|linear transformations]] $V\to W$ and $\alpha$ be a scalar from $F$.

>[!def] Definition
>We define the sum $S+T:V\to W$ by
>$$(S+T)(v)=S(v)+T(v)$$

>[!thm] The sum $S+T$ is a [[Linear transformations|linear transformation]]
>Let $u,v\in V$ and $\lambda\in F$. Then
>1. $(S+T)(u +v)=S(u+v)+T(u+v)$ = $S(u)+S(v)+T(u)+T(v)$ = $(S+T)(u)+(S+T)(v)$
>2. $(S+T)(\lambda v)=S(\lambda v )+T(\lambda v)$ = $\lambda S(v) + \lambda T(v)$ = $\lambda (S+T)(v)$
>Hence $S+T$ is a linear map.

---

#### Spaced repetition

What is the sum of linear transformations?
?
>We define the sum $S+T:V\to W$ by
>$$(S+T)(v)=S(v)+T(v)$$

Prove that the sum $S+T$ is a [[Linear transformations|linear transformation]].
?
>Let $u,v\in V$ and $\lambda\in F$. Then
>1. $(S+T)(u +v)=S(u+v)+T(u+v)$ = $S(u)+S(v)+T(u)+T(v)$ = $(S+T)(u)+(S+T)(v)$
>2. $(S+T)(\lambda v)=S(\lambda v )+T(\lambda v)$ = $\lambda S(v) + \lambda T(v)$ = $\lambda (S+T)(v)$
>Hence $S+T$ is a linear map.