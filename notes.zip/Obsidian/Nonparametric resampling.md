---
tags:
  - MT3508
aliases:
---
Simply replace the random variable generating functions in the parametric bootstrap code with

```R
boot.y <- sample(y, n, replace = T)
```

where `y` and `n` are the original sample and original sample size, respectively.

``` R
# Step 1: find the MLEs from the original sample.
MLEs.OG <- optim(start, nll, y = y.OG)


for(i in 1:nboot) {

	# Step 2: create a new sample of data using non-parametric resampling.
	y.boot.i <- sample(y, n, replace = T)
	
	# Step 3: for this new sample find the MLEs.
	start <- c(MLEs.OG[1], MLEs.OG[2],...)
	MLEs.boot.i <- optim(start, nll, y = y.boot.i)
	
	# Step 4: obtain a vector for each MLE for each sample.
	MLE.1[i] <- MLEs.boot.i[1]
	MLE.2[i] <- MLEs.boot.i[2]
	...
}

# Step 5: find percentails (say 95% for example).
low <- round((nboot + 1) * 0.025))
high <- round((nboot + 1) * 0.975)

sorted.MLE.1 <- sort(MLE.1)
sorted.MLE.2 <- sort(MLE.2)
...

CI.MLE.1 <- c(sorted.MLE.1[low], sorted.MLE.1[high])
CI.MLE.2 <- c(sorted.MLE.2[low], sorted.MLE.2[high])
...
```

See Mark recapture example 3.4.1 for harder example.

```r
# Nonparametric bootstrap for mark recapture data
y <- c(30, 33, 34)
nboot <- 999
boot.N <- rep(0, nboot)
boot.p <- rep(0, nboot)

# Generate a vector of categories, i.e. which cell of the table each individual is in
cells <- rep(1:4, times = c(y, N.hat - sum(y)))
# this returns (1,...,1 (30 times); 2,...,2 (33 times); 3,...,3 (34 times), 4,...,4 (N.hat - 97 times))

# bootstrap
for(i in 1:nboot)  {
  boot.cells <- sample(cells, N.hat, replace = T)
  # format data as we need it for the likelihood function
  boot.y <- rep(0, 3)
  for(j in 1:3)  {
    boot.y[j] <- length(boot.cells[boot.cells == j]) # count number in each cell
  }
  start <- c(log(n.missed.hat), logit(p.hat)) # original estimates are good starting values
  boot.MLE <- optim(start, nll.MR, y=boot.y) # get estimates with bootstrap resampled data
  boot.N[i] <- exp(boot.MLE$par[1]) + sum(y) # store bootstrap estimate of N
  boot.p[i] <- invlogit(boot.MLE$par[2]) # store bootstrap estimate of p
}

# take a look at what we've generated
hist(boot.N, nclass = 25, xlab = "Nonparametric bootstrap estimate of N", main = "")
```
