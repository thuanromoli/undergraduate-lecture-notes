---
tags:
  - MT2504
  - MT4528
  - MT4551
type: def
aliases:
---
Let $\Omega$ be a [[Sample space, Sample points, and Events|sample space]].

>[!def] Axioms
>A probability $\mathbb{P}$ is any [[Functions|function]] which assigns a real number $\mathbb{P}(A)$ to each [[Sample space, Sample points, and Events|event]] $A$ such that:
>1. $0\leqslant \mathbb{P}(A) \leqslant 1$ for every event $A \subseteq \Omega$;
>2. $\mathbb{P}(\Omega)=1$ - this is the honesty condition;
>3. If $A_{1},...,A_{n}$ are a finite collection of pairwise disjoin events, then $\mathbb{P}(A_{1} \cup \ldots \cup A_{n})=\sum\limits_{i=1}^{n}\mathbb{P}(A_{i})$.
