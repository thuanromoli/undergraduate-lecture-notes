---
type: model
tag: MT2507
---
>[!gen]+ Model:
>$$\frac{dN(t)}{dt}\propto N(t)$$

>[!gen]+ ODE:
>$$\frac{dN(t)}{dt}= rN(t)$$

>[!gen]+ Terms:
>- $r$ is the growth rate;
>- $N(t)$ is the amount of substance and $N(t)>0$;
>- $t$ is the time and $t>0$.

>[!gen]+ Solution:
>$$N=N_{0}e^{rt}$$