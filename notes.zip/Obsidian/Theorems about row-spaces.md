---
tag: MT2501
type: thm
alias:
- 
---
>[!thm]- Two [[matrices]] that are [[Elementary row operations|row-equivalent]] to each other have the same [[Row-spaces|row-space]]
>Apply [[Theorems about Span]].

^2cd3d6

>[!thm]- Two [[matrices]] that are [[Elementary row operations|column-equivalent]] to each other have the same [[Row-spaces|column-space]]
>Apply [[Theorems about Span]].

>[!thm]- The [[Row-spaces|row-space]] of a matrix $A \in M_{m\times n}(F)$ is the entire space $F^{n}$ if and only if the [[Echelon form|reduced echelon]] form of $A$ is $$\begin{pmatrix}
 1 & 0 & \cdots & 0 \\
 0 & 1 & \cdots & 0 \\
 \vdots & \vdots & \ddots & \vdots \\
 0 & 0 & \cdots & 1 \\ 
 0 & 0 & \cdots & 0 \\
 \vdots & \vdots & \ddots & \vdots \\
 0 & 0 & \cdots & 0 \\
 \end{pmatrix}$$
>
>The reduced row echelon form of $A$ has the same row space as $A$ by [[Theorems about row-spaces#^2cd3d6|the above theorem]]. If it looks as above, then the first $n$ rows clearly span $F^{n}$. Otherwise, there is a column with no leading entry, and a little more work shows that the space spanned in this case cannot be the entire $F_{n}$.

---

#### Spaced repetition

Prove that two [[matrices]] that are [[Elementary row operations|row-equivalent]] to each other have the same [[Row-spaces|row-space]].
?
>Apply [[Theorems about Span]].

Prove that two [[matrices]] that are [[Elementary row operations|column-equivalent]] to each other have the same [[Row-spaces|column-space]].
?
>Apply [[Theorems about Span]].

Prove that the [[Row-spaces|row-space]] of a matrix $A \in M_{m\times n}(F)$ is the entire space $F^{n}$ if and only if the [[Echelon form|reduced echelon]] form of $A$ is $$\begin{pmatrix}
 1 & 0 & \cdots & 0 \\
 0 & 1 & \cdots & 0 \\
 \vdots & \vdots & \ddots & \vdots \\
 0 & 0 & \cdots & 1 \\ 
 0 & 0 & \cdots & 0 \\
 \vdots & \vdots & \ddots & \vdots \\
 0 & 0 & \cdots & 0 \\
 \end{pmatrix}$$
?
>The reduced row echelon form of $A$ has the same row space as $A$ by [[Theorems about row-spaces#^2cd3d6|the above theorem]]. If it looks as above, then the first $n$ rows clearly span $F^{n}$. Otherwise, there is a column with no leading entry, and a little more work shows that the space spanned in this case cannot be the entire $F_{n}$.
