---
type: def
tag: MT2505
alias: reflexive
---
Let $\sim$ be a [[Relations|relation]] defined on a set $A$.

>[!def] Definition
>$\sim$ is reflexive if $$a\sim a \;\;\forall   a \in A$$
