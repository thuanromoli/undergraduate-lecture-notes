---
tags:
  - MT3501
type: thm
aliases:
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] of dimension $n$ over a [[Fields (Algebra)|field]] $F$ and let $T:V\to V$ be a [[Linear transformations|linear transformation]].
Let $\mathscr B=\set{v_{1},...,v_{n}}$ and let $\mathscr C=\set{w_{1},...,w_{n}}$ be [[bases]] for $V$.
Let $B$ and $C$ be the [[Matrices|matrices]] of $T$ with respect to $\mathscr B$ and $\mathscr C$ respectively.

>[!thm] Theorem
>There exists an [[The inverse of a matrix|invertible]] [[Matrices|matrix]] $P$ such that $$C=P^{-1}BP$$
>specifically, the $(i,j)$th entry of $P$ is the coefficient of $v_{i}$ when $w_{j}$ is expressed as a [[Linear combinations|linear combination]] of the [[Bases|basis]] vectors in $\mathscr B$.

Proof:
Since $\mathscr B$ and $\mathscr C$ are both bases for $V$, we can write a vector in each one as a linear combination of vectors in the other:
$$w_{j}=\sum\limits_{k=1}^{n}\lambda_{kj}v_{k} \;\;\text{ and }\;\; v_{l}=\sum\limits_{i=1}^{n}\mu_{il}w_{i}$$
Let $P=[\lambda_{kj}]$ and $Q=[\mu_{il}]$ be the matrices whose entries are coefficients appearing in these formulae.
Let us substitute the expression for $w_{j}$ into the expression for $v_{l}$:
$$v_{l}=\sum\limits_{i=1}^{n}\mu_{il}w_{i}=\sum\limits_{i=1}^{n}\mu_{il}\sum\limits_{k=1}^{n}\lambda_{ki}v_{k}=\sum\limits_{k=1}^{n}\left(\sum\limits_{i=1}^{n}\lambda_{ki}\mu_{il}\right)v_{k}$$
This must be the unique way of writing $v_{l}$ as a linear combination of the vectors in $\mathscr B=\set{v_{1},...,v_{n}}$. Thus
$$\sum\limits_{i=1}^{n}\lambda_{ki}\mu_{il}=\delta_{kl}=
\begin{cases}
1 & \text{if }k=l \\
0 & \text{if }k\neq l
\end{cases}$$
where $\delta_{kl}$ is called the Kronker delta. The left-hand side is the formula for [[Matrix multiplication|matrix multiplication]], so $PQ=I$.
Hence $P$ and $Q$ are [[The inverse of a matrix|invertible]] matrices with $Q=P^{-1}$.

Now suppose that $T:V\to V$ is a [[Linear transformations|linear transformation]] whose matrix with respect to the basis $\mathscr B$ is $\text{Mat}_{\mathscr B,\mathscr B}(T)=B=[\alpha_{ij}]$. This means
$$T(v_{k})=\sum\limits_{l=1}^{n}\alpha_{lk}v_{l}$$
Now we want to apply $T$ to $w_{j}$ as follows
$T(w_{j})=T\left(\sum\limits_{k=1}^{n}\lambda_{kj}v_{k}\right)$ = $\sum\limits_{k=1}^{n}\lambda_{kj}T(v_{k})$ = $\sum\limits_{k=1}^{n}\lambda_{kj}\sum\limits_{l=1}^{n}\alpha_{lk}v_{l}$ = $\sum\limits_{l=1}^{n}\sum\limits_{k=1}^{n}\alpha_{lk}\lambda_{kj}v_{l}$ = $\sum\limits_{l=1}^{n}\sum\limits_{k=1}^{n}\alpha_{lk}\lambda_{kj}\sum\limits_{i=1}^{n}\mu_{il}w_{i}$ = $\sum\limits_{i=1}^{n}\left(\sum\limits_{l=1}^{n}\sum\limits_{k=1}^{n}\mu_{il}\alpha_{lk}\lambda_{kj}\right)w_{i}$.

Hence $\text{Mat}_{\mathscr C,\mathscr C}(T)=C=[\beta_{ij}]$ where
$$\beta_{ij}=\sum\limits_{l=1}^{n}\sum\limits_{k=1}^{n}\mu_{il}\alpha_{lk}\lambda_{kj}$$
that is,
$$C=QBP=P^{-1}BP$$