---
tags:
  - MT3501
type: thm
aliases:
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Inner product spaces|inner product space]] with inner product $\langle \cdot , \cdot \rangle$.
Let $T:V\to V$ be a [[Self-adjoint transformations|self-adjoint]] [[Linear transformations|linear transformation]].

>[!thm]- A real matrix $A$ defines a [[Self-adjoint transformations|self-adjoint]] transformation if and only if is [[Theorems about transpose matrices|symmetric matrix]]: $A^{\mathsf T}=A$
>This follows from [[Theorems about the adjoint of a transformation#^b48005|this theorem]].

>[!thm]- A complex matrix $A$ defines a [[Self-adjoint transformations|self-adjoint]] transformation if and only if it is Hermitian: $\bar A^{\mathsf{T}}$
>This follows from [[Theorems about the adjoint of a transformation#^b48005|this theorem]].

The theorems below are used to prove the [[Spectral theorem|spectral theorem]].

>[!thm]- If $T^{*}$ is self-adjoin, then the [[Characteristic polynomials|characteristic polynomial]] is a product of linear factors and every [[Eigenvectors and Eigenvalues|eigenvalue]] of $T$ is real
>Any polynomial over $\mathbb C$ can be factorised into a product of linear factors. Thus it is sufficient to show that all the roots of the characteristic polynomial are real.
>
>Firstly, we note that $V$ might be a [[Vector spaces|vector space]] over $\mathbb R$, so we replace it by an inner product space over $\mathbb C$ that in all ways is the same.
>Let $W$ be an [[Inner product spaces|inner product space]] over $\mathbb C$ with $\dim V=\dim W$ and let $S:W\to W$ be a [[Linear transformations|linear transformation]] whose matrix $A$ with respect to an [[Orthogonality|orthonormal]] [[Bases|basis]] for $W$ is the same as that of $T$ with respect to an orthonormal basis for $V$.
>Since $T^{*}=T$, then $\bar A^{\mathsf T}=A$ and therefore $S$ is [[Self-adjoint transformations|self-adjoint]] and furthermore $c_{T}(x)=\det(xI-A)=c_{S}(x)$.
>
>Let $\lambda\in \mathbb C$ be a root of $C_{S}(x)$. Then $\lambda$ is an [[Eigenvectors and Eigenvalues|eigenvalue]] of $S$, so there exists an [[Eigenvectors and Eigenvalues|eigenvector]] $v\in W$ for $S$: $S(v)=\lambda v$. Therefore
>$$\langle S(v),v  \rangle =\langle \lambda v, v \rangle = \lambda {\Vert v \Vert}^{2}$$
>but also
>$$\langle S(v),v \rangle = \langle v,S^{*}(v) \rangle=\langle v,S(v) \rangle= \langle v,\lambda v \rangle=\bar \lambda {\Vert v \Vert}^{2}$$
>Hence
>$$\lambda {\Vert v \Vert}^{2}=\bar \lambda {\Vert v \Vert}^{2}$$
>and since $v\neq \boldsymbol{0}$, we conclude $\lambda =\bar \lambda$. This shows that $\lambda\in \mathbb R$ and the lemma is proved.

^4cfbcb

>[!thm]- If $U$ is a [[Subspaces|subspace]] of $V$ such that $T(U)\subseteq U$ (that is, $U$ is $T$-invariant), then $T^{*}(U^{\perp}) \subseteq U^{\perp}$ (that is, $U^{\perp}$ is $T^{*}$-invariant)
>Let $w\in U^{\perp}$. Then, for any $u\in U$ we apply $T^{*}$ to $w$:
>$$\langle u,T^{*}(w) \rangle = \langle T(u),w \rangle=0$$
>since $T(u)\in U$ and $w \in U^{\perp}$. Hence $T^{*}(w)\in U^{\perp}$.

^d83224

>[!thm]- Any pair of [[Eigenvectors and Eigenvalues|eigenvectors]] for distinct [[Eigenvectors and Eigenvalues|eigenvalues]] are [[Orthogonality|orthogonal]].
>Let $u$ and $v$ be eigenvectors for $T$ with eigenvalues $\lambda$ and $\mu$ respectively, with $\lambda \neq \mu$.
>By [[Theorems about self-adjoint transformations#^4cfbcb|the above theorem]], $\lambda$ and $\mu$ are real numbers.
>Since $T^{*}=T$ and $\bar \mu=\mu$, we have
>$$\begin{align*}
   \langle T(u),v \rangle =\langle \lambda u ,v \rangle = \lambda \langle u,v \rangle\\
   \langle u,T(v) \rangle = \langle u, \mu v \rangle=\mu \langle u,v \rangle
   \end{align*}$$
>and so since $T$ is self-adjoin,
>$$(\lambda-\mu)\langle u,v \rangle=0$$
>As $\lambda-\mu\neq 0$, we conclude that $\langle u,v \rangle=0$. That is, $u$ and $v$ are orthogonal.

^f44d4e
