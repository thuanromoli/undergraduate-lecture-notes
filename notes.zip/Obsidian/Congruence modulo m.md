---
type: def
alias: congruence modulo m
tag: MT2505
---
Let $m>1 \in \mathbb{Z}$.

>[!def] Definition
>Two integers $a$ and $b$ are _congruent modulo_ $m$ if $b-a$ is divisible by $m$: $$a \equiv b \pmod m \iff m \mid b-a$$
