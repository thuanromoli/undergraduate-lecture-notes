---
type: def
tag: MT2506
---
Let $f(\boldsymbol x)$ be a [[Scalar fields|scalar field]] and let $\boldsymbol r(s)$ be a curve.

>[!def] Definition
>The line integral of the scalar field is: 
>$$\int_{s_1}^{s_2}f(\boldsymbol x) \ \text{d}s = \int_{s_1}^{s_2}f(\boldsymbol r(s)) \ \text{d}s=\int_{s_1}^{s_2}g(s) \ \text{d}s$$
>where $g(s) \equiv f(\boldsymbol r(s))$.
