---
tags:
  - MT4003
aliases:
  - p-group
---
Let $p$ be a prime number.

> [!def] Definition
> A $p$-group is a [[Order|finite]] [[Groups|group]] with order a power of $p$.
