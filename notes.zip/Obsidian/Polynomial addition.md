---
type: def
tag: MT2505
---
Let $f(X)=\sum\limits_{i=0}^{n}a_iX^n$ and $g(X)=\sum\limits_{i=0}^{n}b_iX^n$ be [[Polynomials|polynomials]].

>[!def] Definition
>[[Polynomials|Polynomial]] addition is defined as 
>$$f(X)+g(X)=\sum\limits_{i=0}^{n}(a_i+b_i)X^n$$
