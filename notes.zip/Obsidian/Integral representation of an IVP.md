---
tags:
  - MT3504
type: mthd
aliases:
---
Let $y'=f(x,y) \;\; \text{with } \;\; y(x_{0})= y_{0}$ be an [[Initial values and IVP]].

>[!gen] Integral representation of an IVP
>The integral equation is obtained by integrating $y'=f(x,y)$ from $x_{0}$ to $x$:
>$$y(x)=y_{0}+\int_{x_{0}}^{x}f(s,y(s))ds$$

Proof:
We wish to show that the two statements are equivalent. We check that both conditions of the IVP are true for the integral equation.

Initial conditions: set $x=x_{0}$.
Then $y(x_{0})= y_{0}+\int_{x_{0}}^{x_{0}}f(s,y(s))ds=y_{0}$.

ODE: use the Fundamental Theorem of calculus.
$\frac{d}{dx}y=\frac{d}{dx}\left(y_{0}+\int_{x_{0}}^{x}f(s,y(s))ds\right)$ $\implies$ $\frac{dy}{dx}=0+f(x,y(x))$.

---

#### Spaced repetition

What is the integral representation of an IVP?
?
>The integral equation is obtained by integrating $y'=f(x,y)$ from $x_{0}$ to $x$:
>$$y(x)=y_{0}+\int_{x_{0}}^{x}f(s,y(s))ds$$
