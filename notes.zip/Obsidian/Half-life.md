---
type: def
tag: MT2507
---
>[!def] Definition
>The half life of a substance is the time $t$ that satisfies
>$$N(t)= \frac{N_{0}}{2}$$
>In [[Radioactive decay|radioactive decay]], $t=\frac{1}{k}\ln 2$.
