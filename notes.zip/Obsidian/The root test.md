---
tags:
  - MT2502
aliases:
---
Let $(x_{n})_{n}$ be a [[Sequences|sequence]] and $\sum\limits_{x=1}^{\infty}x_{n}$ be its [[Series|series]].

> [!thm] Convergence
> If there exists an $N \in  \mathbb N$ and $r<1$ such that $n \geqslant N \implies |x_{n}|^{\frac{1}{n}} \leqslant r$, then $\sum\limits_{n=1}^{\infty}x_{n}$ is [[Convergence|convergent]].

> [!thm] Divergence
> If there exists an $N \in  \mathbb N$ and $r>1$ such that $n \geqslant \mathbb N \implies |x_{n}|^{\frac{1}{n}} \geqslant r$, then $\sum\limits_{n=1}^{\infty}x_{n}= \infty$ is [[Convergence|divergent]].
