---
tags:
  - MT2502
  - MT3503
aliases:
  - power series
---
#### For real analysis:
Let $(a_{n})_{n}$ be a [[Sequences|sequence]].

> [!def] Definition
> The [[Series|series]] $\sum\limits_{n=0}^{\infty}a_{n}x^{n}$ is called a power series.

#### For complex analysis:
Let $a \in \mathbb C$ and $(c_{n})_{n}$ be a complex [[Sequences|sequence]].

> [!def] Definition
> A power [[Series|series]] is a [[Functions|function]] of the form
> $$\sum\limits_{n=0}^{\infty}c_{n}(z-a)^{n}$$
> whenever this [[Convergence|converges]].
