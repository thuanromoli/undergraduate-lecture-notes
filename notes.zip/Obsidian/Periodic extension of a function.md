---
type: mthd
tag: MT2507
---
Let $f(x)$ be a [[Functions|function]] defined over a finite interval $[a,b)$.

>[!gen]+ Method
>We can always construct a [[Periodic functions|periodic function]] with period $L=b-a$ by copying $f(x)$ to $f(x+L)$, then to $f(x+2L)$ and so on...