---
tags:
  - MT3501
type: def
aliases:
  - norm
---
Let $V$ be an [[Inner product spaces|inner product space]] with inner product $\langle \cdot , \cdot \rangle$.

>[!def] Definition
>The norm is the [[Functions|function]] $\Vert \cdot \Vert:V\to \mathbb R$ defined by
>$$\Vert v \Vert=\sqrt{\langle v,v \rangle}$$
