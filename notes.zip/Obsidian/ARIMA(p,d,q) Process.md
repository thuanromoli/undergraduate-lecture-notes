---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is called an autoregressive integrated moving moving average process of order $(p,d,q)$ if
> $$\phi(B)(1-B)^{d}X_{t}=\theta(B)\varepsilon_{t}, \quad \forall t \in \mathbb Z$$
> where $\phi(B)$ is a [[Stationarity|stationary]] [[AR(p) Process|autoregressive]] operator of order $p$ and $\theta(B)$ is a [[MA(q) Process|moving average]] operator of order $q$.

> [!def] Different representations
> - The difference equation form $X_{t}=$ in terms of $X_{t-1},X_{t-2},...$ and $\varepsilon_{t},\varepsilon_{t-1},...$.
> - The random shock form. $X_{t}=(1-B)^{-d}\frac{\theta(B)}{\phi(B)}\varepsilon_{t}$.
> - The inverted form. $\varepsilon_{t}=\frac{\phi(B)}{\theta(B)}(1-B)^{d}X_{t}$.

> [!gen] Remarks
> - We can write the process as $\phi(B)\nabla^{d}X_{t}=\theta(B)\varepsilon_{t}$.
> - Given that the roots of the $\phi(B)$ polynomial are outwith the unit circle, the process is stationary if and only if $d=0$.

> [!thm] Duality of ARIMA and ARMA processes
> Let $W =( W_{t})_{t \in \mathbb Z}$ and $X=(X_{t})_{t \in \mathbb Z}$ be stochastic processes such that $W_{t}=(1-B)^{d}X_{t}$ or equivalently $X_{t}= (1-B)^{-d}W_{t}$.
> 
> Suppose $X$ is an ARIMA($p,d,q$) process with $\phi(B)(1-B)^{d}X_{t}=\theta(B)\varepsilon_{t}$.
> Then $\phi(B)W_{t}=\theta(B)$ for all $t$.
> Hence $W$ is an ARMA($p,q$) process.
> 
> Conversely, suppose that $W$ is an ARMA($p,q$) process.
> Then we may retrieve a ARIMA process by considering the series expansion of $X_{t}= (1-B)^{-d}W_{t}$.

> [!gen]- Proofs
> Proof 1.
> We write $X_{t}$ in terms of $\varepsilon_{t},\varepsilon_{t-1},...$ and $X_{t-1},X_{t-2},...$ simply by expanding.
> 
> Proof 2.
> Since $X$ is ARIMA, $W$ is ARMA and provided it is causal/stationary, it can be written as a MA($\infty$) process,
> say $W_{t}= \theta(B)\varepsilon_{t}$ where $\theta(B)=\sum\limits_{i=0}^{\infty}\theta_{i}B^{i}$.
> Then $X_{t} = (1-B)^{-d}W_{t}= (1-B)^{-d} \theta(B)\varepsilon_{t}= \nu(B)\varepsilon_{t}$ where $\nu(B)=\sum\limits_{i=0}^{\infty}\nu_{i}B^{i}=(1-B)^{-d}\theta(B)$.
> 
> Proof 3.
> Since $X$ is ARIMA, $W$ is ARMA and provided it is invertible, it can be written as a AR($\infty$) process,
> say $\varepsilon_{t}=\phi(B)W_{t}$ where $\phi(B)=\sum\limits_{i=0}^{\infty}\phi_{i}B^{i}$.
> Then $\varepsilon_{t}= \phi(B) W_{t}=\phi(B)(1-B)^{d}X_{t}=h(B)X_{t}$ where $h(B)=\sum\limits_{i=0}^{\infty}h_{i}B^{i}=\phi(B)(1-B)^{d}$.

![[acfarima_att.png]]