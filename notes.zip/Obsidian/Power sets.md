---
tags:
  - MT3502
aliases:
---
Let $A$ be a set.

> [!def] Definition
> The power set of $A$, written $\mathcal P(A)$, is the set of all subsets of $A$, that is
> $$\mathcal P(A)= \set{Y:Y \subseteq A}.$$
