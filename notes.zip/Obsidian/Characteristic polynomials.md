---
tags:
  - MT3501
type: def
aliases:
  - characteristic polynomial
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $T:V\to V$ be a [[Linear transformations|linear transformation]].
Let $A=\text{Mat}(T)$ be [[The matrix of a linear transformation|the matrix of the linear transformation]] $T$ with respect to some [[Bases|basis]].

>[!def] Definition
>The characteristic [[Polynomials|polynomial]] of $T$ is
>$$c_{T}(x)=\det(xI-A)$$