---
tags:
  - MT3507
aliases:
---
> [!def] Definition
> A parametric family of distributions $\left\{ f(\mathbf{x}| \theta) : \theta \in \Theta \right\}$ is an $(r,k)$ exponential family if $\Theta$ is a subset of $\mathbb R^{k}$ and
> $$f(\mathbf{x}| \theta) = a(\mathbf{x}) b(\theta) \exp \left[ \sum_{i=1}^r c_i(\theta) T_i(\mathbf{x}) \right]$$
> for all $\theta \in \Theta$.
