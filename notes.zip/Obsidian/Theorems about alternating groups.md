---
type: thm
tags:
  - MT2505
  - MT4003
---
Let $n$ be a positive integer.

>[!thm]- If $n \geqslant 2$, then $|A_n|=\frac 1 2 |S_n|=\frac 1 2 n!$.
PROOF:

> [!thm]- If $n \geqslant 5$, then the [[The alternating group|alternating group]] is simple.
> [[Simplicity of the alternating groups]]
