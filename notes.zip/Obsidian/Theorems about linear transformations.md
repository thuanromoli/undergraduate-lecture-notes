---
tags:
  - MT2501
  - MT3501
type: thm
aliases:
---
Let $T:V \to W$ be a [[Linear transformations|linear transformation]] between two [[Vector spaces|vector spaces]] over the [[Fields (Algebra)|field]] $F$.

>[!thm]- If $v_{1},...,v_{k}\in V$ and $\alpha_{1},...,\alpha_{k}\in F$, then $T\left(\sum\limits_{i=1}^{k}\alpha_{i}v_{i}\right)=\sum\limits_{i=1}^{k}\alpha_{i}T(v_{i})$
>Using the definition: $T\left(\sum\limits_{i=1}^{k}\alpha_{i}v_{i}\right)$ = $\sum\limits_{i=1}^{k}T(\alpha_{i}v_{i})$ = $\sum\limits_{i=1}^{k}\alpha_{i}T(v_{i})$

>[!thm]- $T(\boldsymbol{0})= \boldsymbol{0}$
>$T(\boldsymbol{0})$ = $T(0\cdot\boldsymbol{0})$ = $0T(\boldsymbol{0})$ = $\boldsymbol{0}$

>[!thm]- $T(-v)=-T(v) \;\;\forall v\in V$
>$T(\boldsymbol{-v})$ = $T(-1\cdot\boldsymbol{v})$ = $-T(\boldsymbol{v})$

>[!thm]- The [[Image|image]] of $T$ is a [[Subspaces|subspace]] of $W$
>Firstly, note that $\boldsymbol{0}=T(\boldsymbol{0})\in \text{im}(T)$ and hence $\text{im}(T)$ is non-empty.
>Now let $T(u),T(v) \in \text{im}(T)$ and $\alpha\in F$ and consider:
>1. $T(u)+T(v)=T(u+v) \in \text{im}(T)$.
>2. $\alpha T(v)=T(\alpha v)\in\text{im}(T)$.
>
>Hence $\text{im}(T)$ is a subspace of $W$.

>[!thm]- The [[Kernel|kernel]] of $T$ is a [[Subspaces|subspace]] of $V$
>Firstly, note that $\boldsymbol{0}_{W}=T(\boldsymbol{0_{V}})$ and hence we see that $\boldsymbol{0_{V}}\in \ker T$ and we conclude that $\ker T$ is non-empty.
>Now let $u,v\in \ker T$ and $\alpha\in F$ and consider:
>1. $T(u+v)=T(u)+T(v)=\boldsymbol{0}+\boldsymbol{0}=\boldsymbol{0}$ and hence $u+v\in \ker T$.
>2. $T(\alpha v)=\alpha T(v)=\alpha \boldsymbol{0}=\boldsymbol{0}$ and hence $\alpha v\in \ker T$.
>   
>   Hence $\ker T$ is a subspace of $V$.

Let $\mathscr B=\set{v_{1},...,v_{n}}$ be a [[Bases|basis]] for $V$ and let $y_{1},...,y_{n}\in W$ be any arbitrary vectors in $W$.

>[!thm]- There is one and only one (unique) linear transformation $T:V \to W$ such that $T(v_{i})=y_{i} \;\;\forall i=1,...,n$
>Since $\mathscr B$ is a basis for $V$, a vector $v\in V$ can be uniquely expressed as $v=\sum\limits_{i=1}^{n}\alpha_{i}v_{i}$.
>Then linearity of $T$ implies that $T(v)$ = $T\left(\sum\limits_{i=1}^{n}\alpha_{i}v_{i}\right)$ = $\sum\limits_{i=1}^{n}\alpha_{i}T(v_{i})$ = $\sum\limits_{i=1}^{n}\alpha_{i}y_{i}$.
>We have just observed that if there is such linear map, then it is given by the formula above. Hence, if such linear map $T$ exists, then it is unique.
>The proof consists of showing that the formula does define a valid linear transformation and is omitted.

>[!thm]-  $\text{im }T = \text{Span}(y_{1},y_{2},...,y_{n})$
>Let $w\in \text{im T}$ be arbitrary, then we can express $w=T(v)$ for some $v\in V$.
>Since $\mathscr B$ is a basis for $V$, $v=\sum\limits_{i=1}^{n}\alpha_{i}v_{i}$ and hence $w=T\left(\sum\limits_{i=1}^{n}\alpha_{i}v_{i}\right)$ = $\sum\limits_{i=1}^{n}\alpha_{i}T(v_{i})$ = $\sum\limits_{i=1}^{n}\alpha_{i}y_{i}$.
>That is, a [[Linear combinations|linear combination]] of vectors $y_{1},...,y_{n}$.
>Since $w$ is arbitrary, then any vectors in $\text{im }T$ can be expressed as a linear combination of $y_{1},...,y_{n}$.
>Hence $\text{im }T = \text{Span}(y_{1},y_{2},...,y_{n})$.

^f3988b

>[!thm]- $\ker T=\set{\boldsymbol{0}}$ if and only if $\set{y_{1},y_{2},...,y_{n}}$ is a [[Linear independence|linearly independent]] set
>By the [[Rank-Nullity Theorem]], $\text{rank }T + \text{null T}=\dim V$ or $\dim \text{im }T + \dim \ker T=\dim V=n$.
>Hence $\ker T=\boldsymbol{0}$ if and only if $\dim\ker T=0$ if and only if $\dim \text{im }T=n$
>We have [[Theorems about linear transformations#^f3988b|already observed]] that $\set{y_{1},y_{2},...,y_{n}}$ is a [[Spanning sets|spanning set]] for $\text{im }T$.
>Hence $\dim \text{im }T = n$ if and only if $\set{y_{1},y_{2},...,y_{n}}$ is linearly independent.
