---
tags:
  - MT3502
aliases:
  - refinement
---
Let $\mathcal D$ be a [[Dissections|dissection]] of $[a,b]$.

> [!def] Definition
> We say that a dissection $\mathcal D'$ is a refinement of a dissection $\mathcal D$ if every point in $\mathcal D$ is a point of $\mathcal D'$.
