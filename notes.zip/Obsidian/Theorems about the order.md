---
type: thm
tags:
  - MT2505
  - MT4003
---
Let $G$ be a [[Groups|group]] and $x\in G$.

>[!thm]- Suppose $|x|<\infty$. Then $x^{k} = 1 \iff |x| \text{ divides } k$

^1a1344

> [!thm]- $|\langle x\rangle|= |x|$
> Case 1: $|x|$ is infinite.
> If $|x|$ is infinite then the powers $x^{n}$ of $x$, for $n \in \mathbb Z$, are all distinct. So if $x$ has infinite order, then $\langle x \rangle$ contains infinitely many elements.
> 
> Case 2: $|x|$ is finite.
> Recall that $|x|$ is the least positive integer satisfying $x^{|x|}=1$.
> If $n$ is any integer, divide by $|x|$ to obtain a quotient and a reminder: $n=q \cdot |x| +r$ where $0 \leqslant r < |x|$.
> Then $x^{n}=x^{q \cdot |x| +r}=(x^{|x|})^{q}\cdot x^{r}= 1^{q}\cdot x^{r}= x^{r}$.
> So every power of $x$ is equal to $x^{r}$ for some $r \in \set{0,1,...,|x|-1}$ and so $\langle x \rangle = \set{x^{n}:n\in \mathbb Z}= \set{1,x,x^{2},...,x^{|x|-1}}$.
> Moreover, the powers listed in the set above are distinct.
> If it were the case that $x^{i}= x^{j}$, then $x^{i-j}=1$. This contradicts the definition of $|x|$.

^02710d
