---
tags:
  - MT3503
aliases:
  - real decomposition
---
Let $D \subseteq \mathbb C$.

> [!def] Definition
> Given a function $f:D \to \mathbb C$ of a complex variable, one can associate two real-valued functions, namely
> $$\begin{align*}
   \text{Re }f: D \to \mathbb R && \text{and} && \text{Im }f: D \to \mathbb R.
\end{align*}$$
>
> When writing $z \in D$ as $z= x+iy$, we can view $f: D\to \mathbb C$ as a function of two real variables $x$ and $y$:
> $$f(x+iy) = u(x,y) + i v(x,y)$$
> where $u(x,y)$ and $v(x,y)$ are a pair of real-valued functions of two variables
> $$\begin{align*}
   u: \tilde D \to \mathbb R && \text{and} && v: \tilde D \to \mathbb R,
\end{align*}$$
> for a suitable subset $\tilde D$ of $\mathbb R^{2}$.
