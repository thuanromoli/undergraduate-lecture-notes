---
tags:
  - MT2504
  - MT4528
  - MT3508
  - MT3507
aliases:
  - Poisson distribution
---
> [!gen] Parameters
> $\lambda \in (0,\infty)$ - rate

> [!gen] Support
> $x\in\set{0,1,2,...,n}$ - number of events 

>[!gen] [[Probability mass function]]
>$$f(x)= \frac{\lambda^{x}e^{-\lambda}}{x!}$$

> [!gen] Typical use
> Used for count data when there is no limit on the size of the count, e.g. when events occur at some fixed rate and we count the number of events in some time period. It is more suitable as a model when the events to be counted are relatively _rare_.

> [!gen] Intuition
> The Poisson distribution is closely linked to the [[Binomial distributions|binomial distribution]].
> 
> Suppose that events occur randomly at a constant rate of $\lambda$ per unit time, and we wish to know the number of events, say $Y$ that occur in the time interval $(0,t)$.
> 
> We may divide this intervals into a large number, say $n$, of disjoint sub-intervals of equal length $h = \frac{t}{n}$ such that at most one event occurs in each subinterval of length $h$ as $n \to \infty$.
> 
> Let $X_{i}$ be the number of events occurring in the $i$-th sub-interval, then
> $$X_{i}= \begin{cases}
   1 & \text{with probability }p \\
   X_{i} =0 & \text{with probability }1-p
   \end{cases}$$
> that is, $X_{i} \sim \text{Bin}(1,p)$.
> Furthermore, calls arise with rate $\lambda$ so $p=\lambda h = \lambda t/n$.
> And so $Y \sim \text{Bin}(n, \lambda \frac{h}{n})$ with pgf
> $$\begin{align*}
   \lim\limits_{n \to \infty}G(s) &= \lim\limits_{n \to \infty}\left[1-\lambda \frac{t}{n}+s\left(\lambda \frac{t}{n}\right)\right]^{n}\\
   &= \lim\limits_{n \to \infty}\left(1+\frac{\lambda t(s-1)}{n}\right)^{n}\\
   &= e^{\lambda t (s-1)},
   \end{align*}$$
> which is the pgf of a Poisson distribution with mean $\lambda t$.
> 
> Note that we have assumed $\lambda t = np$ is constant, even when $n \to \infty$, so we require $p$ to be small.

> [!thm] Properties
> - $\mathbb E(X) = \lambda$, $\text{Var }(X) = \lambda$
>   Proof: use derivatives of the pgf.


