---
tags:
  - MT4528
type: def
aliases:
  - one-step tpm
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S=\set{1,2,...}$ and [[One-step transition probabilities|one-step transition probabilities]] $p_{ij}=\mathbb{P}(X_{t+1}=j \vert X_{t}=i)$.

>[!def] Definition
>The one-step transition probability matrix is defined as
>$$\boldsymbol{P}=[p_{ij}]=\begin{pmatrix}
  p_{11} & p_{12} & p_{13} & \ldots \\
  p_{21} & p_{22} & p_{23} & \ldots \\
  p_{31} & p_{32} & p_{33} & \ldots \\ 
  \vdots & \vdots & \vdots
  \end{pmatrix}$$
> Remarks:
> - If there are $N$ states then $\boldsymbol{P}$ is $N \times N$. If the state space is infinite, then the matrix required to describe this would be infinite.
> - Since the $p_{ij}$ are probabilities, $0 \leqslant p_{ij} \leqslant 1$ and $\sum\limits_{j\in S}p_{ij}=1$, but in general $\sum\limits_{i\in S}p_{ij}\neq 1$.
