---
tags:
  - MT4528
type: def
aliases:
  - one-step transition probability
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S$.

>[!def] Discrete-time
>The one-step transition probability is defined as
>$$p_{ij}^{(t)}=\mathbb{P}(X_{t+1}=j \vert X_{t}=i)$$
>for $i,j \in S$.

Let $\set{X(t):t \geqslant 0}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov process]] with [[State spaces|state space]] $S$.

>[!def] Continuous-time
>The one-step transition probability is defined as
>$$p_{ij}=\mathbb{P}(X(W_{i})=j | X(0)=i)$$
>for $i,j \in S$ where $W_{i}$ is the [[Sojourn time|sojourn time]].
