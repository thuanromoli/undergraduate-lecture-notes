---
tags:
  - MT3501
type: thm
aliases:
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $T:V\to V$ be a [[Linear transformations|linear transformation]] and $\mathscr{B}$ be a [[Bases|basis]] for $V$.

>[!thm]- [[The matrix of a linear transformation|The matrix]] $\text{Mat}_{\mathscr{B},\mathscr{B}}(T)$ is a [[Diagonal matrices|diagonal matrix]] if and only if the vectors in $\mathscr{B}$ are all [[Eigenvectors and Eigenvalues|eigenvectors]] for $T$
>Fix the [[Bases|basis]] $\mathscr{B}=\set{v_{1},...,v_{n}}$ for $V$. Suppose $T$ is represented by a [[Diagonal matrices|diagonal matrix]] with respect to $\mathscr{B}$:
>$$\text{Mat}_{\mathscr{B},\mathscr{B}}(T)=\begin{pmatrix}
   \lambda_{1} & 0 & \cdots  & 0 \\
   0 & \lambda_{2} & \cdots  & 0 \\
   \vdots & \vdots & \ddots & \vdots \\
   0 & 0 & \cdots & \lambda_{n}
  \end{pmatrix}$$
>for some $\lambda_{1},...,\lambda_{n}\in F$.
>Then $T(v_{i})=\lambda_{i}v_{i}$ for $i=1,...,n$ so each basis vector in $\mathscr{B}$ is an [[Eigenvectors and Eigenvalues|eigenvector]] for $T$.
>
>Conversely, suppose that each vector in $\mathscr{B}$ is an eigenvector for $T$. Then $T(v_{i})=\lambda_{i}v_{i}$ for $i=1,...,n$ for some $\lambda_{1},...,\lambda_{n}\in F$ and the matrix $\text{Mat}_{\mathscr{B},\mathscr{B}}(T)$ is diagonal.

>[!thm]- A set of [[Eigenvectors and Eigenvalues|eigenvectors]] of $T$ corresponding to distinct [[Eigenvectors and Eigenvalues|eigenvalues]] is [[Linear independence|linearly independent]]
>Let $\mathscr{A}=\set{v_{1},...,v_{k}}$ be a set of eigenvectors of $T$. Let $\lambda_{i}$ be the eigenvalue of $v_{i}$ assuming $\lambda_{1},...,\lambda_{k}$ are distinct. We proceed by induction.
>
>Basis: when $k=1$, $\mathscr{A}=\set{v_{1}}$ so it is linearly independent.
>
>Assumptive: assume that if $k>1$ then $\mathscr{A}=\set{v_{1},...,v_{k}}$ is linearly independent.
>
>Inductive: suppose that (eq. 0): $\sum\limits_{i=1}^{k}\alpha_{i}v_{i}=\boldsymbol{0}$.
>Applying $T$: $\sum\limits_{i=1}^{k}\alpha_{i}T(v_{i})=\boldsymbol{0}$ $\implies$ (eq. 1): $\sum\limits_{i=1}^{k}\alpha_{i}\lambda_{i}v_{i}=\boldsymbol{0}$
>Now we multiply (eq. 0) by $\lambda_{k}$ to obtain (eq. 2): $\lambda_{k}\sum\limits_{i=1}^{k}\alpha_{i}v_{i}=\boldsymbol{0}$
>And we calculate $(1)-(2)$: $\sum\limits_{i=1}^{k}\alpha_{i}\lambda_{i}v_{i}-\lambda_{k}\sum\limits_{i=1}^{k}\alpha_{i}v_{i}=\boldsymbol{0}$
>$\implies$ $\sum\limits_{i=1}^{k}\alpha_{i}(\lambda_{i}-\lambda_{k})v_{k}=\boldsymbol{0}$
>$\implies$ $\alpha_{1}(\lambda_{1}-\lambda_{k})v_{1}+\alpha_{2}(\lambda_{2}-\lambda_{k})v_{2}+\ldots+\alpha_{k-1}(\lambda_{k-1}-\lambda_{k})v_{k-1}=\boldsymbol{0}$
>This is an expression of linear dependence involving $v_{1},...,v_{k-1}$, so by induction $\alpha_{i}(\lambda_{i}-\lambda_{k})=0$ for $i=1,2,...,k-1$.
>By assumption the eigenvalues $\lambda_{i}$ are distinct so $\lambda_{i}-\lambda_{k}\neq 0$ for $i=1,2,...,k-1$, and, diving by this non-zero scalar, we deduce $\alpha_{i}=0$ for $i=1,2,...,k-1$.
>Now (eq. 0) forces $\alpha_{k}v_{k}=\boldsymbol{0}$, which forces $\alpha_{k}=0$.

^a9b36a

>[!thm]- The [[Linear transformations|linear transformation]] $T$ is [[Diagonalisability|diagonalisable]] if and only if $C_{T}(x)$ is a product of linear factors and the [[Algebraic multiplicity|algebraic multiplicity]] equals the [[Geometric multiplicity|geometric multiplicity]] for all [[Eigenvectors and Eigenvalues|eigenvalues]] $\lambda$
>Suppose that $C_{T}(x)=(x-\lambda_{1})^{r_{1}}(x-\lambda_{2})^{r_{2}}\cdots(x-\lambda_{k})^{r_{k}}$ where $\lambda_{1},...,\lambda_{k}$ are the distinct eigenvalues of $T$.
>By [[Theorems about characteristic polynomials#^279442|this theorem]], $r_{1}+\cdots+r_{k}=n=\dim V$.
>Let $n_{i}=\dim E_{\lambda_{i}}$ be the geometric multiplicity of $\lambda_{i}$.
>Suppose that $n_{i}=r_{i}$.
>Choose a basis $\mathscr{B}_{i}=\set{v_{i1},v_{i2},...,v_{in_{i}}}$ for each $E_\lambda$ and let $\mathscr{B}=\mathscr{B}_{1}\cup \mathscr{B}_{2} \cup \ldots \cup \mathscr{B}_{k}=\set{v_{ij}:\;i=1,2,...,k;j=1,2,...,n_{i}}$.
>Claim: $\mathscr{B}$ is [[Linear independence|linearly independent]].
>Suppose (eq. 1) $\sum\limits_{\matrix{1 \leqslant j \leqslant k \\ 1 \leqslant j \leqslant n_{i}}}^{} \alpha_{ij}v_{ij}=\boldsymbol{0}$
>Let $w_{i}=\sum\limits_{j=1}^{n_{i}}\alpha_{ij}v_{ij}$. Then $w_{i}$ is a linear combination of vectors in the eigenspace $E_{\lambda_{i}}$ so $w_{i}\in E_{\lambda_{i}}$.
>Now the (eq. 1) can be expressed as $\sum\limits_{i=1}^{k}w_{i}=\boldsymbol{0}$.
>But since $w_{1},...,w_{k}$ are eigenvectors corresponding to distinct eigenvalues, [[Theorems about diagonalisability#^a9b36a|by this theorem]] the vectors $w_{1},...,w_{k}$ are linearly independent.
>This force (eq. 1) to be $w_{i}=\boldsymbol{0} \;\;\forall i=1,2,...,k$.
>That is, $\sum\limits_{j=1}^{n_{i}}\alpha_{ij}v_{ij}=\boldsymbol{0}$.
>Since $\mathscr{B}_{i}$ is a basis for $E_{\lambda_{i}}$, it is linearly independent and we conclude that $\alpha_{ij}=0 \;\;\forall i,j$. Hence $\mathscr{B}$ is a linearly independent set.
>
>Now since $n_{i}=r_{i}$ by assumption,
>$|\mathscr{B}|=n_{1}+n_{2}+\cdots+n_{k}=r_{1}r_{2}+\cdots+r_{k}=n$.
>Hence $\mathscr{B}$ is a linearly independent set of size equal to $\dim V$. Therefore $\mathscr{B}$ is a basis for $V$ and it consists of eigenvectors for $T$. Hence $T$ is diagonalisable.
>
>Conversely, suppose that $T$ is diagonalisable.
>Observe that $C_{T}(x)$ is a product of linear factors. Since $T$ is diagonalisable, there exists a basis$\mathscr{B}$ for $V$ consisting of eigenvectors for $T$.
>Let $\mathscr{B}_{i}=\mathscr{B}\cap E_{\lambda_{i}}$, that is, $\mathscr{B}_{i}$ consists of those vectors from $\mathscr{B}$ that have an eigenvalue $\lambda_{i}$.
>As every vector in $\mathscr{B}$ is an eigenvector, $\mathscr{B}=\mathscr{B}_{1}\cup \mathscr{B}_{2} \cup \ldots \cup \mathscr{B}_{k}$.
>As $\mathscr{B}$ is linearly independent, so is $\mathscr{B}_{i}$ and [[Theorems about dimension#^e45314|this theorem]] tells us $|\mathscr{B}_{i}| \leqslant  \dim E_{\lambda_{i}}=n_{i}$.
>Hence $n=|\mathscr{B}|=|\mathscr{B}_{1}|+|\mathscr{B}_{2}|+\ldots+|\mathscr{B}_{k}|\leqslant  n_{1}+n_{2}+\ldots+n_{k}$
>But $n_{i}\leqslant r_{i}$ and $\sum\limits_{i=1}^{k}r_{i}=n$ so we deduce $n_{i}=r_{i} \;\;\forall i$.
