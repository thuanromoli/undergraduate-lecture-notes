---
tags:
  - MT3508
  - MT3507
aliases:
  - linear model
---
Let $Y$ be an outcome and $X$ be a vector of explanatory variables.

> [!def] Definition
> A general linear model is a special case of a [[Generalised linear models|GLM]], with the following constraints:
> - The random component: the [[Normal distribution|normal distribution]].
> - The linear predictor: $\eta = \boldsymbol{x} \boldsymbol{\beta}$, where $\boldsymbol{x}$ is a row vector of explanatory variables and $\boldsymbol{\beta}$ is a column vector with same length.
> - The link function: $g = \text{id}_\mu$.

For a univariate response we can write
$$\mathbf{y} = \mathbf{X}\boldsymbol{\beta}+ \boldsymbol{\varepsilon}$$
or equivalently,
$$\left( \begin{array}{c}
  y_1 \\
  \vdots \\
  y_n
\end{array} \right) = \left( \begin{array}{ccc}
  x_{11} & \ldots & x_{1k} \\
  \vdots & \ddots & \vdots \\
  x_{n1} & \ldots & x_{nk}
\end{array} \right) \left( \begin{array}{c}
  \beta_1 \\
  \vdots \\
  \beta_k
\end{array} \right) + \left( \begin{array}{c}
  \varepsilon_{1} \\
  \vdots \\
  \varepsilon_{n}
\end{array} \right)$$
where
- $\mathbf{y}$ is the column vector of observations $y_{1},...,y_{n}$.
- $\mathbf{X}$ is an $n\times k$ design matrix.
- $\boldsymbol{\beta}$ is the column vector of parameters $\beta_{1},..., \beta_{k}$.
- $\boldsymbol{\varepsilon}$ is a column vector of errors $\varepsilon_{1},...,\varepsilon_{n}$, where we assume $\boldsymbol{\varepsilon}\sim MVN (\boldsymbol{0}, \boldsymbol{\Sigma})$.
