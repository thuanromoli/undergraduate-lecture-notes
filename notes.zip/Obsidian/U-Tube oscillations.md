---
tags:
  - MT4509
aliases:
---
![[utube_att.png|400]]

Step 1 
Volume flux conservations tells us $u_{2}=u_{1}=u(t)$ since cross-sectional area is constant.

Step 2
Note that $\frac{dh_{2}}{dt}=u_{2}=u$.

Step 3
Use [[Unsteady Bernoulli's Theorem]]
$$\begin{align*}
&\frac{\partial \phi_{1}}{\partial t}+H_{1}= \frac{\partial \phi_{2}}{\partial t}+H_{2}\\
\implies& \frac{\partial \phi_{1}}{\partial t}+ \frac{p_{a}}{\rho}+\frac{1}{2}u^{2}+gh_{1} = \frac{\partial \phi_{2}}{\partial t}+ \frac{p_{a}}{\rho}+\frac{1}{2}u^{2}+gh_{2}\\
\implies& \frac{\partial \phi_{1}}{\partial t}-\frac{\partial \phi_{2}}{\partial t}=gh_{2}-gh_{1}\\
\implies& \frac{\partial }{\partial t}(\phi_{1}-\phi_{2}) = -g (h_{1}-h_{2})
\end{align*}$$
Step 4
The average of $h_{1}$ and $h_{2}$ we can take at $z=0$ by construction $h_{1}=-h_{2}$.
So
$$\frac{\partial }{\partial t}(\phi_{2}-\phi_{1})=-2g h_{2} \tag 1$$
Note by [[Independence of path|this theorem]],
$$\frac{\partial }{\partial t}(\phi_{2}-\phi_{1})= \frac{\partial }{\partial t} \int_{\text{pt }1}^{\text{pt }2}\nabla \phi \cdot d \boldsymbol{l}$$
where $d \boldsymbol{l}=\boldsymbol{n} \cdot dS$. 

So the RHS of (1) is 
$$\begin{align*}
\frac{\partial }{\partial t} \int_{\text{pt }1}^{\text{pt }2}\nabla \phi \cdot d \boldsymbol{l}&= \int_{\text{pt }1}^{\text{pt }2}\frac{\partial }{\partial t} \nabla \phi \cdot d \boldsymbol{l}\\
&= \int_{\text{pt }1}^{\text{pt }2}\frac{\partial \boldsymbol{u}}{\partial t} \cdot d \boldsymbol{l}\\
&= \int_{\text{pt }1}^{\text{pt }2}\frac{\partial (u \boldsymbol{n})}{\partial t} \cdot \boldsymbol{n} \;dS\\
&= \int_{\text{pt }1}^{\text{pt }2}\frac{d u}{d t}\boldsymbol{n} \cdot \boldsymbol{n} \;dS\\
&= \int_{\text{pt }1}^{\text{pt }2}\frac{d u}{d t} \;dS\\
&= \frac{d u}{d t}\int_{\text{pt }1}^{\text{pt }2} \;dS\\
&= \frac{d u}{d t}L\\
&= \frac{d^{2}h_{2}}{d t^{2}}L
\end{align*}$$
So equation (1) is now a second order ODE
$$\frac{d^{2}h_{2}}{d t^{2}}L=-2gh_{2}$$
with general solution
$$h_{2}=A \cos \left(\sqrt{\frac{2g}{L}}t\right)+B \sin \left(\sqrt{\frac{2g}{L}}t\right)$$
with period $T=\frac{1}{f}=\frac{1}{\omega/2\pi}=2 \pi \sqrt{\frac{L}{2g}}$.