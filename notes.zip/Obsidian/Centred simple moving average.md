---
tags:
  - MT4527
aliases:
---
Let $X_{t} = m_{t}+s_{t}+Y_{t},$ be the [[Classical decomposition model|classical decomposition model]], with observations $x_{1},...,x_{t}$ for $t \in \mathbb N_{0}$.

> [!def] Definition
> The centred moving average is the average centred at the time-point of interest.
> 
> If the period $d$ is odd, then
> $$\widehat m_{t}^{{cma}} = (x_{t-q}+x_{t-q+1}+\cdots+x_{t}+\cdots + x_{t+q-1}+x_{t+q})/d$$
> where  $q=(d-1)/2$ and $q < t \leqslant T-q$.
> 
> If the period $d$ is even, then
> $$\widehat m_{t}^{{cma}} = (0.5x_{t-q}+x_{t-q+1}+\cdots+x_{t}+\cdots + x_{t+q-1}+0.5x_{t+q})/d$$
> where $q=d/2$ and $q < t \leqslant T-q$.
