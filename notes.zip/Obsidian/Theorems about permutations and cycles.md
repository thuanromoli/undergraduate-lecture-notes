---
type: thm
tags:
  - MT2505
  - MT4003
---
Let $S_n$ be a [[The symmetric group|symmetric group]] of degree $n$.

>[!thm]- [[Permutations and Cycles|Disjoint cycles]] [[Commutativity|commute]]
>Let $\sigma, \tau\in S_{n}$ be disjoint cycles. We want to show that $\sigma \tau= \tau \sigma$.
>If $\sigma,\tau$ are disjoint then $\set{i_1,\ldots,i_r} \cap\set{j_1,\ldots,j_s}=\varnothing$
>Now we proceed by exhaustion: we show the effect of $\sigma \tau$ and $\tau \sigma$ on $x$.
>- Case 1: $x=i_{k}$ for some $k$.
>$x \sigma=i_{k+1}$ (or $i_{1}$ if $k=r$) 
>Note: both $x$ and $x \sigma$ are fixed by $\tau$
>$x \sigma \tau= i_{k+1} \tau= i_{k+1}=x \sigma$
>$x \tau \sigma= i_{k}\sigma= x \sigma$
>Hence $x\sigma\tau=x\sigma$ and $x\tau\sigma=x\sigma$
>- Case 2: $x=j_{k}$ for some $k$
>$x \tau=j_{k+1}$ (or $j_{1}$ if $k=s$) 
>Note: both $x$ and $x \tau$ are fixed by $\sigma$
>$x \tau \sigma= j_{k+1} \sigma= j_{k+1}=x \tau$
>$x \sigma = j_{k}= x$
>Hence $x\sigma\tau=x\tau$ and $x\tau\sigma=x\tau$
>- Case 3: $x$ is not in either cycle
>$x$ is fixed by both $\sigma$ and $\tau$
>Hence $x\sigma\tau=x\tau=x$ and $x\tau\sigma=x\sigma=x$
>
>Hence $x\sigma\tau=x\tau\sigma \ \ \forall x\in X$.

>[!thm]- Every [[Permutations and Cycles|permutation]] from $S_n$ can be written as a product of [[Permutations and Cycles|disjoint cycles]]

>[!thm]- Every [[Permutations and Cycles|permutation]] from $S_n$ can be written as a product of some [[Permutations and Cycles|transpositions]]

Theorems about the parity.
Let $\sigma \in S_{n}$ be a [[Permutations and Cycles|permutation]] in the [[The symmetric group|symmetric group]] $S_n$.

>[!thm]- The number of [[Permutations and Cycles|transpositions]] occurring in a product that equals $\sigma$ is either always odd or always even.

>[!thm]- Let $\sigma$ be an $r$-[[Permutations and Cycles|cycle]]. If $r$ is odd, then $\sigma$ is an even [[Permutations and Cycles|permutation]].
PROOF:

>[!thm]- Let $\sigma$ be an $r$-[[Permutations and Cycles|cycle]]. If $r$ is even, then $\sigma$ is an odd [[Permutations and Cycles|permutation]].
PROOF:

Theorems about the [[Order|order]].
Let $\sigma, \tau \in S_{n}$ be [[Permutations and Cycles|permutations]] in the [[The symmetric group|symmetric group]] $S_n$.

>[!thm]- If $\sigma$ is an $r$-[[Permutations and Cycles|cycle]] of length $r$, then $|\sigma|=r$

^4bf909

> [!thm]- If $\sigma=\sigma_{1}\sigma_{2}\cdots\sigma_{k}$ is a product of disjoint cycles, then $|\sigma|=\text{lcm}(|\sigma_{1}|,|\sigma_{2}|,...,|\sigma_{k}|)$
> Firstly note that $|\sigma_{i}|=r_{i} \;\;\forall i$ and as disjoin cycles commute, $\sigma^{n}=(\sigma_{1}\sigma_{2}\cdots \sigma_{k})^{n}=\sigma_{1}^{n}\sigma_{2}^{n}\cdots \sigma_{k}^{n}$.
> Let $m = \text{lcm}(r_{1},...,r_{k})$. Then $r_{i} \mid m \;\;\forall i$, so $\sigma_{i}^{m}=(\sigma_{i})^{kr_{i}}=((\sigma_{i})^{r_{i}})^{k}=1^{k}=1$. Therefore $\sigma^{m}=1$.
> On the other hand, if $1 \leqslant n < m$, then $n$ is not a multiple of some $r_{i}$ and therefore, for this value of $i$, $\sigma_{i}^{n}\neq 1$. Then $\sigma^{n}=\sigma_{1}^{n}\sigma_{2}^{n}\cdots \sigma_{k}^{n} \neq 1$ since some point $l$ occurring in the cycle $\sigma_{i}$ is moved by $\sigma_{i}^{n}$, but fixed by $\sigma_{j}^{n} \;\;\forall j\neq i$, and so $l$ is moved by $\sigma^{n}$,
> We conclude that the result holds.

Theorems about [[Conjugacy|conjugacy]].
Let $\sigma=(i_{1}\;\;i_{2}\;\;\cdots\;\; i_{r}), \tau \in S_{n}$ be [[Permutations and Cycles|permutations]] in the [[The symmetric group|symmetric group]] $S_n$.

> [!thm]- $\sigma^{\tau} = (i_{1}\;\;i_{2}\;\;\cdots\;\; i_{r})^{\tau}= (i_{1}\tau\;\;i_{2}\tau\;\;\cdots\;\; i_{r}\tau)$

> [!thm]- $\sigma$ and $\tau$ are [[Conjugacy|conjugates]] if and only if they have the same cycle structure. That is, the same numbers of cycles of each length, when written in disjoin cycle form.

Below is not needed for MT4003.

>[!thm]- Every [[Permutations and Cycles|permutation]] from $S_n$ can be written as a product of the [[Permutations and Cycles|transpositions]] $(1 \ \ 2),(2\ \ 3),...,(n\text{-}1\ \ n)$

>[!thm]- Every [[Permutations and Cycles|permutation]] from $S_n$ can be written as a product of the [[Permutations and Cycles|transpositions]] $(1 \ \ 2)$ and the $n$-[[Permutations and Cycles|cycle]] $(1 \ \ 2 \ \ ... \ \ n)$
