---
tags:
  - MT4528
type: 
aliases:
---
Let $\set {X(t):t \geqslant 0}$ be a [[Markov chains and processes|Markov process]] and let $W_{i}$ be the [[Sojourn time|sojourn time]].

>[!thm]- $W_{i}$ is memoryless. That is, $\mathbb P(W_{i}>s+t | W_{i} >s)=\mathbb P(W_{i}>t)$
>$$\begin{align*}
   \mathbb P(W_{i}>s+t | W_{i} >s) &= \mathbb P(X(u)=i, 0 \leqslant u \leqslant s+t|X(u)=i,0 \leqslant u \leqslant s)\\
   &= \mathbb P(X(u)=i, s \leqslant u \leqslant s+t|X(u)=i,0 \leqslant u \leqslant s)\\
   &= \mathbb P(X(u)=i, s \leqslant u \leqslant s+t|X(s)=i)\\
   &= \mathbb P(X(u)=i, 0 \leqslant u \leqslant t|X(0)=i)\\
   &= \mathbb P(W_{i}>t)
   \end{align*}$$

>[!thm]- $W_{i}\sim \text{Exp}(\lambda_{i})$.
 Proof is omitted and requires some real analysis.

>[!gen] Remarks
>- given a transition away from state $i$, the probability that the process enters a state $j\neq i$ is $p_{ij}$.
>- $p_{ii}=0 \;\;\forall i \in S$
>- $\sum\limits_{j\in S}^{}p_{ij}=1 \;\;\forall i\in S$.
