---
alias: hypothesis test
type: def
tag: MT2508
---
>[!def] Definition
>An hypothesis test is a rule of the form 'Reject $H_{0}$ in favour of $H_1$ if $T \in C$' where $C$ is the [[Critical regions|critical region]] of the test.
