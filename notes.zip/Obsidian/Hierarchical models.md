---
tags:
  - MT4531
aliases:
---
We consider an example.
Suppose we are interested in predicting the occurrence of large earthquakes on a particular fault in southern California. Let $Y_{0}$ be the inter-event times between earthquakes in a fault in California. On this particular fault, there have only ever been 5 large earthquakes in the last 100 years.
We have
$$Y_{0}=(10,25,37,22)$$
and the model is as follows:
$$\begin{align*}
Y_{0} &\sim \text{Expon}(\lambda_{0})\\
\lambda_{0} &\sim \Gamma(\alpha,\beta)\\
(\implies)\quad   Y_{0} | \lambda_{0} &\sim \Gamma(\alpha+n,\beta+ \sum\limits_{i}^{n}Y_{i}).
\end{align*}$$
Note that there are several other faults in Southern California which also have data on their respective earthquakes. It would be sensible to use somehow these data to inform our choice of prior for $\alpha$ and $\beta$.

Therefore, we want to use the data from other faults $Y_{1},Y_{2},...$.
We assume that $Y_{k} \sim \text{Exp}(\lambda_{k})$, with $\lambda_{k}$ denoting inter-event times on fault $k$. Furthermore, let $Y_{k,i}$ be the $i$th inter-arrival time on fault $k$ and let $n_{k}$ be the number of earthquakes on fault $k$.
We are only interested in $\lambda_{0}$.

> [!gen]- No pooling
> Assume that there is no statistical relationship between the different faults and analyse each independently, so we have again
> $$ Y_{0} | \lambda_{0} \sim \Gamma(\alpha+n,\beta+ \sum\limits_{i}^{n}Y_{i}).$$
> Cons: not enough data.

> [!gen]- Complete pooling
> Assume that every fault is exactly the same so that all inter-event times have the same distribution i.e. that $\lambda_{0}=\lambda_{1}=\cdots=\lambda_{K}$.
> Hence, we have only a single value $\lambda$ to estimate, and $n_{0}+n_{1}+\cdots+n_{K}$ observations. The posterior is now
> $$\lambda_{0}|Y_{0},Y_{1},\dots,Y_{K} \sim \Gamma \left( \alpha +
\sum_{k}n_{k},\quad \beta + \sum_{k}\sum_{i}Y_{k,i} \right).$$
> Cons: if assumption is violated, we may do worse than no pooling, since our data will bias our estimate away from its true value.

> [!gen] Hierarchical modelling
> We use these other data sets to choose an appropriate prior for our analysis.
> In other words, we will assume that each of the values of $\lambda_{i}$ are independent samples from some distribution $p(\lambda)$. Our model is hence:
> $$\begin{align*}
Y_{k}&\sim \text{Exp}(\lambda_{k})\\
\lambda_{k}&\sim \Gamma(\alpha,\beta)\\
\alpha,\beta&\sim p(\alpha,\beta)
\end{align*}$$
> We shift our focus and we treat $\lambda_{k}$ as the data, $\alpha, \beta$ as the priors and hence we wish to find the posterior $\lambda_{k}|\alpha, \beta$.
> 
> A key point is that we treat $\alpha$ and $\beta$ as parameters to be estimated along with the $\lambda_{k}$ i.e. we put a prior on $\alpha$ and $\beta$ and learn them from the data. We will treat them simply as extra unknown parameters. Note that, conditional on $\alpha$ and $\beta$, we are estimating each $\lambda_{k}$ independently of all the others (no pooling). But then we update $\alpha$ and $\beta$ using all the $\lambda_{k}$ values (complete pooling). As a consequence, the estimate of $\lambda_{0}$ will shrink towards an overall mean $\alpha/\beta$, borrowing strength from the other estimates $\lambda_{k}$ indirectly through $\alpha$ and $\beta$.
> 
> The parameters $\lambda_{k}$ are often called ‘random effects’. Depending on the particular analysis, random effects can be either considered as auxiliary variables or parameters of interest (as in our example).
> 
> In general, suppose we have model parameters $\boldsymbol{\theta}$ and random effects $\boldsymbol{\lambda}$, we can form the join posterior distribution as
> $$\pi(\boldsymbol{\theta}, \boldsymbol{\lambda}|Y)\propto f(Y|\boldsymbol{\theta}, \boldsymbol{\lambda})p(\boldsymbol{\lambda}|\boldsymbol{\theta})p(\boldsymbol{\theta}).$$
