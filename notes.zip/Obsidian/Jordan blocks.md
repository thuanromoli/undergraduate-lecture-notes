---
tags:
  - MT3501
type: def
aliases:
  - Jordan block
---
>[!def] Definition
>A Jordan block is an $n \times n$ [[Matrices|matrix]] of the form
>$$J_{n}(\lambda)=\begin{pmatrix}
   \lambda & 1 & 0 & \cdots  & 0 \\
   0 & \lambda & 1 & \cdots  & 0 \\ 
   0 & 0 & \ddots & \ddots & \vdots \\ 
   \vdots & \vdots & &\ddots & 1 \\ 
   0 & 0 & \cdots & 0 & \lambda
   \end{pmatrix}$$
