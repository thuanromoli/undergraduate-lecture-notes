- Situation: the title description
- Action: Che cosa ho fatto per raggiungere l'obbiettivo (generale -> dettaglio) + come mi ha migliorato personalmente (soft/hard skills)
- Result: Metti un report di quello che è successo alla fine (usa numeri e figure se possibile)

Cosa ho fatto in generale e poi nel dettaglio. Che skill ho usato per raggiungere e risultati.

*Action verb* ..., specifically ... . Using *soft skills*, *results*.
