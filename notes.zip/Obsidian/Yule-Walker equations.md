---
tags:
  - MT4527
aliases:
---
Let $(X_{t})_{t \in \mathbb Z}$ be an [[AR(p) Process]] such that
$$X_{t}=\phi_{1} X_{t-1}+\cdots+\phi_{p}X_{t-p}+\varepsilon_{t}$$

> [!def] Definition
> The Yule-Walker equations are the equations for the autocorrelation coefficients $\rho_{X}(h)$, for $h=1,2,\ldots,p-1$. Explicitly,
> $$\rho_{X}(h) = \phi_{1}\rho_{X}(h-1)+\phi_{2}\rho_{X}(h-2)+\cdots+\phi_{p}\rho_{X}(h-p)$$
> with initial conditions
> $$\phi_{X}(0)=1, \qquad \rho_{X}(h)=\rho_{X}(-h), \qquad \text{for }h=1,2,...,p-1.$$

Motivation.
Start with
$$X_{t}=\phi_{1} X_{t-1}+\cdots+\phi_{p}X_{t-p}+\varepsilon_{t}$$
and multiply by $X_{t-h}$ for $h=1,...,p-1$.
$$\begin{align*}
X_{t}X_{t-1}&=\phi_{1} X_{t-1}X_{t-1}+\cdots+\phi_{p}X_{t-p}X_{t-1}+\varepsilon_{t}X_{t-1}\\
X_{t}X_{t-2}&=\phi_{1} X_{t-1}X_{t-2}+\cdots+\phi_{p}X_{t-p}X_{t-2}+\varepsilon_{t}X_{t-2}\\
&\vdots\\
X_{t}X_{t-p+1}&=\phi_{1} X_{t-1}X_{t-p+1}+\cdots+\phi_{p}X_{t-p}X_{t-p+1}+\varepsilon_{t}X_{t-p+1}
\end{align*}$$
Note that $\mathbb E(X_{t})=0$ for all $t$ and that $\mathbb E(\varepsilon_{t}X_{t-h})=\mathbb E(\varepsilon_{t})\mathbb E(X_{t-h})=0$. Furthermore
$$\begin{align*}
\gamma_{X}(h)&=\text{Cov}(X_{t},X_{t+h})\\
&=\mathbb E[(X_{t}-\mathbb E(X_{t}))(X_{t+h}-\mathbb E(X_{t+h}))]\\
&= \mathbb E(X_{t}X_{t+h})
\end{align*}$$
Take the expectation of the equations above to obtain, for $h=1,2,...,p-1$
$$\begin{align*}
&X_{t}X_{t-h}=\phi_{1} X_{t-1}X_{t-h}+\cdots+\phi_{p}X_{t-p}X_{t-h}+\varepsilon_{t}X_{t-h}\\
\implies& \mathbb E(X_{t}X_{t-h})=\phi_{1} \mathbb E(X_{t-1}X_{t-h})+\cdots+\phi_{p}\mathbb E(X_{t-p}X_{t-h})+\mathbb E(\varepsilon_{t}X_{t-h})\\
\implies& \gamma_{X}(h)= \phi_{1} \gamma_{X}(h-1) + \cdots+\phi_{p} \gamma_{X}(h-p).
\end{align*}$$
Now dividing through by $\gamma_{X}(0)$, yields the required result.