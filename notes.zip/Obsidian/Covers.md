---
tags:
  - MT3502
aliases:
  - cover
---
Let $A \subseteq X$ be a subset.

> [!def] Covers
> A cover of a set $A$, namely $\mathcal U$, is a collection of distinct sets $\mathcal U=\set{U_{1},U_{2},...}$ such that
> $$A \subseteq \bigcup_{i \in I}U_{i}.$$

> [!def] Open covers
> $\mathcal U$ is an open cover of $A$ when $(X,d)$ is a [[Metric spaces|metric space]] and each $U_{i}$ is [[Open sets|open]].

> [!def] Subcovers
> A subcover of a set $A$ is a cover $\mathcal U'=\set{U'_{1},U'_{2},...}$ of $A$ where $U'_{i} \in \mathcal U$ for all $i$.
