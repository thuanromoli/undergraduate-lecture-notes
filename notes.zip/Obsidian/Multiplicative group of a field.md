---
type: thm
tag: MT2505
---
Let $F$ be a [[Fields (Algebra)|field]].

>[!def] Definition
>The multiplicative group of a field is the set of non-zero elements in $F$: $$F^{*}=F \setminus \set 0$$

>[!thm] Theorem
>$F^{*}$ is an [[Abelian groups|abelian group]] under the multiplication of $F$.
