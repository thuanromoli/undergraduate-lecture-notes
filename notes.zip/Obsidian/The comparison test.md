---
tags:
  - MT2502
aliases:
---
Let $(x_{n})_{n}$ and $(a_{n})_{n}$ be [[Sequences|sequences]] with no negative terms, and let $\sum\limits_{x=1}^{\infty}x_{n}$ and $\sum\limits_{x=1}^{\infty}a_{n}$ be their [[Series|series]].

> [!thm] Convergence
> If $\sum\limits_{n=1}^{\infty}a_{n}$ is [[Convergence|convergent]] and $x_{n} \leqslant a_{n}$ for all $n \in \mathbb N$, then $\sum\limits_{n=1}^{\infty}x_{n}$ is convergent.
> 
> In other words, if $\sum\limits_{n=1}^{\infty}a_{n}$ is [[Convergence|convergent]] and there exists an $N \in \mathbb N$ and $c>0$ such that $x_{n} \leqslant ca_{n}$ for all $n \geqslant  N$, then $\sum\limits_{n=1}^{\infty}x_{n}$ is convergent.

> [!thm] Divergence
> If $\sum\limits_{n=1}^{\infty}a_{n}$ is [[Convergence|divergent]] and $x_{n} \geqslant a_{n}$ for all $n \in \mathbb N$, then $\sum\limits_{n=1}^{\infty}x_{n}$ is divergent.
> 
> In other words, if $\sum\limits_{n=1}^{\infty}a_{n}$ is divergent and there exists an $N \in \mathbb N$ and $c>0$ such that $x_{n} \geqslant  ca_{n}$ for all $n \geqslant  N$, then $\sum\limits_{n=1}^{\infty}x_{n}$ is divergent.
