---
tags:
  - MT3501
type: thm
aliases:
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $T:V\to V$ be a [[Linear transformations|linear transformation]].

>[!def] Definition of the problem
>If the [[Characteristic polynomials|characteristic polynomial]] $c_{T}(x)$ is a product of linear factors, find a [[Bases|basis]] $\mathscr{B}$ with respect to which $T$ is in [[Jordan normal form]] and determine what this Jordan normal form is.

>[!gen] Intuition
>If $\mathscr{B}$ is the basis solving this problem, then
>$$\text{Mat}_{\mathscr B,\mathscr B}(T)=A=\begin{pmatrix}
   J_{n_{1}}(\lambda_{1}) \\
   & J_{n_{2}}(\lambda_{2}) & 0 \\
   & 0 & \ddots \\
   & & &J_{n_{k}}(\lambda_{k})
   \end{pmatrix}$$
>where $J_{n_{1}}(\lambda_{1}),...,J_{n_{k}}(\lambda_{k})$ are [[Jordan blocks|Jordan blocks]].

>[!thm] Observation 1
>The [[Algebraic multiplicity|algebraic multiplicity]] of $\lambda$ as an [[Eigenvectors and Eigenvalues|eigenvalue]] of $T$ equals the sum of the sizes of the [[Jordan blocks]] $J_{n}(\lambda)$ occurring in the [[Jordan normal form]] for $T$.
>
>Proof:
>When we calculate $C_{T}(x)$ each Jordan block contributes a factor of $(x-\lambda_{i})^{n_{i}}$ [[Theorems about Jordan normal form#^9bd163|by this theorem]].

>[!thm] Observation 2
>If $\lambda$ is an [[Eigenvectors and Eigenvalues|eigenvalue]] of $T$, then the power of $(x-\lambda)$ occurring in the [[Minimum polynomial|minimum polynomial]] $m_{T}(x)$ is $(x-\lambda)^{m}$ where $m$ is the largest size of a Jordan block associated to $\lambda$ occurring in the Jordan normal form for $T$.
>
>Proof:
>To ensure the block $J_{n_{i}}(\lambda_{i})$ becomes $0$ when we substitute $A$ into the [[Minimum polynomial|minimum polynomial]], we must have at least a factor $(x-\lambda_{i})^{n_{i}}$ [[Theorems about Jordan normal form#^1e9b25|by this theorem]].

>[!thm] Observation 3
>The [[Geometric multiplicity|geometric multiplicity]] of $\lambda$ as an [[Eigenvectors and Eigenvalues|eigenvalue]] of $T$ equals the number of [[Jordan blocks]] $J_{n}(\lambda)$ occurring in the [[Jordan normal form]] for $T$.
>
>Proof:
>Each block $J_{n}(\lambda)$ occurring in $A$ contributes one [[Linear independence|linearly independent]] [[Eigenvectors and Eigenvalues|eigenvector]] to a [[Bases|basis]] for the [[Eigenspaces|eigenspace]] $E_\lambda$ [[Theorems about Jordan normal form#^5f5ee2|by this theorem]].
>Thus the number of blocks in $A$ corresponding to a particular eigenvalue $\lambda$ will equal $\dim E_\lambda=n_\lambda$.
