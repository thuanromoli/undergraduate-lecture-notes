---
tags:
  - MT4551
aliases:
---
Consider the [[The Black-Scholes equation - derivation|Black-Scholes equation]] $\frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2}V}{\partial S^{2}} + rS \frac{\partial V}{\partial S} -rV =0$.

> [!thm] Theorem
> The general solution to the [[The Black-Scholes equation - derivation|Black-Scholes equation]] is
> $$V(S,t) = e^{-r(T-t)}\int_{0}^{\infty} V(S',T)P(S')dS'$$
> where
> $$P(S') = \frac{1}{\sqrt{2 \pi \sigma^{2}(T-t)}}\cdot \frac{1}{S'} \cdot \exp \left\{ - \frac{[\ln S' - \ln S - (r - \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} \right\}$$
> that is, the log-normal [[Share prices - pdf|pdf of the share price]] but with $\mu$ replaced by $r$ and $P(S')dS'$ is the probability of finding $S$ in the interval $[S,S']$ if the share price is $S$ at time $t$.
> Hence the general solution is the expected value of $V$ discounted to the present time.

Proof:
Our aim is to reduce the B-S equation to the [[Diffusion equation - derivation|diffusion equation]] of which we know the [[Diffusion equation - solution|solution]].
$$\underbrace{\frac{\partial V}{\partial t}}_{(1)} + \underbrace{\frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2}V}{\partial S^{2}}}_{(2)} + \underbrace{rS \frac{\partial V}{\partial S}}_{(3)} - \underbrace{rV}_{(4)} =0.$$
Consider first (1) and (4). Their relationship suggests an exponential dependence.
We choose the substitution
$$V(S,t) = v(S,t)e^{rt}$$ where $v(S,t) = V(S,t) e^{-rt}$ is the value of the FD discounted to $t = 0$. Therefore
$$\begin{align*}
&(1) \implies \frac{\partial V}{\partial t} = \frac{\partial v}{\partial t}e^{rt}+vre^{rt} = \left(\frac{\partial v}{\partial t} +vr\right)e^{rt}\\
&(3) \implies \frac{\partial V}{\partial S} = \frac{\partial v}{\partial S} e^{rt}\\
&(2) \implies \frac{\partial^{2}V}{\partial S^{2}} = \frac{\partial ^{2}v}{\partial S^{2}} e^{rt}\\
&(4) \implies V = ve^{rt}
\end{align*}$$
So our equation is now
$$\begin{align*}
&\frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2}V}{\partial S^{2}} + rS \frac{\partial V}{\partial S} -rV =0\\
\implies & \left(\frac{\partial v}{\partial t} +vr\right)e^{rt} + \frac{1}{2} \sigma^{2} S^{2} \frac{\partial ^{2}v}{\partial S^{2}} e^{rt} + rS \frac{\partial v}{\partial S} - rve^{rt}=0\\
\implies & \frac{\partial v}{\partial t} + vr + \frac{1}{2} \sigma^{2} S^{2} \frac{\partial ^{2}v}{\partial S^{2}} + rS \frac{\partial v}{\partial S} - rv=0\\
\implies & \frac{\partial v}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial ^{2}v}{\partial S^{2}} + rS \frac{\partial v}{\partial S} = 0
\end{align*}$$
and we have reduced it to three terms by eliminating (4).

We consider two changes of variable:
- Impose the [[Boundary conditions|boundary conditions]] at $T$ and then back track to an earlier time, we obtain
  $$\tau = T-t.$$
- Using the fact that $d(\ln S) = (\mu - \frac{1}{2}\sigma^{2})dt+\sigma dW$, we suggest
  $$y = \ln S - (r - \frac{1}{2}\sigma^{2})t.$$

Now we apply the new variables to the equation by noting $v(y,\tau)=v(y(S,t),\tau(t)) = v(S,t)$.
$$\begin{align*}
&(1) \implies \frac{\partial v}{\partial t} = \frac{\partial v}{\partial \tau}\frac{\partial \tau}{\partial t} + \frac{\partial v}{\partial y}\frac{\partial y}{\partial t} = \frac{\partial v}{\partial \tau} (-1) +\frac{\partial v}{\partial y}(-(r- \frac{1}{2}\sigma^{2}))=-\frac{\partial v}{\partial \tau} - (r - \frac{1}{2}\sigma^{2}) \frac{\partial v}{\partial y}\\
&(3) \implies \frac{\partial v}{\partial S} = \frac{\partial v}{\partial \tau}\frac{\partial \tau}{\partial S} + \frac{\partial v}{\partial y}\frac{\partial y}{\partial S} = 0 + \frac{\partial v}{\partial y} \left(\frac{1}{S}\right) = \frac{1}{S}\frac{\partial v}{\partial y} \\
&(2) \implies \frac{\partial^{2}v}{\partial S^{2}} = \frac{\partial }{\partial S}\left(\frac{1}{S} \frac{\partial v}{\partial y}\right) = - \frac{1}{S^{2}} \frac{\partial v}{\partial y} + \frac{1}{S} \frac{\partial ^{2}v}{\partial y^{2}} \frac{\partial y}{\partial S} =  - \frac{1}{S^{2}}\frac{\partial y}{\partial v} + \frac{1}{S^{2}} \frac{\partial v^{2}}{\partial y^{2}}
\end{align*}$$
Now our equation becomes
$$\begin{align*}
& \frac{\partial v}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial ^{2}v}{\partial S^{2}} + rS \frac{\partial v}{\partial S} = 0\\
\implies & -\frac{\partial v}{\partial \tau} - (r - \frac{1}{2}\sigma^{2}) \frac{\partial v}{\partial y} + \frac{1}{2} \sigma^{2}S^{2} \left(- \frac{1}{S^{2}} \frac{\partial v}{\partial y} + \frac{1}{S^{2}}\frac{\partial^{2} v}{\partial y^{2}}\right) + rS \left(\frac{1}{S}\frac{\partial v}{\partial y} \right) = 0\\
\implies & -\frac{\partial v}{\partial \tau} - r \frac{\partial v}{\partial y} + \frac{1}{2}\sigma^{2} \frac{\partial v}{\partial y} - \frac{1}{2} \sigma^{2} \frac{\partial v}{\partial y} + \frac{1}{2}\sigma^{2} \frac{\partial^{2}v}{\partial y^{2}} + r\frac{\partial v}{\partial y} = 0\\
\implies & - \frac{\partial v}{\partial \tau} + \frac{1}{2}\sigma^{2} \frac{\partial ^{2} v}{\partial y^{2}} = 0\\
\implies& \frac{\partial v}{\partial \tau } = \frac{1}{2} \sigma^{2}\frac{\partial ^{2}v}{\partial y^{2}}
\end{align*}$$
that is, the diffusion equation. Hence we know that the solution to it is
$$v(y,\tau) = \frac{1}{\sqrt{2 \pi \sigma^{2} \tau}} \int_{-\infty}^{\infty}v(y',0) \exp\left\{  - \frac{(y-y')^{2}}{2 \sigma^{2} \tau}  \right\} dy'.$$

Now we substitute back the original variables by noting that $v'(y',0)=V'(S',T)e^{-rt}$ and $y'=y'(S',T)$ and $dy' = \frac{1}{S'}dS'$ as $v(y',0) \implies \tau = 0 \implies t = T$.
$$\begin{align*}
V(S,t)e^{-rt} &= \frac{1}{\sqrt{2 \pi \sigma^{2} (T-t)}} \int_{0}^{\infty}V(S',T) e^{-rT} \exp\left\{  - \frac{[\ln S - (r - \frac{1}{2}\sigma^{2})t - (\ln S' - (r - \frac{1}{2}\sigma^{2})T)]^{2}}{2 \sigma^{2} (T-t)}  \right\} \frac{1}{S'}dS'\\
V(S,t) &= \frac{e^{rt} }{\sqrt{2 \pi \sigma^{2} (T-t)}} \int_{0}^{\infty}V(S',T) e^{-rT} \exp\left\{  - \frac{[\ln S - \ln S' + (r - \frac{1}{2}\sigma^{2})(T-t)]^{2}}{2 \sigma^{2} (T-t)}  \right\} \frac{1}{S'}dS'\\
V(S,t) &= \frac{e^{rt}e^{-rT} }{\sqrt{2 \pi \sigma^{2} (T-t)}} \int_{0}^{\infty}V(S',T)  \frac{1}{S'}\exp\left\{  - \frac{[\ln S - \ln S' + (r - \frac{1}{2}\sigma^{2})(T-t)]^{2}}{2 \sigma^{2} (T-t)}  \right\}dS'\\
V(S,t) &= e^{-r(T-t)}\int_{0}^{\infty}V(S',T)  \frac{1}{\sqrt{2 \pi \sigma^{2} (T-t)}} \frac{1}{S'}\exp\left\{  - \frac{[\ln S - \ln S' + (r - \frac{1}{2}\sigma^{2})(T-t)]^{2}}{2 \sigma^{2} (T-t)}  \right\}dS'\\
V(S,t) &= e^{-r(T-t)}\int_{0}^{\infty}V(S',T) P(S')dS'
\end{align*}$$
where
$$P(S') =  \frac{1}{\sqrt{2 \pi \sigma^{2} (T-t)}} \frac{1}{S'}\exp\left\{  - \frac{[\ln S - \ln S' + (r - \frac{1}{2}\sigma^{2})(T-t)]^{2}}{2 \sigma^{2} (T-t)}  \right\}.$$