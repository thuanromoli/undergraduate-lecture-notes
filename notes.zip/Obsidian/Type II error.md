---
type: def
tags:
  - MT2508
  - MT3507
---
>[!def] Definition
>A Type II error occurs when we fail to reject the [[Statistical hypothesis|null hypothesis]] when it is false.
