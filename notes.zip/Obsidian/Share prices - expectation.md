---
tags:
  - MT4551
aliases:
---
Consider the [[Geometric Brownian motion|geometric Brownian share price model]] $dS = \mu S dt + \sigma S dW$.

> [!thm] Theorem
> The [[Expectation|expectation]] of the share price $S$ is
> $$\bar S = S_{0}e^{\mu t}$$

Proof:
By definition,
$$\begin{align*}
\mathbb E(S) &= \int_{-\infty}^{\infty} SP(S)dS\\
&=\int_{0}^{\infty}S \frac{1}{\sqrt{2 \pi \sigma^{2} t}} \frac{1}{S} \exp\left\{-\frac{\left[\ln(S/S_{0}) - (\mu - \frac{1}{2}\sigma^{2})t\right]^{2}}{2 \sigma^{2}t}\right\}dS\\
&=\frac{1}{\sqrt{2 \pi \sigma^{2} t}}\int_{0}^{\infty} \exp\left\{-\frac{\left[\ln(S/S_{0}) - (\mu - \frac{1}{2}\sigma^{2})t\right]^{2}}{2 \sigma^{2}t}\right\}dS.
\end{align*}$$
Using the substitution $y = \ln \frac{S}{S_{0}}\implies S=S_{0}e^{y}$, $dy = \frac{1}{S} dS \implies dS = S dy=S_{0}e^{y}dy$, we obtain
$$\begin{align*}
\mathbb E(S) &= \frac{1}{\sqrt{2 \pi \sigma^{2} t}}\int_{-\infty}^{\infty} \exp\left\{-\frac{\left[y - (\mu - \frac{1}{2}\sigma^{2})t\right]^{2}}{2 \sigma^{2}t}\right\}S_{0}e^{y}dy\\
&= \frac{S_{0}}{\sqrt{2 \pi \sigma^{2} t}}\int_{-\infty}^{\infty} \exp\left\{y-\frac{\left[y - (\mu - \frac{1}{2}\sigma^{2})t\right]^{2}}{2 \sigma^{2}t}\right\}dy\\
&= \frac{S_{0}}{\sqrt{2 \pi \sigma^{2} t}}\int_{-\infty}^{\infty} \exp\left\{y-\frac{\left[y - (\mu t - \frac{1}{2}\sigma^{2}t)\right]^{2}}{2 \sigma^{2}t}\right\}dy
\end{align*}$$
Now consider the exponent and let $A = \mu t- \frac{1}{2}\sigma^{2}t$
$$\begin{align*}
y-\frac{\left[y - (\mu - \frac{1}{2}\sigma^{2})t\right]^{2}}{2 \sigma^{2}t} &= - \frac{1}{2 \sigma^{2}t}((y-A)^{2}-2y \sigma^{2}t)\\
&= - \frac{1}{2 \sigma^{2}t}((y^{2}-2yA +A^{2}-2y \sigma^{2}t)\\
&= - \frac{1}{2 \sigma^{2}t}((y^{2}-2y(A+\sigma^{2}t) +A^{2})\\
&= - \frac{1}{2 \sigma^{2}t}((y^{2}-2y(\mu t- \frac{1}{2}\sigma^{2}t+\sigma^{2}t) +A^{2})\\
&= - \frac{1}{2 \sigma^{2}t}((y^{2}-2y(\mu t+ \frac{1}{2}\sigma^{2}t) +A^{2})\\
&= - \frac{1}{2 \sigma^{2}t}\left(\left(y-\left(\mu t+ \frac{1}{2}\sigma^{2}t\right)\right)^{2} -\left(\mu t+ \frac{1}{2}\sigma^{2}t\right)^{2} +(\mu t- \frac{1}{2}\sigma^{2}t)^{2}\right)\\
&= - \frac{1}{2 \sigma^{2}t}\left(\left(y-\left(\mu t+ \frac{1}{2}\sigma^{2}t\right)\right)^{2} - (\mu^{2} t^{2}+\mu t\sigma^{2}t+ \frac{1}{4}\sigma^{4}t^{2})+(\mu^{2}t^{2}-\mu t\sigma^{2}t+ \frac{1}{4}\sigma^{4}t^{2})\right)\\
&=  -\frac{1}{2 \sigma^{2}t} \left(\left(y- \left(\mu  t+ \frac{1}{2}\sigma^{2}t\right)\right)^{2}-2\mu t \sigma^{2}t\right)\\
&=  -\frac{1}{2 \sigma^{2}t} \left(\left(y- \left(\mu t+ \frac{1}{2}\sigma^{2}t\right)\right)^{2}\right)+\mu t.\\
\end{align*}$$
So
$$\begin{align*}
\mathbb E(S) &= \frac{S_{0}}{\sqrt{2 \pi \sigma^{2} t}}\int_{-\infty}^{\infty} \exp\left\{-\frac{\left(y- \left(\mu t+ \frac{1}{2}\sigma^{2}t\right)\right)^{2}}{2 \sigma^{2}t} + \mu t\right\}dy\\
&= \frac{S_{0} e^{\mu t}}{\sqrt{2 \pi \sigma^{2} t}}\int_{-\infty}^{\infty} \exp\left\{-\frac{\left(y- \left(\mu t+ \frac{1}{2}\sigma^{2}t\right)\right)^{2}}{2 \sigma^{2}t}\right\}dy\\
&= S_{0} e^{\mu t}\frac{1}{\sqrt{2 \pi \sigma^{2} t}}\int_{-\infty}^{\infty} \exp\left\{-\frac{\left(y- \left(\mu t+ \frac{1}{2}\sigma^{2}t\right)\right)^{2}}{2 \sigma^{2}t}\right\}dy\\
&= S_{0} e^{\mu t}.
\end{align*}$$
