---
type: def
tag: MT2506
---
see lecture notes