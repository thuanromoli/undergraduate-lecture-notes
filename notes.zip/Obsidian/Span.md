---
tags:
  - MT2501
  - MT3501
type: def
aliases:
  - span
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$, and let $v_{1},...,v_{k}$ be some vectors from $V$.

>[!def] Definition
>The set of all [[linear combinations]] of $\mathscr{A} = \set{v_{1},...,v_{k}}$ is called the span of $\mathscr{A}$, it is denoted by $\text{Span}(\mathscr A)$ or $\text{Span}(v_{1},...,v_{k})$.
