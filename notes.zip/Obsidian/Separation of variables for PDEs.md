---
tags:
  - MT3504
type: mthd
aliases:
---
>[!gen] General method
>1. Convert to homogeneous problem.
>2. Write $u(x,t)=X(x)T(t)$.
>3. Substitute  $u(x,t)$ into the PDE and separate the two variables:
>	- put all $X$ on one side and $T$ on the other side.
>	- both side equal a constant called separation constant $\lambda$.
>4. Identify the variable that is subject to homogeneous [[Boundary conditions|boundary conditions]] and solve that ODE first. The BVP will determine $\lambda$ and the corresponding solution (we obtain a discrete family of $\lambda$).
>5. Solve the other ODE.
>6. Combine the solutions into a series solution of [[linear superposition|linear superpositions]], summing over the possible separation constants.
>7. Use the [[Initial values and IVP|initial values]] (or other boundary) conditions to determine coefficients and use [[Orthogonality|orthogonality]].
