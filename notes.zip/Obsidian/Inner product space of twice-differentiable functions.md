---
tags:
  - MT3504
type: def
aliases:
  - inner product space of twice-differentiable functions
---
Let $C^{2}(a,b)$ be the [[Vector spaces|vector space]] of twice-[[Differentiability|differentiable]] functions on $(a,b)$ over the [[Fields (Algebra)|field]] $\mathbb C$.

>[!def] Definition
>$C^{2}(a,b)$ is an [[Inner product spaces|inner product space]] with inner product
>$$(f,g)= \int_{a}^{b} w(x)f(x)g(x)dx$$
