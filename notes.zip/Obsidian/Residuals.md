---
type: def
tag: MT2508
alias: residuals
---
> [!def] Definition
> The residual is the difference between the observed value and the estimated value of the quantity of interest.
> We want a residual to have the following qualities:
> - Contain what is not explained by a fitted model.
> - Not contain what is explained by a fitted model.
> 
> This is to ensure that, when we plot residuals, if we see trends then we know our model is wrong.

> [!def] Raw residuals
> The raw residuals are defined as 
> $$\widehat {\varepsilon_{i}}=y_{i}-\widehat {\mu_{i}}.$$

> [!def] Pearson residuals
> The Pearson residuals are defined as 
> $$\widehat {\varepsilon^{P}_{i}} = \frac{y_{i}-\widehat {\mu_{i}}}{\sqrt{V(\widehat {\mu_{i}})}}$$
> where we recall $X^{2} = \sum\limits_{i=i}^{n}(\widehat {\varepsilon^{P}_{i}})^{2}$ is the [[Pearson test]] statistic.

> [!def] Deviance residuals
> The deviance residuals are defined as 
> $$\widehat {\varepsilon^{D}_{i}} = \text{sign}(y_{i}-\widehat {\mu_{i}}) \cdot \sqrt{d_{i}}$$
> where $D=\sum\limits_{i=1}^{n}d_{i}$.
