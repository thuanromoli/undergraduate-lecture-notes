---
type: thm
tags:
  - MT2505
  - MT4003
---
Let $G$ be a [[Groups|group]] and $H$ be a [[Subgroups|subgroup]] of $G$ and $x,y \in G$.
Let $Hx,Hy$ be right [[Cosets|cosets]] of $H$ in $G$.

>[!thm]- $Hx=Hy \iff xy^{-1}\in H$
>- RTP: $Hx=Hy \implies xy^{-1}\in H$.
>Consider $x=1x \in Hx$;
>$x\in Hy$;
>$x=hy$ for some $h\in H$;
>$h=xy^{-1} \in H$.
>- RTP: $xy^{-1}\in H \implies  Hx=Hy$.
>Let $h\in H$;
>$Hx=\set{hx:h\in H}$ and $Hy=\set{hy:h\in H}$;
>a typical element of $Hx$ is $hx=h(xy^{-1})y \in Hy$ since $h,xy^{-1}\in H\implies h(xy^{-1})\in H$;
>thus every element of $Hx$ also belongs to $Hy$, so $Hx \subseteq Hy$;
>a typical element of $Hy$ is $hy=h(yx^{-1})x=h(xy^{-1})^{-1}x \in Hx$ since $h,yx^{-1}\in H\implies h,(xy^{-1})^{-1}\in H\implies h(xy^{-1})\in H$
>thus every element of $Hy$ also belongs to $Hx$, so $Hy \subseteq Hx$; 
>hence $Hx=Hy$

^c02b25

> [!thm]- Two right cosets of $H$ in $G$ are either equal or disjoin
> Consider $Hx$ and $Hy$.
> Assume that they are not disjoint.
> Then there exists $g\in Hx \cap Hy$.
> Since $g\in Hx$, then  $g=hx$ for some $h\in H$.
> Since $g \in Hy$, then $g=ky$ for some $k\in H$.
> So $g=hx=ky$ $\implies$ $xy^{-1}=kh^{-1}\in H$.
> Then by the above theorem, since $xy^{-1}\in H$, then $Hx=Hy$.
> So the cosets $Hx$ and $Hy$ are either disjoint or equal.

> [!thm]- The group $G$ is the disjoint union of the right cosets of $H$
> Note that $x=1x\in Hx$. The choice of $x\in G$ is arbitrary so all elements of $G$ lie in one of the cosets of $H$.
> Therefore $G$ is the union of the cosets of $H$ and the above theorem tells us that this is a disjoint union.

> [!thm]- Every right coset of $H$ in $G$ contains the same number of elements as the subgroup $H$: if $x\in G$, then $|Hx|=|H|$
> Define a [[Functions|function]] $\alpha:H \to Hx$ by $h \alpha = h x$.
> By definition of $Hx$, $\alpha$ is [[Surjective functions|surjective]]. That is, $\forall\; hx\in Hx \;\exists h\in H: h \alpha= hx$.
> Now suppose that $h \alpha = k \alpha$. Then $h x = k x$ so $h=k$. and therefore $\alpha$ is [[Injective functions|injective]].
> So $\alpha$ is a [[Bijective functions|bijection]] from $H$ to $Hx$ and so $|H| = |Hx|$.
