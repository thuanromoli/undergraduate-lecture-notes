---
tags:
  - MT4527
aliases:
---
Let $\mathbb E_{t}(Y)$ denote the conditional expectation $\mathbb E(Y|X_{t},X_{t-1},...)$ and let $\mathbb V_{t}(Y)$ represent the conditional variance $\text{Var }(Y|X_{t},X_{t-1},...)$.
Let $(X_{t})_{t \in \mathbb Z}$ be an [[ARIMA(p,d,q) Process]].

> [!thm]- $\mathbb E_{t}(\varepsilon_{t+h})=0$ and $\mathbb V_{t}(\varepsilon_{t+h})= \sigma^{2}_\varepsilon$ for $h=1,2,3,...$
> Since at time $t+h$ we haven't observed the variables yet, the conditional moments are just the usual moments.

> [!thm]- $\mathbb E_{t}(\varepsilon_{t-h})=\epsilon_{t-h}$ and $\mathbb V_{t}(\varepsilon_{t-h})= 0$ for $h=1,2,3,...$ where $\epsilon_{t-h}=x_{t-h}-\widehat x_{t-h-1}(1)$
> Here we are in the past, so we have observations.
> Note that $\varepsilon_{t-h}=e_{t-h-1}(1)=X_{t-h}-\widehat x_{t-h-1}(1)$.
> At time $t$, both of these are known let $\epsilon_{t-h}=x_{t-h}-\widehat x_{t-h-1}(1)$.
> Then since $\epsilon_{t-h}$ is a constant, we have $\mathbb E_{t}(\varepsilon_{t-h})=\epsilon_{t-h}$ and $\mathbb V_{t}(\varepsilon_{t-h})=0$.

> [!thm]- $\mathbb E_{t}(X_{t-h})=x_{t-h}$ and $\mathbb V_{t}(\varepsilon_{t-h})= 0$ for $h=1,2,3,...$
> Here we are in the past, so we have observations.

> [!thm]- $\mathbb E_{t}(X_{t+L})=\widehat x_{t}(L)$ and $\mathbb V_{t}(X_{t+L})= \sigma^{2}_\varepsilon \sum\limits_{i=0}^{L-1}\nu_{i}^{2}$ for $L=1,2,3,...$
> $$\begin{aligned}
   \mathbb E_t(X_{t+L}) &=  \mathbb E_t(\varepsilon_{t+L} +\nu_1\varepsilon_{t+L-1} + ... + \nu_{L-1}\varepsilon_{t+1} + \nu_L \varepsilon_t + \nu_{L+1} \varepsilon_{t-1} + ... ) \\
   &= \mathbb E_t(\varepsilon_{t+L}) + \nu_1 \mathbb E_t(\varepsilon_{t+L-1}) + ... + \nu_{L-1}\mathbb E_t(\varepsilon_{t+1}) + \nu_L \mathbb E_t(\varepsilon_t) + \nu_{L+1}\mathbb  E_{t}(\varepsilon_{t-1}) + ... \\
   & = 0 + ... + 0 + \nu_L \varepsilon_t + \nu_{L+1} \varepsilon_{t-1} + ... \\
   &=\hat x_t (L)\end{aligned}$$
> $$\begin{aligned}
   \mathbb V_t(X_{t+L}) & =  V_t(\varepsilon_{t+L} + \nu_1\varepsilon_{t+L-1} + ... + \nu_{L-1}\varepsilon_{t+1} + \nu_{L} \varepsilon_t + \nu_{L+1} \varepsilon_{t-1} + ... )\\
   & =  \mathbb V_t(\varepsilon_{t+L}) + \nu^2_1 \mathbb V_t(\varepsilon_{t+L-1}) + ... + \nu^2_{L-1} \mathbb V_t(\varepsilon_{t+1}) + \nu^2_L \mathbb V_t(\varepsilon_t) + \nu^2_{L+1} \mathbb V_{t}(\varepsilon_{t-1}) + ... \\
   & = \sigma^2_{\varepsilon} +  \nu^2_1 \sigma^2_{\varepsilon} + ...+  \nu^2_{L-1} \sigma^2_{\varepsilon} + 0 + 0 + ...\\
   &=\sigma^2_{\varepsilon} \sum_{i=0}^{L-1} \nu_i^2
   \end{aligned}$$

> [!thm] Conditional distribution of $(X_{t+L}|X_{t},X_{t-1},...)$
> If the shocks are normally distributed, then
> $$X_{t+L}|X_{t},X_{t-1},... \sim N\left(\widehat x_{t}(L),\sigma^{2}_\varepsilon \sum\limits_{i=0}^{L-1}\nu_{i}^{2}\right)$$

> [!gen] Remarks
> - The above result holds if we know all of the parameters.
> - In practice, we need estimate $(\nu_{k})_{k \in \mathbb N}$ and $\sigma^{2}_\varepsilon$ (so a $t$-distribution should be used).
> - If the series is longer than 40 observations, the normal distribution is a good approximation.
> - As the lead time increases, the variance naturally increases (unless only a finite number of weights are non-zero).
