---
tags:
  - MT4551
aliases:
---
> [!gen] Early exercise of an American call
> It is never optimal to exercise early. There are scenarios.
> 
> SCENARIO 1: Holding onto stock after exercising the call (I will always pay $E$ regardless).
> - Suppose $S<E$ at the expiry time.
> 	- If I exercise early, I pay $E$ and end up with a share worth $S < E$.
> 	- If I don't exercise early, I let the call elapse and can buy a share for $S$ on the open market.
> - Suppose $E>S$ at the expiry time.
> 	- If I exercise early, I pay $E$ and end up with a share worth $E>S$.
> 	- If I don't exercise early, I still pay $E$ and end up with a share worth $E>S$.
> 	- Hence the difference is that exercising at the end reduces the risk to zero.
> - If I keep $E$ until $T$, I can obtain $Ee^{rT}$ through interest rates.
> 
> SCENARIO 2: Consider the following strategy:
> - $t=0$, take long position on call $(E,T)$.
> - $t=t_{1}$ sell short one share and cash $S(t_{1})$.
> - $t=T$ we have to return the share, hence we have to buy a share. There are two ways.
> 	- Exercise the call option (cost $E$).
> 	- Buy on the open market (cost $S(T)$)
> 
> The payoff is $S(t_{1})e^{r(T-t_{1})} - \min (E,S(T))$. Same reasoning as above.

> [!gen] Early exercise of an American put
> It may be optimal to exercise early if $S<E$.
> 
> Suppose $S=0$, then the payoff is $E$, the maximum. No more profit can be made so exercise. Furthermore you gain interest on $E$ for the remaining time.
> 
> In general if $S<E$, the payoff is $E-S$ plus interest over time.
