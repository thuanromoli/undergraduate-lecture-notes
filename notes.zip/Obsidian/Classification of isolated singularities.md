---
tags:
  - MT3503
aliases:
  - removable singularity
  - pole
  - isolated essential singularity
  - meromorphic
---
Let $f$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] that is [[Holomorphic functions|holomorphic]] on a punctured disc $B'(a,r)$ with an [[Isolated singularity|isolated singularity]] at $a$.

Let $\sum\limits_{n=-\infty}^{\infty}c_{n}(z-a)^{n}$ be the [[Laurent series]] of $f$ at $a$.

> [!def] Removable singularity
> $f$ has a removable singularity at $a$ if $c_{n} = 0$ for all negative $n=0$.

> [!def] Pole of order $m$
> $f$ has a pole of order $m$ at $a$ if $c_{-m} \neq 0$ and $c_{n}=0$ for all $n<-m$.

> [!def] Isolated essential singularity
> $f$ has an isolated essential singularity at $a$ if there is no $m$ such that $c_{n}=0$ for all $n<-m$.

> [!def] Meromorphic functions
> $f$ is said to be meromorphic on an open set $U$ if it is holomorphic on $U$ except for a collection of poles.

