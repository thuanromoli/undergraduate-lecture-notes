---
tags:
  - MT4528
type: model
aliases:
---
>[!def] Definition
>The M/M/s queue has:
>- [[Poisson processes|Poisson process]] arrivals with rate $\lambda$
>- service times $\overset{iid}{\sim}\text{Exp}(\mu)$
>- $s$ servers and capacity is $\infty$
>
>This is a [[Birth and death processes|Birth/death process]] where:
>$$\lambda_{n}=\begin{cases}
   \lambda & \text{for all }n\\
   \end{cases}$$
>$$\mu_{n}=\min\set{n \mu,s \mu}=\begin{cases}
   0 & \text{for } n=0 \\
   n\mu & \text{for } 0 < n \leqslant s \\
   s\mu & \text{for }n > s \\
   \end{cases}$$

>[!thm] Theorem
>For an M/M/s queue with $\frac{\lambda}{s \mu}<1$, the [[Stationary distributions|stationary distribution]] of the process $\set{X(t):t\geqslant 0}$ is given by
>$$\begin{align*}
   \pi_{0} &= \left(\sum\limits_{j=0}^{s-1} \frac{1}{j!}\left(\frac{\lambda}{\mu}\right)^{j}+ \frac{s^{s}}{s!}\sum\limits_{n=s}^{\infty}\left(\frac{\lambda}{s \mu}\right)^{n}\right)^{-1}\\
   \pi_{n} &= \frac{1}{n!} \left(\frac{\lambda}{\mu}\right)^{n}\pi_{0} \;\;\;\;\;\;\;\text{ for } 0 <n \leqslant s\\
   \pi_{n} &= \frac{s^{s}}{s!} \left(\frac{\lambda}{s\mu}\right)^{n}\pi_{0} \;\;\;\;\;\text{ for } n > s\\
   \end{align*}$$
>For $\frac{\lambda}{s \mu} \geqslant 1$ no equilibrium distribution exists.
>
>Proof: see [[Equilibrium distribution of a birth death process|this proposition]], and then use algebra.
