---
tags:
  - MT4527
aliases:
---
Let $(X_{t})_{t \in \mathbb Z}$ be an [[AR(1) Process]] $X_{t}=\phi_{0}+\phi X_{t-1}+\varepsilon_{t}$, or $(1-\phi B)X_{t}=\phi_{0}+\varepsilon_{t}$.
This process is stationary if $\phi<1$, and it is not stationary (random walk) for $\phi=1$. We won't consider $\phi>1$.
Recall that the condition $\phi\neq1$ is equivalent to the condition that $(1- \phi B)$ has no roots on the unit circle.
Furthermore we apply the transformation $\delta= \phi-1$ to obtain $\nabla X_{t}= \phi_{0}+\delta X_{t-1}+\varepsilon_{t}$.
We find the estimates for $\phi_{0}$ and $\delta$ by regressing $\nabla X_{t}$ on $X_{t-1}$.

> [!gen] [[Statistical hypothesis|Hypothesis]]
> $H_{0}$: The process is not stationary / there exists a unit root / $\phi=1$ / $\delta=0$.
> $H_{1}$: The process is stationary / the roots are outside of the unit circle / $\phi<1$ / $\delta<0$.

> [!gen] [[Test statistics]]
> $$\tau = \frac{\hat \delta}{\widehat{\sqrt{\text{Var}}}(\hat \delta)} \sim \text{tabled by Dickey and Fuller}$$
> where
> $$\widehat{\text{Var}}(\hat \delta) = \frac{\frac{1}{T-3}\sum_{t=2}^{T} (\nabla X_t - \hat \phi_0 - \hat \delta X_{t-1})^2}{\sum_{t=2}^{T} (X_{t-1} - \bar X)^2} \qquad \text{with} \quad \bar X = \frac{\sum_{t=2}^{T} X_{t}}{T-1}.$$

This test is generalised by the Augmented Dickey-Fuller test for a [[AR(p) Process]].
The test is similar with the hypothesis $H_{0}: \delta =0$ and $H_{1}: \delta<0$ tested using the regression
$$\nabla X_{t}=c_{t}+\delta X_{t-1} + \sum\limits_{i=1}^{p-1}\phi_{i}\nabla X_{t-1}+\varepsilon_{t},$$
where $c_{t}$ is a deterministic function of the time index $t$.
In practice, the test statistic and p-value is calculated by `R`.
One of the parameters is the lag $k$ and should be chosen by the rule of thumb
$$k= \text{integer part of}\left[12 \left(\frac{T}{100}\right)^{1/4}\right].$$
A slowly decaying empirical ACF plot is typical of ARIMA processes with $d>0$. These plots are not weakly stationary.
![[acfarima_att.png]]