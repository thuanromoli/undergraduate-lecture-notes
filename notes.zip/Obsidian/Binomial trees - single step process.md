---
tags:
  - MT4551
aliases:
---
Let $S$ be the share price at time $t$.

Over the interval $\delta t$, the share price may
1. Increase by a factor $u>1$, with probability $p$.
2. Decrease by a factor $d < 1$, with probability $1-p$.

![[bintreeoneshare_att.png]]

Now we apply the [[The Black-Scholes equation - derivation|Black-Scholes theory]] to work out the value of the option:
1. Work out the expectation value at $t = T$ assuming a risk-neutral probability.
2. Discount it to present day values.

![[bintreeonefd_att.png]]

The value of the financial derivative is
$$V_{0} = e^{-r \delta t}[pV_{1} + (1-p) V_{2}].$$
