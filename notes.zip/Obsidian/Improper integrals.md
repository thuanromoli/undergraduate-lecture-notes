---
tags:
  - MT3502
aliases:
---
Let $f:[a,\infty) \to \mathbb R$ be a [[Boundedness|bounded]] [[Functions|function]].

> [!def] Improper [[Integrability|integral]] - unbounded domain
> We define
> $$\int_{a}^{\infty}f(x) dx = \lim\limits_{X \to \infty} \int_{a}^{X}f(x) dx,$$
> provided that the right-hand integrals exist for all $X$ and the [[Limits|limit]] exists.

Domains of the form $(-\infty, b]$ or $(-\infty,\infty)$ may be treated in a similar way.

Let $f:[a,b] \to \mathbb R$ be [[Boundedness|bounded]] below but not above.

> [!def] Improper [[Integrability|integral]] - unbounded function
> We define
> $$\int_{a}^{b}f(x) dx = \lim\limits_{M \to \infty} \int_{a}^{b}f_{M}(x) dx,$$
> where $f_{M}(x) = \min\set{f(x),M}$, provided that the right-hand integral exist for all $M$ and the [[Limits|limit]] exists.
