---
tags:
  - MT4509
aliases:
---
Vorticity flux
$$\iint_{S} \boldsymbol{\omega \cdot n} \; dS$$
Curl
$$\boldsymbol{\omega} = \boldsymbol{\nabla \times u}$$
Stoke's theorem
$$\iint_{S} (\boldsymbol{\nabla \times u}) \cdot \boldsymbol{n} \;dS = \oint_{\mathcal C} \boldsymbol{u \cdot n}\; dl$$
Circulation $\Gamma$
$$\oint_{\mathcal C}\boldsymbol{u}\cdot d \boldsymbol{l}.$$
