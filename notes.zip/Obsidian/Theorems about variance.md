---
tags:
  - MT2504
type: thm
aliases:
---
Let $X$ and $Y$ be any [[Independent events|independent]] [[Random variables|random variables]] and let $a$ and $b$ be constants.

>[!thm] $\text{Var}(aX+b)=a^{2} \text{Var}(X)$

>[!thm] $\text{Var}(X+Y)=\text{Var}(X)+\text{Var}(Y)$

>[!thm] The above extends to $\text{Var}\left(\sum\limits_{i=1}^{n}X_{i}\right)=\sum\limits_{i=1}^{n}\text{Var}(X_{i})$

---

#### Spaced repetition
