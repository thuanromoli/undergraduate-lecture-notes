---
tags:
  - MT4551
aliases:
---
Consider a [[Particles random walk - standard settings|particles random walk]].

> [!thm] Theorem
> 1. Label each step as $X_1,...,X_n$ such that
>    $$X_{i} = \begin{cases}- \Delta & \text{with probability } p = 1/2 \\+ \Delta & \text{with probability } p = 1/2 \end{cases}$$
> 2. After $N$ steps the final displacement is
>    $$X = X_{1} + X_{2} + \cdots + X_{N} = \sum\limits_{i=1}^{N}X_{i}.$$
> 3. If the process is repeated $M$ times, then the average displacement is
>    $$\bar X = \frac{\sum_{j=1}^{M}X^{j}}{M} = 0$$
>    where $X^{j}$ is the final displacement of the particle during experiment $j$.
> 4. Also
>    $$\begin{align*}X^{2} &=  (X_{1}^{2}+X_{2}^{2} + \cdots + X_{N}^{2})+ (2X_{1}X_{2} + 2X_{1}X_{3} + \cdots + 2X_{1}X_{N}) \\&=  (X_{1}^{2}+X_{2}^{2} + \cdots + X_{N}^{2}) + 0 \text{ as these terms average out to } 0\\ &= N \Delta^{2}.\end{align*}$$
> 5. The [[Variance and standard deviation|standard deviation]] is such that 
>    $$\begin{align*}\sigma_{v}^{2} &=  \sum\limits_{j=1}^{M}\frac{(X^{j}-\bar X)^{2}}{M}\\ &= \frac{M N \Delta^{2} }{M} \\ &= N \Delta^{2}.\end{align*}$$
