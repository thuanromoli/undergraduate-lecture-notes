---
tags:
  - MT4554
type: 
aliases:
---
>[!def] Definition
>The price of anarchy is a measure of the "quality" a less than rational process for strategy update:
>$$PoA=\frac{\max\limits_{\sigma\in \Sigma}W(\sigma)}{\min\limits_{\sigma\in \Sigma_{eq}}W(\sigma)}$$
>where $W(\sigma)=\sum\limits_{i\in \cal N}^{}u_{i}(\sigma_{i},\sigma_{-i})$ and $\Sigma_{eq}$ is the set of equilibrium strategies.
>
>What this says is that the price of anarchy is the ratio between the maximum possible welfare and the worst possible equilibrium state of the process.
>We define welfare as the total payoff of all individual in a population.
