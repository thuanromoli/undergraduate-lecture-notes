---
tags:
  - MT4509
aliases:
---
> [!def] Definition
> A fluid is materially conserved if a field $F$ is constant on every fluid particle.
> That is, when $$\frac{DF}{dt} = 0.$$
