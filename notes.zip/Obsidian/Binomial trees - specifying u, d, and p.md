---
tags:
  - MT4551
aliases:
---
Let $S$ be the share price at time $t$.

> [!thm] Theorem
> The three relations relating $u$, $p$, and $d$ are
> $$\begin{align}
   p &= \frac{e^{r\delta t}-d}{u-d} \\
   u+d &= \frac{e^{(2r+\sigma^{2}) \delta t}-d^{2}}{e^{r\delta t}-d}\\
   p &= \frac{1}{2}\; \text{ or }\; u = \frac{1}{d}
   \end{align}$$
> where $\sigma$ is the volatility and $r$ is the risk-free rate.

Proof:
To determine $u$, $d$, and $p$ we apply three constraints.

Constraint 1: The [[The Black-Scholes equation - derivation|Black-Scholes theory]] tells us that shares grow at $r$ not $\mu$.
The expected value from the B-S theory is $Se^{r\delta t}$.
The expected value from the binomial tree is $pSu+(1-p)Sd$.
These must equal each other and hence we obtain
$$\begin{align*}
& pSu+(1-p)Sd = Se^{r \delta t}\\
\implies & pu+(1-p)d = e^{r \delta t}\\
\implies & pu + d-pd = e^{r \delta t}\\
\implies & p(u-d) = e^{r \delta t} - d\\
\implies & p = \frac{e^{r \delta t} - d}{u-d}.
\end{align*}$$

Constraint 2: The [[The Black-Scholes equation - derivation|Black-Scholes theory]] tells us about the variance of the share price.
The variances from the B-S theory and the binomial tree are, respectively
$$\begin{align*}
\text{Var}_{\text{B-S}}(S) &= \overline{S^{2}}-{\overline{S}}^{2} = [S^{2}e^{(2r + \sigma^{2})\delta t}] \;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;- [S^{2}e^{2r \delta t}]\\
\text{Var}_{\text{Bin}}(S) &= \overline{S^{2}}-{\overline{S}}^{2} = [p(Su)^{2}+(1-p)(Sd)^{2}] - [pSu+(1-p)Sd] 
\end{align*}.$$
We proceed to equate $\overline{S^{2}}$ and ${\overline{S}}^{2}$ from each variance to obtain
$$\begin{align*}
\begin{cases}
\overline{S^{2}}_\text{B-S} = \overline{S^{2}}_{\text{Bin}}\\
{\overline{S}}^{2}_\text{B-S} = {\overline{S}}^{2}_{\text{Bin}}
\end{cases} \implies &
\begin{cases}
[S^{2}e^{(2r + \sigma^{2})\delta t}] = [p(Su)^{2}+(1-p)(Sd)^{2}]\\
{\overline{S}}_\text{B-S} = {\overline{S}}_{\text{Bin}}
\end{cases}\\
\implies &
\begin{cases}
e^{(2r + \sigma^{2})\delta t} = pu^{2}+d^{2}-pd^{2}  \\
\text{same as condition 1 so omitted onwards}
\end{cases}\\
\implies &
\begin{cases}
e^{(2r + \sigma^{2})\delta t} = p(u^{2}-d^{2})+d^{2}\\
p = \frac{e^{r \delta t} - d}{u-d}
\end{cases}\\
\implies &
\begin{cases}
p = \frac{e^{(2r + \sigma^{2})\delta t}-d^{2}}{(u^{2}-d^{2})}\\
p = \frac{e^{r \delta t} - d}{u-d}
\end{cases}\\
\implies & \frac{e^{(2r + \sigma^{2})\delta t}-d^{2}}{(u^{2}-d^{2})} = \frac{e^{r \delta t} - d}{u-d}\\
\implies &  \frac{e^{(2r + \sigma^{2})\delta t}-d^{2}}{(u+d)(u-d)} = \frac{e^{r \delta t} - d}{u-d}\\
\implies &  \frac{e^{(2r + \sigma^{2})\delta t}-d^{2}}{u+d} = {e^{r \delta t} - d}\\
\implies &  {u+d} = \frac{e^{(2r + \sigma^{2})\delta t}-d^{2}}{e^{r \delta t} - d}.
\end{align*}$$

Constraint 3: Unfortunately there is no third constraint to apply: so an arbitrary choice is made. This may be one of two options $p = \frac{1}{2}$ or $d = \frac{1}{u}$..
