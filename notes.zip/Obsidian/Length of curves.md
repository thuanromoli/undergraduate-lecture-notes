---
tags:
  - MT3503
aliases:
  - length
---
Let $\gamma:[a,b] \to \mathbb C$ be a smooth [[Curves|curve]].

> [!def] Definition
> The length of $\gamma$ is
> $$L(\gamma) = \int_{a}^{b} |\gamma'(t)|\; dt.$$
> If $\gamma$ is a piecewise smooth curve with partition of $[a,b]$ as $a = a_{0} < a_{1} < a_{2} < \ldots < a_{n} = b$, then the length of $\gamma$ is
> $$L(\gamma) = \sum\limits_{i=0}^{n-1} \int_{a_{i}}^{a_{i+1}} | \gamma'(t) | \;dt,$$
> the sum of the lengths of each smooth piece $[a_{i},a_{i+1}]$.
