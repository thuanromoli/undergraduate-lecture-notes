---
tags:
  - MT4528
type: 
aliases:
---
Let $\set{X(t):t \geqslant 0}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov process]] with [[State spaces|state space]] $S$.

>[!thm]- $\lim\limits_{t \to 0}\frac{\mathbb P(X(t)\neq i|X(0)=i)}{t}=\lambda_{i}$
>If $X(0)=i$, then as $t \to 0$, any $X(t)\neq i$ refers to the first transition away from the state $i$. Then
>$$\begin{align*}
   \lim\limits_{t \to 0}\frac{\mathbb P(X(t)\neq i|X(0)=i)}{t} &= \lim\limits_{t \to 0} \frac{1}{t}\mathbb P(W_{i} \leqslant t)\\
   &= \lim\limits_{t \to 0} \frac{1}{t} \int_{0}^{t} \lambda_{i}e^{-\lambda_{i}x}dx\\
   &= \lim\limits_{t \to 0} \frac{1}{t}[-e^{-\lambda_{i}x}]_{0}^{t}\\
   &= \lim\limits_{t \to 0} \frac{1}{t}(1-e^{-\lambda_{i}t})\\
   &= \lambda_{i}
   \end{align*}$$

>[!thm]- $\lim\limits_{t \to 0}\frac{\mathbb P(X(t)=j|X(0)=i)}{t}=\lambda_{i}p_{ij}$ for $i\neq j$
>$$\begin{align*}
   \lim\limits_{t \to 0}\frac{\mathbb P(X(t)= j|X(0)=i)}{t} &= \lim\limits_{t \to 0} \frac{1}{t} \frac{\mathbb P(X(t)=j,X(0)=i)}{\mathbb P(X(0)=i)}\\
   &= \lim\limits_{t \to 0} \frac{1}{t} \frac{\mathbb P(X(t)=j,X(t)\neq i, X(0)=i)}{\mathbb P(X(0)=i)}\\
   &= \lim\limits_{t \to 0} \frac{1}{t} \frac{\mathbb P(X(t)=j|X(t)\neq i, X(0)=i) \mathbb P(X(t)\neq i, X(0)=i))}{\mathbb P(X(0)=i)}\\
   &= \mathbb P(X(t)=j|X(t)\neq i, X(0)=i)\lim\limits_{t \to 0} \frac{1}{t} \frac{\mathbb P(X(t)\neq i, X(0)=i))}{\mathbb P(X(0)=i)}\\
   &= p_{ij}\lambda_{i}
   \end{align*}$$