---
tags:
  - MT4528
type: model
aliases:
---
>[!thm] Theorem
>For the scenario where $A$'s initial capital is $a$ and $B$ has infinite capital, [[Gambler's ruin - probability of ruin|probability of ruin]] is given by
>$$R(a)=\begin{cases}
   1 & \text{if }p \leqslant q \\
   \left(\frac{q}{p}\right)^{a} & \text{if } p>q
   \end{cases}$$
>
>Proof:
>Recall that in general,
>$$R(a)=1-W(a)=\begin{cases}
   \frac{(q/p)^{a}-(q/p)^{N}}{1-(q/p)^{N}} & \text{if }p\neq q \\
   1- \frac{a}{N} & \text{if } p=q
   \end{cases}$$
>So we need to find $\lim\limits_{N\to \infty} R(a)$.
>Proof is omitted.
