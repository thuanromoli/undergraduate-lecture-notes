---
tags:
  - MT4003
aliases:
---
Let $G$ be a [[Groups|group]].

> [!def] Definition
> A group $G$ is called soluble if $G^{(n)}= \boldsymbol{1}$ for some $n$.
> 
> The idea is that if $G$ is any group, we can repeatedly take [[The derived subgroup|derived]] [[Subgroups|subgroup]]:
> $$G^{(1)}=G',\;\;\;G^{(2)}=(G')',\;\;\; G^{(3)}=(G^{(2)})',\;\;\;\ldots$$
> and so $G$ has a chain of subgroups
> $$G=G^{(0)} \geqslant G^{(1)} \geqslant G^{(2)} \geqslant  \cdots \geqslant G^{(n)} = \boldsymbol{1}$$
> and, [[Theorems about derived subgroup#^5a1a40|by this theorem]], each quotient $G^{(i)} / G^{(i+1)}$ is [[Abelian groups|abelian]].
> Thus, $G$ is built, in some sense, from abelian groups, and therefore, by [[The fundamental theorem of finite abelian groups|the fundamental theorem of finite abelian groups]], $G$ is built from [[Cyclic groups|cyclic]] groups.
