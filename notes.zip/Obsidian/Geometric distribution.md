---
type: def
tags:
  - MT3508
---
> [!gen] Parameters
> $p \in [0,1]$ - success probability for each trial

> [!gen] Support
> either $x\in\set{1,2,...}$ - number of trials
> or $x\in\set{0,1,2,...,n}$ - number of failures

>[!gen] [[Probability mass function]]
>either $f(x) = (1-p)^{k-1}p$
>or $f(x) = (1-p)^{k}p$

> [!gen] Typical use
> Used for counts of number of events until the first _success_, i.e. number of events until some particular event (a _success_) occurs.
