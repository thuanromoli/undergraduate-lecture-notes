---
tags:
  - MT3503
aliases:
---
Let $\gamma:[a,b] \to \mathbb C$ be a piecewise smooth [[Curves|curve]] and $f: \gamma^{*} \to \mathbb C$ be a [[Continuity|continuous]] [[Functions|function]].

> [!thm]- Let $\overleftarrow{\gamma}$ denote the curve $\gamma$ traced backwards: $\overleftarrow{\gamma}(t) = \gamma (a+b-t)$ for $a \leqslant t \leqslant b$. Then $$\qquad\qquad\int_{\overleftarrow{\gamma}}^{}f(z) \; dz = - \int_{\gamma}^{}f(z)\;dz.$$
> $\overleftarrow{\gamma}(t) = \gamma (a+b-t) \implies \overleftarrow{\gamma}'(t)= -\gamma' (a+b-t)$
> Therefore
> $$\begin{align*}
   \int_{\overleftarrow \gamma}^{} f(z) \;dz &= \int_{a}^{b} f(\overleftarrow \gamma(t)) \overleftarrow \gamma'(t) \; dt\\
   &= \int_{a}^{b} f(\gamma(a+b-t)) \;(- \gamma'(a+b-t))\;dt \\
   &= -\int_{a}^{b} f(\gamma(a+b-t)) \; \gamma'(a+b-t)\;dt \\
   & \;\quad\text{let } s = a+b-t \implies ds = - dt \\
   &= - \int_{b}^{a} f(\gamma(s)) \; \gamma'(s) \;(-ds) \\
   &= - \int_{a}^{b} f(\gamma(s)) \; \gamma'(s) \;(ds) \\
   &= - \int_{\gamma}^{}f(z)\;dz.
   \end{align*}$$

^8c3e80

> [!thm]- If $a < c < b$, with $\gamma_{1}= \gamma\; \big |_{[a,c]}$ and $\gamma_{2}= \gamma\; \big |_{[c,b]}$. Then $$\qquad\qquad\qquad\qquad\qquad\qquad\int_{\gamma}^{}f(z) \; dz = \int_{\gamma_{1}}^{}f(z) \; dz + \int_{\gamma_{2}}^{}f(z) \; dz.$$
> Straightforward, apply the fact that $\int_{a}^{b}g(t)dt=\int_{a}^{c}g(t)dt+\int_{c}^{b}g(t)dt$ for any continuous function $g: [a,b] \to \mathbb R$ to the real and imaginary part of the integrand appearing in the definition of $\int_{\gamma}^{}f(z)dz$.

> [!thm]- Let $\psi:[c,d] \to [a,b]$ be a [[Differentiability|differentiable]] real-valued [[Bijective functions|bijective]] function with positive continuous derivative. Define $\tilde \gamma = \gamma \circ \psi:[c,d] \to \mathbb C$. Then $$\int_{\tilde \gamma}^{}f(z)\;dz = \int_{\gamma}^{} f(z) \;dz.$$
> $$\begin{align*}
   \int_{\tilde \gamma}^{}f(z)\;dz &= \int_{c}^{d} f(\tilde \gamma(t)) \tilde \gamma'(t) \;dt\\
   &= \int_{c}^{d} f(\gamma(\psi(t))\;\gamma'(\psi(t))\;\psi'(t)\;dt\\
   & \;\quad \text{let } s = \psi(t) \implies ds = \psi'(t) dt \text{ and } \psi(c) = a, \psi(d) = b\\
   &= \int_{a}^{b} f(\gamma(s))\gamma'(s)ds\\
   &= \int_{\gamma}^{} f(z) \;dz.
   \end{align*}$$
