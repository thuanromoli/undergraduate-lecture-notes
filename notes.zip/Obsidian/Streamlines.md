---
tags:
  - MT4509
aliases:
  - streamline
---
See [[Streamfunctions|streamfunctions]].

This description of the flow field describes the instantaneous flow state. It consists of lines parallel to $\boldsymbol{u}$ everywhere.

![[streamlines_att.png|300]]

By definition, we draw a family of curves with $d \boldsymbol{x}$ parallel to $\boldsymbol{u}$
$$\frac{dx}{u} = \frac{dy}{v} = \frac{dz}{w} = ds$$
where $s$ is a parameter describing the distance along a given streamline.

So, to plot the streamlines we solve the differential equations above simultaneously. That is,
$$\frac{dx}{ds}=u(x,y,z;t),\quad \frac{dy}{ds}=v(x,y,z;t),\quad \frac{dz}{ds}=w(x,y,z;t)$$
where $t$ is kept as a fixed parameter throughout this analysis.