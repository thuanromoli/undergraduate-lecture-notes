---
tags:
  - MT4509
aliases:
---


![[waterwaves_att.png|400]]

ASSUMPTIONS
Small amplitude means $\text{wave slope }\frac{\partial \eta}{\partial x}\ll1$ and $\eta \ll H$.
Homogenous fluid.
Incompressible fluid.
Irrotational fluid.

SETUP
We have a potential fluid $\nabla ^{2} \Phi =0$ and $\boldsymbol{u}=\nabla \Phi$ or $(u,w)=\left(\frac{\partial \Phi}{\partial x},\frac{\partial \Phi}{\partial z}\right)$ in $D$.

Boundary conditions surface:
- Dynamic boundary condition $p=p_{a}= \text{constant}$
- [[Kinematic boundary condition]] $\frac{D \eta}{Dt}=w(x,z=\eta(x,t),t)$.

Boundary conditions at the bottom:
- [[Normal velocity condition]] $\boldsymbol{u} \cdot \boldsymbol{n}=0$

LINEARISATION
It turns out that we can turn the above conditions into linear boundary conditions.
Kinematic boundary conditions.
$w=\frac{D \eta}{Dt}=\frac{\partial \eta}{\partial t}+u \frac{\partial \eta}{\partial x}\approx \frac{\partial \eta}{\partial t}$ at $z=0$. So $\frac{\partial \Phi}{\partial z}= \frac{\partial \eta}{\partial t}$ at $z=0$
Normal velocity condition
$\boldsymbol{u} \cdot \boldsymbol{n}=0 \implies \nabla \Phi \cdot \boldsymbol{n}=0 \implies\left(\frac{\partial \Phi}{\partial x},\frac{\partial \Phi}{\partial z}\right)\cdot \boldsymbol{e}_{z}=0 \implies \frac{\partial \Phi}{\partial z} =0$ at $z=-H$.
Unsteady Bernoulli
$\frac{\partial \Phi}{\partial t}+\frac{1}{2}|\boldsymbol{u}|^{2}+\frac{p_{a}}{\rho}+g \eta=f(t) \implies \frac{\partial \Phi}{\partial t}+\frac{p_{a}}{\rho}+g \eta\approx f(t) \implies \frac{\partial \Phi}{\partial t}+g \eta = \tilde f(t)$

SET OF EQUATIONS
- $\nabla ^{2}\Phi=0$, $\boldsymbol{u}=\nabla \Phi$ potential flow
- $\frac{\partial \Phi}{\partial z}(0)= \frac{\partial \eta}{\partial t}$ kinematic (1)
- $\frac{\partial \Phi}{\partial z}(x,-H,t)=0$ normal (2)
- $\frac{\partial \Phi}{\partial t}+ g \eta = \tilde f(t)$ Bernoulli (3)

SOLUTION
If the undisturbed (basic) state is independent of $x$ and also $t$, then we can seek "plane-wave" solutions proportional to
$$e^{i(kx-\sigma t)}= e^{i\varphi}$$
where
- $k$ = wave number = $\frac{2 \pi}{ \lambda}>0$.
- $\sigma$ = frequency.
- $\varphi=$ phase = $kx- \sigma t$.

Consider Laplace's equation for $-H < z <0$,
$$\nabla^{2} \Phi=0.$$
The plane-wave solution are (as there is no $x$ or $t$ dependence)
$$\begin{cases}
\Phi= \widehat \Phi(z) e^{i \varphi} \\
\eta= \widehat \eta(z) e^{i \varphi}.
\end{cases}$$
We seek solutions of that kind. So we plug into the Laplace's equation and we have
$$\begin{align*}
\nabla ^{2} \Phi=0 \implies& \frac{\partial ^{2}\Phi}{\partial x^{2}} + \frac{\partial ^{2}\Phi}{\partial z^{2}} =0\\
\implies& \left(-k^{2} \widehat \Phi + \frac{d^{2} \widehat \Phi}{dz^{2}}\right)e^{i\varphi}=0\\
\implies& \widehat \Phi''-k^{2}\widehat \Phi=0\\
\implies& \widehat \Phi= Ae^{kz}+Be^{-kz}
\end{align*}$$
where $A$ and $B$ are constants to be found. We use the linearised boundary conditions.

(2) $\frac{d \Phi}{dz}=0$ at $z=-H$ $\implies$ $\Big[(kAe^{kz}-kBe^{-kz})e^{i\varphi}\big ]_{z=-H}=0$ $\implies$ $Ae^{-kH}-Be^{kH} =0$ $\implies$ $A=Be^{2kH}$.

(1) $\frac{d \Phi}{dz}=\frac{\partial \eta}{\partial t}$ at $z=0$ $\implies$ $\Big[(kAe^{kz}-kBe^{-kz})e^{i\varphi}\big ]_{z=0}=\Big[ -i \sigma \widehat \eta e^{i\varphi} \Big]_{z=0}$ $\implies$ $k(A-B)= -i \sigma \widehat \eta$ $\implies$ $kB(e^{2kH}-1)= -i \sigma \widehat \eta$.

(3) $\frac{\partial \Phi}{\partial t}+ g \eta = \tilde f(t)$ $\implies$ $\underbrace{-i \sigma \widehat \Phi e^{i\varphi}+g \widehat \eta e^{i\varphi}}_{\text{function of time and space}}=\underbrace{\tilde f(t)}_{\text{function of time only}}$ $\implies$ ${-i \sigma \widehat \Phi e^{i\varphi}+g \widehat \eta e^{i\varphi}} = 0$ $\implies$ wlog evaluate at $z=0$, $-i \sigma (A+B)+g \widehat \eta=0$ $\implies$ $i \sigma B(e^{2kH}+1)=g \widehat \eta$.

Equations (1) and (3) yield
$$kB(e^{2kH}-1)+i \sigma \left[\frac{i \sigma B (e^{2kH}+1)}{g}\right]=0$$
$B=0$ is a solution. Let $B\neq 0$.
$$\begin{align*}
&gk(e^{2kH}-1)= \sigma^{2}(e^{2kH}+1)\\
\implies& \sigma^{2}= gk \frac{e^{2kH}-1}{e^{2kH}+1}=gk \tanh kH\\
\implies& \sigma=\pm \sqrt{gk \tanh (kH)}.
\end{align*}$$
where $k>0$ ensures two solutions. This is called the dispersion relation.

Now consider the phase $\varphi = kx -\sigma t=k(x-c_{p}t)$ where $c_{p} = \sigma/k$ is the phase speed.
Then the phase speed is
$$c_{p}=\pm \sqrt{\frac{g}{k}\tanh(kH)}.$$

LIMITING CASES
Recall that $\tanh q \approx q$ for $q \ll 1$ and that the wavelength is $\lambda= \frac{2 \pi}{k}$.

Long waves $kH \ll 1$, $H \ll \lambda$.
$c_{p}=\pm\sqrt{gH}$, a constant. No dispersion. Shallow water waves.

Short waves $kH \gg 1$, $H \gg \lambda$.
$c_{p}=\pm\sqrt{\frac{g}{k}}=\pm \sqrt{\frac{g \lambda}{2 \pi}}$. Dispersive. Deep water waves.