---
tags:
  - MT2504
type: def
aliases:
  - sample space
  - sample point
  - event
---
>[!def] Sample Space
>The sample space, denoted by $\Omega$, is the set of all possible outcomes of an [[experiment]].

>[!def] Sample point
>A sample point, $\omega \in \Omega$, is an element of the sample space: a possible outcome.

>[!def] Event
>An event, $A \subseteq \Omega$, is a subset of the sample space.

---

#### Spaced repetition
