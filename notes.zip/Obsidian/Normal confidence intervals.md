---
type: mthd
tag: MT2508
---
Let $X_1,...,X_n$ be [[Normal distribution|normal]] [[Random variables|rvs]]. Given $\bar X$ and $\sigma^{2}$, define a $100(1-\alpha)$ [[Confidence intervals|CI]] for $\mu$.

### The population variance is known

>[!gen]+ CONDITIONS
>$X_1,...,X_n$ must be [[Independent events|independent]] and [[Normal distribution|normally distributed]] with mean $\mu$ and variance $\sigma^2$.

>[!gen]+ DISTRIBUTION
>$\bar X \sim (\mu,\frac{\sigma^2}n)$ or $Z=\frac{\bar X - \mu}{\sqrt{\frac{\sigma^2}n}} \sim N(0,1)$

>[!gen]+ PROBABILITY
>$\mathbb P(z_{\alpha/2}<Z<z_{1-\alpha/2})=1-\alpha$
>$\mathbb P(-z_{1-\alpha/2}<Z<z_{1-\alpha/2})=1-\alpha$
>$\mathbb P(-z_{1-\alpha/2}<\frac{\bar X - \mu}{\sqrt{\frac{\sigma^2}n}}<z_{1-\alpha/2})=1-\alpha$
>$\mathbb P(-z_{1-\alpha/2}\sqrt{\frac{\sigma^2}n}<\bar X - \mu<z_{1-\alpha/2}\sqrt{\frac{\sigma^2}n})=1-\alpha$
>$\mathbb P(-\bar X-\frac{z_{1-\alpha/2}\sigma}{\sqrt n}<-\mu<-\bar X+\frac{z_{1-\alpha/2}\sigma}{\sqrt n})=1-\alpha$
>$\mathbb P(\bar X+\frac{z_{1-\alpha/2}\sigma}{\sqrt n}>\mu>\bar X-\frac{z_{1-\alpha/2}\sigma}{\sqrt n})=1-\alpha$
>$\mathbb P(\bar X-\frac{z_{1-\alpha/2}\sigma}{\sqrt n}<\mu<\bar X+\frac{z_{1-\alpha/2}\sigma}{\sqrt n})=1-\alpha$

>[!gen]+ CONFIDENCE INTERVAL
>$(\bar x-\frac{z_{1-\alpha/2}\sigma}{\sqrt n},\bar x+\frac{z_{1-\alpha/2}\sigma}{\sqrt n})$

### The population variance is unknown

>[!gen]+ CONDITIONS
>$X_1,...,X_n$ must be [[Independent events|independent]] and [[Normal distribution|normally distributed]] with mean $\mu$ and variance $\sigma^2$.

>[!gen]+ DISTRIBUTION
>$T=\frac{\bar X - \mu}{\sqrt{\frac{S^2}n}} \sim t_{n-1}$

>[!gen]+ PROBABILITY
>$\mathbb P(t_{n-1;\alpha/2}<T<t_{n-1;1-\alpha/2})=1-\alpha$
>$\mathbb P(-t_{n-1;1-\alpha/2}<T<t_{n-1;1-\alpha/2})=1-\alpha$
>$\mathbb P(-t_{n-1;1-\alpha/2}<\frac{\bar X - \mu}{\sqrt{\frac{S^2}n}}<t_{n-1;1-\alpha/2})=1-\alpha$
>$\mathbb P(-t_{n-1;1-\alpha/2}\sqrt{\frac{S^2}n}<\bar X - \mu<t_{n-1;1-\alpha/2}\sqrt{\frac{S^2}n})=1-\alpha$
>$\mathbb P(-\bar X-\frac{t_{n-1;1-\alpha/2}S}{\sqrt n}<-\mu<-\bar X+\frac{t_{n-1;1-\alpha/2}S}{\sqrt n})=1-\alpha$
>$\mathbb P(\bar X+\frac{t_{n-1;1-\alpha/2}S}{\sqrt n}>\mu>\bar X-\frac{t_{n-1;1-\alpha/2}S}{\sqrt n})=1-\alpha$
>$\mathbb P(\bar X-\frac{t_{n-1;1-\alpha/2}S}{\sqrt n}<\mu<\bar X+\frac{t_{n-1;1-\alpha/2}S}{\sqrt n})=1-\alpha$

>[!gen]+ CONFIDENCE INTERVAL
>$(\bar x-\frac{t_{n-1;1-\alpha/2}s}{\sqrt n},\bar x+\frac{t_{n-1;1-\alpha/2}s}{\sqrt n})$

---

#### Spaced repetition

Explain how to obtain a confidence interval for the normal distribution (variance unknown)
?
CONDITIONS:
	$X_1,...,X_n$ must be [[Independent events|independent]] and [[Normal distribution|normally distributed]] with mean $\mu$ and variance $\sigma^2$.
DISTRIBUTION:
	$\bar X \sim (\mu,\frac{\sigma^2}n)$ or $Z=\frac{\bar X - \mu}{\sqrt{\frac{\sigma^2}n}} \sim N(0,1)$
PROBABILITY:
	$\mathbb P(z_{\alpha/2}<Z<z_{1-\alpha/2})=1-\alpha$
	$\mathbb P(-z_{1-\alpha/2}<Z<z_{1-\alpha/2})=1-\alpha$
	$\mathbb P(-z_{1-\alpha/2}<\frac{\bar X - \mu}{\sqrt{\frac{\sigma^2}n}}<z_{1-\alpha/2})=1-\alpha$
	$\mathbb P(-z_{1-\alpha/2}\sqrt{\frac{\sigma^2}n}<\bar X - \mu<z_{1-\alpha/2}\sqrt{\frac{\sigma^2}n})=1-\alpha$
	$\mathbb P(-\bar X-\frac{z_{1-\alpha/2}\sigma}{\sqrt n}<-\mu<-\bar X+\frac{z_{1-\alpha/2}\sigma}{\sqrt n})=1-\alpha$
	$\mathbb P(\bar X+\frac{z_{1-\alpha/2}\sigma}{\sqrt n}>\mu>\bar X-\frac{z_{1-\alpha/2}\sigma}{\sqrt n})=1-\alpha$
	$\mathbb P(\bar X-\frac{z_{1-\alpha/2}\sigma}{\sqrt n}<\mu<\bar X+\frac{z_{1-\alpha/2}\sigma}{\sqrt n})=1-\alpha$
CONFIDENCE INTERVAL:
	$(\bar x-\frac{z_{1-\alpha/2}\sigma}{\sqrt n},\bar x+\frac{z_{1-\alpha/2}\sigma}{\sqrt n})$

Explain how to obtain a confidence interval for the normal distribution (variance unknown)
?
CONDITIONS:
	$X_1,...,X_n$ must be [[Independent events|independent]] and [[Normal distribution|normally distributed]] with mean $\mu$ and variance $\sigma^2$.
DISTRIBUTION:
	$T=\frac{\bar X - \mu}{\sqrt{\frac{S^2}n}} \sim t_{n-1}$
PROBABILITY:
	$\mathbb P(t_{n-1;\alpha/2}<T<t_{n-1;1-\alpha/2})=1-\alpha$
	$\mathbb P(-t_{n-1;1-\alpha/2}<T<t_{n-1;1-\alpha/2})=1-\alpha$
	$\mathbb P(-t_{n-1;1-\alpha/2}<\frac{\bar X - \mu}{\sqrt{\frac{S^2}n}}<t_{n-1;1-\alpha/2})=1-\alpha$
	$\mathbb P(-t_{n-1;1-\alpha/2}\sqrt{\frac{S^2}n}<\bar X - \mu<t_{n-1;1-\alpha/2}\sqrt{\frac{S^2}n})=1-\alpha$
	$\mathbb P(-\bar X-\frac{t_{n-1;1-\alpha/2}S}{\sqrt n}<-\mu<-\bar X+\frac{t_{n-1;1-\alpha/2}S}{\sqrt n})=1-\alpha$
	$\mathbb P(\bar X+\frac{t_{n-1;1-\alpha/2}S}{\sqrt n}>\mu>\bar X-\frac{t_{n-1;1-\alpha/2}S}{\sqrt n})=1-\alpha$
	$\mathbb P(\bar X-\frac{t_{n-1;1-\alpha/2}S}{\sqrt n}<\mu<\bar X+\frac{t_{n-1;1-\alpha/2}S}{\sqrt n})=1-\alpha$
CONFIDENCE INTERVAL:
	$(\bar x-\frac{t_{n-1;1-\alpha/2}s}{\sqrt n},\bar x+\frac{t_{n-1;1-\alpha/2}s}{\sqrt n})$