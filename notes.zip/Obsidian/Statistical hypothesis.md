---
aliases:
  - statistical hypothesis
  - null hypothesis
  - alternative hypothesis
  - HYPOTHESIS
type: def
tags:
  - MT2508
  - MT3507
---
Suppose a data set is drawn from a distribution with parameter $\theta \in \Theta$.

>[!def] Definition
>A statistical hypothesis is a statement about the value of $\theta$, a subset of $\Theta$. There are two hypothesis:
>- the null hypothesis $H_0$;
>- the alternative hypothesis $H_1$
