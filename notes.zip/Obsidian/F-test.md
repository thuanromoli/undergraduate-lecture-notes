---
type: mthd
tag: MT2508
---
Given the two sets of [[Random variables|rvs]] $X_1,...,X_n$ and $Y_1,...,Y_m$, carry out an F-test.

>[!gen]+ CONDITIONS:
>$X_1,...,X_n$ and $Y_1,...,Y_m$ must be two sets of [[Independent events|independent]] [[Normal distribution|normally distributed]] rvs with $X_i\sim N(\mu_X,\sigma^2_X)$ and $Y_j\sim N(\mu_Y,\sigma^2_Y)$

>[!gen]+ [[Statistical hypothesis|HYPOTHESIS]]:
>$H_0:\sigma^2_X=\sigma^2_Y$ vs $H_1:\sigma^2_X\neq\sigma^2_Y$

>[!gen]+ [[Test statistics|TEST STATISTIC]]
>$F=\frac{S^2_X}{S^2_{Y}}\sim F_{n-1,m-1}$

PROOF:
	$F=\frac{S^2_X}{S^{2}_{Y}}=\frac{S^2_X}{S^2_Y}\cdot\frac{\frac{(n-1)}{\sigma^2(n-1)}}{\frac{(m-1)}{\sigma^2(m-1)}}=\frac{\frac{(n-1)S^2_X}{\sigma^2}/(n-1)}{\frac{(m-1)S^2_Y}{\sigma^2}/(m-1)}$
	Hence $F$ is of the form $\frac{U/(n-1)}{V/(m-1)}$ with $U =\frac{(n-1)S^2_X}{\sigma^2}\sim\chi^2_{n-1}$ and $V=\frac{(m-1)S^2_Y}{\sigma^2}\sim\chi^2_{m-1}$.
	Hence $F \sim F_{n-1,m-1}$.

---

#### Spaced repetition

Given the two sets of [[Random variables|rvs]] $X_1,...,X_n$ and $Y_1,...,Y_m$, carry out an F-test.
?
CONDITIONS:
	$X_1,...,X_n$ and $Y_1,...,Y_m$ must be two sets of [[Independent events|independent]] [[Normal distribution|normally distributed]] rvs with $X_i\sim N(\mu_X,\sigma^2_X)$ and $Y_j\sim N(\mu_Y,\sigma^2_Y)$
[[Statistical hypothesis|HYPOTHESIS]]:
	$H_0:\sigma^2_X=\sigma^2_Y$ vs $H_1:\sigma^2_X\neq\sigma^2_Y$
[[Test statistics|TEST STATISTIC]]
	$F=\frac{S^2_X}{S^{2_{Y}}\sim}F_{n-1,m-1}$
	PROOF:
		$F=\frac{S^2_X}{S^{2_{Y}}\sim}F_{n-1,m-1}=\frac{S^2_X}{S^2_Y}\cdot\frac{\frac{(n-1)}{\sigma^2(n-1)}}{\frac{(m-1)}{\sigma^2(m-1)}}=\frac{\frac{(n-1)S^2_X}{\sigma^2}/(n-1)}{\frac{(m-1)S^2_Y}{\sigma^2}/(m-1)}$
		Hence $F$ is of the form $\frac{U/(n-1)}{V/(m-1)}$ with $U =\frac{(n-1)S^2_X}{\sigma^2}\sim\chi^2_{n-1}$ and $V=\frac{(m-1)S^2_Y}{\sigma^2}\sim\chi^2_{m-1}$.
		Hence $F \sim F_{n-1,m-1}$.