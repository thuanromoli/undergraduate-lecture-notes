---
alias: surjective
type: def
tag: MT2505
---
Let $f: X\to Y$ be a [[Functions|function]].

> [!def] Definition
> $f$ is surjective if each element of the codomain is mapped to by at least one element of the domain.

> [!def] Definition
> $f$ is surjective if
> $$\forall y \in Y, \; \exists \; x\in X \; \text{ s.t }\; y=xf$$

> [!def] Definition
> $f$ is surjective if
> $$\text{im } f = Y$$
