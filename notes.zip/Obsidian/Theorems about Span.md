---
tags:
  - MT2501
  - MT3501
type: thm
aliases:
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$, and let $v_{1},...,v_{k}$ be some vectors from $V$.

>[!thm]- $\text{Span}(v_{1},...,v_{k})$ is a [[Subspaces|subspace]] of $V$
>Let $W=\text{Span}(v_{1},...,v_{k})$.
>We proceed to use [[Theorems about subspaces#^b152ec|this theorem]] and note that a typical element of $W$ is $v=\alpha_{1}v_{1}+\alpha_{2}v_{2}+\ldots+\alpha_{k}v_{k}=\sum\limits_{i=1}^{k}\alpha_{i}v_{i}$
>
>Claim 1a: $W$ is non-empty.
>Let $\alpha_{i}=0 \;\;\forall i$, then $v=0v_{1},...,0v_{k}=\boldsymbol{0}$.
>Hence $W$ is certainly non-empty.
>
>Claim 1b: $W$ is a subset of $V$.
>Note that $V$ is a vector space *over* a field $F$ (which is usually infinite or finite mod $p$).
>Hence $V$ is also sually infinite or finite mod $p$.
>Note that $W=\text{Span}(v_{1},...,v_{k})=\set{\sum\limits_{i=1}^{k}\alpha_{i}v_{i}:a_{i}\in F}$.
>In particular all elements of $W$ are linear combinations of $v_{1},...,v_{k}$ and since the scalars are from $F$, the set $W$ is a subset of $V$.
>
>Claim 2: $W$ is closed under vector addition.
>Let $v,w\in W$.
>$v+w=\alpha_{1}v_{1}+\alpha_{2}v_{2}+\ldots+\alpha_{k}v_{k}+\beta_{1}v_{1}+\beta_{2}v_{2}+\ldots+\beta_{k}v_{k}$ = $\sum_{i=1}^{k}\alpha_{i}v_{i}+\sum_{i=1}^{k}\beta_{i}v_{i}=\sum_{i=1}^{k}(\alpha_{i}+\beta_{i})v_{i} \in W$.
>Hence $W$ is closed under vector addition.
>
>Claim 3: $W$ is closed under scalar multiplication.
>Let $v \in W$.
>$\alpha v=(\alpha\alpha_{1})v_{1}+(\alpha\alpha_{2})v_{2}+\ldots+(\alpha\alpha_{k})v_{k} \in W$
>Hence $W$ is closed under scalar multiplication.
>
>Hence $W$ is a subspace of $V$.

Below is not needed for MT3501.

>[!thm]- $\text{Span}(v_{1},...,v_{i},...,v_{j},...,v_{s})=\text{Span}(v_{1},...,v_{j},...,v_{i},...,v_{s})$
>Denote $W_{L}$ and $W_{R}$ the subspaces appearing on the left and right hand sides.
>To prove that they are equal, we need to show that every element of $W_{L}$ belongs to $W_{R}$ and vice-versa.
>This is trivial.

>[!thm]- $\text{Span}(v_{1},...,v_{i},...,v_{s})=\text{Span}(v_{1},...,\alpha v_{i},...,v_{s})$ for $\alpha \neq 0$
>Denote $W_{L}$ and $W_{R}$ the subspaces appearing on the left and right hand sides.
>To prove that they are equal, we need to show that every element of $W_{L}$ belongs to $W_{R}$ and vice-versa.
>Note that for all $l \neq i$, the vector $v_{l}$ is in both $W_{L}$ and $W_{R}$.
>Now consider $v_{i}$ and $\alpha v_{i}$:
>- $v_{i}$ = $0v_{1}+\ldots + 0v_{i-1}+ \frac{1}{\alpha}(\alpha v_{i})+0v_{i+1}+\ldots+0v_{s}\in W_{R}$
>- $\alpha v_{i}= 0v_{1}+\ldots + 0v_{i-1}+(\alpha)v_{i}+0v_{i+1}+\ldots+0v_{s}\in W_{L}$

>[!thm]- $\text{Span}(v_{1},...,v_{i},...,v_{j},...,v_{s})=\text{Span}(v_{1},...,v_{i}+\alpha v_{j},...,v_{j},...,v_{s})$
>Denote $W_{L}$ and $W_{R}$ the subspaces appearing on the left and right hand sides.
>To prove that they are equal, we need to show that every element of $W_{L}$ belongs to $W_{R}$ and vice-versa.
>Note that for all $l \neq i$, the vector $v_{l}$ is in both $W_{L}$ and $W_{R}$.
>Now consider $v_{i}$ and $v_{i}+\alpha v_{j}$:
>- $v_{i}$ = $0v_{1}+\ldots + (v_{i}+\alpha v_{j})+\ldots+(-\alpha)v_{j}+\ldots+0v_{s}\in W_{R}$
>- $v_{i}+\alpha v_{j}= 0v_{1}+\ldots + v_{i}+\ldots +\alpha v_{j}+\ldots+0v_{s}\in W_{L}$

---

#### Spaced repetition

Prove that $\text{Span}(v_{1},...,v_{k})$ is a [[Subspaces|subspace]] of $V$.
?
>Let $W=\text{Span}(v_{1},...,v_{k})$.
>We proceed to use [[Theorems about subspaces#^b152ec|this theorem]] and note that a typical element of $W$ is $v=\alpha_{1}v_{1}+\alpha_{2}v_{2}+\ldots+\alpha_{k}v_{k}=\sum\limits_{i=1}^{k}\alpha_{i}v_{i}$
>
>Claim 1a: $W$ is non-empty.
>Let $\alpha_{i}=0 \;\;\forall i$, then $v=0v_{1},...,0v_{k}=\boldsymbol{0}$.
>Hence $W$ is certainly non-empty.
>
>Claim 1b: $W$ is a subset of $V$.
>Note that $V$ is a vector space *over* a field $F$ (which is usually infinite or finite mod $p$).
>Hence $V$ is also sually infinite or finite mod $p$.
>Note that $W=\text{Span}(v_{1},...,v_{k})=\set{\sum\limits_{i=1}^{k}\alpha_{i}v_{i}:a_{i}\in F}$.
>In particular all elements of $W$ are linear combinations of $v_{1},...,v_{k}$ and since the scalars are from $F$, the set $W$ is a subset of $V$.
>
>Claim 2: $W$ is closed under vector addition.
>Let $v,w\in W$.
>$v+w=\alpha_{1}v_{1}+\alpha_{2}v_{2}+\ldots+\alpha_{k}v_{k}+\beta_{1}v_{1}+\beta_{2}v_{2}+\ldots+\beta_{k}v_{k}$ = $\sum_{i=1}^{k}\alpha_{i}v_{i}+\sum_{i=1}^{k}\beta_{i}v_{i}=\sum_{i=1}^{k}(\alpha_{i}+\beta_{i})v_{i} \in W$.
>Hence $W$ is closed under vector addition.
>
>Claim 3: $W$ is closed under scalar multiplication.
>Let $v \in W$.
>$\alpha v=(\alpha\alpha_{1})v_{1}+(\alpha\alpha_{2})v_{2}+\ldots+(\alpha\alpha_{k})v_{k} \in W$
>Hence $W$ is closed under scalar multiplication.
>
>Hence $W$ is a subspace of $V$.