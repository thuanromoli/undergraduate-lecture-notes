---
tags:
  - MT4554
type: thm
aliases:
---
>[!thm] Theorem
>For every [[Feasible payoffs|feasible payoff]] vector $\boldsymbol{u}$ with $u_{i}>w_{i}$ for all players $i$, there exists a $\delta^{*}<1$ such that for all $\delta\in(\delta^{*},1)$ there is a [[Nash equilibrium]] with payoffs $u$.

>[!gen] Intuition
>The intuition for this theorem is simply that when the players are patient, any finite one-period gain from deviation is outweighed by even a small loss in utility in every future round. The strategies we construct in the proof are “unrelenting” trigger strategies: a player who deviates will receive at most their reservation utility in every subsequent period.

Proof:
We will use a [[Trigger strategy|trigger strategy]].
Let $u_{i}^{*}$ be player $i$'s expected stage game payoff at equilibrium and let $s^{*}$ be the equilibrium strategy.
Let $\tilde u_{i}$ be the largest stage game payoff player $i$ can receive due to deviation and let $\tilde s$ be a strategy that plays at equilibrium then deviates.
Suppose that player $i$ decides to deviate the equilibrium strategy at round $t'$.
Then their round payoff is
$$\begin{align*}
 U_{i}(\tilde s,s^{*})&= (1-\delta)\left(\sum\limits_{t=0}^{t'-1}\sigma^{t}u^{*}_{i}+\sum\limits_{t=t'}^{t'}\sigma^{t}\tilde u_{i}+\sum\limits_{t=t'+1}^{\infty}\sigma^{t}w_{i}\right)\\
 &= (1-\delta) \left(\frac{1-\delta^{t'}}{1-\delta}u^{*}_{i}+\delta^{t'}\tilde u_{i}+ \frac{\delta^{t'+1}}{1-\delta}w_{i}\right)\\
 &= (1-\delta^{t'})u^{*}_{i}+(1-\delta)\delta^{t'}\tilde u_{i}+\delta^{t'+1}w_{i}
 \end{align*}$$
 and so deviation is not advantageous if
 $$\begin{align*}
 & \;\;\;\;\;\;\;\;\;\;U_{i}(\tilde s_{i},s^{*})< u^{*}_{i}\\
 &\iff u^{*}_{i}>(1-\delta^{t'})u_{i}^{*}+(1-\delta)\delta^{t'}\tilde u_{i}+\delta^{t'+1}w_{i}\\
 &\iff \frac{\delta^{t'+1}}{\delta^{t'}}(\tilde u_{i}-w_{i})>(\tilde u_{i}-u^{*}_{i})\\
 &\iff \delta > \frac{\tilde u_{i}-u^{*}_{i}}{\tilde u_{i}-w_{i}}
 \end{align*}$$
and since $u_{i}^{*}>w_{i}$ by our original assumption, then $\delta$.

Note: such punishment may be very costly for the punishers to carry out. Indeed, such strategies are not necessarily subgame perfect (see example in lecture notes and [[subgame perfect trigger strategies]]).