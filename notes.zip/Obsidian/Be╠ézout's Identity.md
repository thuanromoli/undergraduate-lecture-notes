---
type: thm
tag: MT2505
---
Let $a,b\in \mathbb{Z}$ such that at least one of $a$ and $b$ is non-zero.

>[!thm] Theorem
>The greatest common divisor of $a$ and $b$ is the smallest positive integer $d$ that can be written in the form $$d=ua+vb$$for some integers $u,v\in \mathbb{Z}$
>

PROOF:
	Let $d=\gcd(a,b)$. Then certainly $d$ exists since $a$ and $b$ are not both zero.
	Let $d_{1}$ be the smallest positive integer such that $d_{1}=ua+vb$.
	Now we wish to show that $d_{1}=d$.
	Claim 1: $d_{1} \geqslant d$
		Since $d=\gcd(a,b)$, then $d \mid a \wedge d \mid b$, then $a = k_{1}d$ and $b=k_{2}d$ for some $k_1,k_{2}\in \mathbb{Z}$
		In particular $d_{1}=u(k_{1}d)+v(k_{2}d)=(uk_{1}+vk_{2})d$. That is, $d_{1}$ is a multiple of $d$.
		Hence $d_{1}\geqslant d$ 
	Claim 2: $d \leqslant d_{1}$
		Let us divide $a$ by $d$ to obtain a quotient and a reminder
		$a = qd_{1} + r$ where $0 \leqslant r < d_{1}$
		$r=a-qd_{1}=a-q(ua+vb)=(1-qu)a + (-qv)b$
		This is in the same form as $d_{1}$ but $d_{1}$ is the smallest positive integer that can be written in this form. This forces $r$ to be zero.
		Hence $a=qd_{1}$ and similarly $b=sd_{1}$
		In particular $d_{1} \mid a$ and $d_{1} \mid b$ so $d_{1}$ is a common divisor.
		Since $d$ is the greatest of the divisors, $d_{1} \leqslant d$.
	We have shown that $d_{1} \geqslant d$ and $d_{1}\leqslant d$ hence it must me $d_{1}=d$
