---
tags:
  - MT4003
aliases:
---
Let $G$ be a [[Order|finite]] [[Abelian groups|abelian]] [[Groups|group]].

> [!thm]- Every [[Subgroups|subgroup]] of an abelian group is [[Normal subgroups|normal]]

^c20995

> [!thm]- If $H$ and $K$ are [[Subgroups|subgroups]] of $G$, then $H$ and $K$ are normal in $G$ and $HK=\set{hk:h\in H,k\in K}$ is also a subgroup of $G$

> [!thm]- If $x$ and $y$ are elements of $G$, then $|xy| \text{ divides } \text{lcm}(|x|,|y|)$

> [!thm]- If $g \in G$ and $h \in H$, then $|(g,h)|=\text{lcm}(|g|,|h|)$

> [!thm]- If $m$ and $n$ are coprime positive integers, then $C_{mn} \cong C_{m} \times C_{n}$
> Let $C_{m}= \langle x \rangle$ and $C_{n} = \langle y \rangle$.
> By [[Direct products#^bb7e4d|this theorem]], $C_{m} \times C_{n}$ is a group of order $mn$.
> Consider $g=(x,y) \in C_{m} \times C_{n}$.
> We proved that $|g| = \text{lcm}(|x|,|y|)=\text{lcm}(m,n)=mn$, since $m$ and $n$ are coprime.
> Hence $\langle g \rangle$ is a subgroup of order $mn$, which must be all of $C_{m} \times C_{n}$.

> [!thm]- If $n = p_{1}^{k_{1}}p_{2}^{k_{2}}\cdots p_{r}^{k_{r}}\in \mathbb Z_{>0}$ where $p_{1},...,p_{r}$ are distinct prime numbers, then $C_{n} \cong C_{p_{1}^{k_{1}}} \times C_{p_{2}^{k_{2}}} \times \cdots \times C_{p_{r}^{k_{r}}}$

^3a8b88
