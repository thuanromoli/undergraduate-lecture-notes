---
tags:
  - MT4551
aliases:
  - bonds
  - bond
---
> [!def] Definition
> A bond is an investment that:
> 1. Pays a fixed [[Interest rates|interest rate]] for fixed time.
> 2. At expiry returns a capital sum (face value).

> [!gen] Remarks
> - It is used to raise capital by governments (assumed [[Risk-free assets|risk free]]) or companies (higher risk).
> - If inflation rate > [[Interest rates|interest rate]], then at expiry a bond is worth less in real terms.
> - [[Risk-free assets|Risk-free]] interest rates may be determined by government bonds.
> - Once a bond is defined it is traded on the open market up to maturity.
> - If interest rate increases, then the price of a bond will decrease.

(See examples on slides)