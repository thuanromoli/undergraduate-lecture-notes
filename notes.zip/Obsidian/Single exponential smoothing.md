---
tags:
  - MT4527
aliases:
---
Let $X_{t} = m + Y_{t}$ be the [[Classical decomposition model|constant mean model]], with observations $x_{1},...,x_{t}$ for $t \in \mathbb N_{0}$.

> [!def] Definition
> The single exponential smoothing is a weighted average of all previous observations, where we give geometrically decreasing weights to previous observations
> $$\widehat m_{t}^{{es}} = (1-\theta)\sum\limits_{i=0}^{t-1}\theta^{i}x_{t-1}=(1- \theta)x_{t}+ \theta \widehat m_{t-1}^{es}$$
> where $\theta$ is a smoothing constant.
> 
> Sometimes we write instead $\widehat m_{t}^{{es}} = \alpha x_{t} +(1-\alpha)\widehat m_{t-1}^{{es}}$ where $\alpha=1-\theta$ is a discount factor.
