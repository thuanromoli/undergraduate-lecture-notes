---
alias: sample variance
type: def
tag: MT2508
---
Let $X_1,...,X_n$ be [[Random variables|rvs]] each with mean $\mu$ and variance $\sigma^{2}$.

>[!gen]+ Conditions
>$X_1,...,X_n$ must be [[Independent events|independent]]

>[!def] Definition
>The sample variance is
>$$S^{2}=\frac{1}{n-1}\sum\limits_{i=1}^{n}(X_{i}-\bar X)^{2}=\frac{1}{n-1}\left(\sum_{i=1}^nX_i^2-n\bar{X}^2\right)=\frac{1}{n-1}\left(\sum_{i=1}^nX_i^2-\frac{1}{n}(\sum_{i=1}^nX_i)^2\right)$$
>
>PROOF:
>	$S^{2}=\frac{1}{n-1}\sum\limits_{i=1}^{n}(X_{i}-\bar X)^{2}$ = $\frac{1}{n-1}\sum\limits_{i=1}^{n}(X_{i}^{2}-2X_{i}\bar X + \bar X^{2})$ = $\frac{1}{n-1}\left(\sum\limits_{i=1}^{n}X_{i}^{2}-2\sum\limits_{i=1}^{n}X_{i}\bar X + \sum\limits_{i=1}^{n}\bar X^{2}\right)$ = $\frac{1}{n-1}\left(\sum\limits_{i=1}^{n}X_{i}^{2}-2\bar X\sum\limits_{i=1}^{n}X_{i} + n\bar X^{2}\right)$
>		now using $\bar X = \frac{1}{n} \sum\limits_{i=1}^{n}X_{i}$ $\implies$ $\sum\limits_{i=1}^{n}X_{i}=n\bar X$
>	$S^{2}=\frac{1}{n-1}\left(\sum\limits_{i=1}^{n}X_{i}^{2}-2\bar X (n\bar X) + n\bar X^{2}\right)$ = $\frac{1}{n-1}\left(\sum\limits_{i=1}^{n}X_{i}^{2}-2n \bar X^{2} +n \bar X^{2}\right)$ = $\frac{1}{n-1} \left(\sum\limits_{i=1}^{n}X_{i}-n\bar X^{2}\right)$ 

>[!thm] Theorem
>The sample variance is an [[Unbiased estimators|unbiased estimator]] and [[Consistent estimators|consistent estimator]] of $\sigma^{2}$.
>
>PROOF:
>	$\mathbb{E}(S^{2})$ = $\mathbb{E}\left(\frac{1}{n-1}\left(\sum\limits_{i=1}^nX_i^2-n\bar{X}^2\right)\right)$ = $\frac{1}{n-1}\left(\sum\limits_{i=1}^{n}\mathbb{E}(X_{i}^{2})-n \mathbb{E}(\bar X^{2}))\right)$
>		now using $\text{Var}(Y) = \mathbb{E}(Y^{2}) - (\mathbb{E}(Y))^{2}$ $\implies$ $\mathbb{E}(Y^{2}) = (\mathbb{E}(Y))^{2} + \text{Var}(Y)$
>		in particular
>		$\mathbb{E}(X_{i}^{2})=(\mathbb{E}(X_{i}))^{2}+\text{Var}(X_{i})=\mu^{2}+ \sigma^{2}$
>		$\mathbb{E}(\bar X^{2}) = (\mathbb{E}(\bar X))^{2} + \text{Var}(\bar X)$ = $\mu^{2}+{\frac{\sigma^{2}}{n}}$
>	$\mathbb{E}(S^{2})$ = $\frac{1}{n-1}\left(\sum\limits_{i=1}^{n}(\mu^{2}+\sigma^{2})-n(\mu^{2}+ \frac{\sigma^{2}}{n})\right)$ = $\frac{1}{n-1}\left(\sum\limits_{i=1}^{n}(\mu^{2}+\sigma^{2})-n(\mu^{2}+ \frac{\sigma^{2}}{n})\right)$ = $\frac{1}{n-1}\left(n \mu^{2} + n \sigma^{2}-n \mu^{2}+ \sigma^{2}\right)$ = $\frac{1}{n-1}(n-1)\sigma^{2}$ = $\sigma^{2}$

```R
var(x)
```

---

#### Spaced repetition

What is the sample variance and prove the different forms
?
$$S^{2}=\frac{1}{n-1}\sum\limits_{i=1}^{n}(X_{i}-\bar X)^{2}=\frac{1}{n-1}\left(\sum_{i=1}^nX_i^2-n\bar{X}^2\right)=\frac{1}{n-1}\left(\sum_{i=1}^nX_i^2-\frac{1}{n}(\sum_{i=1}^nX_i)^2\right)$$
PROOF:
$S^{2}=\frac{1}{n-1}\sum\limits_{i=1}^{n}(X_{i}-\bar X)^{2}$ = $\frac{1}{n-1}\sum\limits_{i=1}^{n}(X_{i}^{2}-2X_{i}\bar X + \bar X^{2})$ = $\frac{1}{n-1}\left(\sum\limits_{i=1}^{n}X_{i}^{2}-2\sum\limits_{i=1}^{n}X_{i}\bar X + \sum\limits_{i=1}^{n}\bar X^{2}\right)$ = $\frac{1}{n-1}\left(\sum\limits_{i=1}^{n}X_{i}^{2}-2\bar X\sum\limits_{i=1}^{n}X_{i} + n\bar X^{2}\right)$
now using $\bar X = \frac{1}{n} \sum\limits_{i=1}^{n}X_{i}$ $\implies$ $\sum\limits_{i=1}^{n}X_{i}=n\bar X$
$S^{2}=\frac{1}{n-1}\left(\sum\limits_{i=1}^{n}X_{i}^{2}-2\bar X (n\bar X) + n\bar X^{2}\right)$ = $\frac{1}{n-1}\left(\sum\limits_{i=1}^{n}X_{i}^{2}-2n \bar X^{2} +n \bar X^{2}\right)$ = $\frac{1}{n-1} \left(\sum\limits_{i=1}^{n}X_{i}-n\bar X^{2}\right)$ 


Prove that the sample variance is an unbiased estimator of $\sigma^{2}$
?
$\mathbb{E}(S^{2})$ = $\mathbb{E}\left(\frac{1}{n-1}\left(\sum\limits_{i=1}^nX_i^2-n\bar{X}^2\right)\right)$ = $\frac{1}{n-1}\left(\sum\limits_{i=1}^{n}\mathbb{E}(X_{i}^{2})-n \mathbb{E}(\bar X^{2}))\right)$
now using $\text{Var}(Y) = \mathbb{E}(Y^{2}) - (\mathbb{E}(Y))^{2}$ $\implies$ $\mathbb{E}(Y^{2}) = (\mathbb{E}(Y))^{2} + \text{Var}(Y)$
in particular
	$\mathbb{E}(X_{i}^{2})=(\mathbb{E}(X_{i}))^{2}+\text{Var}(X_{i})=\mu^{2}+ \sigma^{2}$
	$\mathbb{E}(\bar X^{2}) = (\mathbb{E}(\bar X))^{2} + \text{Var}(\bar X)$ = $\mu^{2}+{\frac{\sigma^{2}}{n}}$
$\mathbb{E}(S^{2})$ = $\frac{1}{n-1}\left(\sum\limits_{i=1}^{n}(\mu^{2}+\sigma^{2})-n(\mu^{2}+ \frac{\sigma^{2}}{n})\right)$ = $\frac{1}{n-1}\left(\sum\limits_{i=1}^{n}(\mu^{2}+\sigma^{2})-n(\mu^{2}+ \frac{\sigma^{2}}{n})\right)$ = $\frac{1}{n-1}\left(n \mu^{2} + n \sigma^{2}-n \mu^{2}+ \sigma^{2}\right)$ = $\frac{1}{n-1}(n-1)\sigma^{2}$ = $\sigma^{2}$
