---
tags:
  - MT4531
aliases:
---
Let $\mathbf{x}$ be an observed sample from the same distribution with pdf $g(\theta)$, where $\theta$ is a parameter to be estimated.

> [!gen] Method
> 1. The expectation of $\theta$ is $$\mathbb E(\theta)=\int_{}^{}\theta g(\theta)\;d \theta.$$
> 2. Sample $\theta^{1},\theta^{2},...,\theta^{n}$ from $g(\theta)$.
> 3. Then take the average of the sample to obtain the MLE for the expectation of $\theta$ $$\widehat {\mathbb E}(\theta)=\frac{1}{n}\sum\limits_{i=1}^{n}\theta^{i}.$$
> 4. This extends to $$\widehat {\mathbb E}(f(\theta))=\frac{1}{n}\sum\limits_{i=1}^{n}f(\theta^{i}).$$

> [!gen] Calculating any definite integral
> $$\begin{align*}
   \int_{a}^{b}f(x)\;dx &= (b-a) \int_{a}^{b}f(x)\frac{1}{b-a}\;dx\\
   &= (b-a)\;\; \mathbb E(f(x)) \quad \text{(of a $U(a,b)$ distribution)}\\
   &\approx (b-a) \widehat{\mathbb E}(f(x))\\
   &=(b-a) \frac{1}{n} \sum\limits_{i=1}^{n}f(x^{i})
   \end{align*}$$
   where $x^{i}$ are sampled from the uniform $U(a,b)$ distribution.

