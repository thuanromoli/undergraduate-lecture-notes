---
type: def
tag: MT2506
---
>[!def] Definition
>The divergence is a vector operator s.t $\nabla \cdot \boldsymbol F: \mathbb{R}^{3} \to \mathbb{R}$ and it represents a measure of '[[Flux|flux]]'.

>[!gen]+ General coordinates:
>Let $\nabla = \boldsymbol e_u \frac{1}{g_u}\frac{\partial}{\partial u}+\boldsymbol e_v \frac{1}{g_v}\frac{\partial}{\partial v}+\boldsymbol e_w \frac{1}{g_w}\frac{\partial}{\partial w}$ and $\boldsymbol F = F_u\,\boldsymbol e_u+F_v\,\boldsymbol e_v+F_w\,\boldsymbol e_w$. Then
>$$\nabla\cdot\boldsymbol F= \boldsymbol e_u \frac{1}{g_u}\boldsymbol \cdot\frac{\partial\boldsymbol F}{\partial u}+\boldsymbol e_v \frac{1}{g_v}\boldsymbol \cdot\frac{\partial\boldsymbol F}{\partial v}+\boldsymbol e_w \frac{1}{g_w}\boldsymbol \cdot\frac{\partial\boldsymbol F}{\partial w} $$

>[!gen]+ [[Cartesian coordinates]]:
>$$\nabla\boldsymbol{\cdot F} = \frac{\partial F_x}{\partial x}+\frac{\partial F_y}{\partial y}+\frac{\partial F_z}{\partial z}$$

>[!gen]+ [[Cylindrical polar coordinates]]:
>$$\nabla\boldsymbol{\cdot F} = \frac{1}{R}\frac{\partial(RF_R)}{\partial R}+\frac{1}{R}\frac{\partial F_\phi}{\partial \phi}+\frac{\partial F_z}{\partial z}$$

>[!gen]+ [[Spherical coordinates]]:
>$$\nabla\boldsymbol{\cdot F} = \frac{1}{r^2}\frac{\partial(r^2F_r)}{\partial r}+\frac{1}{r\sin\theta}\frac{\partial (\sin\theta F_\theta)}{\partial \theta}+\frac{1}{r\sin\theta}\frac{\partial F_\phi}{\partial \phi}$$

---

#### Spaced repetition

What is the meaning of $\nabla \cdot f$ ?
?
The divergence is a vector operator s.t $\nabla \cdot \boldsymbol F: \mathbb{R}^{3} \to \mathbb{R}$ and it represents a measure of '[[Flux|flux]]'.

What is $\nabla \cdot f$ in general coordinates?
?
$$\nabla\cdot\boldsymbol F= \boldsymbol e_u \frac{1}{g_u}\boldsymbol \cdot\frac{\partial\boldsymbol F}{\partial u}+\boldsymbol e_v \frac{1}{g_v}\boldsymbol \cdot\frac{\partial\boldsymbol F}{\partial v}+\boldsymbol e_w \frac{1}{g_w}\boldsymbol \cdot\frac{\partial\boldsymbol F}{\partial w}  $$

What is $\nabla \cdot f$ in Cartesian Coordinates?
?
$$\nabla\boldsymbol{\cdot F} = \frac{\partial F_x}{\partial x}+
\frac{\partial F_y}{\partial y}+
\frac{\partial F_z}{\partial z}
$$

What is $\nabla \cdot f$ in Cylindrical polar coordinates?
?
$$\nabla\boldsymbol{\cdot F} = \frac{1}{R}\frac{\partial(RF_R)}{\partial R}+
\frac{1}{R}\frac{\partial F_\phi}{\partial \phi}+
\frac{\partial F_z}{\partial z}$$

What is $\nabla \cdot f$ in Spherical coordinates?
?
$$\nabla\boldsymbol{\cdot F} = \frac{1}{r^2}\frac{\partial(r^2F_r)}{\partial r}+
\frac{1}{r\sin\theta}\frac{\partial (\sin\theta F_\theta)}{\partial \theta}+
\frac{1}{r\sin\theta}\frac{\partial F_\phi}{\partial \phi}$$