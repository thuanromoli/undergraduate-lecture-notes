---
tags:
  - MT2502
aliases:
  - subsequence
---
Let $(x_{n})_{n}$ be a [[Sequences|sequence]] and $(m_{k})_{k}$ be a sequence of natural numbers $m_{1}<m_{2}<m_{3}< \cdots$.

> [!def] Definition
> The sequence $(x_{m_{k}})_{k}$ is called a subsequence of $(x_{n})_{n}$.
