---
tags:
  - MT3502
aliases:
---
Let $A \subseteq X$ be a subset.

> [!thm]- $A$ is [[Closed sets and limit points|closed]] $\iff$ $A^{c}$ is [[Open sets|open]]

> [!thm]- $\varnothing$ and $X$ are both open sets

> [!thm]- $\varnothing$ and $X$ are both closed sets

> [!thm]- $U_{1},...,U_{k}$ are each open sets $\implies$ $\bigcap\limits_{i=1}^{k}U_{i}$ is open

> [!thm]- $U_{1},U_{2},...$ are each open sets $\implies$ $\bigcup\limits_{i=1}^{\infty}U_{i}$ is open

> [!thm]- $A_{1},...,A_{k}$ are each closed sets $\implies$ $\bigcup\limits_{i=1}^{k}A_{i}$ is closed

> [!thm]- $A_{1},A_{2},...$ are each closed sets $\implies$ $\bigcap\limits_{i=1}^{\infty}U_{i}$ is closed
