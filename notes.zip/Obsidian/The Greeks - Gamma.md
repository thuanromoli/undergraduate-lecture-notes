---
tags:
  - MT4551
aliases:
---
> [!def] Definition
> The gamma is defined as
> $$\Gamma = \frac{\partial \Delta}{\partial S} = \frac{\partial ^{2}V}{\partial S^{2}}$$
> and it measures the sensitivity of $\Delta$ to $S$ ($\Gamma$ large $\to$ frequent adjustment required).

> [!gen] Remarks
> - $\Gamma = N'(d_{1}) \frac{\partial d_{1}}{\partial S} = \frac{1}{\sqrt{2 \pi}}e^{-d_{1}/2}\frac{1}{S \sigma \sqrt{T-t}}$
