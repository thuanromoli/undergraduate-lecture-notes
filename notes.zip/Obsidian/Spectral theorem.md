---
tags:
  - MT3501
type: thm
aliases:
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Inner product spaces|inner product space]] with inner product $\langle \cdot , \cdot \rangle$.
Let $T:V\to V$ be a [[Self-adjoint transformations|self-adjoint]] [[Linear transformations|linear transformation]].

>[!thm] Theorem
>A [[Self-adjoint transformations|self-adjoint transformation]] of a [[Dimension|finite-dimensional]] [[Inner product spaces|inner product space]] is [[Diagonalisability|diagonalisable]].

>[!gen] Corollary
>- A real symmetric matrix is diagonalisable
>- A Hermitian matrix is diagonalisable
>
>Proof: this comes from the above theorem and [[Theorems about self-adjoint transformations|these first two theorems]].

We prove this theorem by induction on $\dim V$.

Basis, $\dim V = 1$: $\text{Mat}(T)$ is a $1\times 1$ matrix so is already [[Diagonal matrices|diagonal]].

Assumption, $\dim V>1$: assume that a self-adjoint transformation of a f.d.i.p.s. of dimension smaller than $\dim V$ is diagonalisable.

Now consider the [[Characteristic polynomials|characteristic polynomial]] $c_{T}(x)$.
[[Theorems about self-adjoint transformations#^4cfbcb|By this theorem]], $c_{T}(x)$ is a product of linear factors and so there exists some root $\lambda\in F$.
Let $v_{1}$ be an [[Eigenvectors and Eigenvalues|eigenvector]] with [[Eigenvectors and Eigenvalues|eigenvalue]] $\lambda$.
Let $U=\text{Span}(v_{1})$ be the [[Subspaces|subspace]] spanned by $v_{1}$.
Now as $T(v_{1})=\lambda v_{1}\in U$, we see that $U$ is $T$-invariant.
Hence by [[Theorems about self-adjoint transformations#^d83224|this theorem]], $U^{\perp}$ is $T^*$-invariant and since $T=T^{*}$, $U^{\perp}$ is also $T$-invariant.
By [[Theorems about orthogonal complements#^0089bc|this theorem]], $V=U \oplus U^{\perp}$.
Hence $\dim V= 1 +\dim U^{\perp}$, in particular $\dim U^{\perp}<\dim V$.
Now consider the restriction $S=T|_{U^{\perp}}:U^{\perp}\to U^{\perp}$ of $T$ to $U^{\perp}$. This is also self-adjoin since $\langle T(v),w \rangle = \langle v,T(w) \rangle$ for all $v,w\in U^{\perp}$ as $U^{\perp}\subseteq V$ and so $\langle S(v),v \rangle=\langle v,S(v) \rangle$.
So by assumption, since $S$ is self-adjoint and of dimension smaller than $\dim V$, then it is diagonalisable.
Hence there is a basis $\set{v_{2},...,v_{n}}$ for $U^{\perp}$ of [[Eigenvectors and Eigenvalues|eigenvectors]] for $S$.
Hence they are also eigenvectors for $T$.
Then as $V=U \oplus U^{\perp}$, we have that $\set{v_{1},v_{2},...,v_{n}}$ is a basis for $V$ consisting of eigenvalues for $T$.
Hence $T$ is diagonalisable.