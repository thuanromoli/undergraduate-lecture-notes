---
tags:
  - MT4551
aliases:
---
Consider [[Particles random walk - time dependant process|Brownian motion]], with the size of the jump modelled by a [[Normal distribution|normal distribution]] with standard deviation $\sigma_{v}^{2}=2Dt$.

> [!def] Basic Wiener process
> If we take a jump in time $dt$ then the change of position $x$, namely $dx$ is
> $$dx = \sigma dW \;\;\;\;\;\;\text{where}\;\;\;\;\;\; dW = \varepsilon \sqrt{dt}$$
> where $\varepsilon$ is a number chosen randomly from a normal distribution with $\mu= 0$ and $\sigma=1$.
> 

> [!gen] Remarks
> 1. $dW$ is called the Wiener process.
> 2. $dx$ is independent of $x$, it does not depend on the current position.
> 3. $\sigma^{2}=\sigma^{2}(x,t)$ is the variance rate such that at time $t$, $Var = \sigma^{2}t$ and $SD = (\sigma^{2}t)^{\frac{1}{2}}$
> 4. The motion is $dx = \sigma \varepsilon \sqrt{dt}$ and since $\varepsilon\sim N(0,1)$ then $dx$ is also normally distributed with $\mathbb E(dx)=0$ and $\mathbb E(dx^{2})= \sigma^{2}t$.

> [!def] Wiener process with drift
> In addition to the random component $dW$ we may have a non-zero, non-random component to $dx$,
> $$dx = \mu dt + \sigma dW$$
> where $\mu$ is the drift rate.

> [!gen] Motivation
> Suppose there was no random component, that is $dW = 0$.
> Then $dx = \mu dt \implies \int dx=\int\mu dt \implies x=x_{0}+\mu t$.
> Note that if $\mu = 0$ (no drift) then $x = x_{0}$ (the current position).

> [!thm] Solution to the Wiener process
> The solution to the stochastic differential equation $dx = \mu dt + \sigma dW$ is a probability distribution for $x$.
> 
> With the [[Initial values and IVP|initial values]] $t=0$, $x=x_{0}$ and with $\mu$ and $\sigma$ constants, then the position $x$ for a single particle
> 1. Is a [[Particles random walk - time dependant process|random path]] in $x$ that takes the form of a normal distribution.
> 2. Has centre at $x=x_{0}+\mu t$, with variance $\sigma^{2}t$.
> 3. Has [[Probability density function|pdf]]
>    $$f(x) = \frac{1}{\sqrt{2 \pi \sigma^{2}t}} \exp \left[ - \frac{(x-(x_{0}+\mu t))^{2}}{2 \sigma^{2}t} \right]$$
> 4. Graphically,
>    ![[Wienerprocess_att.png|300]]
