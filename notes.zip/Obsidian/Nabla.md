---
type: def
tag: MT2506
---
>[!def] Definition
>Nabla is a vector operator that is used as a building block for other operators such as the [[gradient]], the [[divergence]], the [[curl]], and the [[Laplacian]].

>[!gen]+ General coordinates:
>$$\nabla = \boldsymbol e_u \frac{1}{g_u}\frac{\partial}{\partial u}+\boldsymbol e_v \frac{1}{g_v}\frac{\partial}{\partial v}+\boldsymbol e_w \frac{1}{g_w}\frac{\partial}{\partial w}$$

>[!gen]+ [[Cartesian coordinates]]:
>$$\nabla  = \boldsymbol i\frac{\partial }{\partial x}+\boldsymbol j\frac{\partial }{\partial y}+\boldsymbol k\frac{\partial }{\partial z}$$

>[!gen]+ [[Cylindrical polar coordinates]]:
>$$\nabla  = \boldsymbol e_R\frac{\partial }{\partial R}+\boldsymbol e_\phi\frac{1}{R}\frac{\partial }{\partial \phi}+\boldsymbol e_z\frac{\partial }{\partial z}$$

>[!gen]+ [[Spherical coordinates]]:
>$$\nabla = \boldsymbol e_r\frac{\partial }{\partial r}+\boldsymbol e_\theta\frac{1}{r}\frac{\partial}{\partial \theta}+\boldsymbol e_\phi\frac{1}{r\sin\theta}\frac{\partial }{\partial \phi}$$

---

#### Spaced repetition

What is the meaning of $\nabla$ ?
?
It's a vector operator that is used as a building block for other operators

What is $\nabla$ in general coordinates?
?
$$\nabla = \boldsymbol e_u \frac{1}{g_u}\frac{\partial}{\partial u}+\boldsymbol e_v \frac{1}{g_v}\frac{\partial}{\partial v}+\boldsymbol e_w \frac{1}{g_w}\frac{\partial}{\partial w}$$

What is $\nabla$ Cartesian Coordinates?
?
$$\nabla  = \boldsymbol i\frac{\partial }{\partial x}+\boldsymbol j\frac{\partial }{\partial y}+\boldsymbol k\frac{\partial }{\partial z}
$$

What is $\nabla$ in Cylindrical polar coordinates?
?
$$\nabla  = \boldsymbol e_R\frac{\partial }{\partial R}+\boldsymbol e_\phi\frac{1}{R}\frac{\partial }{\partial \phi}+\boldsymbol e_z\frac{\partial }{\partial z}$$

What is $\nabla$ in Spherical coordinates?
?
$$\nabla = \boldsymbol e_r\frac{\partial }{\partial r}+\boldsymbol e_\theta\frac{1}{r}\frac{\partial}{\partial \theta}+\boldsymbol e_\phi\frac{1}{r\sin\theta}\frac{\partial }{\partial \phi}$$