---
type: model
tag: MT2507
---
>[!gen]+ Intuition
>- When there is no competition then both populations grow ([[Logistic growth]]).
>- Both species are competing for the same resource.
>- Both populations have a negative effect on each other.

>[!gen]+ Model:
>$$\matrix{\frac{dx}{dt}=(a_{1}-b_{1}x)x-c_{1}xy=x(a_{1}-b_{1}x-c_{1}y) \\ \frac{dy}{dt}=(a_{2}-b_{2}y)y-c_{2}xy=y(a_{2}-b_{2}y-c_{2}x )}$$

>[!gen]+ Terms:
>- First form:
>	- $(a_{1}-b_{1}x)x$ and $(a_{2}-b_{2}y)y$ are the logistic equations;
>	- $(c_1 xy)$ and $(c_{2}xy)$ are the effects of the other species;
>- Second form:
>	- $a_1$ and $a_{2}$ is the natural growth of $x$ and $y$;
>	- $(-b_{1}x)$ and $(-b_2y)$ are the inhibition of $x$ and $y$ by themselves;
>	- $c_{1}$ and $c_{2}$ are the inhibition of $x$ and $y$ by the other species.

>[!gen]+ Solution:
>We proceed to [[Sketch of a phase portrait|sketch the phase portrait]].
>Note: there are 4 [[Critical points and steady states|steady states]]:
>- $(0,0)\implies$ both populations die out;
>- $(\frac{a_{1}}{ b_{1}},0)\implies$ $x$ outcompted $y$;
>- $(0,\frac{a_{2}}{b_{2}})\implies$ $y$ outcompeted $x$;
>- $(x^{*},y^{*})\implies$ mutual coexistance if $x^{*},y^{*}>0$.