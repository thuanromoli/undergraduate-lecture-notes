---
tags:
  - MT4509
aliases:
---
[[Incompressibility|Incompressible]] if $\nabla \cdot \boldsymbol{u=0}$ or $\frac{D \rho}{Dt} = 0$.
Homogeneous if $\rho$ = constant everywhere. (which implies incompressibility)
[[Steady flow]] if $\frac{\partial \boldsymbol{u}}{\partial t}=0$ or $\boldsymbol{u}=\boldsymbol{u}(\boldsymbol{x})$ (independent of time $t$).
At rest if $\boldsymbol{u}=0$ (which implies steady flow).
Inviscid if there is no viscosity/friction.
Potential if $\nabla \times \boldsymbol{u}=\boldsymbol{0}$.
