---
tags:
  - MT3501
type: thm
aliases:
---
Let $V$ be an [[Inner product spaces|inner product space]] with inner product $\langle \cdot,\cdot \rangle$.

>[!thm]- $\langle v, \alpha w \rangle=\bar \alpha \langle v,w \rangle \;\;\forall v,w\in V,\alpha\in F$
>$\langle v,\alpha w \rangle=\overline{\langle  \alpha w,v \rangle}=\bar \alpha \overline{\langle w,v \rangle}=\bar \alpha \langle v,w \rangle$

>[!thm]- $\Vert \alpha v\Vert=|\alpha|\cdot\Vert v \Vert \;\;\forall v\in V,\alpha\in F$
>${\Vert \alpha v \Vert}^{2}=\langle \alpha v, \alpha v \rangle=\alpha \langle v,\alpha v \rangle=\alpha \bar \alpha \langle v,v \rangle={|\alpha|}^{2} {\Vert v \Vert}^{2}$
>Then take square roots.

>[!thm]- $\Vert v \Vert>0 \;\;\forall v\neq \boldsymbol{0}$
>$\langle v,v \rangle>0$ whenever $v \neq \boldsymbol{0}$.
