---
type: def
tag: MT2507
---
>[!def] Definition
>Air resistance $R$ is a force which acts against an object as it travels through the air.

There are two cases:
Case 1: we assume $\boldsymbol R$ scales with velocity: 
$$\boldsymbol R=-mk \boldsymbol v$$Case 2: we assume $\boldsymbol R$ scales with velocity squared:
$$\boldsymbol R=-mk |\boldsymbol v| \boldsymbol v$$