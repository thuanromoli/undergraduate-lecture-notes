---
type: def
tag: MT2507
---
Let $f(x)$ be a [[Periodic functions|periodic function]] with period $L=2l$

>[!def] Definition
>The standard interval for a [[Periodic functions|periodic function]] of period $L=2l$ is the symmetric interval $[-l,l)$

>[!gen]+ Method to shift a function $f(x)$ defined on $x \in [a,b)$ onto $[-l,l)$
>1. Define a new independent variable $X=x- \frac{a+b}{2}$
>2. Then the function $f(X)$ is defined on $X\in [-l,l)$
