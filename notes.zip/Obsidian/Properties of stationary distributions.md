---
tags:
  - MT4528
type: thm
aliases:
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $\mathcal S=\set{1,2,...}$ and [[n-step transition probability matrices|tpm]] $\boldsymbol{P}$ and [[Stationary distributions|stationary distribution]] $\boldsymbol{\pi}$.

>[!thm] $\boldsymbol{\pi}$ is a stationary distribution $\iff$ $\boldsymbol{\pi}$ is a left [[Eigenvectors and Eigenvalues|eigenvector]] of $P$ with [[Eigenvectors and Eigenvalues|eigenvalue]] 1.

>[!thm] A Markov chain that is in its stationary distribution at time $t$, $\boldsymbol{u}(t)=\boldsymbol{\pi}$, continues to have this unconditional distribution for all subsequent times

>[!thm] If $\boldsymbol{u}(0)=\boldsymbol{\pi}$ then $\boldsymbol{u}(t)=\boldsymbol{\pi}$ for all $t=0,1,2,...$
