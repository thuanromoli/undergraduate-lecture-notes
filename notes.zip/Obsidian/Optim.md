---
tags:
  - MT3508
aliases:
---
> [!gen] Usage
> When optimising for a single parameter, use
> ``` R
> optim(start, negloglik, y = y, method = 'Brent', lower = lo, upper = up, hessian = TRUE)

> [!gen] Parametrisation
> The function `optim` searches the $\mathbb R^{q}$ space, where $q$ is the number of parameters, for the minimum.
> 
> When we want to impose our own constraints to a parameter $\theta$, we need to write $\theta$ in terms of a parameter $\beta$ which can take values in $\mathbb R$.
> 
> Here are some examples:
> - log-transform: $\sigma^{2}>0$ so $\sigma^{2}=e^ \beta$ where $\beta=\log(\sigma^{2})$.
> - logit-transform: $0 \leqslant p \leqslant 1$ so $p=\frac{\exp(\beta)}{1+\exp(\beta)}$ where $\beta=\log(\frac{p}{1-p})$.

> [!gen] Outputs
> - `par` - the value of $\boldsymbol{\theta}$ at which the minimum of the function occurs.
> - `value` - the value of the function at its minimum.
> - `counts` - a two-element integer vector giving the number of calls to `fn` and `gr`.
> - `convergence` - an integer indicating how sure `optim` is that it has found the minimum.
> - `hessian` - returns the [[Hessian matrix]]. Since we pass a negative [[Log-likelihood]], it returns the negative Hessian, so it returns the [[Fisher information]].
