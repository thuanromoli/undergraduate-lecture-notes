---
tag: MT2501
type: thm
alias:
- 
---
Let $A$ be an $n \times n$ [[Matrices|matrix]].

>[!thm] [[Elementary row operations]] can be represented by elementary matrices
>- for $r_{i}\leftrightarrow r_{j}, i\neq j$
>	1. the matrix is $E_{ij}$
>	2. consider $I_{n}$
>	3. swap rows $i$ and $j$
>- for $r_{i}\mapsto \lambda r_{i}, \lambda \neq 0$
>	1. the matrix is $E_{i}(\lambda)$
>	2. consider $I_{n}$
>	3. replace the $i$th diagonal entry by $\lambda$
>- for $r_{i}\mapsto r_{i} + \lambda r_{j}, i\neq j$
>	1. the matrix $E_{ij}(\lambda)$
>	2. consider $I_{n}$
>	3. replace the entry $0$ in the $(i,j)$ position by $\lambda$

>[!thm] Elementary matrices are inversible
>- $E_{ij}^{-1}=E_{ij}$
>- $E_{i}(\lambda)^{-1}=E_{i}(\frac{1}{\lambda})$
>- $E_{ij}(\lambda)^{-1}=E_{ij}(-\lambda)$

^0b7578

>[!thm] $A$ is [[Elementary row operations|row-equivalent]] to $I_{n}$ $\implies$ $A$ is invertible. (The opposite is also true but is shown in [[Theorems about inverse matrices (as an object and its form)#^17bb19|this theorem]])
>Suppose $A$ can be transformed to $I_{n}$ using e.r.o.s.
>Then we have $E_{k}E_{k-1}\ldots E_{1}A=I_{n}$ for some elementary matrices $E_{i}$. For clarity, let $E=E_{k}E_{k-1}\ldots E_{1}$ and note that $E$ is [[The inverse of a matrix|invertible]] by [[Elementary matrices#^0b7578|this]].
>Hence $EA=I_{n}$ $\implies$ $A=E^{-1}I_{n}=E^{-1}$ $\implies$ $A^{-1}= E$ as claimed.

^2b6b08

---

#### Spaced repetition
What are the elementary matrices that represent the elementary row operations?
?
>- for $r_{i}\leftrightarrow r_{j}, i\neq j$
>	1. the matrix is $E_{ij}$
>	2. consider $I_{n}$
>	3. swap rows $i$ and $j$
>- for $r_{i}\mapsto \lambda r_{i}, \lambda \neq 0$
>	1. the matrix is $E_{i}(\lambda)$
>	2. consider $I_{n}$
>	3. replace the $i$th diagonal entry by $\lambda$
>- for $r_{i}\mapsto r_{i} + \lambda r_{j}, i\neq j$
>	1. the matrix $E_{ij}(\lambda)$
>	2. consider $I_{n}$
>	3. replace the entry $0$ in the $(i,j)$ position by $\lambda$

What are the inverses of the elementary matrices?
?
>- $E_{ij}^{-1}=E_{ij}$
>- $E_{i}(\lambda)^{-1}=E_{i}(\frac{1}{\lambda})$
>- $E_{ij}(\lambda)^{-1}=E_{ij}(-\lambda)$

Prove that: $A$ is [[Elementary row operations|row-equivalent]] to $I_{n}$ $\implies$ $A$ is invertible.
?
>Suppose $A$ can be transformed to $I_{n}$ using e.r.o.s.
>Then we have $E_{k}E_{k-1}\ldots E_{1}A=I_{n}$ for some elementary matrices $E_{i}$. For clarity, let $E=E_{k}E_{k-1}\ldots E_{1}$ and note that $E$ is [[The inverse of a matrix|invertible]] by [[Elementary matrices#^0b7578|this]].
>Hence $EA=I_{n}$ $\implies$ $A=E^{-1}I_{n}=E^{-1}$ $\implies$ $A^{-1}= E$ as claimed.