---
type: thm
tag: MT2506
---
Let $S$ be the closed surface bounding the volume $V$, and $\boldsymbol{F}$ be a [[Differentiability|differentiable]] [[Vector fields|vector field]].

>[!thm] 3D Gauss' Theorem
>Gauss' Theorem states that
>$$\iiint_{V}(\boldsymbol{\nabla \cdot F})\text{ dV}=\iint_{S \text{ closed}}\boldsymbol{F}(\boldsymbol{r}) \cdot \text{d}\boldsymbol{S}$$
>where $\text{d}\boldsymbol{S}$ is directed out of $V$.

>[!thm] 2D Gauss' Theorem
>There is a two-dimensional version of Gauss' Theorem:
>$$\iint_{S}(\boldsymbol{\nabla \cdot F})\text{ dS}=\oint_{C}\boldsymbol{F}(\boldsymbol{r}) \cdot \text{d}\boldsymbol{n}$$
>where the equivalent of $\text{dV}$ is $\text{dS}=|d \boldsymbol{S}|$ and the equivalent of $d \boldsymbol{S}$ is $d \boldsymbol{n}$, the outward normal to the contour $C$.
>Note: in a plane, Gauss' Theorem is equivalent to [[Green's Theorem]].
