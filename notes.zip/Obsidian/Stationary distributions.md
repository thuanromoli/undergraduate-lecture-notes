---
tags:
  - MT4528
type: def
aliases:
  - stationary distribution
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $\mathcal S=\set{1,2,...}$ and [[n-step transition probability matrices|tpm]] $\boldsymbol{P}$.

>[!def] Definition
>A stationary distribution of the Markov chain is a vector $\boldsymbol{\pi}=(\pi_{1},\pi_{2},...)$ such that
>$$\boldsymbol{\pi}\boldsymbol{P}=\boldsymbol{\pi} \;\;\text{ and } \;\;\sum\limits_{i\in \mathcal S}^{}\pi_{i}=1$$
>That is, the limiting distribution of [[State occupation distribution|state occupation distribution]]:
>$$\boldsymbol{\pi}=\lim\limits_{t \to \infty} \boldsymbol{u}(t)$$
>where $\pi_{j}=\lim\limits_{t \to \infty}u_{j}(t)=\lim\limits_{t \to \infty}\mathbb P(X_{t}=j)$.
