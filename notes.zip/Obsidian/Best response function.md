---
tags:
  - MT4554
type: def
aliases:
---
>[!def] Best response
>The best response for a player $i$ is the strategy that gives the highest payoff given all other player's strategies.

>[!def] Best response function
>The best response function for player $i$ given all other player's $-i$ strategies, is defined to be the set of best responses of player $i$:
>$$B_{i}(\sigma_{-i}) = \set{\sigma_{i}' \in \Sigma_{i}:u_{i}(\sigma_{i}',\sigma_{-i})\geqslant u_{i}(\sigma_{i},\sigma_{-i}), \;\;\forall \sigma_{i}\in \Sigma_{i}}$$

>[!def] Set of best responses
>$B(\sigma)=[B_{i}(\sigma_{-i})]_{i\in \mathcal N}$
