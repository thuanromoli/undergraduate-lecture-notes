---
tags:
  - MT3502
aliases:
  - properties of the integral
---
Let $f:[a,b] \to \mathbb R$ be a [[Boundedness|bounded]] [[Functions|function]].

> [!thm]- $\int_{a}^{b}f = \int_{a}^{c}f + \int_{c}^{b}f$, for all $a<c<b$

> [!thm]- $\int_{a}^{b} \lambda f = \lambda \int_{a}^{b}f$

> [!thm]- $\int_{a}^{b} (f+g) = \int_{a}^{b}f + \int_{a}^{b}g$

> [!thm]- If $f$ and $g$ are integrable, then so is $f\;g$

> [!thm]- $\left| \int_{a}^{b} f\right| \leqslant \int_{a}^{b} |f|$

> [!thm]- $M_{1}(b-a) \leqslant \int_{a}^{b}f \leqslant M_{2}(b-a)$, when $M_{1} \leqslant f(x) \leqslant M_{2}$ for all $x \in [a,b]$

> [!thm]- $f \geqslant 0 \implies \int_{a}^{b} \geqslant 0$.

> [!thm]- [[Cauchy-Schwarz inequality]]
