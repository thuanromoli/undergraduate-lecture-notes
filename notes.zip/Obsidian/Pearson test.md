---
tags:
  - MT3508
aliases:
---
> [!gen] [[Statistical hypothesis|Hypothesis]]
> $H_{0}$: the data follow a specified distribution.
> $H_{1}$: the data do not follow a specified distribution.

> [!gen] [[Test statistics]] ($\phi$ must be known)
> $$X^{2} = \sum\limits_{i=1}^{n} \frac{(y_{i}-\widehat{\mu_{i}})^{2}}{V(\widehat {\mu_{i}})} \sim \chi^{2}_{n-p}.$$
> Note: for the [[Poisson distributions]], this is the same as [[Chi squared goodness-of-fit test (testing the distribution)]].
