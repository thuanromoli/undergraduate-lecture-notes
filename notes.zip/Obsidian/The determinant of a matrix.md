---
tag: MT2501
type: def
alias:
- determinant
---
Let $A$ be an $n\times n$ [[Square matrices|square matrix]], and let $i,j \in \set{1,...,n}$ be arbitrary.

>[!def] Definition
>The determinant of the $n \times n$ matrix $A=[a_{ij}]$ is
>$$\det(A) = \lvert A \rvert =\sum\limits_{j=1}^{n}(-1)^{1+j}a_{1j}\det(M_{1j})=\sum\limits_{j=1}^{n}a_{1j}A_{1j}$$
>where $A_{1j}$ is the $(1,j)$ [[The cofactor of a matrix|cofactor of the matrix A]]

---

#### Spaced repetition

What is the determinant of the $n \times n$ matrix $A=[a_{ij}]$?
?
>The determinant of the $n \times n$ matrix $A=[a_{ij}]$ is
>$$\det(A) = \lvert A \rvert =\sum\limits_{j=1}^{n}(-1)^{1+j}a_{1j}\det(M_{1j})=\sum\limits_{j=1}^{n}a_{1j}A_{1j}$$
>where $A_{1j}$ is the $(1,j)$ [[The cofactor of a matrix|cofactor of the matrix A]]
<!--SR:!2023-07-06,3,250-->