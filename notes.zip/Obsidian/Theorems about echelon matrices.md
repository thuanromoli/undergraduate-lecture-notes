---
tag: MT2501
type: thm
alias:
- 
---
Let $A$ be a [[Matrices|matrix]].

>[!thm]- Every non-zero matrix $A$ is [[Elementary row operations|row-equivalent]] to an [[Echelon form|echelon]] matrix
>The proof is the formalisation of Gaussian elimination

>[!thm]- Every non-zero matrix $A$ is [[Elementary row operations|row-equivalent]] to a [[Echelon form|reduced echelon]] matrix
>The proof is the formalisation of Gaussian elimination

>[!thm]- For a given matrix $A$ there is only one [[Echelon form|reduced echelon]] matrix $E$ [[Elementary row operations|row-equivalent]] to $A$
>Proof omitted

>[!thm]- In the case when $A$ is a [[Square matrices|square matrix]], then either $E$ has an all-zero row or $E=I_{n}$
>Proof omitted

^b32e52

>[!thm]- Two matrices $A$ and $B$ are [[Elementary row operations|row-equivalent]] if and only if their [[Echelon form|reduced echelon]] forms are equal
>Proof omitted

>[!thm]- Theorem about number of parameters in the solution(s) of a system of linear equations
>Suppose that the extended matrix of a system of linear equations in $n$ unknowns has the [[Echelon form|reduced echelon]] matrix $E$.
>- If $E$ contains a row of the form $(0 \ldots 0 \vert 1)$, then the system is inconsistent
>- Otherwise, if $E$ has $k$ non-zero rows then the system has a solution involving $n-k$ parameters

>[!thm]- A homogeneous system of linear equations, with fewer equations than unknowns, has a non-trivial solution (a solution in which at least one of the unknowns is non-zero).

^f59fc3

---

#### Spaced repetition
