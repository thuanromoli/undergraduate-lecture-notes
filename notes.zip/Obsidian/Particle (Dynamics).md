---
alias:
  - particle
  - particles
type: def
tag: MT2507
---
>[!def] Definition
>A particle is any object that may be represented by a point.
