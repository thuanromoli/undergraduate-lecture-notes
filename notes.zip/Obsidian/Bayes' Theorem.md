---
tags:
  - MT3507
  - MT4531
aliases:
---
Let $A$ and $B$ be possible events such that $\mathbb P(B) > 0$.

> [!thm] Discrete case
> Bayes' Theorem states that
> $$\mathbb P(A|B) = \frac{\mathbb P(B|A) \mathbb P(A)}{\mathbb P(B)} =  \frac {\mathbb {P}(B|A)\mathbb {P}(A)}{\mathbb {P}(B|A)\mathbb {P}(A) + \mathbb {P}(B|A^{c})\mathbb{P}(A^{c})}.$$
> where we obtain the last form using [[The Law of Total Probability]].
> 

This generalises when we consider mutually exclusive events $A_{1},A_{2},...,A_{n}$ to $\mathbb {P}(A_j|B) =\frac {\mathbb {P}(B|A_j)\mathbb {P}(A_j)} {\sum _{i=1}^n \mathbb {P}(B|A_i)\mathbb {P}(A_i)}$, which is similar to the form for the continuous case.

Let $\mathbf{X}$ be a random vector with values $\mathbf{x}$ and likelihood $f(\mathbf{x}|\theta)$ ($=L(\theta;\mathbf{x})$), where $\theta$ is a parameter that we wish to estimate.

> [!thm] Continuous case
> The [[Posterior distributions|posterior]] of $\theta$ given $\mathbf{X} = \mathbf{x}$ is given by
> $$\pi(\theta | \mathbf{x}) = \frac{\pi(\theta) f(\mathbf{x}| \theta)}{f(\mathbf{x})} = \frac{\pi(\theta) f(\mathbf{x}| \theta)}{\int_{\Theta} \pi(\theta) f(\mathbf{x}| \theta) \ d\theta},$$
> where $\pi(\theta)$ is the [[Prior distributions|prior]] of $\theta$.

Let $\mathbf{X}$ be a random vector with values $\mathbf{x}$ and likelihood $f(\mathbf{x}|\theta)$ ($=L(\theta;\mathbf{x})$), where $\boldsymbol{\theta}$ is a vector of parameters that we wish to estimate.

> [!thm] Multivariate case
> The [[Posterior distributions|posterior]] of $\boldsymbol{\theta}$ given $\mathbf{X} = \mathbf{x}$ is given by
> $$\pi(\boldsymbol{\theta} | \mathbf{x}) = \frac{\pi(\boldsymbol{\theta} ) f(\mathbf{x}| \boldsymbol{\theta} )}{f(\mathbf{x})} = \frac{\pi(\boldsymbol{\theta} ) f(\mathbf{x}| \boldsymbol{\theta} )}{\int_{\boldsymbol{\Theta} } \pi(\boldsymbol{\theta} ) f(\mathbf{x}| \theta) \ d\boldsymbol{\theta} },$$
> where $\pi(\boldsymbol{\theta} )$ is the [[Prior distributions|prior]] of $\boldsymbol{\theta}$.

> [!gen] Remarks
> - Often, the parameters $\boldsymbol{\theta}=(\theta_{1}, \theta_{2},...)$ are assumed to be independent of each other, a priori, so that $p(\boldsymbol{\theta})= \prod\limits_{i=1}^{n}p(\theta_{i})$.
> - Often, prior dependence between the parameters is introduced using another hyper-parameter $\phi$, so that $p(\boldsymbol{\theta}|\phi)=\sum\limits_{i=1}^{n}p(\theta_{i}|\phi), \quad \pi(\phi)=\cdots$.
