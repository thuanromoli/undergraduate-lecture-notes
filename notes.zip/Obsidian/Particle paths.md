---
tags:
  - MT4509
aliases:
  - particle paths
---
This description of the flow field consists of the trajectories of given particles in the velocity field $\boldsymbol{u}(\boldsymbol{x},t)$.

![[particlepaths_att.png|300]]

By definition, the velocity of a fluid particle located at $\boldsymbol{x}$ at time $t$ is given by
$$\frac{d \boldsymbol{x}}{dt} = \boldsymbol{u}(\boldsymbol{x},t).$$

So, to plot the particle paths we solve the differential equations above simultaneously.