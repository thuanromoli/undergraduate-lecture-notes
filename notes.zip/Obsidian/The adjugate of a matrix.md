---
tag: MT2501
type: def
alias:
- adjugate
---
Let $A$ be an $n\times n$ [[Square matrices|square matrix]].

>[!def] Definition
>The adjugate of $A$, denoted by $\text{adj}(A)$ is constructed from $A$ by the following two steps:
>1. replace each entry in the matrix by its [[The cofactor of a matrix|cofactor]]
>2. take the [[The transpose of a matrix|transpose]] of the resulting matrix.

---

#### Spaced repetition

How is the adjugate of $A$, denoted by $\text{adj}(A)$ constructed?
?
>The adjugate of $A$, denoted by $\text{adj}(A)$ is constructed from $A$ by the following two steps:
>1. replace each entry in the matrix by its [[The cofactor of a matrix|cofactor]]
>2. take the [[The transpose of a matrix|transpose]] of the resulting matrix.