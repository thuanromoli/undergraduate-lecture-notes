---
tags:
  - MT2504
  - MT4528
type: def
aliases:
---
Let $\Omega = \bigcup\limits_{i=1}^{n}A_{i}$ be a [[Partitions|partition]] of the [[Sample space, Sample points, and Events|sample space]] $\Omega$ into [[Sample space, Sample points, and Events|events]] with non-zero probabilities, and let $B$ and $C$ be events with $\mathbb{P}(C)>0$.

>[!thm] The Law of Total Conditional Probability
>$$\mathbb{P}(B \vert C)=\sum\limits_{i=1}^{n}\mathbb{P}(B \vert A_{i} \cap C)\mathbb{P}(A_{i}\vert C)$$

Proof:
Firstly, $\mathbb{P}(B|C)=\frac{\mathbb{P}(B\cap C)}{\mathbb{P}(C)}$.
Note that $\mathbb{P}(B)=\mathbb{P}(B \cap \Omega)$ = $\mathbb{P}(B \cap  (\bigcup\limits_{i=1}^{n}A_{i} )$ = $\mathbb{P}( \bigcup\limits_{i=1}^{n}(B \cap A_{i}))$.
And therefore $\mathbb{P}(B\cap C) = \mathbb{P}( (\bigcup\limits_{i=1}^{n}(B \cap A_{i}))\cap C)$ = $\mathbb{P}(\bigcup\limits_{i=1}^{n}(B \cap A_{i}\cap C))$
That is, $\mathbb{P}(B\cap C)= \sum\limits_{i=1}^{n} \mathbb{P}(B\cap A_{i}\cap C)$ = $\sum\limits_{i=1}^{n} \mathbb{P}(B | A_{i}\cap C))\mathbb{P}(A_{i}\cap C)$ = $\sum\limits_{i=1}^{n} \mathbb{P}(B | A_{i}\cap C))\mathbb{P}(A_{i}| C)\mathbb{P}(C)$.
And finally, $\mathbb{P}(B|C)=\frac{\mathbb{P}(B\cap C)}{\mathbb{P}(C)}=\sum\limits_{i=1}^{n} \mathbb{P}(B | A_{i}\cap C))\mathbb{P}(A_{i}| C)$ as required.