---
tags:
  - MT3508
aliases:
---
> [!gen] [[Statistical hypothesis|Hypothesis]]
> $H_{0}$: the sequence was produced in a random manner.
> $H_{1}$: the sequence was not produced in a random manner.

> [!gen] [[Test statistics]]
> $$\begin{align*}
   Q = \text{number of runs} \sim N(\mu_{Q},\sigma^{2}_{Q}).
   \end{align*}$$
> with
> $$\begin{align*}
   \mu_{Q} = 1 + \frac{2n_{1}n_{2}}{n_{1}+n_{2}} && \text{and} && \sigma^{2}_{Q} = \frac{2n_{1}n_{2}(2n_{1}n_{2}-n_{1}-n_{2})}{(n_{1}+n_{2})^{2}(n_{1}+n_{2}-1)}
   \end{align*}$$
> where
> - a run is the maximal subsequence of like observations.
> - $n_{1}$ is the number of positive and negative values in the series.

> [!gen] Method
> 1. Fore each [[Residuals|residual]] $r_{i}$ write $+$ if positive and $-$ if negative.
> 2. Find the test statistic $Q$, the number of runs.
> 3. Find $\mu_{Q}$ and $\sigma^{2}_{Q}$.
> 4. Find the $p$-value.
