---
tags:
  - MT3508
aliases:
  - EDF
---
Let $y_{(1)},...,y_{(n)}$ denote the order statistics of a random sample of size $n$.

> [!def] Definition
> The empirical distribution function $S_{n}(y)$ of the sample is given by
> $$\begin{align*}
  S_n(y) = \left\{ \begin{array}{lll}
   0 & y < y_{(1)} & \\
   \frac{k}{n} & y_{(k)} \leqslant y < y_{(k+1)} & k = 1, 2, \ldots, n - 1 \\
   1 & y \geqslant  y_{(n)} &
  \end{array} \right.
\end{align*}$$
> that is, the proportion of observations in the sample which are less than or equal to $y$.
