---
tags:
  - MT4528
type: 
aliases:
---
>[!def] Definition
>Kendall's notation is a shorthand way of classifying queuing systems, taking the form
>$$\text{input mechanism} / \text{service distribution} / \text{number of servers} / \text{capacity}$$
>For the first two components, the standard abbreviations are
>- $M$ for Markovian (i.e. memoryless).
>- $D$ for deterministic.
>- $G$ for general.
>
>For the input mechanism, $M$ indicates that arrivals are from a [[Poisson processes|Poisson process]] and $D$ indicates constant inter-arrival times.
>
>For the service time distribution, $M$ indicates an exponential distribution and $D$ indicates constant service time.

>[!def] Measures of effectiveness
>To quantify the effectiveness of a queuing system, it can be relevant to look at:
>- $X(t)$, the total number of customers in the system (in either waiting room or service facility).
>- $Y(t)$, the number of customers waiting for service.
>- $X(t)-Y(t)$, the number of customers in the service facility.
>- the customers' queuing times, the service times, and the overall time in the system.
