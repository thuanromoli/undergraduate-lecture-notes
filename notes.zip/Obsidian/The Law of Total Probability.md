---
tags:
  - MT2504
  - MT4528
type: def
aliases:
---
Let $\Omega = \bigcup\limits_{i=1}^{n}A_{i}$ be a [[Partitions|partition]] of the [[Sample space, Sample points, and Events|sample space]] $\Omega$ into [[Sample space, Sample points, and Events|events]] with non-zero probabilities, and let $B$ be an event.

>[!thm] The Law of Total Probability
>$$\mathbb{P}(B)=\sum\limits_{i=1}^{n}\mathbb{P}(B \vert A_{i})\mathbb{P}(A_{i})$$

Proof:
Note that $\mathbb{P}(B)=\mathbb{P}(B \cap \Omega)$ = $\mathbb{P}(B \cap  (\bigcup\limits_{i=1}^{n}A_{i} )$ = $\mathbb{P}( \bigcup\limits_{i=1}^{n}(B \cap A_{i}))$.
That is, $\mathbb{P}(B)= \sum\limits_{i=1}^{n} \mathbb{P}(B\cap A_{i})$ = $\sum\limits_{i=1}^{n} \mathbb{P}(B | A_{i}))\mathbb{P}(A_{i})$ as required.