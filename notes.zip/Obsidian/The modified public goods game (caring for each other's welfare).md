---
tags:
  - MT4554
type: model
aliases: []
---
>[!gen] Why are we studying this?
>It shows that if people care about each other's welfare, then cooperation is a viable solution. So this takes care of one of the critiques of the Prisoner's dilemma.

>[!def] Definition
>The modified public goods game is a game where both players see their payoff as a combination of the money they receive and the money their opponents receive.
>
>![[modpgg_att.png|300]]

>[!gen] Solution
>Here cooperation strictly dominates defection if $\alpha>(2c-b)/b$.
