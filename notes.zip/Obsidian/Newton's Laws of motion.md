---
type: def
tag: MT2507
---
>[!thm] Newton's First Law of motion
>The velocity of an object remains constant unless the body is acted upon by an external net force.

>[!thm] Newton's Second Law of motion
>The acceleration $a$ of an object is in the direction of and directly proportional to the net force $\boldsymbol F$ acting against it and inversely proportional to the mass $m$ of the object, that is
>$$\boldsymbol a=\frac 1 m \boldsymbol F \iff \boldsymbol F = m \boldsymbol a$$

>[!thm] Newton's Third Law of motion
>Every force has an equal and opposite reaction force.

Laws I and II can be written as the [[Equation of Motion]].