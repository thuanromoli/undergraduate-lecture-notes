---
tags:
  - MT4551
aliases:
---
Consider the [[The modified Black-Scholes equation - derivation|modified Black-Scholes equation]] $\frac{\partial V_{1}}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2}V_{1}}{\partial S^{2}} + (r-D_{0})S \frac{\partial V_{1}}{\partial S} -(r-D_{0})V_{1} =0$.

> [!thm] Theorem
> The general solution to the [[The modified Black-Scholes equation - derivation|modified Black-Scholes equation]] is
> $$V(S,t) = V_{1}(S,t)e^{-D_{0}(T-t)}$$
> where
> $$V_{1}(S,t) = e^{-(r-D_{0})(T-t)}\int_{0}^{\infty} V_{1}(S',T)P(S')dS'$$
> where
> $$P(S') = \frac{1}{\sqrt{2 \pi \sigma^{2}(T-t)}}\cdot \frac{1}{S'} \cdot \exp \left\{ - \frac{[\ln (S' / S) - ((r-D_{0}) - \frac{1}{2} \sigma^{2})(T-t)]^{2}}{2\sigma^{2}(T-t)} \right\}$$
> that is, the same solution as the [[The Black-Scholes equation - derivation|Black-Scholes equation]] but
> 1. Instead of $r$ use $r-D_{0}$.
> 2. The solution gives $V_{1}$.
> 3. Obtain $V$ using the above substitution.

Proof:
Our aim is to reduce the modified B-S equation to the [[Diffusion equation - derivation|diffusion equation]] of which we know the [[Diffusion equation - solution|solution]].
$$\underbrace{\frac{\partial V_{1}}{\partial t}}_{(1)} + \underbrace{\frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2}V_{1}}{\partial S^{2}}}_{(2)} + \underbrace{(r-D_{0})S \frac{\partial V}{\partial S}}_{(3)} - \underbrace{(r-D_{0})V}_{(4)} =0.$$
Consider first (1) and (4). Their relationship suggests an exponential dependence.
We choose the substitution
$$V_{1}(S,t) = v_{1}(S,t)e^{(r-D_{0})t}$$ where $v_{1}(S,t) = V_{1}(S,t) e^{-(r-D_{0})t}$ is the value of the FD discounted to $t = 0$. Therefore
$$\begin{align*}
&(1) \implies \frac{\partial V_{1}}{\partial t} = \frac{\partial v_{1}}{\partial t}e^{(r-D_{0})t}+v_{1}re^{(r-D_{0})t} = \left(\frac{\partial v_{1}}{\partial t} +v_{1}(r-D_{0})\right)e^{(r-D_{0})t}\\
&(3) \implies \frac{\partial V_{1}}{\partial S} = \frac{\partial v_{1}}{\partial S} e^{(r-D_{0})t}\\
&(2) \implies \frac{\partial^{2}V_{1}}{\partial S^{2}} = \frac{\partial ^{2}v_{1}}{\partial S^{2}} e^{(r-D_{0})t}\\
&(4) \implies V_{1} = v_{1}e^{(r-D_{0})t}
\end{align*}$$
So our equation is now
$$\begin{align*}
&\frac{\partial V_{1}}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2}V_{1}}{\partial S^{2}} + (r-D_{0})S \frac{\partial V_{1}}{\partial S} -(r-D_{0})V_{1} =0\\
\implies & \left(\frac{\partial v_{1}}{\partial t} +v_{1}(r-D_{0})\right)e^{(r-D_{0})t} + \frac{1}{2} \sigma^{2} S^{2} \frac{\partial ^{2}v_{1}}{\partial S^{2}} e^{(r-D_{0})t} + (r-D_{0})S \frac{\partial v_{1}}{\partial S} - (r-D_{0})v_{1}e^{(r-D_{0})t}=0\\
\implies & \frac{\partial v_{1}}{\partial t} + v_{1}(r-D_{0}) + \frac{1}{2} \sigma^{2} S^{2} \frac{\partial ^{2}v_{1}}{\partial S^{2}} + (r-D_{0})S \frac{\partial v_{1}}{\partial S} - (r-D_{0})v_{1}=0\\
\implies & \frac{\partial v_{1}}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial ^{2}v_{1}}{\partial S^{2}} + (r-D_{0})S \frac{\partial v_{1}}{\partial S} = 0
\end{align*}$$
and we have reduced it to three terms by eliminating (4).

We consider two changes of variable:
- Impose the [[Boundary conditions|boundary conditions]] at $T$ and then back track to an earlier time, we obtain
  $$\tau = T-t.$$
- Using the fact that $d(\ln S) = (\mu - \frac{1}{2}\sigma^{2})dt+\sigma dW$, we suggest
  $$y = \ln S - \left[(r-D_{0}) - \frac{1}{2}\sigma^{2}\right]t.$$

Now we apply the new variables to the equation by noting $v_{1}(y,\tau)=v_{1}(y(S,t),\tau(t)) = v_{1}(S,t)$.
$$\begin{align*}
&(1) \implies \frac{\partial v_{1}}{\partial t} = \frac{\partial v_{1}}{\partial \tau}\frac{\partial \tau}{\partial t} + \frac{\partial v_{1}}{\partial y}\frac{\partial y}{\partial t} = \frac{\partial v_{1}}{\partial \tau} (-1) +\frac{\partial v_{1}}{\partial y}(-((r-D_{0})- \frac{1}{2}\sigma^{2}))=-\frac{\partial v_{1}}{\partial \tau} - ((r-D_{0}) - \frac{1}{2}\sigma^{2}) \frac{\partial v_{1}}{\partial y}\\
&(3) \implies \frac{\partial v_{1}}{\partial S} = \frac{\partial v_{1}}{\partial \tau}\frac{\partial \tau}{\partial S} + \frac{\partial v_{1}}{\partial y}\frac{\partial y}{\partial S} = 0 + \frac{\partial v_{1}}{\partial y} \left(\frac{1}{S}\right) = \frac{1}{S}\frac{\partial v_{1}}{\partial y} \\
&(2) \implies \frac{\partial^{2}v_{1}}{\partial S^{2}} = \frac{\partial }{\partial S}\left(\frac{1}{S} \frac{\partial v_{1}}{\partial y}\right) = - \frac{1}{S^{2}} \frac{\partial v_{1}}{\partial y} + \frac{1}{S} \frac{\partial ^{2}v_{1}}{\partial y^{2}} \frac{\partial y}{\partial S} =  - \frac{1}{S^{2}}\frac{\partial y}{\partial v_{1}} + \frac{1}{S^{2}} \frac{\partial v_{1}^{2}}{\partial y^{2}}
\end{align*}$$
Now our equation becomes
$$\begin{align*}
& \frac{\partial v_{1}}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial ^{2}v_{1}}{\partial S^{2}} + (r-D_{0})S \frac{\partial v_{1}}{\partial S} = 0\\
\implies & -\frac{\partial v_{1}}{\partial \tau} - ((r-D_{0}) - \frac{1}{2}\sigma^{2}) \frac{\partial v_{1}}{\partial y} + \frac{1}{2} \sigma^{2}S^{2} \left(- \frac{1}{S^{2}} \frac{\partial v_{1}}{\partial y} + \frac{1}{S^{2}}\frac{\partial^{2} v_{1}}{\partial y^{2}}\right) + (r-D_{0})S \left(\frac{1}{S}\frac{\partial v_{1}}{\partial y} \right) = 0\\
\implies & -\frac{\partial v_{1}}{\partial \tau} - (r-D_{0}) \frac{\partial v_{1}}{\partial y} + \frac{1}{2}\sigma^{2} \frac{\partial v_{1}}{\partial y} - \frac{1}{2} \sigma^{2} \frac{\partial v_{1}}{\partial y} + \frac{1}{2}\sigma^{2} \frac{\partial^{2}v_{1}}{\partial y^{2}} + (r-D_{0})\frac{\partial v_{1}}{\partial y} = 0\\
\implies & - \frac{\partial v_{1}}{\partial \tau} + \frac{1}{2}\sigma^{2} \frac{\partial ^{2} v_{1}}{\partial y^{2}} = 0\\
\implies& \frac{\partial v_{1}}{\partial \tau } = \frac{1}{2} \sigma^{2}\frac{\partial ^{2}v_{1}}{\partial y^{2}}
\end{align*}$$
that is, the diffusion equation. Hence we know that the solution to it is
$$v_{1}(y,\tau) = \frac{1}{\sqrt{2 \pi \sigma^{2} \tau}} \int_{-\infty}^{\infty}v_{1}(y',0) \exp\left\{  - \frac{(y-y')^{2}}{2 \sigma^{2} \tau}  \right\} dy'.$$

Now we substitute back the original  variables by noting that $v_{1}'(y',0)=v_{1}'(S',T)e^{-rt}$ and $y'=y'(S',T)$ and $dy' = \frac{1}{S'}dS'$ as $v_{1}(y',0) \implies \tau = 0 \implies t = T$.
$$\begin{align*}
V_{1}(S,t)e^{-rt} &= \frac{1}{\sqrt{2 \pi \sigma^{2} (T-t)}} \int_{0}^{\infty}V_{1}(S',T) e^{-(r-D_{0})T} \exp\left\{  - \frac{[\ln S - ((r-D_{0}) - \frac{1}{2}\sigma^{2})t - (\ln S' - ((r-D_{0}) - \frac{1}{2}\sigma^{2})T)]^{2}}{2 \sigma^{2} (T-t)}  \right\} \frac{1}{S'}dS'\\
V_{1}(S,t) &= \frac{e^{(r-D_{0})t} }{\sqrt{2 \pi \sigma^{2} (T-t)}} \int_{0}^{\infty}V_{1}(S',T) e^{-(r-D_{0})T} \exp\left\{  - \frac{[\ln S - \ln S' + ((r-D_{0}) - \frac{1}{2}\sigma^{2})(T-t)]^{2}}{2 \sigma^{2} (T-t)}  \right\} \frac{1}{S'}dS'\\
V_{1}(S,t) &= \frac{e^{(r-D_{0})t}e^{-(r-D_{0})T} }{\sqrt{2 \pi \sigma^{2} (T-t)}} \int_{0}^{\infty}V_{1}(S',T)  \frac{1}{S'}\exp\left\{  - \frac{[\ln S - \ln S' + ((r-D_{0}) - \frac{1}{2}\sigma^{2})(T-t)]^{2}}{2 \sigma^{2} (T-t)}  \right\}dS'\\
V_{1}(S,t) &= e^{-(r-D_{0})(T-t)}\int_{0}^{\infty}V_{1}(S',T)  \frac{1}{\sqrt{2 \pi \sigma^{2} (T-t)}} \frac{1}{S'}\exp\left\{  - \frac{[\ln S - \ln S' + ((r-D_{0}) - \frac{1}{2}\sigma^{2})(T-t)]^{2}}{2 \sigma^{2} (T-t)}  \right\}dS'\\
V_{1}(S,t) &= e^{-(r-D_{0})(T-t)}\int_{0}^{\infty}V_{1}(S',T) P(S')dS'
\end{align*}$$
where
$$P(S') =  \frac{1}{\sqrt{2 \pi \sigma^{2} (T-t)}} \frac{1}{S'}\exp\left\{  - \frac{[\ln S - \ln S' + ((r-D_{0}) - \frac{1}{2}\sigma^{2})(T-t)]^{2}}{2 \sigma^{2} (T-t)}  \right\}.$$
