---
tags:
  - MT4527
aliases:
---
Let $(X_{t})_{t \in \mathbb Z}$ be a [[Stationarity|weakly stationary]] [[Stochastic processes|stochastic process]].
Let $\gamma_{X}(h)$ be the [[ACVF and ACF|ACVF]] of $X$.
Let $\rho_{X}(h)$ be the [[ACVF and ACF|ACF]] of $X$.

> [!thm] $\gamma_{X}(-h) = \gamma_{X}(h)$

> [!thm] $\rho_{X}(-h) = \rho_{X}(h)$

> [!thm]- $\widehat \gamma_{X}(h)$ and $\widehat \rho_{X}(h)$ are not unbiased for $\gamma_{X}(h)$ and $\rho_{X}(h)$.

> [!thm] $\gamma$ and $\rho$ are positive semidefinite function, i.e. the associated matrix is positive semidefinite. That is, $$\sum_{i=1}^n\sum_{j=1}^n a_i \gamma_X(t_i-t_j)a_j \ge 0 \quad \mbox{and} \quad \sum_{i=1}^n\sum_{j=1}^n a_i\rho_X(t_i-t_j)a_j \ge 0$$ for all $n \in \mathbb N$, and $a_{i}\in \mathbb R$, for $i=1,2,...,n$.

> [!thm] $\widehat \gamma$ and $\widehat \rho$ are positive semidefinite function, i.e. the associated matrix is positive semidefinite.
