---
tags:
  - MT2504
type: thm
aliases:
---
>[!thm]- Expectation of a function (discrete rvs)
> Let $X$ be a discrete [[Random variables|rv]] taking values $x_1,x_2,...,x_n$ with [[Probability mass function|pmf]] $f(x)$.
> Then $\mathbb{E}(g(X))=\sum\limits_{x_{i}}g(x_{i})f(x_{i})$

>[!thm]- Expectation of a function (continuous rvs)
> Let $Y$ be a continuous [[Random variables|rv]] with [[Probability density function|pdf]] $f(y)$.
> Then $\mathbb{E}(g(X))=\int\limits_{-\infty}^{\infty} g(x)f(x)$

Let $X$ and $Y$ be any [[Random variables|random variables]] and let $a$ and $b$ be constants.

>[!thm] $\mathbb{E}(aX+b)=a \mathbb{E}(X)+b$

>[!thm] $\mathbb{E}(X+Y)=\mathbb{E}(X)+\mathbb{E}(Y)$

>[!thm] The above extends to $\mathbb{E}\left(\sum\limits_{i=1}^{n}X_{i}\right)=\sum\limits_{i=1}^{n}\mathbb{E}(X_{i})$

>[!thm] If $X$ and $Y$ are [[Independent events|independent]], then $\mathbb{E}(XY)=\mathbb{E}(X)\mathbb{E}(Y)$

>[!thm] The above extends to $\mathbb{E}\left(\prod\limits_{i=1}^{n}X_{i}\right)=\prod\limits_{i=1}^{n}\mathbb{E}(X_{i})$

---

#### Spaced repetition
