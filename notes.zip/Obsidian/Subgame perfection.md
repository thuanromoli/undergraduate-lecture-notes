---
tags:
  - MT4554
type: def
aliases:
  - subgame perfect
---
>[!def] Definition
>A solution to a game is subgame perfect if it is a [[Nash equilibrium]] starting from any node in the game tree.

>[!thm] Theorem
>Every finite [[Extensive-form games|extensive game]] with [[Common knowledge|perfect information]] has a subgame perfect equilibrium.
>
>Proof: this relies on backwards induction and is temporarily omitted.
