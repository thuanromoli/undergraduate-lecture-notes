---
type: thm
tag: MT2506
---
Let $f(\boldsymbol x)$ be a [[Scalar fields|scalar field]] (that is not multi-valued) and $\boldsymbol F(\boldsymbol x)$ be the [[Vector fields|vector field]].
Let $C$ be a curve represented [[Parametrisation|parametrically]] by $\boldsymbol{r}(s)\in \mathbb{R}^3$, with $s_{1} \leqslant s \leqslant s_{2}$ with $s \in \mathbb{R}$ and $\boldsymbol{x_{1}}= \boldsymbol{r}(s_{1})$ and $\boldsymbol{x}_{2}=\boldsymbol{r}(s_2)$

>[!def] Definition
>The [[Line integral of a vector field|line integral]] $\int_C \boldsymbol F(\boldsymbol r)\cdot \text{d}\boldsymbol r$ is independent of the path taken if one of the following conditions is satisfied:
>- $\exists f$ s.t $\boldsymbol{F}= \boldsymbol{\nabla}f$
>- $\boldsymbol{\nabla} \times \boldsymbol{F}= \boldsymbol{0}$

>[!thm] Theorem
>If a [[Line integral of a vector field|line integral]] is independent of the path taken then
>$$\int_C \boldsymbol F(\boldsymbol r)\cdot \text{d}\boldsymbol r = f (\boldsymbol r(s_2))-f(\boldsymbol r(s_1))$$
>Furthermore, if $C$ is a closed curve then $\boldsymbol x_1 = \boldsymbol r(s_1) = \boldsymbol r(s_2) = \boldsymbol x_2$, hence 
>$$\int_C \boldsymbol F(\boldsymbol r)\cdot \text{d}\boldsymbol r = f (\boldsymbol r(s_2))-f(\boldsymbol r(s_1))=0$$

---

#### Spaced repetition

What are the conditions for a line integral to be path independent?
?
- $\exists f$ s.t $\boldsymbol{F}= \boldsymbol{\nabla}f$
- $\boldsymbol{\nabla} \times \boldsymbol{F}= \boldsymbol{0}$

What does the line integral reduce to when it's path independent?
?
$$\int_C \boldsymbol F(\boldsymbol r)\cdot \text{d}\boldsymbol r = f (\boldsymbol r(s_2))-f(\boldsymbol r(s_1))$$
