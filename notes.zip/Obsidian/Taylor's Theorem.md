---
tag: MT2502
type: thm
alias:
- Taylor series
- Taylor expansion
---
#### For complex analysis:
Let $\gamma$ be a positively oriented [[Contours|contour]] and $f: U \to \mathbb C$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] defined on an [[Open sets|open subset]] $U$.

> [!thm] Theorem
> Suppose that $f$ is [[Holomorphic functions|holomorphic]] on an [[Open balls|open ball]] $B(a,r)$ for some $a \in \mathbb C$ and some $r>0$.
> Further suppose that $\gamma^{*} \cup I(\gamma) \subseteq B(a,r)$ and $a \in I(\gamma)$. Then
> $$f(z) = \sum\limits_{n=0}^{\infty}c_{n}(z-a)^{n}$$
> for all $z \in B(a,r)$, where each $c_{n}$ is given by
> $$c_{n} = \frac{1}{2 \pi i}\int_{\gamma}^{}\frac{f(w)}{(w-a)^{n+1}}\; dw = \frac{f^{(n)}(a)}{n!}.$$

> [!gen]- Proof
> For simplicity, we prove for $a = 0$.
> So the new statement becomes: if $f$ is holomorphic on $B(0,r)$, then $f(z) = \sum\limits_{n=0}^{\infty}c_{n}z^{n}$ for some fixed $z \in B(0,r)$ where $c_{n} = \frac{1}{2 \pi i} \int_{\gamma}^{} \frac{f(w)}{w^{n+1}}\;dw$.
> 
> The first step is to apply the [[Deformation Theorem]] to make sure that $\gamma$ is a positively oriented contour about 0 of radius $R$ such that $|z| < R < r$.
> ![[taylorthm_att.png|200]]
> Note the proof of geometric series,
> $$\begin{align*}
   S_{N} &= 1+ \frac{z}{w} + \left(\frac{z}{w}\right)^{2}+ \cdots +\left(\frac{z}{w}\right)^{N}\\
   \frac{z}{w}S_{N}&=  \quad\;\;\, \frac{z}{w} + \left(\frac{z}{w}\right)^{2}+ \cdots +\left(\frac{z}{w}\right)^{N} +\left(\frac{z}{w}\right)^{N+1} \\\\
   \implies &S_{N}-\frac{z}{w} S_{N} = 1-(z/w)^{N+1}\\
   \implies & \left(1-\frac{z}{w}\right) S_{N} = 1-(z/w)^{N+1}\\
   \implies &  S_{N} = \frac{1-(z/w)^{N+1}}{1-(z/w)}=\frac{1}{1-(z/w)}-\frac{(z/w)^{N+1}}{1-(z/w)}\\
   \end{align*}$$
> so by rearranging the above into $\frac{1}{1-(z/w)}=S_{N}+\frac{(z/w)^{N+1}}{1-(z/w)}$, we note
> $$   \frac{1}{w-z} = \frac{1}{w} \cdot \frac{1}{1-(z/w)}
   = \frac{1}{w} \cdot \left(\sum\limits_{n=0}^{N}\left(\frac{z}{w}\right)^{n}+ \frac{(z/w)^{N+1}}{1-(z/w)}\right).$$
> Now we substitute this into [[Cauchy's Integral Formula]]
> $$\begin{align*}
   f(z) &= \frac{1}{2 \pi i} \int_{\gamma}^{}\frac{f(w)}{w-z}\;dw\\
   &= \frac{1}{2 \pi i} \int_{\gamma}^{}f(w) \cdot \frac{1}{w-z}\;dw\\
   &= \frac{1}{2 \pi i} \int_{\gamma}^{}f(w) \cdot \frac{1}{w}\cdot \left(\sum\limits_{n=0}^{N}\left(\frac{z}{w}\right)^{n}+ \frac{(z/w)^{N+1}}{1-(z/w)}\right)\;dw\\
   &= \frac{1}{2 \pi i} \int_{\gamma}^{}f(w) \cdot \frac{1}{w}\cdot \sum\limits_{n=0}^{N}\left(\frac{z}{w}\right)^{n}dw+ \frac{1}{2 \pi i}\int_{\gamma}^{}f(w)\cdot \frac{1}{w}\cdot\frac{(z/w)^{N+1}}{1-(z/w)}\;dw\\
   &= \frac{1}{2 \pi i} \int_{\gamma}^{}\sum\limits_{n=0}^{N} \left(\frac{z}{w}\right)^{n} \cdot\frac{f(w)}{w} \;dw+ \frac{1}{2 \pi i}\int_{\gamma}^{} f(w) \cdot \frac{(z/w)^{N+1}}{w-z}\;dw\\
   &= \sum\limits_{n=0}^{N}\left(\frac{1}{2 \pi i}\int_{\gamma}^{} \left(\frac{z}{w}\right)^{n}\cdot \frac{f(w)}{w}\;dw\right) + E_{N}(z)\\
   &= \sum\limits_{n=0}^{N}\left(\frac{1}{2 \pi i}\int_{\gamma}^{} \frac{f(w)}{w^{n+1}}\;dw \right)z^{n}+E_{N}(z)\\
   &= \sum\limits_{n=0}^{N} c_{n}z^{n}+E_{N}(z)
   \end{align*}$$
> Now we wish to show that $E_{N}(z) \to 0$.
> Firstly, we note that $f$ is [[Boundedness|bounded]] as $\gamma^{*}$ is [[Closed sets and limit points|closed]] and bounded, so write $|f(w)| \leqslant M \;\;\forall w \in \gamma^{*}$.
> Also note that $|w| = R$ and $|w-z| \geqslant |w|-|z| = R-|z|$ for $w \in \gamma^{*}$.
> Hence by the [[Crude Estimation Theorem]]
> $$\begin{align*}
   |E_{N}(z)| &=  \left |\frac{1}{2 \pi i}\int_{\gamma}^{} f(w) \cdot \frac{(z/w)^{N+1}}{w-z}\;dw \right |\\
   &\leqslant \frac{1}{2 \pi} \cdot \frac{M}{R-|z|}\left(\frac{|z|}{R}\right)^{N+1}\cdot 2 \pi R\\
   &= \frac{RM}{R-|z|}\left(\frac{|z|}{R}\right)^{N+1} \to 0
   \end{align*}$$
> as $|z| / R < 1$.
> 
> So we are done.


#### For real analysis:
Let $n \geqslant 2$ and suppose that $f:[a,b] \to \mathbb{R}$ is a [[Functions|function]] which has its first $n-1$ derivatives [[Continuity|continuous]] on $[a,b]$ and [[Differentiability|differentiable]] on $(a,b)$.

>[!thm] Theorem
>Suppose $x_{0} \in [a,b]$.
>Then for $x\in [a,b]$ with $x\neq x_{0}$, there exists $\theta$ between $x_{0}$ and $x$ such that $$f(x)=\sum\limits_{r=0}^{n-1}\frac{(x-x_{0})^{r}}{r!}f^{(r)}(x_{0})+\frac{(x-x_{0})^{n}}{n!}f^{(n)}(\theta)$$
