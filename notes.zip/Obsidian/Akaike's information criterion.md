---
tags:
  - MT3508
aliases:
  - AIC
---
> [!def] Definition
> The Akaike's information criterion is defined as
> $$\text{AIC} = -2 \log [L(\widehat{\boldsymbol{\theta}})]+2q$$
> where $L(\widehat{\boldsymbol{\theta}})$ is the [[Likelihood|likelihood]] evaluated at the [[Maximum Likelihood Estimator|MLE]] and $\widehat{\boldsymbol{\theta}}$ is a vector of length $q$, the number of parameters in the model.

```R
AIC <- 2 * mle$value + 2 * length(mle$par)
# Note: mle$value returns the negative likelihood already
```

> [!gen] Remarks
> - The AIC by itself has no meaning. It is used as a comparison metric.
> - If $\Delta(\text{AIC}) \geqslant 2$ then we say that the lower model is better.
> - The two models being compared must use the same data set.
> - The two models being compared do not require nesting.
