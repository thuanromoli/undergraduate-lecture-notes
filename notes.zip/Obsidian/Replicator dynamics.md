---
tags:
  - MT4554
type: def
aliases:
---
>[!def] Definition
>Replicator dynamics and the replicator equations comprise the most commonly used model of how natural selection causes the strategies in a population to change over time.
>
>Let $x_{k}$ be the proportion of a population who use the strategy $\sigma^{k}\in \Sigma$. We will assume that the total number of possible strategies is $K$.
>Replicators dynamics describe the time evolution of $x_{k}$ as
>$$\frac{dx_{k}}{dt}=x_{k}\left(V^{k}-\sum\limits_{j=1}^{K}x_{j}V^{j}\right)$$
>where $V^{k}$ is the [[Population level payoff|population level payoff]] to an individual using strategy $\sigma^{k}$.

>[!gen] [[Stability]] analysis of the ODE at equilibrium
>Equilibrium occurs when $\frac{dx_{k}}{dt}=0$.
>This occurs when $x_{k}=0$ or $V^{k}=\sum\limits_{j=1}^{K}x_{j}V^{j}$.
>That is, the payoff to players using strategy $k$ is equal to the average payoff of the population.
>If this holds for all $k$, no player can gain by changing strategies.
>
>More generally, replicator dynamics say that a strategy will increase in frequency if it receives a payoff greater than the population average.

>[!gen] [[Stability to invasion]]
>We can model the behaviour of an invader.
>A rare invader using strategy $\sigma^{k}$ invades a population using resident strategy $\sigma^{k}$.
>The frequency of people using $\sigma^{k}$ will increase if $V^{k}(\sigma^{k},\sigma^{r})>V^{r}(\sigma^{r})$.
>Under [[Adaptive dynamics|adaptive dynamics]], we assume that the invading strategy is a small perturbation compared to the resident and we can write
>$$\left.\frac{\partial V^{k}(\sigma^{k},\sigma^{r})}{\partial \sigma^{k}}\right\vert_{\sigma^{k}=\sigma^{r}}>0$$
>as the condition for invasion, and the condition for an evolutionary equilibrium is
>$$\left.\frac{\partial V^{k}(\sigma^{k},\sigma^{r})}{\partial \sigma^{k}}\right\vert_{\sigma^{k}=\sigma^{r}}=0$$
