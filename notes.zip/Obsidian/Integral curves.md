---
tags:
  - MT3504
type: def
aliases: []
---
Consider $y'=f(x,y)$.

>[!def] Definition
>Integral curves are the solution curves whose slope is equal to $f(x,y)$ at each point.
>These are obtained graphically by connecting the line segments on the [[Direction fields|direction field]].

---

#### Spaced repetition

Define what is an integral curve.
?
>Integral curves are the solution curves whose slope is equal to $f(x,y)$ at each point.
>These are obtained graphically by connecting the line segments on the [[Direction fields|direction field]].