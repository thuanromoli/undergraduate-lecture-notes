---
type: def
tag: MT2507
---
>[!def] Definition
>An autonomous system is a [[general system of first order ODEs]] but does not depend on time:$$\matrix{\frac{dx}{dt}=F(x(t),y(t)) \\\frac{dy}{dt}= G(x(t),y(t))}$$

