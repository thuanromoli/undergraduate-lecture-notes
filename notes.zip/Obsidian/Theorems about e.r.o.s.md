---
tag: MT2501
type: thm
alias:
- 
---
Let $A\in M_{m \times n}(F)$ be a [[Matrices|matrix]] and let $r_{1},...,r_{m}$ be its rows.

>[!thm]- [[Elementary row operations]] can be reversed
>- to reverse $r_{i} \leftrightarrow r_{j}$, apply $r_{i} \leftrightarrow r_{j}$ again
>- to reverse $r_{i} \mapsto \lambda r_{i}$, apply $r_{i} \mapsto \frac{1}{ \lambda} r_{i}$
>- to reverse $r_{i} \mapsto r_{i}+\lambda r_{j}$, apply $r_{i} \mapsto r_{i}-\lambda r_{j}$

>[!thm]- [[Elementary row operations|Row-equivalence]] is an [[Equivalence relations|equivalence relation]] on $M_{m \times n}(F)$
>- $A\sim A$
>- if $A\sim B$ then $B \sim A$
>- if $A\sim B$ and $B \sim C$ then $A \sim C$

---

#### Spaced repetition
