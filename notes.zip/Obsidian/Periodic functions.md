---
aliases:
  - periodic function
  - periodic functions
type: def
tags:
  - MT2507
  - MT3504
---
Let $f(x)$ be a [[Functions|function]].

>[!def] Periodic function
>A periodic function is a function that satisfies
>$$f(x+L)=f(x) \;\;\forall x$$
>where $L$ is a finite non-zero constant called the period.

>[!thm] Theorem
>If a function is periodic then $f(x)=f(x+jL)$ for $j=2,3,...$
>
>PROOF:
>	$f(x+L)=f(x) \implies f(x+a+L)=f(x+a)$
>	By choosing $a=jL$ then $f(x+(j+1)L=f(x+jL)$
>	but $f(x+jL)=f(x+(j-1)L)$
>	and by repeated application, $f(x+jL)=f(x)$

>[!def] Nomenclature
>If $L$ is such that $f$ is not periodic on any shorter interval, then $L$ is called the fundamental period. The quantities $jL$ for $j=2,3,...$ are called harmonics.

>[!thm] Theorem
>The frequency $k$ of a trigonometric function is $2 \pi /L$
