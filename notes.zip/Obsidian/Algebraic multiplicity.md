---
tags:
  - MT3501
type: def
aliases:
  - algebraic multiplicity
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $T:V\to V$ be a [[Linear transformations|linear transformation]] and $\lambda$ be an [[Eigenvectors and Eigenvalues|eigenvalue]] of $T$.

>[!def] Definition
>The algebraic multiplicity of $\lambda$ is the largest power $k$ such that $(x-\lambda)^{k}$ is a factor of the [[Characteristic polynomials|characteristic polynomial]] $C_{T}(x)$.
