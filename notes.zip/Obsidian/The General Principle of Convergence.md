---
tags:
  - MT2502
aliases:
---
Let $(x_{n})_{n}$ be a [[Sequences|sequence]].

> [!thm] Lemma 1
> If $(x_{n})_{n}$ is [[Convergence|convergent]]  then the sequence is [[Cauchy sequence|Cauchy]].

> [!thm] Lemma 2
> If $(x_{n})_{n}$ is Cauchy then the sequence is [[Boundedness|bounded]].

> [!thm] Lemma 3
> If $(x_{n})_{n}$ is Cauchy, and has a [[Subsequences|subsequence]] $(x_{m_{k}})_{k}$ that converges to some $x \in \mathbb R$, then the original sequence $(x_{n})_{n}$ also converges to $x$.

> [!thm] The General Principle of Convergence
> Every Cauchy sequence of real numbers converges, i.e. the space $(\mathbb R,|\cdot |)$ is [[Completeness|complete]].
> 
> $(x_{n})_{n}$ is convergent $\iff$ $(x_{n})_{n}$ is Cauchy.
