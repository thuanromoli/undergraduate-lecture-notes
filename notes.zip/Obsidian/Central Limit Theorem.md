---
type: thm
tag: MT2508
---
>[!gen] CONDITIONS:
>$X_1,...,X_n$ must be [[Independent events|independent]] identically distributed [[Random variables|rvs]] with mean $\mu$ and variance $\sigma^{2}$

>[!thm] Theorem
>The central limit theorem states that the sum or the mean of $n$ [[Independent events|independent]] and identically distributed rvs from almost any distribution is approximately [[Normal distribution|normal]] for large enough $n$:
>$$\frac{\sum_{i=1}^nX_i-n\mu}{\sigma\sqrt{n}}\ \ \dot\sim \ \ N(0,1) \ \ \ \ \ \ \text{as $n \to \infty$}$$
>$$\sum_{i=1}^nX_i \ \ \dot\sim \ \ N(n\mu,n\sigma^2)\ \ \ \ \ \ \text{as $n \to \infty$}$$
>$$\bar{X} \ \ \dot\sim \ \ N(\mu,\frac{\sigma^2}{n})\ \ \ \ \ \ \text{as $n \to \infty$}$$
>$$\frac{\bar{X}-\mu}{\sigma / \sqrt n} \  \ \dot\sim \ \ N(0,1)\ \ \ \ \ \ \text{as $n \to \infty$}$$

---

#### Spaced repetition

What is the central limit theorem?
?
The central limit theorem states that the sum or the mean of $n$ [[Independent events|independent]] and identically distributed rvs from almost any distribution is approximately [[Normal distribution|normal]] for large enough $n$:
$$\frac{\sum_{i=1}^nX_i-n\mu}{\sigma\sqrt{n}}\ \ \dot\sim \ \ N(0,1) \ \ \ \ \ \ \text{as $n \to \infty$}$$
$$\sum_{i=1}^nX_i \ \ \dot\sim \ \ N(n\mu,n\sigma^2)\ \ \ \ \ \ \text{as $n \to \infty$}$$
$$\bar{X} \ \ \dot\sim \ \ N(\mu,\frac{\sigma^2}{n})\ \ \ \ \ \ \text{as $n \to \infty$}$$
$$\frac{\bar{X}-\mu}{\sigma / \sqrt n} \  \ \dot\sim \ \ N(0,1)\ \ \ \ \ \ \text{as $n \to \infty$}$$