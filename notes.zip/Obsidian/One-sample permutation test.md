---
type: mthd
tag: MT2508
---
Proceed as with [[Matched-pairs permutation test]] but replace $d_i=y_i-x_i$ with $d_i=x_i-\mu_0$ (i.e use $(X,Y)=(X,\mu_{0}$)).