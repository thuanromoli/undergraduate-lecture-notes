---
tags:
  - MT3507
aliases:
---
Consider a [[General linear models|linear model]].

> [!def] Definition
> The normal equations are
> $$\mathbf{X}^T \mathbf{X}\widehat{\boldsymbol{\beta}} = \mathbf{X}^T \mathbf{y}.$$

> [!gen] Remarks
> - These are obtained by finding the value of $\boldsymbol{\beta}$ that minimises the square errors
> $$\begin{align*}
  \sum_{i} \epsilon_i^2 &= \boldsymbol{\epsilon}^T \boldsymbol{\epsilon}\\
  & = (\mathbf{y}- \mathbf{X}\boldsymbol{\beta})^T (\mathbf{y}- \mathbf{X}\boldsymbol{\beta}) \\
  & = \mathbf{y}^T \mathbf{y}- 2\boldsymbol{\beta}^T \mathbf{X}^T \mathbf{y}+ \boldsymbol{\beta}^T \mathbf{X}^T \mathbf{X}\boldsymbol{\beta}\\
  & \\
  \Rightarrow \quad \frac{\partial \boldsymbol{\epsilon}^T \boldsymbol{\epsilon}}{\partial \boldsymbol{\beta}} & = - 2 \mathbf{X}^T \mathbf{y}+ 2 \mathbf{X}^T \mathbf{X}\boldsymbol{\beta}.
\end{align*}$$
> - Note that a [[Maximum Likelihood Estimator|MLE]] approach would have also yielded the same normal equations.
> - These are useful to find $\widehat{\boldsymbol{\beta}}$, by rearranging to $\widehat{\boldsymbol{\beta}} = (\mathbf{X}^T \mathbf{X})^{-1} \mathbf{X}^T \mathbf{y}.$
