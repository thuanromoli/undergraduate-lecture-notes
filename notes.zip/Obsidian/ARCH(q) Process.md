---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A stochastic process $(\varepsilon_{t})_{t \in \mathbb Z}$ is called an autoregressive conditionally heteroscedastic process of order $q$ if there exists an independent [[White noise|white noise]] $(\eta_{t})_{t \in \mathbb Z}$ of unit variance $\sigma^{2}_\eta=1$ and real numbers $\alpha_{0}>0, \alpha_{1}\geqslant 0,...,\alpha_{q} \geqslant 0$ such that for all $t \in \mathbb Z$,
> $$\begin{align*}
   \varepsilon_{t}&=\sigma_{t} \eta_{t} \qquad\text{with}\\
   \sigma^{2}_{t} &= \alpha_{0}+\alpha_{1} \varepsilon^{2}_{t-1}+\cdots + \alpha_{q}\varepsilon_{t-q}^{2}
   \end{align*}$$
> where $\eta_{t}$ is referred to as "innovation".

> [!thm] Properties (under certain [[Stationarity of AR(p) Processes|regularity conditions]])
> - Unconditional mean $$\mathbb E(\varepsilon_{t})=0.$$
> - Unconditional variance (requiring $\alpha_{1}+\alpha_{2}+\cdots +\alpha_{q}<1$) $$\text{Var }(\varepsilon_{t})= \frac{\alpha_{0}}{1-\alpha_{1}-\alpha_{2}-\cdots - \alpha_q}.$$
> - Kurtosis $>3$.

> [!gen] Remarks
> - An ARCH($q$) process is a white noise.
> - The innovation's distribution is often specified as normal (then $\eta$ is a Gaussian white noise) or t-distributed (if heavy tails are needed).
> - Under suitable conditions, the ARCH($q$) model can be represented in the form of an AR($q$) process for $\varepsilon^{2}_{t}$.
> - ARCH($q$) displays volatility clustering.