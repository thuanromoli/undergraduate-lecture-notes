---
type: def
tags:
  - MT2505
---
Let $f(X)=\sum\limits_{i=0}^{n}a_iX^n$ and $g(X)=\sum\limits_{i=0}^{n}b_iX^n$ be [[Polynomials|polynomials]].

>[!def] Definition
>[[Polynomials|Polynomial]] multiplication is defined as
>$$f(X)g(X)=\sum\limits_{i=0}^{n}c_iX^n$$
>where $c_k= a_0b_k+a_1b_{k-1}+\ldots+a_kb_0=\sum_{i=0}^ka_ib_{k-i}$
