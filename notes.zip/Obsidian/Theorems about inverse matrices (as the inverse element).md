---
tag: MT2501
type: thm
alias:
- 
---
Let $A,B \in M_n(F)$ be [[The inverse of a matrix|invertible]] [[Matrices|matrices]].

>[!thm]- The [[The inverse of a matrix|inverse]] of $A$ is unique
>If there is an inverse, $A\in M_n(F)$ and $M_{n}(F)$ is the [[General linear group]]. Then see [[uniqueness of the inverse]].

>[!thm]- $A^{-1}$ is invertible and $(A^{-1})^{-1}=A$
>see [[Theorems about the inverse]].

>[!thm]- $AB$ is invertible and $(AB)^{-1}=B^{-1}A^{-1}$
>See [[Theorems about the inverse]].

---

#### Spaced repetition
