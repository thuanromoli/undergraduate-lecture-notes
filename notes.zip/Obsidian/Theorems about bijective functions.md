---
type: thm
tags:
  - MT2505
  - MT3502
---
Let $f:X\to Y$ be a [[Functions|function]].

>[!thm]- $f$ is [[Bijective functions|bijective]] $\iff$ $\exists f^{-1}: Y\to X$ s.t. $ff^{-1}=\text{id}_X$ and $f^{-1}f=\text{id}_Y$
>RTP: $f$ is bijective $\implies$ $\exists f^{-1}: Y\to X$ s.t. $ff^{-1}=\text{id}_X$ and $f^{-1}f=\text{id}_Y$
>- Claim 1: $f$ is bijective $\implies$ $f^{-1}f=\text{id}_{Y}$
>If $f$ is bijective then $f$ is both injective and surjective.
>Hence $\forall y \in Y \ \ \exists \, x\in X \ \text{ s.t }\ xf=y$ and $x$ is unique.
>Define $f^{-1}: Y\to X$ such that $yf^{-1}=x$
>$yf^{-1}=x \implies yf^{-1}f=xf \implies yf^{-1}f=y$
>Hence $f^{-1}f=\text{id}_{Y}$
>- Claim 2: $f$ is bijective $\implies$ $ff^{-1}=\text{id}_{X}$
>If $f$ is bijective then $f$ is both injective and surjective.
>Hence $\forall y \in Y \ \ \exists \, x\in X \ \text{ s.t }\ xf=y$ and $x$ is unique.
>-Define $f^{-1}: Y\to X$ such that $yf^{-1}=x$
>$xf=y$ $\implies$ $xff^{-1}=yf^{-1}$ $\implies$ $xff^{-1}=x$
>-Hence $ff^{-1} = \text{id}_{X}$
>
>RTP: $\exists f^{-1}: Y\to X$ s.t. $ff^{-1}=\text{id}_X$ and $f^{-1}f=\text{id}_Y$ $\implies$ $f$ is bijective
>- Claim 1: $\exists f^{-1}: Y\to X$ s.t. $ff^{-1}=\text{id}_X$ and $f^{-1}f=\text{id}_Y$ $\implies$ $f$ is injective
>Define $x_{1},x_{2}\in X$.
>$x_{1}f=x_{2}f$ $\implies$ $x_{1}ff^{-1}=x_{2}ff^{-1}$ $\implies$ $x_{1}=x_{2}$
>Hence $f$ is injective.
>- Claim 2: $\exists f^{-1}: Y\to X$ s.t. $ff^{-1}=\text{id}_X$ and $f^{-1}f=\text{id}_Y$ $\implies$ $f$ is surjective
>Let $y\in Y$ be arbitrary and $x=yf^{-1}$
>Then $x=yf^{-1} \implies xf=yf^{-1}f \implies xf=y$
>Hence $f$ is surjective
