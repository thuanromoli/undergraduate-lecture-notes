---
tags:
  - MT4551
aliases:
---
> [!def] Definition
> The delta is defined as
> $$\Delta = \frac{\partial V}{\partial S}$$
> and it measures the [[Hedging ratio|ideal hedging ratio]] ($\Delta$ large $\to$ hedge larger quantity).

> [!gen] Remarks
> - For a European Call (long position), $\Delta = N(d_{1})$
> - For a European Put (long position), $\Delta = N(d_{1})-1$
