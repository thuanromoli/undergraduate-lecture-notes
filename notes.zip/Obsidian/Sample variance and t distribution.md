---
type: def
tag: MT2508
---
Let $\bar X$ and $S^{2}$ be the sample mean and variance from a random sample of size $n$ from the $N(\mu,\sigma^2)$ distribution. Define $T=\frac {\bar X-\mu} {\sqrt{S^2/n}}$.

>[!gen]+ CONDITIONS/PRELIMINARY PROPERTIES
>- $\frac{\bar X - \mu}{\sqrt{\sigma^2/n}}\sim N(0,1)$
>- $\frac{(n-1)S^2}{\sigma^2}\sim\chi^2_{n-1}$
>- $\bar X$ and $S^{2}$ are [[Independent events|independent]]

>[!gen]+ DISTRIBUTION
>$$T=\frac{\bar X-\mu}{\sqrt{S^2/n}}=\frac{\bar X-\mu}{\sqrt{S^2/n}}\cdot\frac{\sqrt{\sigma^2/n}}{\sqrt{\sigma^2/n}}=\frac{\frac{\bar X - \mu}{\sqrt{\sigma^2/n}}}{\sqrt{\frac{S^2/n}{\sigma^2/n}}}=\frac{\frac{\bar X - \mu}{\sqrt{\sigma^2/n}}}{\sqrt{\frac{S^2}{\sigma^2}}}=\frac{\frac{\bar X - \mu}{\sqrt{\sigma^2/n}}}{\sqrt{\frac{(n-1)S^2}{\sigma^2}}/(n-1)}$$
>Hence $T$ is of the form $\frac{Z}{\sqrt{Y/(n-1)}}$ with $Z =\frac{\bar X-\mu}{\sqrt{\sigma^2/n}} \sim N(0,1)$ and $Y=\frac{(n-1)S^2}{\sigma^2}\sim\chi^2_{n-1}$
>Hence $T\sim t_{n-1}$ is [[t distributions|t distributed]].
