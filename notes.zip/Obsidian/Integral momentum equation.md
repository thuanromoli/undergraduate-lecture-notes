---
tags:
  - MT4509
aliases:
---
Let $V$ be a volume fixed in space with surface $S$ and outward normal $\boldsymbol{n}$.

> [!thm] Theorem
> Suppose that a long-range body force $\boldsymbol{F}$ and a short-range molecular force $-p \boldsymbol{n}$ act on $dV$. Then
> $$\iiint_{V}\frac{\partial (\rho \boldsymbol{u})}{\partial t}dV=-\iint_{S \text{ closed}}\rho \boldsymbol{u}(\boldsymbol{u \cdot n})\;dS + \iiint_{V} \rho \boldsymbol{F}\;dV-\iint_{S \text{ closed}}\rho \boldsymbol{n}\;dS.$$
> That is, rate of change of momentum = net inflow of momentum + body forces − pressure forces on $S$.
> 
> Often, we have steady flows ($\implies \frac{\partial \boldsymbol{u}}{\partial t}=0$) and the body forces can be ignored ($\implies \boldsymbol{F}=\boldsymbol{0}$). So we have
> $$\iint_{S \text{ closed}}(p \boldsymbol{n}+\rho \boldsymbol{u}(\boldsymbol{u \cdot n})) \;dS= \boldsymbol{0}.$$

In general the momentum density is $\iiint_{V} \rho \boldsymbol{u} \;dV$.
The local change is $\iiint_{V} \frac{\partial }{\partial t}(\rho \boldsymbol{u})\;dV$.

How can there be change in momentum?
Net flux of momentum into the volume = $-\iint_{S \text{ closed}}(\rho \boldsymbol{u})\boldsymbol{u \cdot n} \;dS$.
Effect of body forces over the volume = $+ \iiint_{V}\rho \boldsymbol{F}\;dV$.
Pressure forces on the volume = $-\iint_{S\text{ closed}}p \boldsymbol{n}dS$

Using [[Euler's equation]],
$$\frac{D \boldsymbol{u}}{Dt}=-\frac{\nabla p}{\rho}+\boldsymbol{F}.$$
Then multiply both sides by $p$ and integrate over volume to obtain
$$\begin{align*}
\iiint_{V} \rho \frac{D\boldsymbol{u}}{Dt}dV &= -\iiint_{V} \nabla \rho\;dV+\iiint_{V}\rho \boldsymbol{F}\;dV\\
\iiint_{V}\rho\left(\frac{\partial \boldsymbol{u} }{\partial t}+(\boldsymbol{u} \cdot \nabla) \boldsymbol{u}\right)dV&= -\iint_{S \text{ closed}} p \boldsymbol{n}dS +\iiint_{V}\rho \boldsymbol{F}\;dV\\
\iiint_{V}\left(\frac{\partial (\rho \boldsymbol{u})}{\partial t}-\boldsymbol u \frac{\partial p}{\partial t}+\rho(\boldsymbol{u} \cdot \nabla) \boldsymbol{u}\right)dV&= -\iint_{S \text{ closed}} p \boldsymbol{n}dS +\iiint_{V}\rho \boldsymbol{F}\;dV
\end{align*}$$
We now focus on the LHS.
Using the [[Continuity equation|continuity equation]], $\frac{\partial p}{\partial t}+\nabla \cdot (\rho \boldsymbol{u})=0 \implies \frac{\partial p}{\partial t}=- \nabla  \cdot (\rho \boldsymbol{u})$.
So the LHS becomes
$$\iiint_{V}\left(\frac{\partial (\rho \boldsymbol{u})}{\partial t}+\boldsymbol u \nabla \cdot (\rho \boldsymbol{u)}+\rho(\boldsymbol{u} \cdot \nabla) \boldsymbol{u}\right)dV.$$
Consider the $x$-component and the last two terms of the integrand.
Note that $\nabla \cdot (f \boldsymbol{F})=f \nabla \cdot \boldsymbol{F}+ \boldsymbol{F} \cdot \nabla f$. So with $f=u$ and $\boldsymbol{F}=\rho  \boldsymbol{u}$ we note that
$$\begin{align*}
& \;\quad u \nabla \cdot(\rho \boldsymbol{u})+ \rho(\boldsymbol{u \cdot}\nabla)u\\
&= u\left(\frac{\partial (\rho u)}{\partial x}+\frac{\partial (\rho v)}{\partial y}+\frac{\partial (\rho w) }{\partial z}\right)+\rho\left(u \frac{\partial u}{\partial x}+v \frac{\partial u}{\partial y}+w \frac{\partial u}{\partial z}\right)\\
&= u( \nabla \cdot (\rho \boldsymbol{u}))+(\rho \boldsymbol{u})\cdot \nabla u\\
&= \boldsymbol{\nabla }\cdot(u(\rho \boldsymbol{u})).
\end{align*}$$
We now use the divergence theorem to obtain
$$\iiint_{V}(\boldsymbol{\nabla }\cdot u (\rho \boldsymbol{u}))\;dV =\iint_{S \text{ closed}} u \rho \boldsymbol{u} \cdot \boldsymbol{n}\;dS.$$
We note that this holds also for the $y$- and $z$-coordinates and we abuse notation a little bit by writing $\nabla \cdot(\rho \boldsymbol{uu})=(\nabla \cdot (\rho \boldsymbol{u}u),\nabla \cdot (\rho \boldsymbol{u}v),\nabla \cdot (\rho \boldsymbol{u}w))$ to obtain
$$\iiint_{V}(\boldsymbol{\nabla }\cdot (\boldsymbol{u}\rho \boldsymbol{u}))\;dV = \iint_{S \text{ closed}}\boldsymbol{u}\rho \boldsymbol{u} \cdot \boldsymbol{n}\;dS.$$
Combining this together yields the required result.
