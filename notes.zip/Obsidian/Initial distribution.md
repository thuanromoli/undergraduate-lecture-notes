---
tags:
  - MT4528
type: def
aliases:
  - initial distribution
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S$ and let $u_{j}(t)= \mathbb{P}(X_{t}= j)$.

>[!def] Definition
>The initial distribution of the Markov chain is given by the row vector
>$$\boldsymbol{u}(0)=(u_{1}(0),u_{2}(0),...)=(\mathbb{P}(X_{0}=1),\mathbb{P}(X_{0}=2),...)$$
