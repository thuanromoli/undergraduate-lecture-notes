---
tags:
  - MT4528
type: def
aliases:
  - accessible
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S$.

>[!def] Definition
>A state $j \in S$ is called accessible from state $i\in S$ if
>$$p_{ij}(n)=\mathbb{P}(X_{t+n}=j | X_{t}=i)>0 \text{ for some } n \geqslant 0$$
>That is, the probability to get to state $j$ from $i$ in any time is non-zero and we write $i\to j$.
