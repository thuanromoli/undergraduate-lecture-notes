---
tags:
  - MT4003
aliases:
  - directly decomposable
---
Let $G$ be a [[Groups|group]].

> [!def] Definition
> $G$ is directly decomposable if there exists non-trivial groups $H$ and $K$ such that 
> $$G \cong H \times K.$$
