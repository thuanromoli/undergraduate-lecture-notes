---
tags:
  - MT4554
type: 
aliases:
  - evolutionary stable strategy
---
>[!def] Definition
>A resident strategy $\sigma^{r}$ is an evolutionary stable strategy in a population if
>1. $u(\sigma^{r},\sigma^{r})>u(\sigma^{k},\sigma^{r})$ OR
>2. $u(\sigma^{r},\sigma^{r})=u(\sigma^{k},\sigma^{r})$ and $u(\sigma^{r},\sigma^{k})>u(\sigma^{k},\sigma^{k})$
>for all $\sigma^{k}\in \Sigma$.
>
>In other words, when a strategy $\sigma^{r}$ is evolutionary stable, either a strategy $\sigma^{k}$ cannot invade a resident population OR if $\sigma^{k}$ does as good as $\sigma^{t}$ when invading (that is, $\sigma^{r}$ is a [[Nash equilibrium]]), then $\sigma^{r}$ can invade a population using $\sigma^{k}$.
