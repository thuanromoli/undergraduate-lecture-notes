---
tags:
  - MT4528
type: thm
aliases:
---
Let $\set{X_{n}:n=0,1,...}$ be a [[Galton-Watson processes|Galton-Watson process]] starting at $X_{0}=1$.
Let $\mathbb{F}_{n}(s)$ denote the [[Probability generating functions|pgf]] of $X_{n}$ and $\mathbb{G}(s)$ the [[Probability generating functions|pgf]] of the offspring distribution.

>[!thm]- $\mathbb{F}_{1}(s)=\mathbb{G}(s)$
>Since $X_{1}=\sum\limits_{i=1}^{X_{0}}Z_{i}=Z_{1}$ then $\mathbb{P}(X_{1}=k)=\mathbb{P}(Z_{1}=k)=p_{k}$.
>Hence $\mathbb{F}_{1}(s)=\mathbb{G}(s)$

>[!thm]- $\mathbb{F}_{n}(s)=\underbrace{\mathbb{G}(\mathbb{G}(\ldots\mathbb{G}(s)))}_{n\text{ times}}$
>Since $X_{n}=Z_{1}+\ldots+Z_{X_{n-1}}$ and $Z_{i}$'s are [[Independent events|independently]] identically distributed, $X_{n}$ is a [[Compound distributions|compound distribution]]. Hence
>$$\begin{align*}
   \mathbb{F}_{n}(s) &= \mathbb{F}_{n-1}(\mathbb{G}(s))\\
   &= \mathbb{F}_{n-2}(\mathbb{G}(\mathbb{G}(s)))\\
   & \vdots \\
   &= \underbrace{\mathbb{G}(\mathbb{G}(\ldots\mathbb{G}(s)))}_{n\text{ times}}.
   \end{align*}$$

>[!thm]- $\mathbb{F}_{n}(s)=\mathbb{G}(\mathbb{F}_{n-1}(s))$
>From the above we have that $\mathbb{F}_{n-1}(s)=\underbrace{\mathbb{G}(\mathbb{G}(\ldots\mathbb{G}(s)))}_{n-1\text{ times}}$.
>So $\mathbb{F}_{n}(s)=\underbrace{\mathbb{G}(\mathbb{G}(\ldots\mathbb{G}(s)))}_{n\text{ times}}=\mathbb{G}\underbrace{(\mathbb{G}(\ldots\mathbb{G}(s)))}_{n-1 \text{ times}}=\mathbb{G}(\mathbb{F}_{n-1}(s))$

^286458

Let $\mu=\mathbb{E}(X_{1})$ and $\sigma^{2}=\text{Var }(X_{1})$.

>[!thm]- $\mathbb{E}(X_{n})=\mu^{n}$
>Note that $\mathbb{E}(X_{n})=\mathbb{F}_{n}'(1)$ as $\mathbb{F}_{n}(s)$ is the [[Probability generating functions|pgf]] of $X_{n}$.
>From the above theorem, $\mathbb{F}_{n}(s)=\mathbb{G}(\mathbb{F}_{n-1}(s))$. Hence $\mathbb{F}_{n}'(s)=\mathbb{G}'(\mathbb{F}_{n-1}(s))\mathbb{F}'_{n-1}(s)$.
>So $\mathbb{E}(X_{n})=\mathbb{F'}(1)=\mathbb{G'}(\mathbb{F}_{n-1}(1))\mathbb{F'}_{n-1}(1)$.
>Here $\mathbb{F}_{n-1}(1)=1$ (see [[theorems about pgfs]]) and $\mathbb{F}'_{n-1}(1)=\mathbb{E}(X_{n-1})$.
>Hence $\mathbb{E}(X_{n})=\mathbb{G'}(1)\mathbb{E}(X_{n-1})$.
>But since $\mathbb{G}(s)=\mathbb{F}_{1}(s)$ by the above theorem, $\mathbb{G'}(1)=\mathbb{F}'_{1}(1)=\mathbb{E}(X_{1})=\mu$.
>Hence $\mathbb{E}(X_{n})=\mu\mathbb{E}(X_{n-1})$.
>And finally by induction or otherwise, $\mathbb{E}(X_{n})=\mu^{n}$.

>[!thm]- $$\text{Var }(X_{n})=\begin{cases}
   n \sigma^{2} & \text{if } \mu = 1 \\
   \frac{\sigma^{2}\mu^{n-1}(\mu^{n}-1)}{\mu-1} & \text{if } \mu \neq 1
   \end{cases}$$
>Note that $\text{Var }(X_{n})=\mathbb{F}''_{n}(1)+\mathbb{F}'_{n}(1)-(\mathbb{F}_{n}'(1))^{2}$.
>
>STEP 1: Finding $\mathbb{F}''_{n}(1)$.
>Firstly we wish to find $\mathbb{F}''_{n}(s)$.
>From the above theorem, $\mathbb{F}_{n}(s)=\mathbb{G}(\mathbb{F}_{n-1}(s))$ $\implies$ $\mathbb{F}_{n}'(s)=\mathbb{G}'(\mathbb{F}_{n-1}(s))\mathbb{F}'_{n-1}(s)$.
>Hence $\mathbb{F}''_{n}(s)=\mathbb{G}''(\mathbb{F}_{n-1}(s))(\mathbb{F}'_{n-1}(s))^{2}+\mathbb{G}'(\mathbb{F}_{n-1}(s))\mathbb{F}''_{n-1}(s)$.
>$$\begin{align*}
   \mathbb{F}''_{n}(1) &= \mathbb{G}''(\mathbb{F}_{n-1}(1))(\mathbb{F}'_{n-1}(1))^{2}+\mathbb{G}'(\mathbb{F}_{n-1}(1))\mathbb{F}''_{n-1}(s)\\
   &= \mathbb{G}''(1)(\mathbb{E}(X_{n-1}))^{2}+\mathbb{G}'(1)\mathbb{F}''_{n-1}(1)\\
   &= \mathbb{G}''(1)(\mu^{n-1})^{2}+\mu \mathbb{F}''_{n-1}(1).
   \end{align*}$$
>This is a recursive definition so we proceed to evaluate $\mathbb{F}_{2},\mathbb{F}_{3},...,\mathbb{F}_{n}$:
>$$\begin{align*}
   & \mathbb F''_{2}(1) = \mathbb{G}''(1)\mu^{2}+\mu \mathbb{F}''_{1}(1) =\mathbb G''(1)\mu(1+\mu)\\
   \implies & \mathbb F''_{3}(1) = \mathbb{G}''(1)\mu^{4}+\mu \mathbb{F}''_{2}(1) = \mathbb{G}''(1)\mu^{4}+\mu (\mathbb G''(1)\mu(1+\mu)) =\mathbb G''(1)\mu^{2}(1+\mu+\mu^{2})\\
   \implies & \mathbb F''_{4}(1) = \mathbb{G}''(1)\mu^{6}+\mu \mathbb{F}''_{3}(1) = \mathbb{G}''(1)\mu^{6}+\mu (\mathbb G''(1)\mu^{2}(1+\mu+\mu^{2})) =\mathbb G''(1)\mu^{3}(1+\mu+\mu^{2}+\mu^{3})\\
   & \vdots \\
   \implies & \mathbb F_{n}''(1) = \mathbb G''(1)\mu^{n-1}\sum\limits_{k=0}^{n}\mu^{k-1}=\begin{cases}
   \mathbb G''(1) \mu^{n-1} \frac{\mu^{n}-1}{\mu-1} & \text{for } \mu \neq 1 \\
   \mathbb G''(1) n  & \text{for } \mu=1
   \end{cases}
   \end{align*}$$
>where $\mathbb G''(1)=\mathbb E(X_{1}^{2})-\mathbb E(X_{1})=\sigma^{2}-\mu+\mu^{2}$
>
>STEP 2: Finding $\mathbb F'_{n}(1)$.
>This is just $\mathbb E(X_{n})=\mu^{n}$
>
>STEP 3: Combining all the above.
>$$\text{Var }(X_{n})=\mathbb{F}''_{n}(1)+\mathbb{F}'_{n}(1)- (\mathbb{F}_{n}'(1))^{2} = \begin{cases}
   n \sigma^{2} & \text{if } \mu = 1 \\
   \frac{\sigma^{2}\mu^{n-1}(\mu^{n}-1)}{\mu-1} & \text{if } \mu \neq 1
   \end{cases}$$