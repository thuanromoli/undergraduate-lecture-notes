---
tags:
  - MT2501
  - MT3501
type: def
aliases:
  - dimension
  - finite-dimensional
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$.

>[!def] Definition
>The size of any [[Bases|basis]], and hence all bases, of a vector space is called the dimension of $V$ and is denoted by $\text{dim}(V)$.

>[!def] Definition
>We say that $V$ is finite-dimensional if it possesses a finite [[Span|spanning set]].

---

#### Spaced repetition

What is the dimension of a vector space?
?
>The size of any [[Bases|basis]], and hence all bases, of a vector space is called the dimension of $V$ and is denoted by $\text{dim}(V)$.

When is a vector space finite-dimensional?
?
>We say that $V$ is finite-dimensional if it possesses a finite [[Span|spanning set]].