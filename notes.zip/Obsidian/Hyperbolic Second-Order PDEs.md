---
tags:
  - MT3504
type: 
aliases:
---
Let $u=u(x,y)$ satisfy the PDE $au_{xx}+2bu_{xy}+cu_{yy}=0$ where $a,b,c$ are constant.
If $b^{2}-ac>0$ then we have an [[Classification of Second-Order PDEs|hyperbolic equation]] and by a suitable transformation the PDE is equivalent to $u_{\zeta \eta}=0$ which can be easily solved.
Note: if $a=c=0$ then the PDE is already of the required form. If $a=0$ we can swap $x$ and $y$ so wlog we assume that $a \neq 0$.

STEP 1: Find characteristics
The [[Classification of Second-Order PDEs|characteristics]] are defined by $\frac{dy}{dx}=\frac{b\pm \sqrt{b^{2}-ac}}{a}\equiv \mu_{1,2}$.
So $y=\mu_{1} x+\eta$ and $y=\mu_{2} x+\zeta$ are the characteristics equations.

STEP 2: Find the intersection point of the two curves (solve for $x$ and $y$)
Using matrices, simultaneous equations, or otherwise we obtain $x=\frac{\zeta-\eta}{\mu_{1}-\mu_{2}}$ and $y=\frac{\mu_{1}\zeta-\mu_{2}\eta}{\mu_{1}-\mu_{2}}$.

STEP 3: Use the chain rule to show that $u_{\zeta\eta}=0$
$$\frac{\partial }{\partial \zeta}=\frac{\partial x}{\partial \zeta}\frac{\partial }{\partial x}+\frac{\partial y}{\partial \zeta}\frac{\partial }{\partial y}=\left(\frac{1}{\mu_{1}-\mu_{2}}\right)\frac{\partial }{\partial x}+\left(\frac{\mu_{1}}{\mu_{1}-\mu_{2}}\right)\frac{\partial }{\partial y}$$
and
$$\frac{\partial }{\partial \eta}=\frac{\partial x}{\partial \eta}\frac{\partial }{\partial x}+\frac{\partial y}{\partial \eta}\frac{\partial }{\partial y}=\left(-\frac{1}{\mu_{1}-\mu_{2}}\right)\frac{\partial }{\partial x}+\left(-\frac{\mu_{2}}{\mu_{1}-\mu_{2}}\right)\frac{\partial }{\partial y}$$
so
$$\begin{align*}
\frac{\partial ^{2}u}{\partial \zeta \partial \eta} &= \left[\left(\frac{1}{\mu_{1}-\mu_{2}}\right)u_{x}+\left(\frac{\mu_{1}}{\mu_{1}-\mu_{2}}\right)u_{y}\right]\left[\left(-\frac{1}{\mu_{1}-\mu_{2}}\right)u_{x}+\left(-\frac{\mu_{2}}{\mu_{1}-\mu_{2}}\right)u_{y}\right]\\
&= -\frac{1}{(\mu_{1}-\mu_{2})^{2}}u_{xx} - \frac{\mu_{2}}{(\mu_{1}-\mu_{2})^{2}}u_{xy}-\frac{\mu_{1}}{(\mu_{1}-\mu_{2})^{2}}u_{yx}-\frac{\mu_{1}\mu_{2}}{(\mu_{1}-\mu_{2})^{2}}u_{yy}\\
&= -\frac{1}{(\mu_{1}-\mu_{2})^{2}}(u_{xx}+(\mu_{1}+\mu_{2})u_{xy}+\mu_{1}\mu_{2}u_{yy})\\
\end{align*}$$
Now note:
- $\mu_{1}+\mu_{2}=\frac{b+\sqrt{b^{2}-ac}}{a}+\frac{b-\sqrt{b^{2}-ac}}{a}=\frac{2b}{a}$
- $\mu_{1}-\mu_{2}=\frac{b+\sqrt{b^{2}-ac}}{a}-\frac{b-\sqrt{b^{2}-ac}}{a}=\frac{2\sqrt{b^{2}-ac}}{a}$
- $\mu_{1}\mu_{2}=\frac{b+\sqrt{b^{2}-ac}}{a}\cdot\frac{b-\sqrt{b^{2}-ac}}{a}=(\frac{b^{2}-b^{2}+ac}{a^{2}})=\frac{c}{a}$

Hence
$$\begin{align*}
\frac{\partial ^{2}u}{\partial \zeta \partial \eta} &=  -\frac{1}{\frac{4(b^{2}-ac)}{a^{2}}}\left(u_{xx}+\frac{2b}{a}u_{xy}+ \frac{c}{a}u_{yy}\right)\\
&= -\frac{a^{2}}{4(b^{2}-ac)}\left(u_{xx}+\frac{2b}{a}u_{xy}+ \frac{c}{a}u_{yy}\right)\\
&= -\frac{a}{4(b^{2}-ac)}\left(au_{xx}+2bu_{xy}+ cu_{yy}\right)\\
&= 0
\end{align*}$$

STEP 4: Integrate with respect of $\eta$ and $\zeta$
$$\begin{align*}
&\;\;\;\;\;\;\;\;\;\;\frac{\partial ^{2}u}{\partial \zeta \partial \eta} = 0\\
&\iff \frac{\partial u}{\partial \zeta}=\int_{}^{}0 \; d \eta + \tilde F(\zeta)\\
&\iff u = \int_{}^{} \tilde F(\zeta) \;d \zeta + G(\eta)
\end{align*}$$
So the PDE has solution $u(\zeta,\eta)=F(\zeta)+G(\eta)$ or $u(x,y)=F(y-\mu_{2}x) + G(y-\mu_{1}x)$

STEP 5: Apply initial conditions