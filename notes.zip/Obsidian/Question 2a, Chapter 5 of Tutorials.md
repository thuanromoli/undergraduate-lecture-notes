Prove that $f_{n}(x) = \frac{x^{2}}{n+x^{2}}$ is not uniformly convergent.

A sequence $(f_{n})_{n}$ uniformly converges to $f$ if
$$\forall \varepsilon > 0 \;\; \exists N \in \mathbb N \;\; \text{s.t.} \;\;\forall n \in \mathbb N,\forall x \in [a,b], \quad n \geqslant N \implies |f_{n}-f| < \varepsilon.$$
Hence the negation of the above statement would be $(f_{n})_{n}$ doesn't uniformly converge if
$$\exists  \varepsilon >0 \;\text{s.t}\; \forall N \in \mathbb N, \;\exists \;n \mathbb \in \mathbb N\text{ and } x \in \mathbb [a,b] \;\text{s.t}\;\; n \geqslant N \implies|f_{n}-f| \geqslant \varepsilon$$

To me this means that I need to find values of $x$ and $n$ and $\varepsilon$ that satisfy the above.

So, I set $\varepsilon = \frac{1}{2}$. Choose $x = \sqrt{n}$ and $n= n$. Then $n \geqslant N$ implies that
$$|f_{n}-f| = \left|\frac{x^{2}}{n+x^{2}} \right| = \frac{n}{n+n} = \frac{n}{2n} = \frac{1}{2} \geqslant \varepsilon.$$
I aimed to choose $x$ and $n$ so that the inequality doesn't depend on $n$, to avoid the condition $n \geqslant N$.

The solutions differ (see solutions attached to the email) and I was wondering if 
1. the two solutions are equally as valid.
2. the idea behind this proof makes sense.