---
tags:
  - MT4509
aliases:
  - material surface
---
> [!def] Definition
> A material surface is a surface always consisting of the same fluid particles. The surface forever consists of the same fluid particles.
> It is often represented by the equation $F(\boldsymbol{x},t) = C$, constant.
