---
tags:
  - MT2501
  - MT3501
type: thm
aliases:
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$.

>[!thm]- Suppose that $\set{v_{1},...,v_{m}}$ is a [[Linear independence|linearly independent]] set of vectors in $V$ and $\set{w_{1},...,w_{n}}$ is a [[Spanning sets|spanning set]] for $V$. Then $m \leqslant n$
>Since $\set{w_{1},...,w_{n}}$ is a [[Spanning sets|spanning set]] for $V$, we can write every vector in $V$ as a [[Linear combinations|linear combination]] of $w_{1},...,w_{n}$; in particular $v_{1}=\sum\limits_{i=1}^{n}\alpha_{i}w_{i}$.
>Since $\set{v_{1},...,v_{m}}$ is [[Linear independence|linearly independent]], certainly $v_{1}\neq \boldsymbol{0}$ [[Theorems about linear independence#^2f365e|by this theorem]].
>Thus some of the $\alpha_{i}$ are non-zero. WLOG, assume $\alpha_{1} \neq 0$.
>Then $w_{1}=\frac{1}{\alpha_{1}}\left(v_{1}-\sum\limits_{i=2}^{n}(\alpha_{i}w_{i})\right)$.
>This enables us to replace $w_{1}$ in any expression by a linear combination of vectors $v_{1},w_{2},...,w_{n}$.
>Since $V=\text{Span}(w_{1},w_{2},...,w_{n})$, we now deduce that $V=\text{Span}(v_{1},w_{2},...,w_{n})$.
>
>Now suppose that we manage to show that $V=\text{Span}(v_{1},v_{2},...,v_{j},w_{j+1},...,w_{n})$ for some value $j:j<m,n$.
>Then $v_{j+1}$ is a vector in $V$, so can be expressed as a linear combination of $v_{1},v_{2},...,v_{j},w_{j+1},...,w_{n}$,
>say $v_{j+1}=\sum\limits_{i=1}^{j}\beta_{i}v_{i}+\sum\limits_{i=j+1}^{n}\beta_{i}w_{i}$.
>Now if $\beta_{j+1}=\ldots=\beta_{n}=0$, then we would have $v_{j+1}=\sum\limits_{i=1}^{j}\beta_{i}v_{i}$, which would contradict the fact that the set $\set{v_{1},...,v_{m}}$ is linearly independent [[Theorems about linear independence#^0715f1|by this proof]].
>So there must exist some non-zero $\beta_{i}$ with $i \geqslant j+1$.
>
>Now we can re-arrange, assuming $w_{j+1}$ is non-zero, the expression $v_{j+1}=\sum\limits_{i=1}^{j}\beta_{i}v_{i}+\sum\limits_{i=j+1}^{n}\beta_{i}w_{i}$ to obtain an expression for $w_{j+1}$:
>$w_{j+1}=\frac{1}{\beta_{j+1}}\left(v_{j+1}-\sum\limits_{i=1}^{j}\beta_{i}v_{i}-\sum\limits_{i=j+2}^{n}\beta_{i}w_{i}\right)$.
>Consequently, we can replace $w_{j+1}$ in any expression by a linear combination of vectors $v_{1},...,v_{j+1},w_{j+2},...,w_{n}$.
>
>Therefore $V=\text{Span}(v_{1},...,v_{j},w_{j+1},...,w_{n})=\text{Span}(v_{1},...,v_{j+1},w_{j+2},...,w_{n})$.
>If it were the case that $m>n$, then this process stops when we replaced all the $w_{i}$ by $v_{i}$ and we have $V=\text{Span}(v_{1},...,v_{n})$.
>But then $v_{n+1}$ is a linear combination of $v_{1},...,v_{n}$ which contradicts $\set{v_{1},...,v_{m}}$ being linearly independent.
>
>Hence $m \leqslant n$ as required.

^e45314

>[!thm]- Any two [[bases]] for $V$ have the same size and consequently, $\dim(V)$ is uniquely determined
>If $\set{v_{1},...,v_{m}}$ and $\set{w_{1},...,w_{n}}$ are bases for $V$, then they are both linearly independent and spanning sets for $V$.
>By applying the above theorem twice, we obtain $m \leqslant n$ and $n \leqslant m$.
>Hence $m=n$

Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $\mathscr A = \set{v_{1},...,v_{k}}$ be a set of vectors in $V$. 

>[!thm]- If $\mathscr A$ [[Span|spans]] $V$, then there is some subset of $\mathscr A$ which is a [[Bases|basis]] for $V$. That is we can remove some vectors to $\mathscr A$ to produce a set $\mathscr B$ that is a basis for $V$.
>Case 1: $\mathscr A$ is linearly independent.
>Then by definition, $\mathscr A$ is a basis for $V$.
>
>Case 2: $\mathscr A$ is linearly dependent.
>Then by [[Theorems about linear independence#^1f270a|this theorem]] we can create a subset $\mathscr B \subseteq \mathscr A$ such that $\text{Span}(\mathscr B)=\text{Span}(\mathscr A)=V$ and $\mathscr B$ is linearly independent.
>This is a [[Bases|basis]] for $V$.

>[!thm]- If $\mathscr A$ is [[Linear independence|linearly independent]], then it can be extended to a basis. That is we can add some vectors to $\mathscr A$ to produce a set $\mathscr B$ that is a basis for $V$
>Case 1: $\mathscr A$ spans $V$.
>Then by definition, $\mathscr A$ is a basis for $V$.
>
>Case 2: $\mathscr A$ does not span $V$.
>Then, there exists some vector $v_{k+1} \notin \text{Span}(\mathscr A)$. Let $\mathscr A' = \set{v_{1},...,v_{k},v_{k+1}}$.
>Now we want to show that $\mathscr A'$ is linearly independent.
>Suppose $\sum\limits_{i=1}^{k+1}\alpha_{i}v_{i}=\boldsymbol{0}$.
>If $a_{k+1}=0$, then $v_{k+1}=-\frac{1}{\alpha_{k+1}}\sum\limits_{i=1}^{m}\in \text{Span}\mathscr A$.
>This is a contradiction, thus $a_{k+1}=0$.
>Hence $\mathscr A'$ is linearly independent.
>This process can be repeated but not forever since [[Theorems about dimension#^e45314|by this theorem]], there is a maximum size for a linearly independent set, namely $\dim(V)$. 
>Hence we have created $\mathscr B$ such that $\text{Span}(\mathscr B) = V$. $\mathscr B$ is also linearly independent.
>Hence $\mathscr B$ is a basis for $V$.

^63394b

>[!thm]- If $\mathscr A$ satisfies any of the following three conditions then it is a [[Bases|basis]] of $V$:
>- it is a [[Span|spanning set]] for $V$
>- it is [[Linear independence|linearly independent]]
>- it contains precisely $\dim(V)$ vectors

Below is not needed for MT3501.

Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $u_{1},...,u_{n}$ be a [[Span|spanning set]] for $V$.

>[!thm]- Any collection of $m>n$ vectors is [[Linear independence|linearly dependent]]
>We are trying to show that $\set{u_{1},...,u_{n},u}$ is linearly dependent.
>Consider $u \notin {u_{1},...,u_{n}}$ and note that $u\in V$.
>Since $V=\text{Span}(u_{1},...,u_{n})$, we can write $u$ as a linear combination of $u_{1},...,u_{n}$ and therefore the set $\set{u_{1},...,u_{n},u}$ is linearly dependent.

---

#### Spaced repetition

Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and suppose that $\set{v_{1},...,v_{m}}$ is a [[Linear independence|linearly independent]] set of vectors in $V$ and $\set{w_{1},...,w_{n}}$ is a [[Spanning sets|spanning set]] for $V$. Prove that $m \leqslant n$.
?
>Since $\set{w_{1},...,w_{n}}$ is a [[Spanning sets|spanning set]] for $V$, we can write every vector in $V$ as a [[Linear combinations|linear combination]] of $w_{1},...,w_{n}$; in particular $v_{1}=\sum\limits_{i=1}^{n}\alpha_{i}w_{i}$.
>Since $\set{v_{1},...,v_{m}}$ is [[Linear independence|linearly independent]], certainly $v_{1}\neq \boldsymbol{0}$ [[Theorems about linear independence#^2f365e|by this theorem]].
>Thus some of the $\alpha_{i}$ are non-zero. WLOG, assume $\alpha_{1} \neq 0$.
>Then $w_{1}=\frac{1}{\alpha_{1}}\left(v_{1}-\sum\limits_{i=2}^{n}(\alpha_{i}w_{i})\right)$.
>This enables us to replace $w_{1}$ in any expression by a linear combination of vectors $v_{1},w_{2},...,w_{n}$.
>Since $V=\text{Span}(w_{1},w_{2},...,w_{n})$, we now deduce that $V=\text{Span}(v_{1},w_{2},...,w_{n})$.
>
>Now suppose that we manage to show that $V=\text{Span}(v_{1},v_{2},...,v_{j},w_{j+1},...,w_{n})$ for some value $j:j<m,n$.
>Then $v_{j+1}$ is a vector in $V$, so can be expressed as a linear combination of $v_{1},v_{2},...,v_{j},w_{j+1},...,w_{n}$,
>say $v_{j+1}=\sum\limits_{i=1}^{j}\beta_{i}v_{i}+\sum\limits_{i=j+1}^{n}\beta_{i}w_{i}$.
>Now if $\beta_{j+1}=\ldots=\beta_{n}=0$, then we would have $v_{j+1}=\sum\limits_{i=1}^{j}\beta_{i}v_{i}$, which would contradict the fact that the set $\set{v_{1},...,v_{m}}$ is linearly independent [[Theorems about linear independence#^0715f1|by this proof]].
>So there must exist some non-zero $\beta_{i}$ with $i \geqslant j+1$.
>
>Now we can re-arrange, assuming $w_{j+1}$ is non-zero, the expression $v_{j+1}=\sum\limits_{i=1}^{j}\beta_{i}v_{i}+\sum\limits_{i=j+1}^{n}\beta_{i}w_{i}$ to obtain an expression for $w_{j+1}$:
>$w_{j+1}=\frac{1}{\beta_{j+1}}\left(v_{j+1}-\sum\limits_{i=1}^{j}\beta_{i}v_{i}-\sum\limits_{i=j+2}^{n}\beta_{i}w_{i}\right)$.
>Consequently, we can replace $w_{j+1}$ in any expression by a linear combination of vectors $v_{1},...,v_{j+1},w_{j+2},...,w_{n}$.
>
>Therefore $V=\text{Span}(v_{1},...,v_{j},w_{j+1},...,w_{n})=\text{Span}(v_{1},...,v_{j+1},w_{j+2},...,w_{n})$.
>If it were the case that $m>n$, then this process stops when we replaced all the $w_{i}$ by $v_{i}$ and we have $V=\text{Span}(v_{1},...,v_{n})$.
>But then $v_{n+1}$ is a linear combination of $v_{1},...,v_{n}$ which contradicts $\set{v_{1},...,v_{m}}$ being linearly independent.
>
>Hence $m \leqslant n$ as required.


Prove that any two [[bases]] for $V$ have the same size and consequently, $\dim(V)$ is uniquely determined.
?
>If $\set{v_{1},...,v_{m}}$ and $\set{w_{1},...,w_{n}}$ are bases for $V$, then they are both linearly independent and spanning sets for $V$.
>By applying the above theorem twice, we obtain $m \leqslant n$ and $n \leqslant m$.
>Hence $m=n$

Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $\mathscr A = \set{v_{1},...,v_{k}}$ be a set of vectors in $V$. Prove that if $\mathscr A$ [[Span|spans]] $V$, then there is some subset of $\mathscr A$ which is a [[Bases|basis]] for $V$. That is we can remove some vectors to $\mathscr A$ to produce a set $\mathscr B$ that is a basis for $V$.
?
>Case 1: $\mathscr A$ is linearly independent.
>Then by definition, $\mathscr A$ is a basis for $V$.
>
>Case 2: $\mathscr A$ is linearly dependent.
>Then by [[Theorems about linear independence#^1f270a|this theorem]] we can create a subset $\mathscr B \subseteq \mathscr A$ such that $\text{Span}(\mathscr B)=\text{Span}(\mathscr A)=V$ and $\mathscr B$ is linearly independent.
>This is a [[Bases|basis]] for $V$.

Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $\mathscr A = \set{v_{1},...,v_{k}}$ be a set of vectors in $V$. Prove that if $\mathscr A$ is [[Linear independence|linearly independent]], then it can be extended to a basis. That is we can add some vectors to $\mathscr A$ to produce a set $\mathscr B$ that is a basis for $V$.
?
>Case 1: $\mathscr A$ spans $V$.
>Then by definition, $\mathscr A$ is a basis for $V$.
>
>Case 2: $\mathscr A$ does not span $V$.
>Then, there exists some vector $v_{k+1} \notin \text{Span}(\mathscr A)$. Let $\mathscr A' = \set{v_{1},...,v_{k},v_{k+1}}$.
>Now we want to show that $\mathscr A'$ is linearly independent.
>Suppose $\sum\limits_{i=1}^{k+1}\alpha_{i}v_{i}=\boldsymbol{0}$.
>If $a_{k+1}=0$, then $v_{k+1}=-\frac{1}{\alpha_{k+1}}\sum\limits_{i=1}^{m}\in \text{Span}\mathscr A$.
>This is a contradiction, thus $a_{k+1}=0$.
>Hence $\mathscr A'$ is linearly independent.
>This process can be repeated but not forever since [[Theorems about dimension#^e45314|by this theorem]], there is a maximum size for a linearly independent set, namely $\dim(V)$. 
>Hence we have created $\mathscr B$ such that $\text{Span}(\mathscr B) = V$. $\mathscr B$ is also linearly independent.
>Hence $\mathscr B$ is a basis for $V$.
