---
tags:
  - MT3508
aliases:
---
> [!def] The problem
> ![[newheavhist_att.png|400]]
> ![[newheaventemps_att.png|400]]
> 
> We would like to use these data to make statements about the probability that the mean temperature is in any particular range in a future year.

> [!gen] Model 1
> From the first graph, a normal probability model may be reasonable for these data.
> - $\boldsymbol{y} = (y_{1},...,y_{60})$.
> - $\boldsymbol{x},\boldsymbol{\gamma}$ are not present.
> - $\boldsymbol{\theta} = (\mu, \sigma)$.
> 
> We then have $f(y_{i})= \frac{1}{\sqrt{2\pi \sigma^{2}}}\exp\left\{-\frac{(y_{i}-\mu)^{2}}{2\sigma^{2}}\right\}$ and
> $$\begin{align*}
   f(\boldsymbol{y};\boldsymbol{\theta}) &=  \prod_{i=1}^{60}f(y_{i})\\
   &= \prod_{i=1}^{60} \frac{1}{\sqrt{2\pi \sigma^{2}}}\exp\left\{-\frac{(y_{i}-\mu)^{2}}{2\sigma^{2}}\right\}
   \end{align*}$$

> [!gen] Model 2
> From the second graph, we might think that the mean temperature has changed over the years such that $\mathbb E(Y_{i})=\beta_{0}+\beta_{t}t_{i}$
> - $\boldsymbol{y} = (y_{1},...,y_{60})$.
> - $\boldsymbol{x} = \boldsymbol{t} = (t_{1},...,t_{60})$
> - $\boldsymbol{\theta} = (\beta_{0}, \beta_{t}, \sigma)$.
> 
> We then have $f(y_{i})= \frac{1}{\sqrt{2\pi \sigma^{2}}}\exp\left\{-\frac{[y_{i}-(\beta_{0}+\beta_{t}t_{i})]^{2}}{2\sigma^{2}}\right\}$ and
> $$\begin{align*}
   f(\boldsymbol{y};\boldsymbol{\theta},\boldsymbol{t}) &=  \prod_{i=1}^{60}f(y_{i})\\
   &= \prod_{i=1}^{60} \frac{1}{\sqrt{2\pi \sigma^{2}}}\exp\left\{-\frac{[y_{i}-(\beta_{0}+\beta_{t}t_{i})]^{2}}{2\sigma^{2}}\right\}
   \end{align*}$$
