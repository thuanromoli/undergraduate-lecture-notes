---
tags:
  - MT4509
aliases:
---
> [!def] Definition
> A pole is a solution to [[Laplace's equation]] $\nabla ^{2}\phi=0$.

> [!thm] Monopole (1 potential)
> If there is only a spherically symmetrical potential $\phi=\phi(r)$, then
> $$\phi = - \frac{A}{r}+B \quad \text{and} \quad \boldsymbol{u}=\frac{A}{r^{2}}\boldsymbol{e}_{r}$$

> [!gen] Remarks
> - The volume flux is $$\iint_{S} \boldsymbol{u \cdot n}\;dS = \iint_{S} \frac{A}{r^{2}} \boldsymbol{e}_{r} \cdot \boldsymbol{e}_{r}\;dS =\iint \frac{A}{r^{2}}\;dS$$
> - Consider the surface of a sphere with radius $a$ and centre $r=0$ enclosing the potential $\phi$, then the volume flux across this sphere is $$\frac{A}{a^{2}}\iint_{S}dS = \frac{A}{a^{2}}(4 \pi a^{2})=4 \pi A=m; \quad \text{and so } A=\frac{m}{4 \pi}.$$
> - We say that $\phi = - \frac{m}{4 \pi}\frac{1}{r}$ is the potential of a simple source or sink (monopole) at $r=0$, of strength $m$. (Think of flow radially in to/outwards from the potential).

> [!thm] Multipoles
> It is possible to generate infinitely many potentials, corresponding to different derivatives of $\phi$. The solutions of Laplace's equation of these potentials are called multipoles.

In cartesian coordinates, if $\phi$ is a potential then $\nabla ^{2} \phi=0$ represents
$$\frac{\partial ^{2}\phi}{\partial x^{2}}+\frac{\partial ^{2}\phi}{\partial y^{2}}+\frac{\partial ^{2}\phi}{\partial z^{2}}=0$$
so
$$\frac{\partial }{\partial x}\left(\frac{\partial ^{2}\phi}{\partial x^{2}}+\frac{\partial ^{2}\phi}{\partial y^{2}}+\frac{\partial ^{2}\phi}{\partial z^{2}}\right)=0$$
and
$$\frac{\partial ^{2}}{\partial x^{2}}\left(\frac{\partial \phi}{\partial x}\right)+\frac{\partial ^{2}}{\partial y^{2}}\left(\frac{\partial \phi}{\partial x}\right)+\frac{\partial ^{2}}{\partial z^{2}}\left(\frac{\partial \phi}{\partial x}\right)=0$$
so $\frac{\partial \phi}{\partial x}$ is also a potential flow.
This corresponds to a dipole (a source and a sink close to each other like a magnet).
