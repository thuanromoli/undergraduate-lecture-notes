---
tags:
  - MT3501
type: mthd
aliases:
---
### Eliminating vectors to find a [[Bases|basis]]
Suppose we have a [[Spanning sets|spanning set]] $\mathscr A=\left\{\begin{pmatrix}1  \\ -1 \\ 0 \\ 3\end{pmatrix},\begin{pmatrix}2  \\ 1 \\ 1 \\ 0\end{pmatrix},\begin{pmatrix}0 \\ 3 \\ 1 \\ -6\end{pmatrix},\begin{pmatrix}0 \\ 1 \\ 0 \\ -1\end{pmatrix},\begin{pmatrix}-1 \\ 1 \\ -1 \\ 0\end{pmatrix}\right\}=\set{v_{1},v_{2},v_{3},v_{4},v_{5}}$ and want to find a basis $\mathscr B$.

SOLUTION:
Check for [[Linear independence|linear independence]].
Suppose $\alpha v_{1}+\beta v_{2}+\gamma v_{3}+ \delta v_{4}+ \varepsilon v_{5}=\boldsymbol{0}$.
Then by [[Elementary row operations|e.r.o.s]]:
$$\begin{align*}
\alpha &= 2 \gamma -3 \varepsilon\\
\beta &= -\gamma + \varepsilon\\
\delta &= 0\gamma-3 \varepsilon
\end{align*}$$
Then choose different $\gamma$ and $\varepsilon$ to find $\alpha$, $\beta$, and $\delta$.
If $\gamma=1$ and $\varepsilon=0$ then $\alpha=2$, $\beta=-1$, $\delta=0$.
So $2v_{1}-v_{2}+v_{3}=\boldsymbol{0}$.
If $\gamma=0$ and $\varepsilon=1$ then $\alpha=-1$, $\beta=1$, $\gamma=-3$.
So $-v_{1}+v_{2}-3v_{4}+v_{5}=\boldsymbol{0}$.
Note that in the two equations above $v_{1},v_{2}$ always appear so we write equations in term of them:
$v_{3}=-2v_{1}+v_{2}$ and $v_{5}=v_{1}-2v_{2}+3v_{4}$.
So $v_{3}$ and $v_{5}$ are [[Linear combinations|linear combinations]] of $v_{1},v_{2},v_{4}$.
So $\mathscr B=\set{v_{1},v_{2},v_{4}}$ is a basis.
Check linear independence.

### Extending a linearly independent set to a [[Bases|basis]]
Suppose we have a [[Linear independence|linearly independent]] set $\mathscr A=\left\{\begin{pmatrix}3 \\ 1 \\ 0 \\ 0\end{pmatrix},\begin{pmatrix}1 \\ 0 \\ 3 \\ 4 \\ \end{pmatrix}\right\}=\set{v_{1},v_{2}}$ and want to find a basis $\mathscr B$ for $\mathbb R^{4}$.

SOLUTION:
Start adding standard basis vectors and check it is linear independent.
Check $\set{v_{1},v_{2},e_{1}}$.
If linearly independent next add $e_{2}$. If not linearly independent add $e_{2}$ next.
Proceed until $\dim \mathscr A=4$.

### [[The matrix of a linear transformation]]
To find the matrix $\text{Mat}_{\mathscr B,\mathscr C}(T)$ think about we are going from $\mathscr B$ to $\mathscr C$.
So find $T(j\text{th basis vector in }\mathscr B)=\sum\limits_{i=i}^{n}\alpha_{ij}(\text{basis in }\mathscr C)$.
Then $\text{Mat}(T)=[\alpha_{ij}]$.

### [[Change of basis matrix]]
To find the change of basis matrix $P$ from $\mathscr B$ to $\mathscr C$ think about we are going from $\mathscr B$ to $\mathscr C$.
So find $j \text{th basis vector in } \mathscr C=\sum\limits_{i=i}^{n}\alpha_{ij}(\text{basis in }\mathscr B)$.
Then $P=[\alpha_{ij}]$.
Then $\text{Mat}_{\mathscr C,\mathscr C}=P^{-1}\text{Mat}_{\mathscr B,\mathscr B}P$

### Decompositions
To show that $V=U \oplus W$:
1. Take $v=u+w$ and show it can be expressed as a linear combination of vectors in the basis for $U$ or $W$. Hence $v\in U+W$.
2. Take $v\in U\cap W$. Then $v=\sum\limits_{i=i}^{k}\alpha_{i}u_{i}=\sum\limits_{i=1}^{m}\beta_{i}w_{i} \implies \sum\limits_{i=i}^{k}\alpha_{i}u_{i}-\sum\limits_{i=1}^{m}\beta_{i}w_{i} =0$. But since that is a sum of vectors in the basis and they are linearly independent, $\alpha_{i}=\beta_{i}=0$ for all $i$. So $v=0$.
Then to decompose $v$ into $u$ and $w$ write $v$ as a linear combination of the basis for $U$ and $W$.

### [[Diagonalisability|Diagonalising a matrix or linear transformation]]
To show $T$ is diagonalisable:
1. Find $c_{T}(x)=\det(xI-A)$.
2. If it is a product of linear factors, then $c_{T}(x)=(x-\lambda_{1})^{r_{\lambda_{1}}}(x-\lambda_{2})^{r_{\lambda_{2}}}\cdots(x-\lambda_{n})^{r_{\lambda_{k}}}$. If not then it is not diagonalisable.
3. (Shortcut) $T$ is [[Diagonalisability|diagonalisable]] if and only if the [[Minimum polynomial|minimum polynomial]] $m_{T}(x)=(x-\lambda_{1})(x-\lambda_{2})\cdots(x-\lambda_{n})$ or in other words if and only if $m_{T}(T)=(T-\lambda_{1})(x-\lambda_{2})\cdots(T-\lambda_{n})=0$.
4. Find $m_{T}(x)$ by guessing and using [[Cayley-Hamilton theorem]]:
	1. Guess $m_{T}(x)=(x-\lambda_{1})(x-\lambda_{2})\cdots(x-\lambda_{n})$. Check if $m_{T}(T)=0$.
	2. Guess $m_{T}(x)=(x-\lambda_{1})^{2}(x-\lambda_{2})\cdots(x-\lambda_{n})$. Check if $m_{T}(T)=0$.
	3. Guess $m_{T}(x)=(x-\lambda_{1})(x-\lambda_{2})^{2}\cdots(x-\lambda_{n})$. Check if $m_{T}(T)=0$.
	4. And so on.
5. $T$ is [[Diagonalisability|diagonalisable]] if and only if the [[Minimum polynomial|minimum polynomial]] $m_{T}(x)$ is a product of distinct linear factors.

To diagonalise $T$:
1. Find $c_{T}(x)=\det(xI-A)$.
2. Find [[Eigenvectors and Eigenvalues|eigenvalues]]. Solve $c_{T}(x)=0$
3. Find [[Eigenspaces|eigenspaces]] $E_\lambda=\ker(A-\lambda I)=\set{v\in V:(A-\lambda I)v=\boldsymbol{0}}$. Solve $(A-\lambda I)v=\boldsymbol{0}$.
4. Then there exists a transformation matrix $P$ that goes from standard basis to a basis made of eigenvectors.

### [[Jordan normal form]]
We use the following observations:
1. The [[Algebraic multiplicity|algebraic multiplicity]] of $\lambda$ as an [[Eigenvectors and Eigenvalues|eigenvalue]] of $T$ equals the sum of the sizes of the [[Jordan blocks]] $J_{n}(\lambda)$ occurring in the [[Jordan normal form]] for $T$.
2. If $\lambda$ is an [[Eigenvectors and Eigenvalues|eigenvalue]] of $T$, then the power of $(x-\lambda)$ occurring in the [[Minimum polynomial|minimum polynomial]] $m_{T}(x)$ is $(x-\lambda)^{m}$ where $m$ is the largest size of a Jordan block associated to $\lambda$ occurring in the Jordan normal form for $T$.
3. The [[Geometric multiplicity|geometric multiplicity]] of $\lambda$ as an [[Eigenvectors and Eigenvalues|eigenvalue]] of $T$ equals the number of [[Jordan blocks]] $J_{n}(\lambda)$ occurring in the [[Jordan normal form]] for $T$.

To find the [[Jordan normal form]]:
1. Calculate $c_{T}(x)=\det(xI-A)=(x-\lambda_{1})^{r_{\lambda_{1}}}(x-\lambda_{2})^{r_{\lambda_{2}}}\cdots(x-\lambda_{n})^{r_{\lambda_{k}}}$.
2. Then for $\lambda_{i}$, we can have a combination of $J_{1}(\lambda_{i}),J_{2}(\lambda_{i}),...,J_{r_{\lambda_{i}}}(\lambda_{i})$ such that the sum of the dimensions of the blocks $1,2,...,r_{\lambda_{i}}$ is $r_{\lambda_{i}}$.
3. Find $m_{T}(x)$ by guessing and using [[Cayley-Hamilton theorem]]:
	1. Guess $m_{T}(x)=(x-\lambda_{1})(x-\lambda_{2})\cdots(x-\lambda_{n})$. Check if $m_{T}(T)=0$.
	2. Guess $m_{T}(x)=(x-\lambda_{1})^{2}(x-\lambda_{2})\cdots(x-\lambda_{n})$. Check if $m_{T}(T)=0$.
	3. Guess $m_{T}(x)=(x-\lambda_{1})(x-\lambda_{2})^{2}\cdots(x-\lambda_{n})$. Check if $m_{T}(T)=0$.
	4. And so on.
4. Then for $\lambda_{i}$, suppose $m_{T}(x)=\cdots(x-\lambda_{i})^{m}\cdots$. To choose what combination of $J_{1}(\lambda_{i}),J_{2}(\lambda_{i}),...,J_{r_{\lambda_{i}}}(\lambda_{i})$ to use, we use the fact that we must use $J_{m}(\lambda_{i})$ and there is no larger dimension available.
5. Now we determine the eigenspace of $E_{\lambda_{i}}$. The geometric multiplicity ($\dim E_{\lambda_{i}}$) is the number of Jordan blocks.

To find the basis of the Jordan normal form:
see examples 5.11, 5.12, 5A

### [[Gram-Schmidt process]]

![[Gram-Schmidt process#^ed162b]]

### Finding the distance to a subspace
To find the distance from a vector $v_{0}$ from $V$ to the subspace $U$:
1. Find $U^{\perp}$ by letting $v\in V$ and computing $\langle v,u \rangle$ for all $u\in U$.
2. Then write $v_{0}$ as a decomposition.
3. Apply the projection map onto $U$: $P_{U}(v_{0})$. This is the nearest vector in $U$ to $v_{0}$.
4. Then the distance is ${\Vert v_{0} - P_{U}(v_{0}) \Vert}$.


1. PS5 Q5 (ii), (iii), (v), and (vi), Q7 (i), (iii), (vi)
2. PS6 Q6, Q7, Q8, Q9, Q10, Q11
3. PS7 Q1, Q4 (a), (b)
4. Injective, surjective, bijective, homomorphisms, linear functionals