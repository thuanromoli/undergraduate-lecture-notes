---
tags:
  - MT4554
type: model
aliases:
---
>[!gen] Why are we studying this?
>This game investigates fairness.
>We introduce sequential games and game trees.
>Furthermore we talk about subgame perfection.

>[!def] Definition
>The ultimatum game is a game in which the proposer is given an endowment of value $b$. The game then proceeds in two steps:
>- The proposer decides what proportion of the pot to offer to the responder.
>- The responder decides whether to accept or reject the offer.
>
>If the responder accepts, both players keep their respective share of endowment.
>If the responder rejects, both players receive nothing.
>
>![[ultg_att.png|250]]
>![[ultgt_att.png|300]]

>[!gen] Strategies
>There are two [[Pure strategies|pure strategies]] for player 1: $F$ and $U$
>There are four [[Pure strategies|pure strategies]] for player 2:
>1. Always accept ($s^{1}$)
>2. Always reject ($s^{2}$)
>3. Accept if fair, reject if unfair ($s^{3}$)
>4. Reject if fair, accept if unfair ($s^{4}$)

>[!gen] Solutions
>Regardless whether player 1 plays $F$ or $U$, player 2 is always better off playing $A$ as $\frac{b}{2}>0$ and $(1-p)b>0$.
>But then if player 2 is always better off playing $A$, player 1 will want to play $U$ all the time.
>
>The strategy pairs $(U,s^{1})$ and $(U,s^{4})$ are a [[Nash equilibrium]], since neither payer can gain unilaterally switching.
>
>Now consider this equilibrium $(F,s^{3})$. It is an equilibrium since if the proposer switched, the responder would reject and so the proposer has no incentive to switch.
>Something seems wrong with this equilibrium. Since the proposer moves first, the responder can only make a decision given the game as it is after the proposer has moved.
>
>Only the strategy $(U,s^{1})$ is [[Subgame perfection|subgame perfect]] and this leaves us unsatisfied.

>[!gen] Resolving the Ultimatum game
>Clearly the basic game theoretic result that fairness is not rational doesn't make sense. A common conclusion is that this theory cannot be a good model oh human behaviour.
>
>We need to modify our assumptions: let us assume that the players do not know whether they are the proposer or responder in advance. Let us further assume that their strategy space consists of:
>1. The offer they will make if they are the proposer.
>	- $U_{p}$ is the action of proposing an unfair deal
>	- $F_{p}$ is the action of proposing a fair deal
>2. The minimum offer they will accept if they are the responder.
>	- $U_{r}$ is the action of accepting an unfair offer as their minimum
>	- $F_{r}$ is the action of accepting a fair offer as their minimum
>
>So now each player has the following pure [[Pure strategies|strategy space]]: $S=\set{(U_{p},U_{r}),(U_{p},F_{r}),(F_{p},U_{r}),(F_{p},F_{r})}$.
>
>![[modultgam_att.png|300]]
>
>And finally we observe that fairness $((F_{p},F_{r}),(F_{p},F_{r}))$ is a [[Nash equilibrium]].
