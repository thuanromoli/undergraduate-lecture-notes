---
tags:
  - MT4531
aliases:
---
We discard until we reach the stationary distribution. How do we know when we reach a stationary distribution?
Use trace plots with different starting points and see when they start overlapping.
![[traceplot_att.png|300]]
We can do this visually or use the BGR Method (based on ANOVA).
![[bgr_att.png|400]]
Important to start in very diffused starting point as there might be a multimodal distribution. Picking starting values close to each other will lead to convergence to the same mode.
![[multimodal_att.png]]
