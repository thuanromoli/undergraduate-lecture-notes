---
tags:
  - MT4551
aliases:
  - risk-free
---
> [!def] Definition
> These are assets that grow at a risk-free [[Interest rates|interest rate]] (set by a governing authority).
> We consider two types of risk-free assets:
> 1. Short term bank accounts, $r$ set by Bank of england.
> 2. Long term government [[Bonds|bonds]], $r$ set by the yield on bonds.

> [!thm] Theorem
> There are two rules:
> 1. Over any fixed period of time all risk-free assets must carry the same [[Interest rates|interest rate]] to avoid [[Arbitrage|arbitrage]].
> 2. In determining future and discounted values of money, the risk free interest rate is always used.

(See examples on slides)
