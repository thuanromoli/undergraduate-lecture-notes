---
tags:
  - MT3504
type: mthd
aliases:
  - Wronskian
---
Let $y_{1}$ and $y_{2}$ be [[General solution of Second-Order ODEs|general solutions of a second-order ODE]]

>[!thm] If there exists a constant $C\neq 0$ such that $y_{1} = Cy_{2}$ or vice-versa (that is, they are scalar multiples of each other), then $y_{1}$ and $y_{2}$ are [[Linear independence|linearly dependent]].
>To show [[linear independence]], either show that $y_{1}$ and $y_{2}$ are not scalar multiples of each other or $C$ is not constant.
>
>Proof:
>[[Theorems about linear independence#^0715f1|By this theorem]], $y_{1}$ and $y_{2}$ are [[Linear independence|linearly dependent]] if and only if they can be expressed as a [[Linear combinations|linear combination]].

>[!def] Definition
>The Wronskian of $y_{1}$ and $y_{2}$ is defined by
>$$W[y_{1},y_{2}]=\det \begin{pmatrix}
   y_{1} & y_{2} \\
   y'_{1} & y'_{2}
   \end{pmatrix}$$

>[!thm] If $y_{1}$ and $y_{2}$ are [[Linear independence|linearly dependent]] then $W[y_{1},y_{2}]=0$.
>To show [[linear independence]] use the contrapositive: if $W\neq 0$ then $y_{1},y_{2}$ are [[Linear independence|linearly independent]].
>
>Proof:
>If $y_{1}$ and $y_{2}$ are [[Linear independence|linearly dependent]] then $y_{1}=Cy_{2}$ and $y'_{1}=Cy'_{2}$ by the above theorem.
>Hence $W[y_{1},y_{2}]$ = $W[Cy_{2},y_{2}]$ = $\det \pmatrix{Cy_{2} & y_{2} \\Cy'_{2} & y'_{2}}$ = $Cy_{2}y'_{2}-Cy'_{2}y_{2}=0$.
