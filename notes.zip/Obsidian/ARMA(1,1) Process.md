---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is called an autoregressive moving average process of order $(1,1)$ if it is [[Stationarity|weakly stationary]] and there exists a [[White noise|white noise]] $(\varepsilon_{t})_{t \in \mathbb Z}$ and real numbers $\phi,\theta \in \mathbb R$ with $\phi+ \theta\neq 0$ such that for all $t \in \mathbb Z$,
> $$X_{t}= \phi X_{t-1}+\varepsilon_{t}+\theta \varepsilon_{t-1}.$$
> 
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is an autoregressive moving average process of order $(1,1)$ with mean $\mu$ if $X_{t}-\mu$ is an ARMA(1,1) process.

> [!thm] Properties (under certain [[Stationarity of AR(p) Processes|regularity conditions]])
> - $$\gamma_X (h) = \left\{ \begin{array}{ll}
   \sigma^{2}_\varepsilon \frac{1 + 2 \phi \theta+ \theta^{2}}{1-\phi^{2}} & \quad h=0 \\
   \sigma^{2}_\varepsilon \frac{(1+\phi \theta)(\phi+ \theta)}{1-\phi^{2}} & \quad h=1 \\
   \phi^{h-1} \gamma_{X}(1) & \quad h \geqslant 2.
\end{array} \right.$$
> - $$\rho_{X}(h) = \left\{ \begin{array}{ll}
   1 & \quad h=0 \\
   \frac{(1+\phi \theta)(\phi+\theta)}{1+2 \phi \theta + \theta^{2}} & \quad h=1 \\
   \phi^{h-1} \rho_{X}(1) & \quad h \geqslant 2.
\end{array} \right.$$

> [!gen] Remarks
> - The requirement $\phi+\theta\neq 0$ ensures that the process is written in its simplest form.
> - If $|\phi|<1$, we can find a [[Causality|causal]], [[Stationarity|weakly stationary]] process.
> - If $|\theta| <1$, the process is [[Invertibility|invertible]] with respect to $(\varepsilon_{t})_{t \in \mathbb Z}$.
> - Both ACVF and ACF decay exponentially in absolute value and do not vanish.

![[arma11a_att.png]]
![[arma11b_att.png]]