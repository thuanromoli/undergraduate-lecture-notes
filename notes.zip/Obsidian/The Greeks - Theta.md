---
tags:
  - MT4551
aliases:
---
> [!def] Definition
> The theta is defined as
> $$\theta = \frac{\partial V}{\partial t}$$
> and it measures the time decay of the option ($\theta$ large $\to$ frequent adjustment required).

> [!gen] Remarks
> - For a European Call (long position), $\theta = - \frac{SN'(d_{1})\sigma}{2 \sqrt{T-t}}-rEe^{-r(T-t)}N(d_{2})$.
