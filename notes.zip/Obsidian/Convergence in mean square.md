---
tags:
  - MT4527
aliases:
---
Let $(Y_{n})_{n \in \mathbb Z}$ be a [[Sequences|sequence]] of [[Random variables|random variables]].

> [!def] Definition
> The sequence $(Y_{n})_{n \in \mathbb Z}$ converges in mean square to a random variable $Z$ if
> $$\lim\limits_{n \to \infty} \mathbb E\Big[(Y_{n} -Z)^{2}\Big] = 0.$$

Let $Y_{0},Y_{1},...$ be an infinite sequence of random variables and let $b_{0},b_{1},...$ be an infinite sequence of constants.

> [!thm] Theorem
> Suppose that there exists a finite constant $C$ such that $\mathbb E(Y_{t}^{2}) \leqslant C$ for all $t$ and that $\sum\limits_{i=0}^{\infty}|b_{i}| < \infty$.
> Then, for each $t$, the infinite linear sum
> $$\sum\limits_{i=0}^{\infty}b_{i}Y_{t-i}$$
> converges in mean square to a random variable $X_{t}$.
