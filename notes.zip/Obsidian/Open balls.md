---
tags:
  - MT3503
  - MT3502
aliases:
  - open ball
---
#### For real analysis:
Let $(X,d)$ be a [[Metric spaces|metric space]] or let $(X, {\Vert \cdot \Vert})$ be a [[Normed spaces|normed space]].

> [!def] Definition
> The open ball of centre $x \in X$ and radius $r>0$ is
> $$\begin{align*}
   B(x,r,d) &= \set{y \in X:d(x,y)<r}\\
   B(x,r, {\Vert \cdot \Vert}) &= \set{y \in X: {\Vert x-y \Vert}<r}\\
   \end{align*}$$

> [!thm]- Any open ball is [[Open sets|open]]
> Given $x \in X$ and $r>0$, consider $B(x,r)$.
> Let $y \in B(x,r)$, we want to show that there exists some $r'>0$ such that $B(y,r')\subseteq B(x,r)$.
> We pick $r' = r-d(x,y)$, i.e. the distance from the edge of the ball to $y$.
> Then $d(x,y)<r$, so $r'>0$.
> Now if $z \in B(y,r')$ then $z \in B(x,r)$ since
> $$d(x,z) \leqslant d(x,y)+d(y,z) < d(x,y)+ r'=d(x,y)+r-d(x,y )=r.$$
> This implies that $B(y,r') \subseteq B(x,r)$.

#### For complex analysis:
Let $w \in \mathbb C$ and $r \in \mathbb R:r>0$.

> [!def] Definition
> The open ball (or open disk) of radius $r$ about $w$ is 
> $$B(w,r) = \set{z \in \mathbb C : |z-w| < r}.$$

> [!thm]- The open ball $B(w,r)$ is an [[Open sets|open set]]

![[openball_att.png]]
$B(w,r)$ is the set of all points inside (and not including) the circumference.