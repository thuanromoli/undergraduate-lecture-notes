---
type: mthd
tag: MT2505
---
INPUT: Two integers $a$ and $b$ with $a \geqslant b > 0$
OUTPUT: The greatest common divisor $\gcd(a,b)$
METHOD:
- Step 1:
	1. Define $a_1=a$ and $b_1=b$.
	2. Divide $a_{1}$ by $b_1$ and find quotient and remainder: $$a_1=q_1b_1+r_1$$where $0 \leqslant r_{1}<b_{1}$.
-  Step $n$:
	1. Define $a_{n}= b_{n-1}$ and $b_{n}=r_{n-1}$ arising from the previous step.
	2. Divide $a_{n}$ by $b_{n}$ and find quotient and remainder: $$a_n=q_nb_n+r_n$$where $0 \leqslant r_{n}<b_{n}$.
- Repeat until $r_{k}=0$.
- The last non-zero reminder $r_{k-1}$ is $\gcd(a,b)$.
