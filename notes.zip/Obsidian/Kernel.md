---
type: def
tags:
  - MT2505
  - MT3501
  - MT4003
aliases:
  - kernel
---
#### For group theory:
Let $\phi: G \to H$ be a [[Homomorphisms|homomorphism]] from a [[Groups|group]] $G$ to a [[Groups|group]] $H$.

>[!def] Definition
>The kernel of $\phi$ is the set of elements of $G$ that are mapped to the [[Identity element|identity element]] of $H$: $$\ker\phi=\set{x\in G : x \phi= 1_{H}}$$

#### For linear algebra:
Let $T : V \to W$ be a [[Linear transformations|linear transformation]] between [[Vector spaces|vector spaces]] $V$ and $W$ over the [[Fields (Algebra)|field]] $F$.

>[!def] Linear Algebra
>The kernel of $T$ is the set of elements of $V$ that are mapped to the zero vector of $W$: $$\ker T=\set{v\in V: T(v) = \boldsymbol{0}}$$
