---
tags:
  - MT4528
type: 
aliases:
  - HMM
---
>[!def] Definition
>An $N$-state HMM is a doubly stochastic process $\set{(X_{t},S_{t}:t=1,2,3,...}$, where
>- conditional on the current state, each observation is independent of all past observations and states, i.e. the following holds:
>  $$f(x_{t}|x_{1},...,x_{t-1},s_{1},...,s_{t})=f(x_{t}|s_{t})$$
>- the (hidden) process $\set{S_{t}:t=1,2,3,...}$ is a discrete-time [[Markov chains and processes|Markov chain]] with $N$ states, i.e. the following holds
>  $$f(s_{t}|s_{1},...,s_{t-1})=f(s_{t}|s_{t-1})$$
>
>Here $f$ is used as a general notation indicating either a probability or a density. For example, $f(s_{t}|s_{t-1})=\mathbb P(S_{t}=s_{t}|S_{t-1}=s_{t-1})$ (the [[One-step transition probabilities|one-step transition probability]]).

>[!gen] Two interpretations of HHMs
>1. If primarily the states are of interest, then the observations of the state dependent process can be regarded as indirect, noisy observations of the states, and the purpose of HMMs id to decode the hidden state sequence based on the observations of the state-dependent process.
>2. If primarily the observations of the state-dependent process are of interest, then the states are regarded as nuisance parameters, which are of no interest in themselves but are required, for example, to provide accurate forecasts.
