---
tags:
  - MT4554
type: def
aliases:
---
>[!def] Definition
>A population is stable against invasion if an initially rare mutant is not favoured to spread by natural selection, where
>- "mutant" means some non-resident strategy.
>- "natural selection" means some process of copy or replication.
