---
type: thm
tags:
  - MT2505
  - MT4003
---
Let $G = \langle x \rangle$ be a [[Cyclic groups|cyclic]] [[Groups|group]].

> [!thm]- $G$ is [[Abelian groups|abelian]]
> Let $g,h\in G$. Then $g = x^{m}$ and $h = x^{n}$ for some $m,n \in \mathbb Z$.
> Now, $gh = x^{m}x^{n}=x^{m+n}=x^{n}x^{m}=hg$.

> [!thm]- Let $G$ be infinite. Then $G$ is [[Isomorphisms|isomorphic]] to the additive group $\mathbb Z$
> If $G = \langle x \rangle$ and $|x|= \infty$ then the powers of $x$ all distinct.
> We define a map $\phi: \mathbb Z \to G$ by $n \phi = x^{n}$ and observe that it is a bijection.
> Now $(m+n) \phi= x^{m+n} = x^{m}x^{n} = m \phi \cdot n \phi$ for all $m,n \in \mathbb Z$.
> Hence $\phi$ is an isomorphism and $G \cong \mathbb Z$.

> [!thm]- Let $G$ be of [[Order|order]] $n$. Then $G$ is [[Isomorphisms|isomorphic]] to the additive group $\mathbb Z_{n}$
> Let $G = \langle x \rangle = \set{1,x,x^{2},...,x^{n-1}}$ and define a map $\phi: \mathbb Z_{n} \to G$ by $i \phi=x^{i}$.
> Then $\phi$ is a bijection since $G$ and $\mathbb Z_{n}$ have the same size and they are clearly onto.
> As $|x| = n$, if $i+j \equiv r \mod n$, then  $(i+j)\phi= r \phi = x^{r}=x^{i+j}= x^{i}x^{j}=i \phi \cdot j \phi$.
> Hence $\phi$ is an isomorphism and $G \cong \mathbb Z_{n}$.

> [!thm]- Let $G$ be of order $p$ prime. Up to isomorphism, there is exactly one group of oder $p$
> If $G$ is a group of order $p$, then $G$ is [[Cyclic groups|cyclic]] by [[Lagrange's Theorem#^816d54|this theorem]], so by the above $G \cong \mathbb Z_{p}$

^ec5cdd

> [!thm]- Let $G$ be finite. Every subgroup of $G$ is cyclic.
> Let $H$ be a [[Subgroups|subgroup]] of $G$. Then $H$ consists of some powers of $x$ and $1 = x^{n} \in H$. We can therefore take $m$ to be the smallest positive integer such that $x^{m} \in H$. Then [[Theorems about generating sets#^3f5566|by this theorem]], $\langle x^{m} \rangle \leqslant H$.
> Now we claim that $H \leqslant \langle x^{m} \rangle$.
> Let $h\in H$ then $h = x^{i}$ for some $i$.
> Divide $i$ by $m$ to obtain a quotient and a reminder $i = qm +r$ where $0 \leqslant r < m$.
> Then $x^{i}= x^{qm}x^{r} \implies x^{r}=x^{i}x^{-qm}=x^{i}(x^{m})^{-q}\in H$ since $x^{i},x^{m}\in H$.
> The minimality of $m$ and the condition $r<m$ forces $r=0$.
> So $x^{i}=x^{qm}=(x^{m})^{q}\in \langle x^{m} \rangle$.
> Hence $H = \langle x^{m} \rangle$.

> [!thm]- Let $G$ be of order $n$. For each divisor $d$ of $n$, then $G$ has a unique subgroup of order $d$, namely $\langle x^{n/d} \rangle$
> We start by proving the existence of such group.
> Write $n = dk$ for some $k \in \mathbb Z$.
> Then $\langle x^{\frac{n}{d}} \rangle = \langle x^{k} \rangle = \langle x^{k},x^{2k},...,x^{dk}=x^{n}=1 \rangle$, a subgroup of order $d$.
> Now for uniqueness we let $H$ be a subgroup of $G$ of order $d$.
> Then as in the above theorem, $H = \langle x^{m} \rangle$ for some minimum positive value of $m$, and the minimality of $m$ implies that when dividing $n$ by $m$ to obtain a quotient and a reminder, $n = qm+r$, we force $r = 0$ and so $n=qm$.
> The elements of $H$ are therefore $x^{m},x^{2m},...,(x^{m})^{q}=(x^{m})^{n/m}=x^{n}=1$.
> And $|x^{m}|=n/m=d$, so $m=n/d=k$ and $H = \langle x^{n/d} \rangle$.

^922674

> [!thm]- Let $G$ be infinite. Then every non-trivial subgroup of $G$ has the form $\langle x^{m} \rangle$, for some $m \in \mathbb Z_{>0}$, and this is the unique subgroup of $G$ of index $m$
> 
