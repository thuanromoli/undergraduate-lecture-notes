---
type: def
tag: MT2505
alias: ring
---
>[!def] Definition
>A ring is a set $R$ together with two [[binary operations]]
>$$R \times R \rightarrow R \ \ \ \ \text{ and }\ \ \ \ R \times R \rightarrow R$$
>$$(a,b) \mapsto a + b \ \ \ \ \text{ and }\ \ \ \ (a,b) \mapsto ab$$
>such that the following conditions all hold:
>$\text{A1: } a+b=b+a \ \ \forall a,b \in R$
>$\text{A2: }(a+b)+c=a+(b+c) \ \ \forall a,b,c \in R$
>$\text{A3: } \exists \text{ some }0 \in R \ \text{ s.t } \ 0+a=a+0=a \ \ \forall a\in R$
>$\text{A4: } \forall a \in R, \ \exists \text{ some} -a \in R \ \text{ s.t } \ a+(-a)=(-a)+a=0$
>$\text{M2: } (ab)c=a(bc) \ \ \forall a,b,c \in R$
>$\text{D: }a(b+c)=ab+ac \ \text{ and } \ (a+b)c =ac+bc \ \ \forall a,b,c \in R$ 
