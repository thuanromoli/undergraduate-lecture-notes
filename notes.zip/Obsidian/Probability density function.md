---
alias:
  - pdf
  - PDF
type: def
tag: MT2504
---
Let $Y$ denote a continuous [[Random variables|rv]] that can take values in the range $[a,b]$.

>[!def] Definition
>The probability density [[Functions|function]] for $Y$ is the [[Functions|function]] $f(y)$ such that:
>$$\mathbb{P}(a \leqslant Y \leqslant b)=\int_{a}^{b}f(y)\ \text{d}y $$

>[!gen]+ PROPERTIES:
>1. $\mathbb{P}(Y \leqslant y)=\int_{-\infty}^{y}f(u)\ \text{d}u$ for $u\in \mathbb{R}$;
>2. $\int_{-\infty}^{\infty}f(y)\ \text{d}y=1$.
