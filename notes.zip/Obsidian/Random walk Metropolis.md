---
tags:
  - MT4531
aliases:
---
> [!thm] Theorem
> Suppose that the candidate generating function is a symmetric function, i.e.
> $$q(\boldsymbol{\phi}|\boldsymbol{\theta}) = q(\boldsymbol{\theta} -
\boldsymbol{\phi}) = q(\boldsymbol{\phi} - \boldsymbol{\theta}) =
q(\boldsymbol{\theta}|\boldsymbol{\phi}).$$
> Then, the acceptance function reduces to
> $$\alpha(\boldsymbol{\theta},\boldsymbol{\phi}) = \min \left ( 1 ,
\frac{\pi(\boldsymbol{\phi})}{\pi(\boldsymbol{\theta})} \right ).$$
> 
> Furthermore, the transition kernel is a random walk, since the candidate observation is of the form $\boldsymbol{\phi}=\boldsymbol{\theta}^{t}+\boldsymbol{z}$ where $\boldsymbol{z}\sim f$, where $f$ is symmetrical about zero.
