---
type: def
tag: MT2505
alias: [inverse element,inverse]
---
Let $A$ be a set and $*$ be a [[Binary operations|binary operation]] on $A$.

>[!def] Definition
>If there is an [[Identity element|identity element]] $e$, an inverse for $a\in A$ is an element $b\in A$ such that: $a*b=b*a = e$.
