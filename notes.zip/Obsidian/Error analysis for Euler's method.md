---
tags: MT2507
type: thm
alias:
- 
---
Suppose the exact solution to the system $\frac{dx}{dt}=f(t,x)$ is $x(t)$.
Let us expand this using the [[Taylor's Theorem|Taylor expansion]] $$x(t)=x(t_{0})+\left(\frac{dx}{dt}\right)_{t_{0}}(t-t_{0})+\left(\frac{d^{2}x}{dt^{2}}\right)_{t_{0}}\frac{(t-t_{0})^{2}}{2}+\ldots$$
and evaluating at $t=t_{1}$ and use $t_{1}=t_{0}+h \implies t_{1}-t_{0}=h$ and $\frac{dx}{dt}=f(t,x)$:
$$x(t_{1})=x_{0}+hf(t_{0},x_{0})+ \frac{h^{2}}{2} \left(\frac{df}{dt}\right)_{t_{0}}+\frac{h^{3}}{6} \left(\frac{d^{2}f}{dt^{2}}\right)_{t_{0}}+\ldots$$
We now wish to compare [[Euler's method]] solution to the above expression:
$$x(t_{1})=x_{0}+hf(t_{0},x_{0})$$
and we can see that it agrees for the first two terms.
Hence the error is of order $h^{2}$.

---

#### Spaced repetition
