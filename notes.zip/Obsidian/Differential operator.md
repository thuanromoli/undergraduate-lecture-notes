---
tags:
  - MT3504
type: def
aliases:
---
>[!def] Definition
>A general linear differential operator is one of the form
>$$L = a_{n}(x) \frac{d^{n}}{dx^{n}} + \ldots + a_{2}(x) \frac{d^{2}}{dx^{2}}+ a_{1}(x) \frac{d}{dx} +a_{0}(x)$$
>This is an operator on the space of $n$-[[Differentiability|differentiable]] functions on an interval $[a,b]$ (or the interval might be the entire real line).
>If $a_{n}(x)$ is non-zero on $[a,b]$ then the operator is regular, otherwise is singular.

For our second-order ODEs, we have $L[y] = a_{2}(x) \frac{d^{2}y}{dx^{2}}+ a_{1}(x) \frac{dy}{dx} +a_{0}(x)y$ for $y\in C^{2}[a,b]$.
