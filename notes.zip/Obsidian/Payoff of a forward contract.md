---
tags:
  - MT4551
aliases:
---
Let $E$ be the strike price, $T$ be the strike date, and $S(t)$ the spot price.

> [!def] Definition
> The payoff of a [[Forward contracts|forward contract]] is defined as
> $$\text{Payoff}=\begin{cases}
   S(T)-E=S(T)-S(0)e^{rT} & \text{for the long position} \\
   E-S(T)=S(0)e^{rT}-S(T) & \text{for the short position}
   \end{cases}$$
> with the following remarks:
> 1. Payoff is only realised at the strike date.
> 2. It consists of a [[Two-strategy, two-player, zero-sum games|zero sum game]].
> 
> ![[fcpayoff_att.png|300]]
