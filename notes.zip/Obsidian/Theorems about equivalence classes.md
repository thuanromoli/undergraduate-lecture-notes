---
type: thm
tag: MT2505
---
Let $\sim$ be an [[Equivalence relations|equivalence relation]] on a set $A$ and $[a],[b]$ be its [[Equivalence classes|equivalence classes]].

>[!thm]- $a\in [a] \;\;\forall a \in A$
Let $a\in A$ and consider $[a]=\set{b: a\sim b}$.
Since $\sim$ is an equivalence relation, $\sim$ is reflexive and $a\sim a$ hence $a\in [a]$.

>[!thm]- $A$ is the union of all equivalence classes of $\sim$
Every element of $A$ lies in at least one equivalence class by above.
Hence $A$ is the union of all equivalence classes.

>[!thm]- If $a,b \in A$, then either $[a]=[b]$ or $[a] \cap [b] = \varnothing$
Let $a,b \in A$ and suppose $[a] \cap [b] \neq \varnothing$.
Then there is at least one element, say $c$, belonging to both $[a]$ and $[b]$.
Then $a\sim c$ and $b \sim c$ by definition
Using symmetry $a\sim c$ and $c\sim b$
Using transitivity $a\sim b$ and by symmetry $b\sim a$
>- Claim 1: Every element of $[a]$ is in $[b]$. In other words $[a] \subseteq [b]$.
Let $x\in [a]$ be arbitrary. Then $a\sim x$ and since $b\sim a$, by transitivity, $b\sim x$.
Hence $x \in[b]$.
This shows that $[a] \subseteq [b]$
>- Claim 2: Every element of $[b]$ is in $[a]$. In other words $[b] \subseteq [a]$.
Let $y\in [b]$ be arbitrary. Then $b\sim y$ and since $a\sim b$, by transitivity, $a\sim y$.
Hence $y \in[a]$.
This shows that $[b] \subseteq [a]$
>
>In conlusion we showed that if $[a] \cap [b] \neq \varnothing$ then $[a]=[b]$

>[!thm]- $A$ is the disjoin union of the equivalence classes of $\sim$
We know from above that
>1. $A$ is the union of all equivalence classes of $\sim$
>2. If $a,b \in A$, then either $[a]=[b]$ or $[a] \cap [b] = \varnothing$

>[!thm]- $[a]=[b] \iff a\sim b$
>- RTP: $[a]=[b] \implies a\sim b$
If $[a]=[b]$ then $b\in [b]=[a]$ by above theorem.
Hence $a\sim b$
>- RTP: $a\sim b \implies [a]=[b]$
If $a\sim b$ then $b\in [a]$ and also $b\in [b]$.
Hence $b\in [a] \cap [b]$.
By the above theorem, since $[a] \cap [b] \neq \varnothing$ then $[a]=[b]$

>[!thm]- $[a]\cap [b] = \varnothing \iff a\not\sim b$
>- RTP: $[a]\cap [b] = \varnothing \implies a\not\sim b$
By the above therem, since $[a] \cap [b] =\varnothing$ then $[a]\neq[b]$
And by the contrapositive of the above thorem, $[a]\neq[b] \implies a\not\sim b$
>- RTP: $a\not\sim b \implies [a]\cap [b] = \varnothing$
By the contrapositive of the above thorem, $a\not\sim b \implies [a]\neq[b]$
By the above theorem, since $[a]\neq[b]$ then $[a] \cap [b] =\varnothing$
