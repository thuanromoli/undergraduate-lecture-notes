---
type: def
tag: MT2506
---
>[!def] Definition
>The circulation is the [[Line integral of a vector field|line integral]]
>$$\oint_{C}\boldsymbol F \cdot \text{d} \boldsymbol r$$and it is used to define the [[Curl|curl]]:
>$$\lim_{A\to0}\frac{1}{A} \oint_{C}\boldsymbol F \cdot \text{d} \boldsymbol r$$

PROOF:
	Let $S$ be an infinitesimally small surface $f(\boldsymbol{x}): x = \text{constant}$ with area $A = \ \text{d}y \ \text{d}x$ and [[Boundedness|bounded]] by a closed curve $C$.
	1. By [[Stokes' Theorem]]: $\iint_S(\boldsymbol\nabla\times\boldsymbol F)\boldsymbol \cdot \text{d}\boldsymbol S=\oint_{C}\boldsymbol F \cdot \text{d} \boldsymbol r$
	2. $(\boldsymbol\nabla\times\boldsymbol F)\boldsymbol \cdot \boldsymbol iA=\oint_{C}\boldsymbol F \cdot \text{d} \boldsymbol r$
	3. $(\boldsymbol\nabla\times\boldsymbol F)\boldsymbol \cdot \boldsymbol i=\frac{1}{A} \oint_{C}\boldsymbol F \cdot \text{d} \boldsymbol r$
