---
tags:
  - MT3503
aliases:
  - continuous
  - uniformly continuous
---
#### For real analysis in any [[Metric spaces|metric]] or [[Normed spaces|normed]] space
Let $(X,d)$ and $(Y,d')$ be [[Metric spaces|metric spaces]] and $f: X \to Y$ be a [[Functions|function]].

> [!def] Epsilon-Delta definition
> $f$ is continuous at a point $c \in X$ if
> $$\forall \varepsilon>0\;\;\exists \delta>0 \;\;\text{s.t}\;\;\forall x \in X, \;\; d(x,c) \leqslant \delta \implies d'(f(x),f(c))\leqslant \varepsilon.$$

> [!def] Sequential definition
> $f$ is continuous at a point $c \in X$ if
> $\forall$ [[Sequences|sequences]] $(x_{n})_{n}$ in $X$ where $x_{n}\to c$ in $d$, we also have $f(x_{n}) \to f(c)$ in $d'$.

> [!def] Uniformly continuous definition
> $f$ is uniformly continuous if
> $$\forall \varepsilon>0\;\;\exists \delta>0 \;\;\text{s.t}\;\;\forall c \in X,\forall x \in X, \;\; d(x,c) \leqslant \delta \implies d'(f(x),f(c))\leqslant \varepsilon.$$
#### For complex analysis:
Let $U$ be an [[Open sets|open subset]] of $\mathbb C$ and $f:U \to \mathbb C$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] defined on $U$.

> [!def] Definition
> $f$ is continuous at a point $c \in U$ if
> $$\lim\limits_{z \to c} f(z) = f(c).$$

#### For real analysis in the metric $(\mathbb R,|\cdot |)$
Let $A \subseteq \mathbb R$ and $f: A \to \mathbb R$ be a [[Functions|function]] on $A$.

> [!def] Limit definition
> $f$ is continuous at a point $x_{0} \in A$ if
> 1. $f(x_{0})$ is defined.
> 2. $\lim\limits_{x \to x_{0}}f(x)$ exists.
> 3. $f(x_{0}) = \lim\limits_{x \to x_{0}}f(x)$.

> [!def] Epsilon-Delta definition
> $f$ is continuous at a point $x_{0} \in A$ if
> $$\forall \varepsilon>0\;\;\exists \delta>0 \;\;\text{s.t}\;\;\forall x \in A, \;\;|x-x_{0}| \leqslant \delta \implies |f(x)-f(x_{0})| \leqslant \varepsilon.$$

> [!def] Sequential definition
> $f$ is continuous at a point $x_{0} \in A$ if
> $\forall$ [[Sequences|sequences]] $(x_{n})_{n} \subset A$ s.t $x_{n}\to x_{0}$, we have $f(x_{n}) \to f(x_{0})$.
