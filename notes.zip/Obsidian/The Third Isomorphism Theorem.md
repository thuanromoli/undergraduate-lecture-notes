---
tags:
  - MT4003
aliases:
  - the third isomorphism theorem
---
Let $G$ be a [[Groups|group]], and $H,K$ be [[Normal subgroups|normal]] [[Subgroups|subgroups]] of $G$ with $K \leqslant H \leqslant G$.

>[!thm] Theorem
>The Third Isomorphism Theorem states that $H/K$ is normal in $G/K$ and
> $$\frac{G/K}{H/K} \cong \frac{G}{H}$$

Proof:
Define a map
$$\begin{align*}
\phi:  G/ K &\to G/H\\
Kx & \mapsto Hx.
\end{align*}$$
Since the definition of $\phi$ depend on the choice of the representative $x$, we must verify that $\phi$ is well-defined, then we show it's a [[Homomorphisms|homomorphism]] and we apply [[The First Isomorphism Theorem|the first isomorphism theorem]] by finding the [[Kernel|kernel]] and [[Image|image]] of $\phi$.

$\phi$ is well-defined.
We want to show that $Kx = Ky \implies (Kx)\phi=(Ky )\phi$.
$$\begin{align*}
Kx = Ky &\implies xy^{-1}\in K \leqslant H\\
& \implies Hx = Hy\\
& \implies (Kx) \phi = (Ky) \phi
\end{align*}$$

$\phi$ is a homomorphism.
$$((Kx)(Ky))\phi=(K(xy)) \phi = H(xy) = (Hx)(Hy)=(Kx)\phi\cdot(Ky)\phi$$

The kernel of $\phi$.
$$\begin{align*}
\ker \phi&= \set{Kx \in G/K:(Kx)\phi=H1}\\
&= \set{Kx \in G/K : Hx=H}\\
&= \set{Kx \in G/K: x\in H}\\
&= H/K \mathrel{\unlhd} G/K
\end{align*}$$
last step by [[Theorems about the kernel and the image#^b80cab|this theorem]].

The image of $\phi$.
$$\begin{align*}
\text{im } \phi &= \set{(Kx)\phi:Kx \in G/K}\\
&= \set{Hx : x\in G}\\
&=  G/H.
\end{align*}$$

And now finally using the first isomorphism theorem,
$$\frac{G/K}{H/K} = \frac{G/K}{\ker \phi} \cong \text{im } \phi = G/H.$$