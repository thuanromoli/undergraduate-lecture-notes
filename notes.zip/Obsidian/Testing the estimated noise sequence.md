---
tags:
  - MT4527
aliases:
---
> [!gen] Motivation
> We transform the data to obtain a series with
> - no deviations from stationarity,
> - no apparent trend,
> - no apparent seasonality.
> 
> Next, we model the estimated noise sequence.
> If the residuals are independent then we just estimate their mean and variance.
> However, we do wish for dependence as we can use past information to make forecasts, in which case a more complicated model needs to be used.

> [!gen] Relevant tests
> - [[ACF independence test]]
> - [[Portmanteau and Ljung-Box test]]
> - [[Jarque-Bera test]]
