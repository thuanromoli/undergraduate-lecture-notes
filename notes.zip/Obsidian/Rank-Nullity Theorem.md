---
tags:
  - MT3501
type: def
aliases:
---
Let $T:V \to W$ be a [[Linear transformations|linear transformation]] between two [[Vector spaces|vector spaces]] over the [[Fields (Algebra)|field]] $F$ where $V$ is [[Dimension|finite-dimensional]].

>[!thm] Rank-Nullity Theorem
>$$\text{rank }T + \text{null }T=\dim V$$
>Remarks: This can be viewed as an analogue of [[The First Isomorphism Theorem]] in the world of vector spaces.

Proof:
	Let $\mathscr B=\set{v_{1},...,v_{n}}$ be a [[Bases|basis]] for $\ker T$ such that $\text{null }T=n$ and extend this ([[Theorems about dimension#^63394b|by this theorem]]) to a basis $\mathscr C=\set{v_{1},...,v_{n},v_{n+1},...,v_{n+k}}$ for $V$ such that $\dim V= n+k$.
	We now seek to find a basis for $\text{im }T$.
	If $w\in \text{im }T$, then $w=T(v)$ for some $v\in V$. We can write $v$ as a [[Linear combinations|linear combination]] of the vectors in the basis $\mathscr C$, say $v=\sum\limits_{i=1}^{n+k}\alpha_{i}v_{i}$.
	Then, applying $T$ and using linearity, $w=T(v)$ = $T\left(\sum\limits_{i=1}^{n+k}\alpha_{i}v_{i}\right)$ = $\sum\limits_{i=1}^{n+k}\alpha_{i}T(v_{i})$ = $\sum\limits_{i=1}^{n}\alpha_{i}T(v_{i}) +\sum\limits_{j=1}^{k}\alpha_{n+j}T(v_{n+j})$ = $\sum\limits_{j=1}^{k}\alpha_{n+j}T(v_{n+j})$ since $T(v_{1})=\ldots=T(v_{n})=\boldsymbol{0}$ as $v_{1},...,v_{n}\in \ker T$.
	This shows that the set $\mathscr D=\set{T(v_{n+1}),...,T(v_{n+k})}$ spans $\text{im }T$.
	Now suppose that $\sum\limits_{j=1}^{k}\beta_{j}T(v_{n+j})= \boldsymbol{0}$, that is $T\left(\sum\limits_{j=1}^{k}\beta_{j}v_{n+j}\right)= \boldsymbol{0}$.
	Hence $\sum\limits_{j=1}^{k}\beta_{j}v_{n+j} \in\ker T$, so as $\mathscr B=\set{v_{1},...,v_{n}}$ is a basis for $\ker T$, we have $\sum\limits_{j=1}^{k}\beta_{j}v_{n+j}=\sum\limits_{i=1}^{n}\gamma_{i}v_{i}$.
	We now have an expression $(-\gamma_{1})v_{1}+\ldots +(- \gamma_{n})v_{n}+\beta_{1}v_{n+1}+\ldots +\beta_{k}v_{n+k}=\boldsymbol{0}$ involving the vectors in the basis $\mathscr C$ for $V$.
	Since $\mathscr C$ is [[Linear independence|linearly independent]], we conclude all the coefficients occurring here are the zero.
	In particular, $\beta_{1}=\ldots=\beta_{k}=0$.
	This shows that $\mathscr D=\set{T(v_{n+1}),...,T(v_{n+k})}$ is a linearly independent set and consequently a basis for $\text{im }T$. Thus
	$\text{rank}(T)=\dim \text{im }T=k=\dim V - \text{null }T$ and this establishes the theorem.

---

#### Spaced repetition

Prove that $\text{rank }T + \text{null }T=\dim V$.
?
	Let $\mathscr B=\set{v_{1},...,v_{n}}$ be a [[Bases|basis]] for $\ker T$ such that $\text{null }T=n$ and extend this ([[Theorems about dimension#^63394b|by this theorem]]) to a basis $\mathscr C=\set{v_{1},...,v_{n},v_{n+1},...,v_{n+k}}$ for $V$ such that $\dim V= n+k$.
	We now seek to find a basis for $\text{im }T$.
	If $w\in \text{im }T$, then $w=T(v)$ for some $v\in V$. We can write $v$ as a [[Linear combinations|linear combination]] of the vectors in the basis $\mathscr C$, say $v=\sum\limits_{i=1}^{n+k}\alpha_{i}v_{i}$.
	Then, applying $T$ and using linearity, $w=T(v)$ = $T\left(\sum\limits_{i=1}^{n+k}\alpha_{i}v_{i}\right)$ = $\sum\limits_{i=1}^{n+k}\alpha_{i}T(v_{i})$ = $\sum\limits_{i=1}^{n}\alpha_{i}T(v_{i}) +\sum\limits_{j=1}^{k}\alpha_{n+j}T(v_{n+j})$ = $\sum\limits_{j=1}^{k}\alpha_{n+j}T(v_{n+j})$ since $T(v_{1})=\ldots=T(v_{n})=\boldsymbol{0}$ as $v_{1},...,v_{n}\in \ker T$.
	This shows that the set $\mathscr D=\set{T(v_{n+1}),...,T(v_{n+k})}$ spans $\text{im }T$.
	Now suppose that $\sum\limits_{j=1}^{k}\beta_{j}T(v_{n+j})= \boldsymbol{0}$, that is $T\left(\sum\limits_{j=1}^{k}\beta_{j}v_{n+j}\right)= \boldsymbol{0}$.
	Hence $\sum\limits_{j=1}^{k}\beta_{j}v_{n+j} \in\ker T$, so as $\mathscr B=\set{v_{1},...,v_{n}}$ is a basis for $\ker T$, we have $\sum\limits_{j=1}^{k}\beta_{j}v_{n+j}=\sum\limits_{i=1}^{n}\gamma_{i}v_{i}$.
	We now have an expression $(-\gamma_{1})v_{1}+\ldots +(- \gamma_{n})v_{n}+\beta_{1}v_{n+1}+\ldots +\beta_{k}v_{n+k}=\boldsymbol{0}$ involving the vectors in the basis $\mathscr C$ for $V$.
	Since $\mathscr C$ is [[Linear independence|linearly independent]], we conclude all the coefficients occurring here are the zero.
	In particular, $\beta_{1}=\ldots=\beta_{k}=0$.
	This shows that $\mathscr D=\set{T(v_{n+1}),...,T(v_{n+k})}$ is a linearly independent set and consequently a basis for $\text{im }T$. Thus
	$\text{rank}(T)=\dim \text{im }T=k=\dim V - \text{null }T$ and this establishes the theorem.