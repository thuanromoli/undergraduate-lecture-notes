---
tags:
  - MT4531
aliases:
---
Let $\boldsymbol{\theta}=(\theta_{1},...,\theta_{p})$ be a random vector with distribution $\pi(\boldsymbol{\theta}| \boldsymbol{x})$. For readability, drop the conditioning on the data and notation gives $\pi(\boldsymbol{\theta}| \boldsymbol{x})=\pi(\boldsymbol{\theta})$.

> [!gen] Algorithm
> 1. Set arbitrary starting values $\boldsymbol{\theta}^{0} = (\theta_{1}^{0},..., \theta_{p}^{0})$.
> 2. Given that the Markov chain is in state $\boldsymbol{\theta}^{t}=(\theta_{1}^{t},...,\theta_{p}^{t})$, then consider the parameter $\theta_{i}$ and set $\boldsymbol{\theta}^{t}_{i}=(\theta_{1}^{t+1},...,\theta_{i-1}^{t+1},\theta_{i}^{t},\theta_{i+1}^{t},...,\theta_{p}^{t+1})$.
> 3. Propose a new candidate value $\phi_{i}\sim q(\phi_{i}|\boldsymbol{\theta}_{i}^{t})$, and set $\boldsymbol{\phi}_{i}=(\theta_{1}^{t+1},...,\theta_{i-1}^{t+1},\phi_{i},\theta_{i+1}^{t},...,\theta_{p}^{t+1})$. Here, note that $\boldsymbol{\phi}_{i}$ is just $\boldsymbol{\theta}_{i}^{t}$ with $\phi_{i}$ replacing $\theta_{i}^{t}$ and so $\boldsymbol{\phi}_{(i)}=\boldsymbol{\theta}^{t}_{(i)}=(\theta_{1}^{t+1},...,\theta_{i-1}^{t+1},\theta_{i+1}^{t},...,\theta_{p}^{t})$.
>    For other parameters, the proposal is $\boldsymbol{\phi}_{(i)}=\boldsymbol{\theta}^{t}_{(i)}$ with probability 1.
> 4. Accept the candidate value with probability $\min(1,A)$, where,
>    $$A = \frac{\pi(\boldsymbol{\phi}_p)
q(\theta_p^t|\boldsymbol{\phi}_p)}{\pi(\boldsymbol{\theta}_p^t)
q(\phi_p|\boldsymbol{\theta}_p^t)}
= \frac{\pi(\phi_p|\boldsymbol{\theta}_{(p)}^t)
\pi(\boldsymbol{\theta}_{(p)}^t)
q(\theta_p^t|\boldsymbol{\phi}_p)}{\pi(\theta_p^t|\boldsymbol{\theta}_{(p)}^t)
\pi(\boldsymbol{\theta}_{(p)}^t) q(\phi_p|\boldsymbol{\theta}_p^t)}
= \frac{\pi(\phi_p|\boldsymbol{\theta}_{(p)}^t)
q(\theta_p^t|\boldsymbol{\phi}_p)}{\pi(\theta_p^t|\boldsymbol{\theta}_{(p)}^t)
q(\phi_p|\boldsymbol{\theta}_p^t)}.$$
> The simplification is obtain by noting that $\pi(\boldsymbol{\phi}_p) =\pi(\phi_p|\boldsymbol{\theta}_{(p)}^t)\pi(\boldsymbol{\theta}_{(p)}^t)$.
> 5. This completes a transition from $\boldsymbol{\theta}^{t}$ to $\boldsymbol{\theta}^{t+1}$. The Markov chain is then the sequence $\boldsymbol{\theta}^{0},\boldsymbol{\theta}^{1},...,\boldsymbol{\theta}^{T}$.
