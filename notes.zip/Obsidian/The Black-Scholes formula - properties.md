---
tags:
  - MT4551
aliases:
---
> [!thm] Limiting case
> As $t \to T$, $C(S,t) \to S-E$ if $S>E$ and $C(S,t)\to 0$ if $S<E$.
> As $t \to T$, $P(S,t) \to E-S$ if $S<E$ and $P(S,t)\to 0$ if $S>E$.

> [!thm] European call properties
> ![[eucall_att.png]]
> - Higher share price $S$, higher value of the call $C$.
> - Further away from expiry time $T$, higher value of the call $C$.
> - Even when $S<E$ the call still has value as there is a finite probability that at $T$, $S>E$.

> [!thm] European call properties
> ![[europut_att.png]]
> - Lower share price $S$, higher value of the put $P$.
> - As opposed to a call option, the price may fall below $S-E$:
> 	- If $S < E$, then the closer to expiry time $T$, the higher the value of the put $P$.
> 	- If $S > E$, then the further away from expiry time $T$, the higher the value of the put $P$.

> [!thm] Factors affecting option prices
>
| If increase | Effect on $C_E$ | Effect on $P_E$ | Why                                                   |
| ----------- | --------------- | --------------- | ----------------------------------------------------- |
| $S$         | $+$             | $-$             | See graph, it will be more likely that at $T$, $S>E$. |
| $E$         | $-$             | $+$             | See graph, it will be more likely that at $T$, $S<E$. |
| $T$         | $+$             | $+$             | More uncertainty.                                     |
| $\sigma$    | $+$             | $+$             | More uncertainty.                                     |
| $r$         | $+$             | $-$             | Long/Short parties could bank at risk-free interest.  |
| $D$         | $-$             | $+$             | Dividends when paid decrease the share price.         |
