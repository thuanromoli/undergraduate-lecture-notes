---
tags:
  - MT4554
type: thm
aliases:
---
Consider a [[Two-strategy, two-player, zero-sum games|two-strategy, two-player, zero-sum game]].

>[!thm] Theorem
>$$\min\limits_{\sigma_{2}\in \Sigma_{2}}\max\limits_{\sigma_{1}\in \Sigma_{1}}u_{1}(\sigma_{1},\sigma_{2})=\max\limits_{\sigma_{1}\in \Sigma_{1}}\min\limits_{\sigma_{2}\in \Sigma_{2}}u_{1}(\sigma_{1},\sigma_{2})$$
>And so, the [[Mixed strategies|strategy profile]] $(\sigma_{1}^{\dagger},\sigma_{2}^{\dagger})$ is an equilibrium of the game.

>[!gen] Intuition
>In general for this game we have that Player 1 wants to maximise $u_{1}$ while Player 2 wants to minimise $u_{1}$.
>
>Assuming Player 2 plays optimally, Player 1 wants to choose $\sigma_{1}$ to maximise the minimum possible payoff. That is, Player 1 should adopt a strategy $\sigma_{1}^{\dagger}$ such that
>$$\min\limits_{\sigma_{2}\in \Sigma_{2}}u_{1}(\sigma_{1}^{\dagger},\sigma_{2})=\max\limits_{\sigma_{1}\in \Sigma_{1}}\min\limits_{\sigma_{2}\in \Sigma_{2}}u_{1}(\sigma_{1},\sigma_{2})$$
>This is the maximin strategy as it maximises the minimum payoff to Player 1.
>
>Similarly, assuming Player 1 plays optimally, Player 2 wants to choose $\sigma_{2}$ to minimise the maximum possible payoff. That is, Player 2 should adopt a strategy $\sigma_{2}^{\dagger}$ such that
>$$\max\limits_{\sigma_{1}\in \Sigma_{1}}u_{1}(\sigma_{1},\sigma_{2}^{\dagger})=\min\limits_{\sigma_{2}\in \Sigma_{2}}\max\limits_{\sigma_{1}\in \Sigma_{1}}u_{1}(\sigma_{1},\sigma_{2})$$
>This is the minimax strategy as it minimises the maximum payoff to Player 1.

Formal Proof:
By [[The Nash equilibrium theorem]], there exists at least one [[Nash equilibrium]], $(\sigma_{1}^{*},\sigma_{2}^{*})$, such that $u_{2}(\sigma_{2}^{*},\sigma_{1}^{*}) \geqslant u_{2}(\sigma_{2},\sigma_{1}^{*}) \;\;\forall \sigma_{2}\in \Sigma_{2}$.
Since $u_{2}=-u_{1}$, then $u_{1}(\sigma_{1}^{*},\sigma_{2}^{*})\leqslant u_{1}(\sigma_{1}^{*},\sigma_{2}) \;\;\forall \sigma_{2}\in \Sigma_{2}$. Hence
$$u_{1}(\sigma_{1}^{*},\sigma_{2}^{*})=\min\limits_{\sigma_{2}\in \Sigma_{2}}u_{1}(\sigma_{1}^{*},\sigma_{2})\leqslant \max\limits_{\sigma_{1}\in\Sigma_{1}}\min\limits_{\sigma_{2}\in \Sigma_{2}}u_{1}(\sigma_{1},\sigma_{2})$$
Further, $u_{1}(\sigma_{1}^{*},\sigma_{2}^{*}) \geqslant u_{1}(\sigma_{1},\sigma_{2}^{*}) \;\;\forall \sigma_{1}\in \Sigma_{1}$. Hence
$$u_{1}(\sigma_{1}^{*},\sigma_{2}^{*}) \geqslant \min\limits_{\sigma_{2}\in \Sigma_{2}}u_{1}(\sigma_{1},\sigma_{2}) \geqslant \max\limits_{\sigma_{1}\in\Sigma_{1}}\min\limits_{\sigma_{2}\in \Sigma_{2}}u_{1}(\sigma_{1},\sigma_{2})$$
And so, $u_{1}(\sigma_{1}^{*},\sigma_{2}^{*})=\max\limits_{\sigma_{1}\in\Sigma_{1}}\min\limits_{\sigma_{2}\in \Sigma_{2}}u_{1}(\sigma_{1},\sigma_{2})$

A similar argument can be made for $u_2$, giving $u_{2}(\sigma_{2}^{*},\sigma_{1}^{*})=\max\limits_{\sigma_{2}\in\Sigma_{2}}\min\limits_{\sigma_{1}\in \Sigma_{1}}u_{2}(\sigma_{2},\sigma_{1})$ so that $u_{1}(\sigma_{1}^{*},\sigma_{2}^{*})=\min\limits_{\sigma_{2}\in \Sigma_{2}}\max\limits_{\sigma_{1}\in\Sigma_{1}}u_{1}(\sigma_{1},\sigma_{2})$.
And this establishes the theorem.
