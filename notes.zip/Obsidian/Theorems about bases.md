---
tags:
  - MT2501
  - MT3501
type: thm
aliases:
---
Let $\mathscr{B}=\set{v_{1},...,v_{k}}$ be a [[Bases|basis]] for a [[Vector spaces|vector space]] $V$.

>[!thm]- Every vector in $V$ can be expressed in precisely one way as a [[Linear combinations|linear combination]] of the vectors in the basis $\mathscr B$ (uniquely!)
>PROOF 1: Existence
>Since $\mathscr B$ is a [[Spanning sets|spanning set]] for $V$, by definition we can express $v\in V$ as [[Linear combinations|linear combination]].
>PROOF 2: Uniqueness
>Suppose we have two expressions for $v$: $v=\sum\limits_{i=1}^{n}\alpha_{i}v_{i}=\sum\limits_{i=1}^{n}\beta_{i}v_{i}$.
>Hence $\sum\limits_{i=1}^{n}\alpha_{i}v_{i}-\sum\limits_{i=1}^{n}\beta_{i}v_{i}=\boldsymbol{0}$ $\implies$ $\sum\limits_{i=1}^{n}(\alpha_{i}-\beta_{i})v_{i}= \boldsymbol{0}$.
>Since the set $\mathscr B$ is [[Linear independence|linearly independent]], we deduce that $\alpha_{i}-\beta_{i}=0 \;\;\forall i$.
>That is, $\alpha_{i}=\beta_{i} \;\;\forall i$.
>Hence our linear combination expression is indeed unique.

Below is not needed for MT3501.

>[!thm]- The non-zero rows in an [[Echelon form|echelon]] matrix $E$ form a [[Bases|basis]] for the [[Row-spaces|row-space]] of $E$, and the row-space of every [[Matrices|matrix]] [[Elementary row operations|row-equivalent]] to $E$.

Let $v_{1},...,v_{n}\in F^{n}$, let $A$ be a matrix with rows $v_{1},...,v_{n}$ and let $E$ be the [[Echelon form|reduced echelon]] form for $A$.

>[!thm]- $\set{v_{1},...,v_{n}}$ is a [[Bases|basis]] for $F^{n}$ $\iff$ $E=I_{n}$ $\iff$ $\det(A)\neq 0$

---

#### Spaced repetition

Prove that every vector in $V$ can be expressed in precisely one way as a [[Linear combinations|linear combination]] of the vectors in the basis $\mathscr B$ (uniquely!).
?
>PROOF 1: Existence
>Since $\mathscr B$ is a [[Spanning sets|spanning set]] for $V$, by definition we can express $v\in V$ as [[Linear combinations|linear combination]].
>PROOF 2: Uniqueness
>Suppose we have two expressions for $v$: $v=\sum\limits_{i=1}^{n}\alpha_{i}v_{i}=\sum\limits_{i=1}^{n}\beta_{i}v_{i}$.
>Hence $\sum\limits_{i=1}^{n}\alpha_{i}v_{i}-\sum\limits_{i=1}^{n}\beta_{i}v_{i}=\boldsymbol{0}$ $\implies$ $\sum\limits_{i=1}^{n}(\alpha_{i}-\beta_{i})v_{i}= \boldsymbol{0}$.
>Since the set $\mathscr B$ is [[Linear independence|linearly independent]], we deduce that $\alpha_{i}-\beta_{i}=0 \;\;\forall i$.
>That is, $\alpha_{i}=\beta_{i} \;\;\forall i$.
>Hence our linear combination expression is indeed unique.
