---
tags:
  - MT3502
aliases:
  - normed space
---
Let $X$ be a [[Vector spaces|vector space]].

>[!def] Definition
> A norm on $X$ is a [[Functions|function]]
> $$\begin{align*}
   {\Vert \cdot \Vert}:X &\to \mathbb R\\
   x &\mapsto {\Vert x \Vert}
   \end{align*}$$
> such that the following conditions all hold:
> M1: positivity, ${\Vert x \Vert} \geqslant 0 \;\;\forall x \in X$ and ${\Vert x \Vert}=0 \iff x=0$.
> N2: scalar property, ${\Vert \lambda x \Vert} = |\lambda|{\Vert x \Vert} \;\;\forall x \in X,\;\;\forall \lambda \in \mathbb R$.
> N3: [[Triangle inequality|triangle inequality]], ${\Vert x+y \Vert} \leqslant {\Vert x \Vert} + {\Vert y \Vert} \;\;\forall x,y \in X$.
> 
> The pair $(X,{\Vert \cdot \Vert})$ is called a normed space.

Let $(X,{\Vert \cdot \Vert})$ be a normed space.

> [!thm] Theorem
> Define $d: X\times X \to \mathbb R$ by
> $$d(x,y) = {\Vert x-y \Vert}.$$
> Then $d$ is a [[Metric spaces|metric]] on $X$.

Proof:
M1: $d(x,y) = {\Vert x-y \Vert} \geqslant 0$ from N1 and
$$\begin{align*}
d(x,y) = 0 &\iff {\Vert x-y \Vert} = 0\\
&\iff x-y = 0 & \text{by N1}\\
&\iff x = y
\end{align*}$$
M2:
$$\begin{align*}
d(x,y) &= {\Vert x-y \Vert}\\
&= {\Vert -1(y-x) \Vert}\\
&= |-1|{\Vert y-x \Vert} & \text{by N2}\\
&={\Vert y-x \Vert}\\
&= d(y,x
\end{align*}$$
M3:
$$\begin{align*}
d(x,y) &= {\Vert x-y \Vert}\\
&= {\Vert x-z+z-y \Vert}\\
&\leqslant {\Vert x-z \Vert} + {\Vert z-y \Vert} & \text{by N3}\\
&= d(x,z)+d(z,y).
\end{align*}$$
