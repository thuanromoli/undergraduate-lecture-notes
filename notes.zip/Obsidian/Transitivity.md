---
type: def
tag: MT2505
alias: transitive
---
Let $\sim$ be a [[Relations|relation]] defined on a set $A$.

>[!def] Definition
>$\sim$ is transitive if $$a\sim b \text{ and }b\sim c\implies a\sim c \ \ \text{ for some }a,b,c \in A$$
