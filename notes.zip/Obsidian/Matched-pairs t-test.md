---
type: mthd
tag: MT2508
---
Given the paired [[Random variables|rvs]] $(X_1,Y_1), \ldots, (X_n,Y_n)$, carry out a paired [[t-test]].

>[!gen]+ CONDITIONS:
>$(X_1,Y_1), \ldots, (X_n,Y_n)$ must be [[Normal distribution|normally distributed]] with $X_i\sim N(\mu_X,\sigma^2)$ and $Y_i\sim N(\mu_Y,\sigma^2)$

>[!gen]+ [[Statistical hypothesis|HYPOTHESIS]]:
>$H_0:\mu_X=\mu_Y$ vs $H_1:\mu_X\neq\mu_Y$

>[!gen]+ [[Test statistics|TEST STATISTIC]]:
>$T= \frac{\bar D}{S / \sqrt n} \sim t_{n-1}$ where $D_i= Y_i-X_{i} \sim N(\mu_Y-\mu_X,\sigma^2)=N(0, \sigma^{2})$

---

#### Spaced repetition

Given the paired [[Random variables|rvs]] $(X_1,Y_1), \ldots, (X_n,Y_n)$, carry out a paired [[t-test]].
?
CONDITIONS:
	$(X_1,Y_1), \ldots, (X_n,Y_n)$ must be [[Normal distribution|normally distributed]] with $X_i\sim N(\mu_X,\sigma^2)$ and $Y_i\sim N(\mu_Y,\sigma^2)$
[[Statistical hypothesis|HYPOTHESIS]]:
	$H_0:\mu_X=\mu_Y$ vs $H_1:\mu_X\neq\mu_Y$
[[Test statistics|TEST STATISTIC]]:
	$T= \frac{\bar D}{S / \sqrt n} \sim t_{n-1}$ where $D_i= Y_i-X_{i} \sim N(\mu_Y-\mu_X,\sigma^2)=N(0, \sigma^{2})$
