---
type: mthd
tag: MT2508
---
Given the two sets of [[Random variables|rvs]] $X_1,...,X_n$ and $Y_1,...,Y_m$, carry out a two-sample [[t-test]].

>[!gen]+ CONDITIONS
$X_1,...,X_n$ and $Y_1,...,Y_m$ must be two sets of [[Independent events|independent]] [[Normal distribution|normally distributed]] rvs with $X_i\sim N(\mu_X,\sigma^2)$ and $Y_j\sim N(\mu_Y,\sigma^2)$

>[!gen]+ [[Statistical hypothesis|HYPOTHESIS]]
$H_0:\mu_X=\mu_Y$ vs $H_1:\mu_X\neq\mu_Y$

>[!gen]+ [[Test statistics|TEST STATISTIC]] (with known variance)
$T= \frac{\bar D}{\sigma / \sqrt{\frac{1}{n}+ \frac{1}{m}}} \sim N(0,1)$ where $\bar D= \bar Y-\bar X \sim N(\mu_Y-\mu_X,\sigma^2( \frac{1}{n}+ \frac{1}{m}))=N(0, \sigma^2( \frac{1}{n}+ \frac{1}{m}))$

>[!gen]+ [[Test statistics|TEST STATISTIC]] (with unkown variance)
$T=\frac{\bar X - \bar Y}{S_p\sqrt{\frac 1 n +\frac 1 m}} \sim t_{m+n-2}$
PROOF: see [[Pooled sample variance]]

---

#### Spaced repetition

Given the two sets of [[Random variables|rvs]] $X_1,...,X_n$ and $Y_1,...,Y_m$, carry out a two-sample [[t-test]].
?
CONDITIONS:
	$X_1,...,X_n$ and $Y_1,...,Y_m$ must be two sets of [[Independent events|independent]] [[Normal distribution|normally distributed]] rvs with $X_i\sim N(\mu_X,\sigma^2)$ and $Y_j\sim N(\mu_Y,\sigma^2)$
[[Statistical hypothesis|HYPOTHESIS]]:
	$H_0:\mu_X=\mu_Y$ vs $H_1:\mu_X\neq\mu_Y$
[[Test statistics|TEST STATISTIC]] (with known variance):
	$T= \frac{\bar D}{\sigma / \sqrt{\frac{1}{n}+ \frac{1}{m}}} \sim N(0,1)$ where $\bar D= \bar Y-\bar X \sim N(\mu_Y-\mu_X,\sigma^2( \frac{1}{n}+ \frac{1}{m}))=N(0, \sigma^2( \frac{1}{n}+ \frac{1}{m}))$
[[Test statistics|TEST STATISTIC]] (with unkown variance):
	$T=\frac{\bar X - \bar Y}{S_p\sqrt{\frac 1 n +\frac 1 m}} \sim t_{m+n-2}$
	PROOF: see [[Pooled sample variance]]