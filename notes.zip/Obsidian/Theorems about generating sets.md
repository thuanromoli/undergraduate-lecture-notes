---
tags:
  - MT4003
aliases:
---
Let $G$ be a [[Groups|group]] and $\set{H_{i}:i\in I}$ be a set of [[Subgroups|subgroups]] of $G$.

> [!thm]- The intersection $\bigcap\limits_{i \in I}H_{i}$ is also a subgroup of $G$
> Let $H = \bigcap_{i\in I}H_{i}$.
> Since each $H_{i}$ is a subgroup, they all contain $1$ of $G$.
> Hence $1\in H$ and so it is non-empty.
> Let $x,y \in H$.
> Then for each $H_{i}$, $x,y \in H_{i}$ and $xy\in H_{i}$ and $x^{-1}\in H_{i}$.
> So $xy,x^{-1}\in H$ and so $H \leqslant G$.

^9ab8e9

Let $G$ be a [[Groups|group]] and $H$ be any subgroup of $G$ containing the set $X$.

> [!thm]- The subgroup $\langle X \rangle$ [[Generating set|generated]] by $X$ is the smallest subgroup of $G$ containing $X$, i.e. if $X \subseteq H \leqslant G$, then $\langle X \rangle \leqslant H$
> Since $H$ contains $X$, then when we construct $\langle X \rangle$, we intersect it. So by construction, $\langle X \rangle \leqslant H$.

^3f5566

Let $G$ be a [[Groups|group]] and $X$ be a non-empty subset of $G$.

> [!thm]- Let $S$ be the set of all possible products of elements of $X$ and their inverses: $$S=\set{x_{1}^{\varepsilon_{1}}x_{2}^{\varepsilon_{2}}\cdots x_{n}^{\varepsilon_{n}} : n \in \mathbb Z_{>0},x_{i}\in X, \varepsilon_{i}=\pm 1 \text{ for }i=1,2,...,n}$$ Then $\langle X \rangle = S$
> Claim 1: $S \subseteq \langle X \rangle$.
> First, $\langle X \rangle$ is a subgroup of $G$ so is closed under products and inverses. Second, $\langle X \rangle$ contains $X$. Therefore $\langle X \rangle$ must contain all the products that appear in $S$, so $S \subseteq \langle X \rangle$.
> 
> Claim 2: $\langle X \rangle \leqslant S$.
> To prove this we use the above proposition. So we want to show that $S$ is a subgroup of $G$ and since $S$ contains $X$, we can then prove the claim.
> $S$ is clearly non-empty, since it contains $X$.
> Let $g,h\in S$, say $g=x_{1}^{\varepsilon_{1}}x_{2}^{\varepsilon_{2}}\cdots x_{m}^{\varepsilon_{m}}$ and $h=y_{1}^{\varepsilon_{1}}y_{2}^{\varepsilon_{2}}\cdots y_{n}^{\varepsilon_{n}}$, where $m,n \in \mathbb Z_{>0}$, $x_{i},j_{i} \in X$ and $\varepsilon_{i}, \eta_{i} = \pm 1$ for all $i$ and $J$. Then
> $gh =x_{1}^{\varepsilon_{1}}x_{2}^{\varepsilon_{2}}\cdots x_{m}^{\varepsilon_{m}} y_{1}^{\varepsilon_{1}}y_{2}^{\varepsilon_{2}}\cdots y_{n}^{\varepsilon_{n}} \in S$ and $g^{-1} = x_{m}^{- \varepsilon_{m}} x_{m-1}^{- \varepsilon_{m-1}}\cdots x_{2}^{- \varepsilon_{2}} x_{1}^{- \varepsilon_{1}} \in S$.
> Hence $S$ is a subgroup of $G$. Since this group contains $X$, we conclude that $\langle X \rangle \leqslant S$.
> 
> Hence $\langle X \rangle = S$, as required.

^42ff6c

> [!thm]- When $X=\set{x}$, by the above theorem $\langle X \rangle=\set{x^{n}:n\in \mathbb Z}$

> [!thm]- If furthermore $G$ is finite, then $\langle X \rangle=\set{x_{1}x_{2}\cdots x_{n} : n \in \mathbb Z_{>0},x_{i}\in X \text{ for }i=1,2,...,n}$
> If $|x|=k$ is finite (as must happen if the group is finite), then $x^{k}=1 \implies x^{-1}=x^{k-1}$. This means that we can replace $x^{-1}$ by $x^{k-1}$. We can then deduce the result from the above theorem.

^dc4fb4

