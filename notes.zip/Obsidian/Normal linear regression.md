---
tag: MT2508
type: def
---
We need to [[Hypothesis test|test hypothesis]] about our [[Least-squares estimation|least-squares estimates]] $\hat \alpha$ and $\hat \beta$ (see [[MLEs of the parameters in linear regression]]). To do so we need to make assumptions about the distributions of $Y_1,...,Y_n$.

>[!gen]+ [[Checking the linear regression assumptions|CONDITIONS]]
>$Y_1,...,Y_n$ are [[Independent events|independent]] and [[Normal distribution|normally distributed]] with the same variance and satisfy a [[simple linear regression]]: $Y_i \sim N(\alpha+\beta x_i,\sigma^2)$.

>[!gen]+ [[Likelihood|LIKELIHOOD FUNCTION]]
>$$L(\alpha, \beta, \sigma^{2};(x_{1},y_{1}),...,(x_{n},y_{n}))=\prod_{i=1}^{n} \frac{1}{\sqrt{2 \pi \sigma^{2}}}\exp\left(- \frac{(y_{i}-(\alpha+\beta x_{i})^{2}}{2}\sigma^{2}\right)$$

>[!gen]+ [[Log-likelihood|LOG-LIKELIHOOD]]
>$$l(\alpha, \beta, \sigma^{2};(x_{1},y_{1}),...,(x_{n},y_{n}))=- \frac{n}{2}\log(2\pi \sigma^{2})- \frac{1}{2\sigma^{2}}\sum\limits_{i=1}^{n}(y_{i}-(\alpha+\beta x_{i}))^{2}$$

>[!gen]+ [[Maximum Likelihood Estimator|MLE]]
>$$\hat\alpha = \bar y-\hat \beta \bar x \ \ \text{ and } \ \ \hat\beta=\frac{SS_{XY}}{SS_{XX}}$$
---

#### Spaced repetition

In normal linear regression, what is the distribution of $Y_{i}$?
?
$Y_i \sim N(\alpha+\beta x_i,\sigma^2)$

What are the MLEs for $\alpha$ and $\beta$ in a linear regression?
?
$$\hat\alpha = \bar y-\hat \beta \bar x \ \ \text{ and } \ \ \hat\beta=\frac{SS_{XY}}{SS_{XX}}$$

