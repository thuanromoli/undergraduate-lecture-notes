---
tags:
  - MT3501
type: def
aliases:
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $T:V\to V$ be a [[Linear transformations|linear transformation]].

>[!def] Definition
>$T$ has a Jordan normal form if there exists a [[Bases|basis]] $\mathscr{B}$ for $V$ with respect to which [[The matrix of a linear transformation|the matrix]] of $T$ is
>$$\text{Mat}_{\mathscr{B},\mathscr{B}}(T)=\begin{pmatrix}
   J_{n_{1}}(\lambda_{1}) & 0 & 0 & \cdots  & 0 \\
   0 & J_{n_{2}}(\lambda_{2}) & 0 & \cdots  & 0 \\ 
   0 & 0 & \ddots & \ddots & \vdots \\ 
   \vdots & \vdots & &\ddots & 0 \\ 
   0 & 0 & \cdots & 0 & J_{n_{k}}(\lambda_{k})
   \end{pmatrix}$$
>for some positive integers $n_{1},n_{2},...,n_{k}$ and scalars $\lambda_{1},\lambda_{2},...,\lambda_{k}$.
>The occurrences of $0$ here indicate zero matrices of appropriate sizes.

>[!thm] Existence
>See [[theorems about Jordan normal form]].