---
tags:
  - MT4528
type: thm
aliases: []
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S$ and let $u_{j}(t)= \mathbb{P}(X_{t}= j)$.

>[!thm] Theorem
>The [[State occupation distribution|state occupation distribution]] satisfies:
>1. $\boldsymbol{u}(t)=\boldsymbol{u}(t-1)\boldsymbol{P},t \geqslant 1$
>2. $\boldsymbol{u}(t)=\boldsymbol{u}(0)\boldsymbol{P}^{t},t \geqslant 0$

Proof:
For (i), we have $u_{j}(t)=\mathbb{P}(X_{t}=j)$ = $\sum\limits_{k\in S}^{}\mathbb{P}(X_{t}=j|X_{t-1}=k)\mathbb{P}(X_{t-1}=k)$ by [[The Law of Total Probability]].
So $u_{j}(t)=\sum\limits_{k\in S}^{}p_{kj}u_{k}(t-1)$, and (i) is completed.
For (ii), we have $u_{j}(t)=\mathbb{P}(X_{t}=j)$ = $\sum\limits_{k\in S}^{}\mathbb{P}(X_{t}=j|X_{0}=k)\mathbb{P}(X_{0}=k)$ by [[The Law of Total Probability]].
So $u_{j}(t)=\sum\limits_{k\in S}^{}p_{kj}(t)u_{k}(0)$.
Hence $\boldsymbol{u}(t)=\boldsymbol{u}(0)\boldsymbol{P}^{(t)}=\boldsymbol{u}(0)\boldsymbol{P}^{t}$.
