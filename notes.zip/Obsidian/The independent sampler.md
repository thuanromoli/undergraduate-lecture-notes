---
tags:
  - MT4531
aliases:
---
> [!thm] Theorem
> Suppose that the candidate generating function is such that
> $$q(\boldsymbol{\phi}|\boldsymbol{\theta}) = f(\boldsymbol{\phi}).$$
> Then, the acceptance function reduces to
> $$\alpha(\boldsymbol{\theta},\boldsymbol{\phi}) =
\min \left( 1,
\frac{\pi(\boldsymbol{\phi})
f(\boldsymbol{\theta})}{\pi(\boldsymbol{\theta}) f(\boldsymbol{\phi})}
\right)
= \min \left( 1,
\frac{w(\boldsymbol{\phi})}{w(\boldsymbol{\theta})} \right),$$
> with $w(\boldsymbol{\theta}) =\pi(\boldsymbol{\theta})/f(\boldsymbol{\theta})$, where $w$ is the importance weight function that would be used in importance sampling given samples generated from $f$; see [[Importance sampling]].
