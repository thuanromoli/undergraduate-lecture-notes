---
tags:
  - MT4003
aliases:
  - commutator
---
Let $G$ be a [[Groups|group]].

> [!def] Definition
> The commutator of $x,y \in G$ is denoted by $[x,y]$ and is defined to be
> $$[x,y] = x^{-1}y^{-1}xy$$
> such that, by construction
> $$xy = yx[x,y].$$
> Hence $[x,y]=1$ if and only if $xy=yx$. In this sense commutators measure "by how much" two elements fail to commute.
