---
type: model
tag: MT2507
---
Consider a [[Particle (Dynamics)|particle]] of mass $m$ moving in the $x$ direction and acted on by a force $F(x)\boldsymbol{i}$. Let the potential energy function be $V(x)$.

>[!gen]+ Model with a conservative force
>1. Determine $V(x)$ using $F(x)=-\frac{dV}{dx} \implies V(x)=-\int F(x)\ dx + C$
>	-  PROOF: if force is conservative then it's [[Independence of path|path independant]] and we can write $$\boldsymbol{F} = -\nabla V \implies F_{x}\boldsymbol{i}+F_{y}\boldsymbol{j} +F_{z}\boldsymbol{k}=-\left(\frac{dV}{dx}\boldsymbol{i}+\frac{dV}{dy}\boldsymbol{j}+\frac{dV}{dz}\boldsymbol{k}\right)$$
>	- And by comparing bases: $F(x)=-\frac{dV}{dx} \implies V(x)=-\int F(x)\ dx + C$.
>2. Then proceed to evaluate $E$ using the [[Energy Conservation Equation]] and initial conditions: $E=\frac{1}{2}mv_{0}^{2}+ V(x_{0})$
>4. Find if it oscillates or heads to infinitity
>	- Note: $\frac{1}{2}mv^{2}\geqslant 0 \;\;\forall x$ hence $E-V(x)\geqslant 0 \;\;\forall x \implies E \geqslant V(x) \;\;\forall x$
>	- Find range of values of $V(x)$ such that $v^{2}>0$ using the above information
>5. Find the velocity of $v(x)$ at any $x$ and/or $\lim_\limits{x\to \pm\infty}v(x)$
