---
type: def
tag: MT2508
alias: simple linear regression
---
Let $Y$ be the [[Response variable|response variable]] and $x$ be the [[Explanatory variable|explanatory variable]].

>[!gen]+ [[Regression|REGRESSION MODEL]]
>$Y_i=\alpha+\beta x_i + \varepsilon_i$ where $\alpha$ and $\beta$ are parameters that can be estimated using [[Least-squares estimation]]
>
>The population regression line is $y=\alpha+\beta x$.

---

#### Spaced repetition

What is a simple linear regression model?
?
$$Y_i=\alpha+\beta x_i + \varepsilon_i$$