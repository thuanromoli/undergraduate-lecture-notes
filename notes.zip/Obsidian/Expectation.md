---
type: def
tags:
  - MT2504
  - MT4551
aliases:
  - expectation
  - mean
---
> [!gen] MOTIVATION
> The expectation represents the long-term mean of the distribution of a [[Random variables|random variable]].

Let $X$ be a discrete [[Random variables|rv]] taking values $x_1,x_2,...,x_n$ with [[Probability mass function|pmf]] $f(x)$.

> [!def] Expectation of discrete rvs
 >The expectation of $X$ is 
 >$$\mathbb{E}(X)=\sum\limits_{i=1}^{n}x_if(x_i)$$

Let $Y$ be a continuous [[Random variables|rv]] with [[Probability density function|pdf]] $f(y)$.

> [!def] Expectation of continuous rvs
> The expectation of $Y$ is $$\mathbb{E}(Y)=\int_{-\infty}^{\infty}yf(y) \ \text{d}y $$
