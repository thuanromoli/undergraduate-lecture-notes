---
tags:
  - MT4527
aliases:
---
Let $(X_{t})_{t \in \mathbb Z}$ be an [[AR(p) Process]] such that
$$X_{t}=\phi_{1} X_{t-1}+\cdots+\phi_{p}X_{t-p}+\varepsilon_{t}.$$

>[!thm] Lemma
> If an [[MA(inf) Process|infinite moving average]] representation $X_{t}= \sum\limits_{i=0}^{\infty}\psi_{i}\varepsilon_{t-i}$ exists, then its coefficients would have to satisfy the $p$-th order recurrence relation
> $$\psi_{i+p}-\phi_{1}\psi_{i+p-1}-\cdots-\phi_{p}\psi_{i}=0\qquad \text{for}\; i=-p+1,-p+2,...$$
> subject to initial conditions
> $$\psi_{0}=1, \quad \psi_{i}=0, \qquad \text{for}\;i=-p+1,-p+2,...,-1.$$

> [!thm] Theorem
> If all characteristic roots of the characteristic equation
> $$\psi(z) = z^{p}-\psi_{1}z^{p-1}-\cdots-\phi_{p}=0$$
> lie inside the unit circle, that is $|z|<1$, then the process is [[Stationarity|stationary]].

> [!thm] Theorem
> If there exists a polynomial function $\varphi(B)$ with a well-defined inverse $\varphi^{-1}(B)$ and we can write
> $$X_{t}=\varphi^{-1}(B)\varepsilon_{t} \quad \forall t \in \mathbb Z,$$
> then the process is stationary.
> 
> In other words, the process is stationary if the roots of the complex polynomial $\varphi(z)$ lie outside of the unit circle, that is $|z|>1$.

Proof of lemma.
Suppose an [[MA(inf) Process|infinite moving average]] representation $X_{t}= \sum\limits_{i=0}^{\infty}\psi_{i}\varepsilon_{t-i}$ exists.
Then we can write
$$\sum\limits_{i=0}^{\infty}\psi_{i}\varepsilon_{t-i}=\phi_{1}\sum\limits_{i=0}^{\infty}\psi_{i}\varepsilon_{t-1-i}+\cdots+\phi_{p}\sum\limits_{i=0}^{\infty}\psi_{i}\varepsilon_{t-p-i}+\varepsilon_{t}.$$
Matching the coefficients of $\varepsilon_{j}$ for $j=1,...,t$ we have the result.

Proof of theorem (sketch).
If all the roots are inside the unit circle, then $\sum\limits_{i=0}^{\infty}|\psi_{i}| < \infty$.
So $\sum\limits_{i=0}^{\infty}\psi_{i}\varepsilon_{t-i}$ [[Convergence in mean square|converges in mean square]] to a random variable $X_{t}$, which satisfies the [[AR(p) Process]] definition with probability 1.
So an infinite moving average representation exsits.
Hence the process $(X_{t})_{t \in \mathbb Z}$ is stationary.

Proof of theorem 2.
An AR($p$) process can be written as
$$\varphi (B)X_{t}=\varepsilon_{t} \quad \text{with} \quad \varphi(B) = 1-\phi_{1}B-\cdots - \phi_{p}B^{p}.$$
Suppose the characteristic equation $\psi(z) = z^{p}-\phi_{1}z^{p-1}-\cdots-\phi_{p}=0$ had root $\lambda$.
Then since $\phi_{p}\neq 0$ and $\lambda\neq 0$, we have
$$ \lambda^{p}-\phi_{1}\lambda^{p-1}-\cdots-\phi_{p}=0 \implies 1-\phi_{1}\frac{1}{\lambda}-\cdots-\phi_{p}\left(\frac{1}{\lambda}\right)^{p}=0.$$
But this means that $\frac{1}{\lambda}$ is the solution to $\varphi(z)=0$.
So since we need $|\lambda|<1$ for stationarity, we have that $(X_{t})_{t}$ is stationary if and only if the roots of $\varphi(z)=0$ are outside of the unit circle.