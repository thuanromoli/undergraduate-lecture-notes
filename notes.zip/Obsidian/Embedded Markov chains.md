---
tags:
  - MT4528
type: 
aliases:
---
Let $\set{X(t):t \geqslant 0}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov process]] with [[State spaces|state space]] $S$.

>[!def] Definition
>The process $\set{Y_{n}:n=0,1,2,...}$ where $Y_{n}$ is the state of $X(t)$ after the $n$-th transition occurred, is called the embedded Markov chain, or sometimes the jump chain.