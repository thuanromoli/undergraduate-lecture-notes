---
tags:
  - MT4551
aliases:
---
> [!def] Nomenclature
> There are many different possible strategies but common ones are the following.
> 1. A position on stock + position on an option.
> 2. Spread: two or more options of the same type (all calls or all puts) on the same stock on different positions (long and short).
> 3. Combination: two or more options of different type (at least a call and a put) on the same stock.

> [!gen] Covered call
> Short call $(E>S_{0},T)$ and long stock $S_{0}$.
> See payoff diagram from lecture notes or hand notes.

> [!gen] Bull spread
> Long call $(C_{1},E_{1},T)$ and short call $(C_{2}<C_{1},E_{2}>E_{1},T)$. Initial cost is $C_{2}-C_{1}<0$.
> See payoff diagram from lecture notes or hand notes.
