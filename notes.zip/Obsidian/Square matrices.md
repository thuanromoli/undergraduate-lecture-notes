---
tag: MT2501
type: def
alias:
- square matrix
---
>[!def] Definition
>A square matrix is a [[Matrices|matrix]] with $m=n$

---

#### Spaced repetition
