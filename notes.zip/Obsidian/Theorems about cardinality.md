---
tags:
  - MT3502
aliases:
---
Let $A, B, C$ be sets.

> [!thm]- $|A|=|A|$

> [!thm]- $|A| = |B| \implies |B| = |A|$

> [!thm]- $|A|=|B| \text{ and } |B| = |C| \implies |A| = |C|$

> [!thm]- $|A| \leqslant |A|$

> [!thm]- $|A| \leqslant |B| \text{ and } |B| \leqslant |C| \implies |A| \leqslant |C|$

> [!thm]- [[Schroeder–Bernstein's Theorem]] $|A| \leqslant |B| \text{ and } |B| \leqslant |A| \implies |A| = |B|$

The following are corollaries.

> [!thm] If $|A|$ is a non-empty set, then $|A| < |\mathcal P(A)|$

> [!thm] There are infinitely many different infinite [[Cardinality|cardinalities]]

> [!thm] There is no largest [[Cardinality|cardinality]]

> [!thm] There is no set containing all sets
