---
tags:
  - MT3501
type: def
aliases:
  - rank
---
Let $T : V \to W$ be a [[Linear transformations|linear transformation]] between [[Vector spaces|vector spaces]] $V$ and $W$ over the [[Fields (Algebra)|field]] $F$.

>[!def] Definition
>The rank of $T$, which we shall denote $\text{rank } T$, is the [[Dimension|dimension]] of the [[Image|image]] of $T$.

---

#### Spaced repetition

What is the definition of the rank of a linear transformation?
?
>The rank of $T$, which we shall denote $\text{rank } T$, is the [[Dimension|dimension]] of the [[Image|image]] of $T$.