---
tags:
  - MT4554
type: model
aliases: []
---
>[!gen] Why are we studying this?
>We want to show how to find [[population level payoff]] and [[population level equilibria]].

>[!def] Definition
>![[matchingpenn_att.png|300]]

>[!gen] Solution
>The [[Mixed strategies|mixed strategy]] [[Nash equilibrium]] is $\sigma_{1}^{*}(H)=\sigma_{2}^{*}(H)=1/2$.
>
>Suppose there are $N$ players and $h$ of them are playing $H$.
>Then the [[Population level payoff|population level payoffs]] are
>$$\begin{align*}
   V_{H}&= \frac{1}{2}[(h-1)\cdot 1+(N-h)\cdot (-1)] + \frac{1}{2}[(h-1)\cdot(-1)+(N-h)\cdot(1)]=0\\
   V_{T}&= \frac{1}{2}[(h)\cdot (-1)+(N-h-1)\cdot (1)] + \frac{1}{2}[(h)\cdot(1)+(N-h-1)\cdot(-1)]=0
   \end{align*}$$
>And since $V_{H}=V_{T}$, we have a [[Population level equilibria|population level equilibria]].
