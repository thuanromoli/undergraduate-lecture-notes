---
tags:
  - MT4509
aliases:
---
> [!thm] Line element
> Let $\boldsymbol{dl}$ be an infinitesimal vector indicating a straight line segment.
> $$\frac{D}{Dt}\boldsymbol{dl} = (\boldsymbol{dl} \cdot \nabla ) \boldsymbol{u}\; \Big|_{\boldsymbol{x}=\boldsymbol{x_{0}}}$$

> [!thm]- Proof
> ![[lineelement_att.png|300]]
> ![[lineelementchange_att.png|300]]
>Then
> $$\begin{align*}
\frac{D}{Dt}\boldsymbol{dl}&=\frac{D}{Dt}(\boldsymbol{x}_{1}- \boldsymbol{x}_{0})\\
&= \frac{D}{Dt}\boldsymbol{x}_{1}- \frac{D}{Dt}\boldsymbol{x}_{0}\\
&= \boldsymbol{u}(\boldsymbol{x}_{1},t)- \boldsymbol{u}(\boldsymbol{x}_{0},t)\\
&= \boldsymbol{u}(\boldsymbol{x}_{0}+ \boldsymbol{dl},t)- \boldsymbol{u}(\boldsymbol{x}_{0},t)\\
&= (\boldsymbol{dl} \cdot \nabla ) \boldsymbol{u}\; \Big|_{\boldsymbol{x}=\boldsymbol{x_{0}}}
\end{align*}$$

> [!thm] Surface element
> Let $\boldsymbol{dS}$ be an infinitesimal vector indicating a surface element.
> $$\frac{D}{Dt}\boldsymbol{dS} = (\nabla \cdot \boldsymbol{u})\boldsymbol{dS}-(\nabla  \boldsymbol{u})^{T}\cdot \boldsymbol{dS}$$

> [!thm]- Proof
> ![[surfaceelement_att.png|300]]
> $$\begin{align*}
\frac{D}{Dt}\boldsymbol{dS} &= \frac{D}{Dt}(\boldsymbol{dl}_{1}\times \boldsymbol{dl}_{2})\\
&= \left(\frac{D}{Dt}\boldsymbol{dl}_{1}\right) \times \boldsymbol{dl}_{2}+\boldsymbol{dl}_{1} \times \left(\frac{D}{Dt}\boldsymbol{dl}_{2}\right)\\
&= \Big[(\boldsymbol{dl}_{1} \cdot \nabla )\boldsymbol{u} \Big] \times \boldsymbol{dl}_{2} + \boldsymbol{dl}_{1} \times\Big[(\boldsymbol{dl}_{2} \cdot \nabla )\boldsymbol{u} \Big]\\
&= \Big[(\boldsymbol{dl}_{1} \cdot \nabla )\boldsymbol{u} \Big] \times \boldsymbol{dl}_{2} - \Big[(\boldsymbol{dl}_{2} \cdot \nabla )\boldsymbol{u} \Big] \times \boldsymbol{dl}_{1}\\
&= (\nabla \cdot \boldsymbol{u})\boldsymbol{dS}-(\nabla  \boldsymbol{u})^{T}\cdot \boldsymbol{dS}
\end{align*}$$

> [!thm] Volume element
> Let ${dV}$ be an infinitesimal vector indicating a volume element.
> $$\frac{D}{Dt}dV=dV \boldsymbol{\nabla \cdot u}.$$

> [!thm]- Proof
> ![[volumeelement_att.png|300]]
> Proof 1: Use the [[Continuity equation|continuity equation]] and mass conservation.
> Recall that $\frac{D}{Dt} \rho + \rho \nabla \cdot \boldsymbol{u}=0$ and $dM = \rho dV$.
> The mass is conserved so
> $$\begin{align*}
> \frac{D}{Dt}dM = 0 &\implies \frac{D}{Dt} \rho dV =0 \\
> &\implies \frac{D \rho}{Dt} dV + \rho \frac{D(dV)}{Dt}=0\\
> &\implies -(\rho \nabla \cdot \boldsymbol{u})dV +\rho \frac{D}{Dt}(dV) =0\\
> &\implies \frac{D}{Dt}dV =dV \boldsymbol{\nabla \cdot u}.
> \end{align*}$$
> 
> Proof 2: Consider the normal velocity $\boldsymbol{u \cdot n}$ on a small volume.
> $$\begin{align*}
> \frac{D}{Dt}\delta v &= \iint_{S \text{ closed}} \boldsymbol{u \cdot n}dS\\
> &=\iiint_{V} \boldsymbol{\nabla \cdot u}\;dV
> \end{align*}$$
> In the limit, as $\delta v \to dV$,
> $$\frac{D}{Dt}dV=dV \boldsymbol{\nabla \cdot u}.$$
