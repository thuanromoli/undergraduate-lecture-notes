---
type: def
tag: MT2506
alias: [parametrise,parametrisation]
---
Consider a [[Position vectors|position vector]] $\boldsymbol r(s)$.

If $s$ takes a range of values, then it's a curve.
If $s$ is a single value, then it's a point.