---
tags:
  - MT4554
type: 
aliases:
---
>[!def] Introspection dynamics
>Introspection update rule works as follows:
>1. a player $i$ chooses another strategy $\sigma^{k}\in \Sigma_{i}$ from their space of possible strategies according to some (probabilistic) update rule.
>2. player $i$ compares the payoff they have received previously from their current strategy $\sigma^{r}$, to the one they would have received under the alternate strategy.
>3. depending on the difference in their true payoff and their hypothetical alternate payoff, player $i$ changes their strategy to $\sigma^{k}$ with probability
>   $$\Pi(\sigma^{r}\to \sigma^{k})= \frac{1}{1+\exp[h(V^{k}-V^{r})]}$$

>[!gen] Remarks
>This differs from [[Imitation dynamics|imitation dynamics]] since:
>- imitation dynamics has $i$ compare $\sigma_{i}\in \Sigma_{i}$ (his strategy) to $\sigma_{k}\in \Sigma_{k}$ ($k$'s strategy)
>- introspection dynamics has $i$ compare $\sigma^{r}\in \Sigma_{i}$ (his strategy) to $\sigma^{k} \in \Sigma_{i}$ ($i$'s strategy in his space)
>
>Note that the comparison is done randomly and it is not iterative.
