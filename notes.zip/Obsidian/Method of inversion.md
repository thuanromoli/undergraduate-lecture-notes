---
tags:
  - MT4531
aliases:
---
Let $X$ be a random variable with pdf $f$ and cdf $F$.

> [!gen] Algorithm
> 1. Generate $u$ as a realisation from $U \sim U[0,1]$.
> 2. Then, $x = F^{-1}(u)$ is a sample from $X \sim f$

> [!thm] Theorem 1
> If $U=F(X)$, then $U\sim U[0,1]$.
> 
> Proof:
> The cdf of a random variable $U\sim U[0,1]$ is
> $$\mathbb P(U \leqslant u)= \begin{cases}
   0 & \text{for } u \leqslant 0 \\
   u & \text{for } 0 \leqslant y \leqslant 1 \\
   1 & \text{for } u \geqslant 1.
   \end{cases}$$
> We want to show that the cdf of $U=F(x)$ is of the above form, for $0 \leqslant u \leqslant 1$.
> $$\mathbb P(U \leqslant u) = \mathbb P(F(X) \leqslant u)=\mathbb P(X \leqslant F^{-1}(u) )=F(F^{-1}(u))=u.$$

> [!thm] Theorem 2
> Assume that the inverse function $F^{-1}(u)$ is well defined for $0 \leqslant u \leqslant 1$.
> If $X = F^{-1}(U)$, then $X \sim f$.
> 
> Proof:
> The cdf of $X\sim f$ is $F(x)$.
> We want to show that the cdf of $X=F^{-1}(u)$ is of the above form, for $0 \leqslant u \leqslant 1$.
> $$\mathbb P (X \leqslant x) = \mathbb P(F^{-1}(U) \leqslant x) = \mathbb P(U \leqslant F(x) ) = F(x).$$