---
tags:
  - MT3501
type: 
aliases:
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $T:V\to V$ be a [[Linear transformations|linear transformation]].

>[!thm]- (Existence) If the [[Characteristic polynomials|characteristic polynomial]] $c_{T}(x)$ is a product of linear factors with [[Eigenvectors and Eigenvalues|eigenvalues]] $\lambda_{1},...,\lambda_{n}$ then there exists a [[Bases|basis]] for $V$ with respect to which $\text{Mat}(T)$ is in [[Jordan normal form]] where each [[Jordan blocks|Jordan block]] has the form $J_{m}(\lambda_{i})$ for some $m$ and some $i$
>Proof: omitted.

>[!thm]- If $A$ is a [[Square matrices|square matrix]] over $\mathbb C$ then there exists an [[The inverse of a matrix|invertible]] matrix $P$ such that $P^{-1}AP$ is in [[Jordan normal form]].
>If $A$ is a square matrix over $\mathbb C$ then the [[Characteristic polynomials|characteristic polynomial]] can always be written as a product of linear factors.
>By the above theorem, then there exists a Jordan normal form, say $J$.
>By [[Change of basis matrix|change of basis]], we can find a matrix $P$ such that $J=P^{-1}AP$ when viewing $J$ and $A$ as linear transformations

>[!thm]- Let $A$ and $B$ are two [[Square matrices|square matrices]] over $\mathbb C$. Then $A$ and $B$ are similar (that is, $B=P^{-1}AP$ for some invertible matrix $P$) if and only if they have the same [[Jordan normal form]]
>If $A$ and $B$ have the same [[Jordan normal form]] $J$, then there exist invertible matrices $P_{1}$ and $P_{2}$ such that $P_{1}^{-1}AP_{1}=P_{2}^{-1}BP_{2}=J$.
>Now $P_{1}^{-1}AP_{1}=P_{2}^{-1}BP_{2}$ $\implies$ $P_{2}P_{1}^{-1}AP_{1}=BP_{2}$ $\implies$ $P_{2}P_{1}^{-1}AP_{1}P_{2}^{-1}=B$.
>Noting that $(P_{1}P_{2}^{-1})^{-1}=P_{2}P_{1}^{-1}$, we have that $P^{-1}AP=B$ where $P=P_{1}P_{2}^{-1}$.
>
>The converse is omitted.

Let $J=J_{n}(\lambda)$ be an $n\times n$ [[Jordan blocks|Jordan block]].

>[!thm]- $c_{J}(x)=(x-\lambda)^{n}$
>By direct calculation,
>$$\begin{align*}
   c_{J}(x) =\det(xI-J) &= \det\begin{pmatrix}x-\lambda & -1 & \\
   & x-\lambda & -1 & 0 \\
   &  & \ddots & \ddots \\
   &&0 & \ddots & -1 \\
   &&&&x-\lambda
   \end{pmatrix} \\
   &= (x-\lambda)\det\begin{pmatrix}x-\lambda & -1 & 0\\
   & \ddots & \ddots \\
   &0 & \ddots & -1 \\
   &&&x-\lambda
   \end{pmatrix} \\
   &\;\;\vdots\\
   \\
   &= (x-\lambda)^{n}
   \end{align*}$$

^9bd163

>[!thm]- $m_{J}(x)=(x-\lambda)^{n}$
>Firstly, we note that $m_{J}(x)$ divides $c_{J}(x)$. So $m_{J}(x)=(x-\lambda)^{k}$ for some $k\in [1,n]$.
>We find $m_{J}(J)=(J-\lambda I)^{k}$ for different values of $k$ until $m_{J}(J)=0$.
>$$k=1 \implies J-\lambda I =\begin{pmatrix}
   0 & 1 & \\
   & 0 & 1 & 0 \\
   &  & \ddots & \ddots \\
   &&0 & \ddots & 1 \\
   &&&&0
   \end{pmatrix} $$
>$$k=2 \implies (J-\lambda I)^{2} =\begin{pmatrix}
   0 & 1 & \\
   & 0 & 1 & 0 \\
   &  & \ddots & \ddots \\
   &&0 & \ddots & 1 \\
   &&&&0
   \end{pmatrix}\begin{pmatrix}
   0 & 1 & \\
   & 0 & 1 & 0 \\
   &  & \ddots & \ddots \\
   &&0 & \ddots & 1 \\
   &&&&0
   \end{pmatrix} = \begin{pmatrix}
   0  & 0 & 1 & \\
   0 & & 0 & 1 & 0 \\
   0 & &  & \ddots & \ddots \\
   0 & &&0 & \ddots & 1 \\
   0 & &&&&0
   \end{pmatrix} $$
>Noting that repeatedly multiplying by $J-\lambda I$ successively moves the diagonal of $1$s one level higher in the matrix.
>Thus
>$$k=n-1 \implies (J-\lambda I)^{n-1} =\begin{pmatrix}
   0 & \cdots & 0 & 1 \\
   0 & \cdots & 0 & 0 \\
   \vdots &  & \vdots & \vdots  \\
   0 & \cdots & 0 & 0
   \end{pmatrix} $$
>and
>$$k=n \implies (J-\lambda I)^{n} =\begin{pmatrix}
   0 & \cdots & 0 & 0 \\
   0 & \cdots & 0 & 0 \\
   \vdots &  & \vdots & \vdots  \\
   0 & \cdots & 0 & 0
   \end{pmatrix} $$
>So $m_{J}(x)=(x-\lambda)^{n}$.

^1e9b25

>[!thm]- The [[Eigenspaces|eigenspace]] $E_\lambda$ of $J$ has [[Dimension|dimension]] 1.

^5f5ee2

