---
tags:
  - MT3504
type: 
aliases:
---
Let $C^{2}(a,b)$ be the [[Inner product space of twice-differentiable functions|inner product space of twice-differentiable functions]].

>[!thm] Theorem
>The generalised Fourier Series is
>$$f(x)= \sum\limits_{n=1}^{\infty}c_{n}\phi_{n}(x)$$
>where $c_{n}=(\phi_{n},f)$ and $\phi_{n}(x)= \frac{y_{n}}{(y_{n},y_{n})^\frac{1}{2}}$

Proof (somewhat similar to the [[Gram-Schmidt process]]):
Let $y_{n}$ and $y_{m}$ be two distinct [[Eigenvectors and Eigenvalues|eigenfunctions]] of a [[Sturm-Liouville problems|Sturm-Liouville problem]] $L[y]=\lambda w(x)y$.
Then $(y_{n},y_{m})=0$ for $m\neq n$ by [[Properties of Sturm-Liouville problems#^3ae102|this theorem]].
When $m=n$, we define
$$\phi_{n}=\frac{y_{n}}{(y_{n},y_{n})^\frac{1}{2}}$$
such that
$$(\phi_{m},\phi_{n})=\delta_{mn}$$
note that $\phi_{1}, \phi_{2},...$ form a [[Orthogonality|orthonormal]] [[Bases|basis]] for $C^{2}(a,b)$. So for any $f\in C^{2}(a,b)$
$$f(x)=\sum\limits_{n=1}^{\infty}c_{n}\phi_{n}(x)$$
We can compute the coefficients using an inner product with respect to $\phi_{m}$:
$$\begin{align*}
 (\phi_{m},f) &= \left(\phi_{m},\sum\limits_{n=1}^{\infty}c_{n}\phi_{n}\right)\\
 &= \sum\limits_{n=1}^{\infty}c_{n}(\phi_{m},\phi_{n})\\
 &= \sum\limits_{n=1}^{\infty}c_{n}\phi_{mn}\\
 &= c_{m}
 \end{align*}$$
So $$c_{n}=(\phi_{n},f)=\int_{a}^{b}w(x)\phi_{n}(x)f(x)dx$$
