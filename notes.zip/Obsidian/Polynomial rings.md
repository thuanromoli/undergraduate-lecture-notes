---
type: thm
tag: MT2505
---
Let $R$ be a [[Rings|ring]] and $R[X]$ be the set of all [[Polynomials|polynomials]] with indeterminate $X$ over $R$.

>[!thm] Theorem
>$R[X]$ is a [[Rings|ring]] with respect to [[polynomial addition]] and [[polynomial multiplication]].
