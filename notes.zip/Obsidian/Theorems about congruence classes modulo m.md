---
type: thm
tag: MT2505
---
>[!thm]- There are well-defined addition and multiplication operations on the set of [[Congruence classes modulo m|congruence classes modulo m]] given by $[a]+[b]=[a+b]$ and $[a]\cdot [b] = [ab]$
PROOF:


>[!thm]- The set $\mathbb{Z}/m\mathbb{Z}=\set{[0],[1],...,[m-1]}$ of [[Congruence classes modulo m|congruence classes modulo m]] is a [[Commutative rings|commutative ring]] under the addition and multiplication of congruences classes modulo $m$.
PROOF:

>[!thm]- Let $p$ be any prime number. $\mathbb{Z}/p\mathbb{Z}=\set{[0],[1],...,[p-1]}$ is a [[Fields (Algebra)|field]].