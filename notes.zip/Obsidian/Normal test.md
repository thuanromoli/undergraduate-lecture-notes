---
type: mthd
tag: MT2508
---
Given the [[Random variables|rvs]] $X_1,...,X_n$, carry out a [[Normal distribution|normal]] test.

>[!gen]+ CONDITIONS
>$X_1,...,X_n$ must be [[Independent events|independent]] and [[Normal distribution|normally distributed]] with $X_{i}\sim N(\mu,\sigma^{2})$

>[!gen]+ [[Statistical hypothesis|HYPOTHESIS]]
>$H_0:\mu=\mu_{0}$ vs $H_{1}: \mu \ne \mu_{0}$

>[!gen]+ [[Test statistics|TEST STATISTIC]]
>$\bar X \sim N(\mu_0,\frac{\sigma^2} n)$ or $Z= \frac{\bar X - \mu_0}{\sigma/ \sqrt n} \sim N(0,1)$

---

#### Spaced repetition

Given the [[Random variables|rvs]] $X_1,...,X_n$, carry out a [[Normal distribution|normal]] test.
?
CONDITIONS:
	$X_1,...,X_n$ must be [[Independent events|independent]] and [[Normal distribution|normally distributed]] with $X_{i}\sim N(\mu,\sigma^{2})$
[[Statistical hypothesis|HYPOTHESIS]]:
	$H_0:\mu=\mu_{0}$ vs $H_{1}: \mu \ne \mu_{0}$
[[Test statistics|TEST STATISTIC]]:
	$\bar X \sim N(\mu_0,\frac{\sigma^2} n)$ or $Z= \frac{\bar X - \mu_0}{\sigma/ \sqrt n} \sim N(0,1)$
