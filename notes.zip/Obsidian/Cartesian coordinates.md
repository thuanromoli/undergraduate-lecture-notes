---
type: def
tag: MT2506
alias: [cartesian]
---
>[!gen] [[Unit basis vectors|Basis vectors]]:
>$\boldsymbol i,\; \boldsymbol j,\;\boldsymbol k$

>[!gen] [[Position vectors|Position vector]]:
>$\boldsymbol{r}(t)=x(t)\,\boldsymbol{i}+y(t)\,\boldsymbol{j}+z(t)\,\boldsymbol{k}$
