---
tags:
  - MT2504
  - MT4528
type: 
aliases:
  - independent
---
Let $A$ and $B$ be events with $\mathbb{P}(B)>0$.

>[!thm] Theorem
>$A$ and $B$ are independent if and only if $\mathbb{P}(A \vert B)=\mathbb{P}(A)$.
>In other words, two events are independent if and only if knowing that event $B$ has occurred does not give any information relating to the occurrence of $A$.

>[!thm] Lemma
>$A$ and $B$ are independent if and only if $\mathbb{P}(A \cap B)=\mathbb{P}(A)\mathbb{P}(B)$.
