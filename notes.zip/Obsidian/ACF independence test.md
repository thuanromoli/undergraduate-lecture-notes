---
tags:
  - MT4527
aliases:
---
Let $(X_{t})_{t=1,...,T}$ be a sequence of [[Random variables|random variables]] with finite variance.

> [!thm] Theorem
> For large $T$, if $X$ is a sequence of iid rvs, then the [[ACVF and ACF|sample autocorrelations]] of $X$ are approximately iid with $N(0,\frac{1}{T})$.

> [!gen] [[Statistical hypothesis|Hypothesis]]
> $H_{0}$: $X$ is a sequence of iid rvs.
> $H_{1}$: $X$ is not a sequence of iid rvs.

> [!gen] Plot
> Under $H_{0}$, 95% of the sample autocorrelations should fall between the bounds $\pm1.96/\sqrt{T}$ (see [[Normal confidence intervals|normal intervals]]).
> 
> ![[ACFtest_att.png|400]]
