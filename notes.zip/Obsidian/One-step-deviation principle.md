---
tags:
  - MT4554
type: def
aliases:
---
>[!thm] Theorem
>A [[Pure strategies|strategy profile]] $\boldsymbol{s}$ is [[Subgame perfection|subgame perfect]] if and only if there is no player $i$ and strategy $\hat s_{i}$ that agrees with $s$ except at a single $t$ and $h^{t}$ such that $\hat s_{i}$ is a better response to $s_{-i}$ than $s_{i}$ conditional on history $h^{t}$ being reached.
>
>In other words, a [[Pure strategies|strategy profile]] $\boldsymbol{s}$ is NOT [[Subgame perfection|subgame perfect]] if and only if
>there exists a player $i$ and strategy $\hat s_{i}$ such that
>1. $\hat s_{i}$ agrees with $s$ except at a single $t$ and $h^{t}$
>2. $\hat s_{i}$ is a better response to $s_{-i}$ than $s_{i}$ conditional on history $h^{t}$ being reached.
>
>Note: this works for both finite- and infinite-horizon games however, the proof is different a the knowledge of continuous games at infinity is required.
>>[!def]- Continuous games
>>A repeated game is continuous at infinity if and only if, given any $\varepsilon > 0$, there exists some $t$ such that, for any two histories which agree up to time $t$, the payoff difference for each player $i$ between the two histories is less than $\varepsilon$.

>[!gen] Intuition
>To verify that a strategy profile $\boldsymbol{s}$ of a fixed-horizon repeated game is [[Subgame perfection|subgame perfect]], it is sufficient to check whether there are any histories $h^{t}$ where some player $i$ can gain by deviating from the actions prescribed by $s_{i}$ at at $h^{t}$ and conforming to $s_{i}$ thereafter.

Proof (finite-horizon):
The forward proof is relatively easy and it follows by the definition of [[subgame perfection]]. In fact, if a strategy profile is subgame perfect than it's a [[Nash equilibrium]] and there is no player $i$ and strategy $\hat s_{i}$ that is a better response to $s_{-i}$ conditional on $h^{t}$.

The backward proof is less obvious as there could be a multi-step deviation which is worse over one-step however it makes up for it in subsequent steps. So to prove this is not possible, we use backwards induction.

Suppose that a strategy profile $\boldsymbol{s}$ satisfies the one-step-deviation principle.
Suppose that there exists some other strategy $\hat s_{i}$ such that it is worse at round $t$ but then it is better over multiple rounds after $t$ and $h^{t}$.
Let $t'$ be the last round where $\hat s_{i}$ deviates.
Now consider another strategy identical to $\hat s_{i}$ except at round $t'$ where it plays like $s_{i}$.

![[onestepdev_att.png|500]]

If we start our game at $t'$, the bottom strategy is just $s_{i}$ and the middle strategy has a one-step deviation and by our assumption, no strategy is better than $\boldsymbol{s}$ by a one-step deviation.
So the bottom strategy is as good a response as the middle strategy starting at $t'$.
So we can compare the bottom strategy to $\boldsymbol{s}$ instead of the middle strategy.
In that case we have a strategy that deviates from $\boldsymbol{s}$ for $t'-t-1$ steps instead of $t'-t$ steps.
We can repeat this argument argument again and by backwards induction, the one-step-deviation principle holds.

Proof (infinite-horizon):
We proceed by contradiction. Consider a similar setup as above.
Suppose that a strategy profile $\boldsymbol{s}$ satisfies the one-step-deviation principle.
Suppose there exists some other strategy $\hat s_{i}$ such that it is better over multiple rounds after $t$ and $h^{t}$.
Let the amount of the improvement be $\eta>0$.
Now consider another strategy identical to $\hat s_{i}$ except after round $t'$ where it plays like $s_{i}$.
By continuity this strategy exists and it differs from $\hat s_{i}$ by $\varepsilon$.
We choose $\varepsilon < \eta$.
This strategy must improve on $s_{i}$ in a finite number of steps in the subgame starting at $h^{t}$.
But this contradict the fact that no finite sequence deviations can make any improvement at all.
