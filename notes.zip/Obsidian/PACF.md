---
tags:
  - MT4527
aliases:
  - PACF
---
Let $(X_{t})_{t \in \mathbb Z}$ be a [[Stationarity|weakly stationary]] [[Stochastic processes|stochastic process]].
Let $\rho_{X}(h)$ be the [[ACVF and ACF|ACF]] of $X$.
Let $R_{h}$ be the [[ACVF and ACF|autocorrelation matrix]] of lag $h$ of $X$.

> [!def] Definition
> The partial autocorrelation function $\alpha_{X}(h)$ of lag $h$ of $X$ is given by the ratio of the determinants
> $$\alpha_{X}(h)=\frac{|R_{h}^{*}|}{|R_{h}|}$$
> where $R_{h}^{*}$ is the matrix obtained from $R_{h}$ by replacing the last column by
> $$(\rho_X (1), \rho_X (2), ..., \rho_X (h))'.$$

> [!gen] Remarks
> - The intuitive understanding of $\alpha(h)$ is that it examines whether the correlation between $X_{t}$ and $X_{t-h}$ is solely due to both these random variables being correlated with intermediate random variables of the process.
> - Roughly speaking, $\alpha(h)$ measures the leftover correlation between $X_{t}$ and $X_{t-h}$ after accounting for their correlation with $x_{t-1},X_{t-2},...,X_{t-h+2},X_{t-h+1}$.
> - $\alpha(h)$ near one indicates that leftover correlation is strong.
> - $\alpha(h)$ near zero indicates that leftover correlation is weak or non-existent.

Motivation
Consider a AR(1) process $X_{t}=\phi X_{t-1}+\varepsilon_{t}$.
Then
$$\begin{align*}
&X_{t+1}= \phi_{11}X_{t}+\varepsilon_{t+1}\\
\implies& X_{t+1}X_{t}=\phi_{11}X_{t}^{2}+\varepsilon_{t+1}X_{t}\\
\implies& \mathbb E(X_{t+1}X_{t}) = \phi_{11} \mathbb E(X_{t}^{2})+\mathbb E(\varepsilon_{t+1}X_{t})\\
\implies& \gamma_{X} (1) = \phi_{11} \gamma_{X}(0)\\
\implies& \frac{\gamma_{X}(1)}{\gamma_{X}(0)} = \phi_{11}\\
\implies& \rho_{X}(1)= \phi_{11}.
\end{align*}$$
And also
$$\begin{align*}
&X_{t+2}= \phi_{21}X_{t+1}+\phi_{22}X_{t}+\varepsilon_{t+2}\\
\implies& X_{t+2}X_{t+1}= \phi_{21}X_{t+1}X_{t+1}+\phi_{22}X_{t}+X_{t+1}\varepsilon_{t+2}\\
\implies& \rho_{X}(1) = \phi_{21}\rho_{X}(0)+\phi_{22}\rho_{X}(1)\\
\implies& \rho_{X}(1)X_{t} = \phi_{21}\rho_{X}(0)X_{t}+\phi_{22}\rho_{X}(1)X_{t}\\
\implies& \rho_{X}(2) = \phi_{21}\rho_{X}(1)X_{t}+\phi_{22}\rho_{X}(0).
\end{align*}$$
Use last two equations 
$$\begin{cases}
\rho_{X}(1) = \phi_{21}\rho_{X}(0)+\phi_{22}\rho_{X}(1)\\
\rho_{X}(2) = \phi_{21}\rho_{X}(1)X_{t}+\phi_{22}\rho_{X}(0)
\end{cases}$$
or in matrix notation
$$\begin{bmatrix}1  & \rho_{X}(1) \\ \rho_{X}(1)  & 1\end{bmatrix}
\begin{bmatrix}\phi_{21} \\ \phi_{22}\end{bmatrix} = \begin{bmatrix}\rho_{X}(1)  \\ \rho_{X}(2)\end{bmatrix}$$
Use Cramer's rule.