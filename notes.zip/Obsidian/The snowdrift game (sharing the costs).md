---
tags:
  - MT4554
type: model
aliases: []
---
>[!gen] Why are we studying this?
>This game is not of the same structure as the Prisoner's dilemma so it is not a social dilemma but a anti-coordination game.
>Here we want to show that even if mutual cooperation is not an equilibrium of the static game, there is some degree of cooperation at equilibrium.
>
>Furthermore we want to show that in a population, the ratio between cooperators and defectors corresponds to the probability found in the Nash equilibrium.
>We also want to show the stability of such equilibrium.

>[!def] Definition
>The snowdrift game is a game where the costs of cooperation are shared to generate a benefit for both (here $b>c>0$).
>
>![[snowdgame_att.png|300]]

>[!gen] Solution (one shot game)
>A [[Rationality|rational]] player would play $D$ if the other player plays $C$ and would play $C$ if the other player plays $D$. So both strategies are [[Rationalizability|rationalisable]] and neither strategy is [[Strictly dominated strategy|strictly dominated]].
>
>A [[Nash equilibrium]] is therefore the pure strategy profile $(C,D)$.
>There also exists a [[Mixed strategies|mixed strategies]] [[Nash equilibrium]]:
>Let $\sigma_{1}(C)=p_{1}$ and $\sigma_{2}(C)=p_{2}$. Then the expected payoff to player 1 is: $u_{1}(p_{1},p_{2})=(p_{1})(1-p_{2})(b-c)+(1-p_{1})(p_{2})(b)+(p_{1})(p_{2})(b-c/2)$.
>Recall that a Nash Equilibrium $(p_{1}^{*},p_{2}^{*})$ must be such that $u_{1}(p_{1}^{*},p_{2}^{*})\geqslant u_{1}(p_{1},p_{2}^{*}) \;\;\forall p_{1}\in[0,1]$.
>A necessary but not sufficient condition is that $\frac{du_{1}}{dp_{1}}=0$.
>That yields the condition $p_{2}=\frac{b-c}{b-c/2}$.
>A similar calculation for player 2 yields $p_{1}=\frac{b-c}{b-c/2}$.
>And hence the only strategy profile that yields a mixed Nash equilibrium is $p_{1}^{*}=p_{2}^{*}=\frac{b-c}{b-c/2}$.

>[!gen] Solution (population level)
>Suppose that there are $N$ players and $n$ players play $C$.
>Then the [[Population level payoff|population level payoffs]] are
>$$\begin{align*}
   V_{C} &= (n-1)\left(b- \frac{c}{2}\right)+(N-n)(b-c)\\
   V_{D} &= nb+(N-n-1)\cdot 0= nb\\
   \end{align*}$$
>And so a player that plays C will be incentivised to switch to $D$ if
>$$\begin{align*}
   &\;\;\;\;\;\;\;\;\;\;V_{D}>V_{C}\\
   &\iff nb > (n-1)\left(b- \frac{c}{2}\right)+(N-n)(b-c)\\
   &\iff nb>nb- \frac{nc}{2} -b+ \frac{c}{2} + Nb - Nc-nb+nc\\
   &\iff 0 > + \frac{nc}{2}-b+ \frac{c}{2} + N(b-c) -nb\\\\
   &\iff 0 > n\left( \frac{c}{2}-b\right)+ \frac{c}{2}-b +N(b-c)\\
   &\iff n(b-c/2)>N(b-c)-(b-c/2)\\
   &\iff n > N\left(\frac{b-c}{b-c/2}\right)-1
   \end{align*}$$
>And conversely a player will be incentivised to switch to $C$ if $n<N(\frac{b-c}{b-c/2})-1$.
>And so there is a [[Population level payoff|population level payoff]] when
>$$\frac{n^{*}}{N}= \frac{b-c}{b-c/2}- \frac{1}{N}$$
>If $N$ is large, the proportion of players that should cooperate is the same as the probability of cooperating found in the [[Nash equilibrium]].

>[!gen] [[Stability]] using [[Replicator dynamics|replicator dynamics]]
>Suppose there is a rare invading strategy $k$ where $\sigma_{i}(C)=p_{i}$, while the rest of the population use the resident strategy $\sigma^{r}(C)=p$.
>
>Calculating the [[Population level payoff|population level payoff]] to the invader
>$$V^{k}(p_{k},p)=(N-1)[p_{k}p(b-c/2)+(1-p_{k})p(b)+p_{k}(1-p)(b-c)]$$
>and
>$$\left.\frac{\partial V^{k}(p_{k},p)}{\partial p_{k}}\right\vert_{\sigma^{k}=\sigma^{r}}=p(b-c/2)+(1-p)(b-c)-pb$$
>This is zero when $p^{*}=\frac{b-c}{b-c/2}$ which is the Nash equilibrium for the game.

>[!gen] [[Evolutionary stable strategies]]
>We now investigate whether the equilibrium $p^{*}=\frac{b-c}{b-c/2}$ found above is an evolutionary stable strategy.
>Now we calculate that
>$$\begin{align*}
   u(p^{*},p) &= p^*p(b-c/2)+p^{*}(1-p)(b-c)+(1-p^{*})pb \\
   &= p(b-c)+(1-p)( \frac{b-c}{b-c/2})(b-c)+ \frac{c/2}{b-c/2}pb\\
   u(p,p) &= p^{2}( b-c/2)+ p(1-p)(b-c)+(1-p)p(b)\\
   &= p^{2}( b-c/2)+ p(1-p)(2b-c)\\
   &= p^{2}( b-c/2)+ 2p(1-p)(b-c/2)\\
   &= (p^{2}+2p(1-p))(b-c/2)
   \end{align*}$$
>and the condition for a evolutionary stable strategy is $p^{*}$ is a Nash equilibrium (checked), and
>$$\begin{align*}
   &\;\;\;\;\;\;\;\;\;\;u(p^{*},p)>u(p,p)\\
   &\iff (p^{2}+2p(1-p))(b-c/2)>p(b-c)+(1-p)( \frac{b-c}{b-c/2})(b-c)+ \frac{c/2}{b-c/2}pb\\
   &\iff \frac{1}{4}\frac{2b(1-p-c(2-p))^{2}}{b-c/2}>0\\
   \end{align*}$$
>which is always true.
