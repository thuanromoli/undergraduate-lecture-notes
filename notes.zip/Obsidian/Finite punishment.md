---
tags:
  - MT4554
type: model
aliases:
---
Consider the [[The prisoner's dilemma|Prisoner's Dilemma]] and its [[Solving the prisoner's dilemma|solution]].
The [[Trigger strategy|trigger strategy]] does indeed enforce cooperation however, switching to defection for all subsequent rounds in response to a single deviation from cooperation may not be desirable in general.
In particular it does not allow for the possibility of "errors" or misunderstandings.

We can instead consider a forgiving trigger strategy that defects for $P$ rounds in response to deviation, then returns to cooperation.

The payoff in response to a one-step deviation at round $t'$ is then
$$\begin{align*}
 U_{1}(\hat s,\text{Forgiving grim})&= (1-\delta)\left(\sum\limits_{t=0}^{t'-1}\sigma^{t}u_{CC}+\sum\limits_{t=t'}^{t'}\sigma^{t}u_{DC}+\sum\limits_{t=t'+1}^{P+t'}\sigma^{t}u_{DD}+\sum\limits_{t=t'+P+1}^{\infty}\sigma^{t}u_{CC}\right)\\
 &= (1-\delta) \left(\frac{1-\delta^{t'}}{1-\delta}u_{CC}+\delta^{t'}u_{DC}+ \sum\limits_{t=0}^{P-1}\sigma^{t}u_{DD} + \frac{\delta^{t'+P+1}}{1-\delta}u_{CC}\right)\\
 &= (1-\delta^{t'})u_{CC}+(1-\delta)\delta^{t'}u_{DC}+(1-\delta^{P})u_{DD}+\delta^{t'+P+1}u_{CC}\\
 &= (1+\delta^{t'+P+1}-\delta^{t'})u_{CC}+(1-\delta)\delta^{t'}u_{DC}+\delta^{t'+1}(1-\delta^{P})u_{DD}
 \end{align*}$$
So to enforce cooperation the conditions is the following
$$\begin{align*}
 & \;\;\;\;\;\;\;\;\;\;U_{1}(\text{FGrim},\text{Fgrim})>U_{1}(\hat s,\text{FGrim})\\
 &\iff u_{CC}>(1+\delta^{t'+P+1}-\delta^{t'})u_{CC}+(1-\delta)\delta^{t'}u_{DC}+\delta^{t'+1}(1-\delta^{P})u_{DD}\\
 &\iff u_{CC}>u_{CC}+\delta^{t'+P+1}u_{CC}-\delta^{t'}u_{CC}+\delta^{t'}u_{DC}-\delta^{t'+1}u_{DC}+\delta^{t'+1}u_{DD}-\delta^{t'+P+1}u_{DD}\\
 &\iff 0>\delta^{P+1}u_{CC}-u_{CC}+u_{DC}-\delta u_{DC}+ \delta u_{DD}- \delta^{P+1}u_{DD}\\
 &\iff u_{DC}-u_{CC}<\delta(-\delta^{P}u_{CC}+u_{DC}-u_{DD}+\delta^{P}u_{DD})\\
 &\iff u_{DC}-u_{CC} < \delta[(u_{DC}-u_{DD})-\delta^{P}(u_{CC}-u_{DD})]
 \end{align*}$$
 Using the [[The donation game (charitable helping)|donation game]] payoffs, the condition becomes
 $$\frac{c}{b}<\delta\left[1-\delta^{P}\left(1-\frac{c}{b}\right)\right]$$
 and if $\delta$ is close to 1,
 $$P> \frac{c}{b-c}$$
