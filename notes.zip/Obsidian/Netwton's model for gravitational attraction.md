---
type: model
tag: MT2507
---
Let two [[Particle (Dynamics)|particles]] of masses $M$ and $m$ be a [[distance]] $r$ apart.

>[!def] Vector definition
>The force of gravitational attraction $\boldsymbol{F}$ on each object is $$\boldsymbol{F}=-\frac{GMm}{|\boldsymbol{r}|^{2}} \hat{\boldsymbol{r}}$$where $\boldsymbol{r}$ is the vector from one particle to the other.

>[!def] Scalar definition
>The force of gravitational attraction $\boldsymbol F$ on each object has magnitude $$F=|\boldsymbol F|=\frac{GMm}{r^2}$$in the direction of the other object.
