---
type: thm
tags:
  - MT2505
  - MT4003
---
Let $F$ be a [[Fields (Algebra)|field]] and $n>0 \in \mathbb{Z}$.

> [!def] Definition
> The general linear group of degree $n$ over $F$ written $GL_{n}(F)$ is the set of all $n \times n$ [[Matrices|matrices]] over the field F that have non-zero determinant:
> $$GL_{n}(F)=\set{A\in M_{n}(F):\det A \ne 0}$$
> together with [[Matrix multiplication|matrix multiplication]] as [[Binary operations|binary operation]].

>[!thm] Theorem
>$GL_{n}(F)$ is indeed a [[Groups|group]].
>
> Proof: use axioms.
> We can treat a matrix as a function $M_{n}(F):F^{n}\to F^{n}$ so [[Theorems about function composition#^62b5af|by associativity of functions]], matrix multiplication is associative.
> The [[Identity matrices|identity matrix]] $I_{n}$ has the property that $IA=AI=A$ for all $M_{n}(F)$.
> If $\det A\neq 0$ then $A$ has an inverse $A^{-1}$ such that $AA^{-1}=A^{-1}A=I$.
