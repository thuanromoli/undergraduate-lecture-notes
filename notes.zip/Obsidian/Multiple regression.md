---
type: def
tag: MT2508
alias: multiple linear regression
---
Let $Y$ be the [[Response variable|response variable]] and $x$ be the [[Explanatory variable|explanatory variable]].

>[!gen]+ [[Regression|REGRESSION MODEL]]:
>$Y_{i} =\alpha +\beta_{1} x_{1i}+\ldots+\beta_{k}x_{ki}+ \varepsilon_{i}$ where $\alpha$ and $\beta_{1},...,\beta_{k}$ are parameters that can be estimated using a higher dimension generalisation of the [[Least-squares estimation]] and the [[Normal linear regression]] model.
