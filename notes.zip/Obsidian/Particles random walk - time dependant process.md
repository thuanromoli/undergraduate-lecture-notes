---
tags:
  - MT4551
aliases:
---
Consider a [[Particles random walk - standard settings|particles random walk]].

> [!thm] Theorem
> Recall the [[Particles random walk - continuous process|the previous result]]: $P(s) = \left(\frac 2 {\pi N} \right)^{\frac{1}{2}}e^{-s^{2}/2N}$ where $P(s)$ is the probability of being a distance $s \Delta$ from the origin.
> 
> We now introduce a time dependancy.
> Let $n = \frac{\text{no. of jumps}}{\text{unit time}}$ and $x = s \Delta= \text{displacement}$, where we assume small jumps and continuous displacement.
>
>Now we wish to compare the discrete process to the continuous one.
> ![[parwalk_att.png|400]]
> In the interval $dx$, we have $dx / \Delta$ discrete points.
> 
> Note: if we take an even number of steps we can only access points that are even and similar for odd.
> 
> So the number of points that are accessible in the interval $dx$ is $\frac{dx}{2\Delta}$,
> 
> Now we further assume that $\mathbb P(\text{ending at point } i)=\mathbb P(\text{ending at point } j)$, in other words, we assume that the probability of ending in any point in $dx$ is $P(s)$.
> 
> Hence $\mathbb P(\text{ending in the interval }dx)=\mathbb P \text{(ending in any point in the interval)}$ = $\mathbb P\left(\text{ending in any of the }\frac{dx}{2\Delta} \text{ points}\right)$= $P(s) \frac{dx}{2\Delta}$.
> Hence $P(x)dx = P(s) \frac{dx}{2\Delta}$ and we obtain
> $$P(x) = \frac{1}{\sqrt{2 \pi \Delta^{2}N}}e^{\frac{-x^{2}}{2N \Delta^{2}}}$$
> (note this is justified by the [[Central Limit Theorem]]).
> 
> We now let $N = nt$ to obtain 
> $$P(x) = \frac{1}{2\sqrt{\pi Dt}} \exp\left\{\frac{-x^{2}}{4Dt}\right\}$$
> where $D = \frac{1}{2}n \Delta^{2}$, the diffusion coefficient.
> 
> We lastly note that this represent a [[Normal distribution|normal distribution]] so $\mu= 0$ and $\sigma_{v}^{2}=2Dt$.
