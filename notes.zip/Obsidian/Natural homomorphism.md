---
tags:
  - MT4003
aliases:
---
Let $G$ be a [[Groups|group]], $N$ be a [[Normal subgroups|normal]] [[Subgroups|subgroup]] of $G$ and $G/N$ the [[Quotients groups|quotient group]] of $N$ in $G$.

> [!def] Definition
> The natural homomorphism associated to $N$ is a [[Functions|function]] $\pi:G \to G/N$ such that
> $$x \pi = Nx \;\;\forall x \in G$$

> [!thm] Theorem
> The natural homomorphism $\pi$ is an [[Homomorphisms|homomorphism]].
> 
> Proof:
> $(xy)\pi = N(xy) = Nx \cdot Ny = (x \pi)(y \pi)$ for all $x, y\in G$.
