---
tags:
  - MT4527
aliases:
---
Let $(X_{t})_{t=1,...,T}$ be a sequence of [[Random variables|random variables]] with finite variance.

> [!gen] [[Statistical hypothesis|Hypothesis]]
> $H_{0}$: $\rho_{X}(1)=\cdots=\rho_{X}(m)=0$.
> $H_{1}$: not the above.

> [!gen] Portmanteau [[Test statistics]]
> $$Q^{*}(m) = T \sum\limits_{l=1}^{m} \hat \rho^{2}_{X}(l) \sim \chi^{2}_{m}.$$

> [!gen] Ljung-Box [[Test statistics]] (finite samples)
> $$Q(m) = T(T+2) \sum\limits_{l=1}^{m} \frac{\hat \rho^{2}_{X}(l)}{T-l} \sim \chi^{2}_{m}.$$

Note: in practice $m$ may affect the performance of the statistic. As a rule of thumb use $m \approx \ln T$.
