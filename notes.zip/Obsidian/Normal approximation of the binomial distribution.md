---
type: mthd
tag: MT2508
---
>[!gen]+ INTUITION
>Use the fact that if $X_1,...,X_n$ are [[Independent events|independent]] identically distributed rvs from a [[Bernoulli distribution]] then $\sum\limits_{i=1}^{n}X_{i} \sim \text{Bin}(n,p)$, with $\mathbb{E}(X_i)=p$ and $\text{Var}(X_i)=p(1-p)$.

>[!gen]+ [[Normal distribution|NORMAL]] APPROXIMATION
>By the [[Central Limit Theorem]]:
>$$\frac{X-np}{\sqrt{np(1-p)}}\ \ \dot\sim \ \ N(0,1) \ \ \ \text{or} \ \ \ X \  \ \dot\sim \ \ N(np,np(1-p)) \ \ \ \text{as } n\to \infty$$

>[!gen]+ APPROXIMATE [[Confidence intervals|CI]] FOR $p$
>$\mathbb{P}(-z_{1-\alpha /2}< \frac{X-np}{\sqrt{np(1-p)}}<z_{1-\alpha /2})=1-\alpha$
>using the [[Maximum Likelihood Estimator]] $\hat p= X/n$
>$\mathbb{P}(-z_{1-\alpha /2}< \frac{X-np}{\sqrt{n\hat p(1-\hat p)}}<z_{1-\alpha /2})=1-\alpha$
>$\mathbb{P}(\frac{X}{n}-z_{1-\alpha /2} \sqrt{\frac{\hat p (1-\hat p)}{n}}<p<\frac{X}{n}+z_{1-\alpha /2} \sqrt{\frac{\hat p (1-\hat p)}{n}}) = 1-\alpha$
>The $100(1-\alpha)\%$ C.I is $(\hat p-z_{1-\alpha /2} \sqrt{\frac{\hat p (1-\hat p)}{n}},\hat p +z_{1-\alpha /2} \sqrt{\frac{\hat p (1-\hat p)}{n}})$

>[!gen]+ VALIDITY
>This approximation is valid if $\text{min}(np,n(1-p))>5$

---

#### Spaced repetition

Explain how to get a normal approximation of the binomial distribution
?
INTUITION:
	Use the fact that if $X_1,...,X_n$ are [[Independent events|independent]] identically distributed rvs from a [[Bernoulli distribution]] then $\sum\limits_{i=1}^{n}X_{i} \sim \text{Bin}(n,p)$, with $\mathbb{E}(X_i)=p$ and $\text{Var}(X_i)=p(1-p)$.
[[Normal distribution|NORMAL]] APPROXIMATION:
	By the [[Central Limit Theorem]]: $$\frac{X-np}{\sqrt{np(1-p)}}\ \ \dot\sim \ \ N(0,1) \ \ \ \text{or} \ \ \ X \  \ \dot\sim \ \ N(np,np(1-p)) \ \ \ \text{as } n\to \infty$$
APPROXIMATE [[Confidence intervals|CI]] FOR $p$:
	$\mathbb{P}(-z_{1-\alpha /2}< \frac{X-np}{\sqrt{np(1-p)}}<z_{1-\alpha /2})=1-\alpha$
	using the [[Maximum Likelihood Estimator]] $\hat p= X/n$
	$\mathbb{P}(-z_{1-\alpha /2}< \frac{X-np}{\sqrt{n\hat p(1-\hat p)}}<z_{1-\alpha /2})=1-\alpha$
	$\mathbb{P}(\frac{X}{n}-z_{1-\alpha /2} \sqrt{\frac{\hat p (1-\hat p)}{n}}<p<\frac{X}{n}+z_{1-\alpha /2} \sqrt{\frac{\hat p (1-\hat p)}{n}}) = 1-\alpha$
	The $100(1-\alpha)\%$ C.I is $(\hat p-z_{1-\alpha /2} \sqrt{\frac{\hat p (1-\hat p)}{n}},\hat p +z_{1-\alpha /2} \sqrt{\frac{\hat p (1-\hat p)}{n}})$
VALIDITY:
	This approximation is valid if $\text{min}(np,n(1-p))>5$
