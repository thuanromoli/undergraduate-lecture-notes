---
tags:
  - MT4003
aliases:
---
Let $G$ be a [[Groups|group]], and let $x,y \in G$.

> [!thm]- $[x,y]=1$ if and only if $x$ and $y$ [[Commutators|commute]]. In particular, $G' = \boldsymbol{1}$ if and only if $G$ is [[Abelian groups|abelian]].

> [!thm] Theorem
> The [[The derived subgroup|derived]] [[Subgroups|subgroup]] of $G$ is the smallest [[Normal subgroups|normal]] subgroup $N$ of $G$ such that the [[Quotients groups|quotient]] group $G/N$ is abelian.
> 
> In other words, if $N \mathrel{\unlhd} G$ and $G/N$ is abelian then $G' \leqslant N$.

^5a1a40

We want to show that $G'$ is normal, then that $G/G'$ is abelian, and finally that $G' \leqslant N$.

$G'$ is a normal subgroup of $G$.
Let $x \in G'$. Then write $x=c_{1}c_{2}\cdots c_{k}$ as a product of commutators.
Now, $x^{g}=c_{1}^{g}c_{2}^{g}\cdots c_{k}^{g} \in G'$ since $c_{1}^{g},...,c_{k}^{g}$ are also commutators [[Theorems about commutators#^a0d9d9|by this theorem]], and so $c_{1}^{g}c_{2}^{g}\cdots c_{k}^{g}$ is a product of commutators. Thus $G' \mathrel{\unlhd} G$.

$G/G'$ is an abelian quotient.
Let $G'x,G'y \in G/G'$.
Then consider the products $(G'x)(G'y)=G'(xy)$ and $(G'y)(G'x)=G'(yx)$.
[[Theorems about cosets#^c02b25|By this theorem]], $G'(xy)=G'(yx) \iff xy(yx)^{-1} \in G'$.
Note: $xy(yx)^{-1}=xyx^{-1}y^{-1}=[x^{-1},y^{-1}]=[x,y]^{-1}\in G'$.
So, working backwards $G'(xy)=G'(yx) \implies G'(x)G'(y) = G'(y)G'(x)$, and hence abelian.

$G'$ is minimal.
Let $N$ be a normal subgroup of $G$ such that $G/N$ is abelian.
For all $x,y \in G$,
$$\begin{align*}
N[x,y] &= Nx^{-1}y^{-1}xy\\
&= (Nx)^{-1}(Ny)^{-1}NxNy\\
&= N1 \;\;\text{ since }G/N \text{ is abelian.}
\end{align*}$$
So $N[x,y]=N1 \iff [x,y]1^{-1} \in N$, in particular $[x,y] \in N$.
Since $G'$ contains all commutators, it follows that $G' \leqslant N$.