---
type: mthd
tags:
  - MT2507
  - MT3504
aliases:
---
>[!gen] ODE
>$$y'+p(x)y=q(x)$$

>[!gen] Integrating factor
>$$\mu(x)=\exp\left(\int p(x) dx\right)$$
>such that $\frac{d\mu}{dx}=p(x)\mu(x)$.

>[!gen] Solution
>$$y'+p(x)y=q(x)$$
>$$\mu(x)y'+\mu(x)p(x)y=\mu(x)q(x)$$
>$$\mu(x)y'+ \frac{d\mu}{dx}y=\mu(x)g(x)$$
>$$\frac{d}{dx}(y \mu(x))=\mu(x)g(x)$$
>Then integrate.

>[!thm] Uniqueness of the solution
>Suppose that there are two solutions, $y_{1}$ and $y_{2}$, to the linear [[Initial values and IVP|IVP]] $y'+p(x)y=q(x)$ with $y(x_{0})=y_{0}$.
>Then by considering the ODE:
>- (1) $y_{1}'+p(x)y_{1}=q(x)$ with $y_{1}(x_{0})=y_{0}$.
>- (2) $y_{2}'+p(x)y_{2}=q(x)$ with $y_{2}(x_{0})=y_{0}$.
>
>Then let $u(x)=y_{1}(x)-y_{2}(x)$ and by subtracting (1) and (2):
>$$u'+p(x)u=0 \;\; \text{ with } \;\; u(x_{0})=0$$
>By integrating, we obtain $\int \frac{du}{u} = - \int p(x) dx$.
>This gives $u(x)=A\exp\left(-\int p(x)dx\right)$ where $A$ is an arbitrary constant of integration. The initial condition $u(x_{0})=0$ then implies that $A=0$ since $\exp\left(-\int p(x)dx\right)>0$ and so $u({x})\equiv 0$.
>Hence $y_{1}=y_{2}$.
>So a first-order linear ODE has a unique solution.

---

#### Spaced repetition

What is the form of a linear first-order ODE?
?
>$y'+p(x)y=q(x)$

How do you solve $y'+p(x)y=q(x)$?
?
>Using integrating factor $\mu(x)=\exp \left(\int(p(x))dx\right)$
>$\mu(x)y'+\mu(x)p(x)y=\mu(x)q(x)$
>$\mu(x)y'+ \frac{d\mu}{dx}y=\mu(x)g(x)$
>$\frac{d}{dx}(y \mu(x))=\mu(x)g(x)$
>Then integrate.

Prove that the solution to a linear first-order ODE is unique.
?
>Suppose that there are two solutions, $y_{1}$ and $y_{2}$, to the linear [[Initial values and IVP|IVP]] $y'+p(x)y=q(x)$ with $y(x_{0})=y_{0}$.
>Then by considering the ODE:
>- (1) $y_{1}'+p(x)y_{1}=q(x)$ with $y_{1}(x_{0})=y_{0}$.
>- (2) $y_{2}'+p(x)y_{2}=q(x)$ with $y_{2}(x_{0})=y_{0}$.
>
>Then let $u(x)=y_{1}(x)-y_{2}(x)$ and by subtracting (1) and (2):
>$$u'+p(x)u=0 \;\; \text{ with } \;\; u(x_{0})=0$$
>By integrating, we obtain $\int \frac{du}{u} = - \int p(x) dx$.
>This gives $u(x)=\exp\left(-\int p(x)dx\right)=A\mu^{-1}$ where $A$ is an arbitrary constant of integration. The initial condition $u(x_{0})=0$ then implies that $A=0$ and so $u_{x}\equiv 0$.
>Hence $y_{1}=y_{2}$.
>So a first-order linear ODE has a unique solution.