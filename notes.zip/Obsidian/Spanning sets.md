---
tags:
  - MT3501
type: def
aliases:
  - spanning set
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$, and let $W$ be a subspace of $V$.

>[!def] Definition
>The spanning set for a subspace $W$ is some subset $\mathscr{A}$ of $W$ such that $\text{Span}(\mathscr A)=W$.
