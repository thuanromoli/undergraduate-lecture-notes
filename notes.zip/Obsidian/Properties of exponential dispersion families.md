---
tags:
  - MT3508
aliases:
---
> [!thm] Theorem
> The [[Exponential dispersion families|exponential dispersion families]] have the following property:
> $$\text{Var }(Y|X) = \varphi V\{\mathbb E(Y|X) \}$$
> for some transformation $f$ and proportionality constant $\varphi$, called the dispersion.
> In other words, the variance is the proportional to a function of the expectation.
