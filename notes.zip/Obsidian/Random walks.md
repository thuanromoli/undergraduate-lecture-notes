---
tags:
  - MT4527
aliases:
---
Let $\varepsilon := (\varepsilon_{t})_{t \in \mathbb Z}$ be a white noise.

> [!def] Random walk (without drift)
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is called a random walk (without drift) if we have for all $t \in \mathbb Z$
> $$X_{t}= X_{t-1} + \varepsilon_{t}.$$

> [!def] Random walk (with drift)
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is called a random walk (with drift $\alpha_{0} \in \mathbb R$) if we have for all $t \in \mathbb Z$
> $$X_{t}= \alpha_{0} + X_{t-1} + \varepsilon_{t}.$$
