---
tags:
  - MT4003
aliases:
---
Let $p$ be a prime number, and let $G$ be a [[Order|finite]] [[Groups|group]] of order $p^{n}m$, where $p$ does not divide $m$.

> [!thm] Theorem
> Sylow's Theorem tells us that:
> 1. $G$ has a [[Sylow p-subgroups|Sylow p-subgroup]].
> 2. Any two [[Sylow p-subgroups]] of $G$ are [[Conjugacy|conjugate]].
> 3. The number of [[Sylow p-subgroups]], denoted $n_{p}$, satisfies:
> 	- $n_{p} \equiv 1 \pmod p$
> 	- $n_{p} \mid m$.
> 4. Every [[p-subgroups|p-subgroup]] of $G$ is contained in a [[Sylow p-subgroups|Sylow p-subgroup]].

> [!gen] Remarks
> If $P$ is a [[Sylow p-subgroups|Sylow p-subgroup]] of $G$ and $g \in G$, then the conjugate $P^{g}$ is also a [[Subgroups|subgroup]] of $G$ and, since the [[Conjugacy|conjugation]] map $\tau_{g}:x \mapsto x^{g}$ is an [[Automorphisms|inner automorphism]], $|P^{g}| = |P|$.
> Thus $P^{g}$ is also a [[Sylow p-subgroups|Sylow p-subgroup]]. Part (2.) tells us that every [[Sylow p-subgroups|Sylow p-subgroup]] arises in this manner.

We divide the proof in two parts. We first prove part (1.) and then we develop some lemmas to prove parts (2. - 4.).

So we start by proving the existence of a Sylow $p$-subgroup inside $G$.
We induct on $|G|$. If $|G| = 1$, or more generally if $p^{n}=1$, then the trivial subgroup is a Sylow $p$-subgroup.
So assume that when $|G| > 1$ and $p^{n}>1$, a Sylow $p$-subgroup exists.
Let $\mathscr C_{1},..., \mathscr C_{k}$ be the [[Conjugacy classes|conjugacy classes]] of size greater than 1, and let $x_{i} \in \mathscr C_{i}$ for each $i$.
Then by [[The class equation|the class equation]], $|G| = |Z(G)| + \sum\limits_{i=i}^{k}|G:C_{G}(x_{i})|$.
We now consider two cases, one where $p^{n}$ divides $|G:C_{G}(x_{i})|$ and its opposite.
Assume first that $p^{n}$ divides $|C_{G}(x_{i})|$ for some $i \in \set{1,...,k}$.
It follows from [[The orbit-stabiliser theorem|the orbit-stabiliser theorem]] that $|G:C_{G}(x_{i})| = |\mathscr C_{i}| > 1$, and so by [[Lagrange's Theorem]] $|G:C_{G}(x_{i})|=\frac{|G|}{|C_{G}(x_{i})|}>1$.
Hence $|G| > |C_{G}(x_{i})|$, and by induction $C_{G}(x_{i})$ contains a subgroup $Q$ of order $p^{n}$. Then $Q$ is a Sylow $p$-subgroup of $C_{G}(x_{i})$, and hence of $G$.
Assume instead that $p^{n}$ does not divide any of the orders $|C_{G}(x_{i})|$ and hence (since $p^{n}>1)$ $p$ divides the index $|G:C_{G}(x_{i})|$ for all $i \in \set{1,...,k}$.
It now follows from the class equation that $p$ divides $|Z(G)|$.
Now [[The centre|the centre]] $Z(G)$ is an [[Abelian groups|abelian]] group of order divisible by $p$.
By a theorem, $N \leqslant Z(G) \implies N \mathrel{\unlhd} G$.
As $|N| = p$, the [[Quotients groups|quotient group]] $G/N$ has order $p^{n-1}m$.
By induction, $G/N$ has a Sylow $p$-subgroup, and this has order $p^{n-1}$.
By [[The Correspondence Theorem|the correspondence theorem]], this Sylow $p$-subgroup has the form $H/N$ where $H$ is a subgroup of $G$ with $N \leqslant H \leqslant G$.
As $|H/N|=p^{n-1}$ and $|N| = p$, we conclude that $H = p^{n}$ and so $H$ is a Sylow $p$-subgroup of $G$.
Hence each finite group $G$ contains a Sylow $p$-subgroup.

We now proceed to prove some lemmas.
Let $\Sigma = \set{P^{g}:g \in G}$ where $P$ is a Sylow $p$-subgroup. That is, $\Sigma$ is the set of all conjugates of $P$ in $G$, namely the [[Orbits|orbit]] of $P$ under conjugation action of $G$ on the set of all subgroups.

> [!thm]- Let $p$ be a prime number, $Q$ a Sylow $p$-subgroup of $G$ and $R$ any $p$-sungroup of $G$. Then $$\begin{align*}
&(1): R \leqslant N_{G}(Q) \iff R \leqslant Q \\
&(2): \set{Q^{x}:x \in R} = \set{Q} \iff R \leqslant Q
\end{align*}$$

> [!thm]- The size of the $G$-orbit $\Sigma = \set{P^{g}: g \in G}$ satisfies $|\Sigma|\equiv 1 \pmod p$

Proof of part 2.
Let $Q$ be any Sylow $p$-subgroup of $G$.
Let $\Gamma_{1},...,\Gamma_{k}$ be the orbits of $Q$ in its action on $\Sigma$.
Since $Q$ is a $p$-group, each orbit $\Gamma_{i}$ has size a power of $p$ by the orbit-stabiliser theorem.
Now $|\Gamma_{1}| + \cdots + |\Gamma_{k}| = |\Sigma| \equiv 1 \pmod p$, by the above lemma.
Therefore some $|\Gamma_{i}|$ is not divisible by $p$, and so has size 1, say $\Gamma_{i}= \set{R_{i}}$.
Then $Q \leqslant R_{i}$ by the above lemma.
But $Q$ and $R_{i}$ are both Sylow $p$-subgroups of $G$, so $Q=R_{i} \in \Sigma$.
Hence every Sylow $p$-subgroup of $G$ is a conjugate of $P$, as required.

Proof of part 3.
We know that $\Sigma$ is the set of all Sylow $p$-subgroups of $G$.
The above lemmas show that $|\Sigma| \equiv 1 \pmod p$, so the number of Sylow $p$-subgroups of $G$ is congruent to $1 \pmod p$.
Also, using [[Theorems about normalisers#^ed07aa|this theorem]], we have $|\Sigma| = |G:N_{G}(P)| = \frac{|G|/|P|}{|N_{G}(P)|/|P|} = \frac{|G:P|}{|N_{G}(P):P|}=\frac{m}{|N_{G}(P):P|}$.
Hence the number of Sylow $p$-subgroups of $G$ divides $m$.

Proof of part 4.
Let $Q$ be any $p$-subgroup of $G$ (not necessarily a Sylow subgroup).
Let $\Gamma_{1},...,\Gamma_{k}$ be the orbits of $Q$ in its action on $\Sigma$ by conjugation.
Since $Q$ is a $p$-group, each $\Gamma_{i}$ has size a power of $p$, by the orbit-stabiliser theorem.
Since $|\Sigma| \equiv 1 \pmod p$, at least one $|\Gamma_{i}|$ is not divisible by $p$ and so is equal to 1, say $\Gamma_{i} = \set{R_{i}}$.
Then $Q \leqslant N_{G}(R_{i})$ by the above lemma and $Q \leqslant R_{i}$, as required.