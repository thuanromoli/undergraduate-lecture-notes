---
type: thm
tags:
  - MT2505
  - MT4003
---
Let $\phi: G \to H$ be a [[Homomorphisms|homomorphism]] from a [[Groups|group]] $G$ to a [[Groups|group]] $H$.

> [!thm]- The [[Kernel|kernel]] of $\phi$ is a [[Normal subgroups|normal]] [[Subgroups|subgroup]] of $G$
> First we want to prove that $\ker \phi$ is a subgroup, then that it is normal.
> Firstly, $1_{G} \phi=1_{H}$ hence $1_{G}\in \ker \phi$, in particular $\ker \phi$ is non-empty.
> Let $x,y \in \ker \phi$. Then $(xy)\phi=(x \phi)(y \phi)=1\cdot 1= 1$ so $xy\ker \phi$. Also $(x^{-1})\phi=(x \phi)^{-1}=1^{-1}=1$ and so $x^{-1} \in \ker \phi$.
> So we conclude $\ker \phi \leqslant G$.
> 
> Now we wish to show that $\forall x\in \ker \phi$ and $g\in G$, $x^{g}\in\ker \phi$.
> $(x^{g})\phi=(g^{-1}xg)\phi = (g^{-1}\phi)(x \phi)(g \phi) = (g\phi)^{-1}(1)(g \phi)=1$. Hence $\ker \phi \mathrel{\unlhd} G$.

^b80cab

> [!thm]- The [[Image|image]] of $\phi$ is a [[Subgroups|subgroup]] of $H$
> $1 \phi=1$ so $\text{im }\phi$ is non-emtpy.
> Let $g,h\in \text{im } \phi$ then there exists $x,y\in G$ such that $g =x \phi$ and $h = y \phi$.
> Then $gh = (x \phi)(y \phi)  = (xy)\phi \in \text{im }\phi$.
> And also $g^{-1} = (x \phi)^{-1} = x^{-1}\phi \in \text{im } \phi$.
> Hence $\text{im } \phi \leqslant H$.

^06df95

> [!thm]- $\phi$ is [[Injective functions|injective]] if and only if $\ker \phi=\set{1_{G}}$
> Suppose that $\phi$ is injective. Then $x \phi = y \phi \implies x=y$ for all $x,y \in G$.
> Let $x \in \ker \phi$. Then $x \phi = 1 = 1 \phi \implies x=1$ so $\ker \phi = \boldsymbol{1}$.
> Conversely, suppose that $\ker \phi = \boldsymbol{1}$.
> Suppose that $x \phi = y \phi$. Then
> $$\begin{align*}
   (xy^{-1}) \phi &= (x \phi) (y^{-1} \phi)\\
   &= (x \phi) (y \phi)^{-1}\\
   &= (x \phi) (x \phi)^{-1}\\
   &= 1
   \end{align*}$$
> so $xy^{-1}\in \ker \phi$. In particular, $xy^{-1}=1 \implies x=y$.

> [!thm]-  $\phi$ is [[Surjective functions|surjective]] if and only if $\text{im } \phi=H$

^fa67a2
