---
tags:
  - MT4003
aliases:
  - the class equation
---
Let $G$ be a [[Order|finite]] [[Groups|group]].

> [!thm] Theorem
> Suppose that $\mathscr C_{1},...,\mathscr C_{k}$ are the [[Conjugacy classes|conjugacy classes]] of size $\geqslant 2$ and that $x_{i}$ is an element of $\mathscr C_{i}$ for $i = 1,...,k$.
> Then
> $$|G| = |Z(G)| + \sum\limits_{i=1}^{k} |G:C_{G}(x_{i})|.$$

Let $\mathscr C_{k+1},..., \mathscr C_{m}$ be the conjugacy classes of size 1 and let $\mathscr C_{i}=\set{x_{i}}$ for $i = k+1,...,m$.
[[Theorems about the centre#^55ac96|By this theorem]], $x_{i} \in \mathscr C_{i} \implies x_{i} \in Z(G)$ for $i = k+1,...,m$.
So [[The centre|the centre]] is the union of the conjugacy classes of size 1: $Z(G) = \set{x_{k+1},...,x_{m}} = \mathscr C_{k+1} \cup \cdots \cup \mathscr C_{m}$ and in particular, $|\mathscr C_{k+1}|+\cdots|\mathscr C_{m}|=|Z(G)|$.

Then we also have that the [[Centralisers|centraliser]] $C_G(x_{i})= \set{g \in G:x_{i}g=gx_{i}}$ is the [[Stabilisers|stabiliser]] of $x_{i}$ in the conjugation action of $G$ on its elements.
Hence by [[The orbit-stabiliser theorem|the orbit-stabiliser theorem]], $|\mathscr C_{i}| = |G:G_{x_{i}}| = |G:C_{G}({x_{i}})|$.

Moreover, $G$ is the disjoin union of its conjugacy classes, so
$$\begin{align*}
|G| &= |\mathscr C_{1}| + \cdots + |\mathscr C_{k}| + |\mathscr C_{k+1}| + \cdots + |\mathscr C_{m}|\\
&= |G:C_{G}(x_{1})| + \cdots + |G:C_{G}(x_{k})| +|Z(G)|\\
&= \sum\limits_{i=1}^{k}|G:C_{G}(x_{i})| + Z(G).
\end{align*}$$
