---
type: mthd
tags:
  - MT2508
  - MT3508
---
Consider the [[normal linear regression]] model $Y_{i}\sim N(\alpha+ \beta x_{i}\sigma^{2})$ for $i=1,...,n$.

>[!gen] Assumptions
>- $Y_{1},...,Y_{n}$ are [[Independent events|independent]] (use [[The runs test (testing independence)|the runs test]]).
>- $Y_{1},...,Y_{n}$ are [[Normal distribution|normally distributed]] (use [[QQ plots]] or [[The Kolmogorov-Smirnov one-sample test (testing the distribution)|the K-S test]])
>- $Y_{1},...,Y_{n}$ are linear, $\mathbb{E}(Y_{i}) = \alpha + \beta x_{i}$ (use residuals-fitted plots).
>- $Y_{1},...,Y_{n}$ have the same variance (use scale-location plots and [[Bartlett test (testing the equality of variances)|Bartlett test]]).

Use the function in `R` called `plot`. The first three plots are:
1. `Residuals vs Fitted` of [[residuals]] $r_{1},...,r_n$ against the [[Fitted values|fitted values]] $\hat{y}_{1},...,\hat{y}_{n}$.
2. `Normal Q-Q plot` of the standardised residuals $r_{1}^{*},...,r_n^{*}$.
3. `Scale-Location plot` of $\sqrt{|r_{1}^{*}|},...,\sqrt{|r_{n}^{*}|}$ against the fitted values $\hat{y}_{1},...,\hat{y}_{n}$.
4. `Residual vs Leverage` see [[Leverage, Influence, and Cooke's distance]].

Here $r_{i}^{*}=\frac{r_{i}}{\sqrt{\hat{\text{Var}}(r_{i})}}$.

![[linassump_att.png]]

If the assumptions hold, we expect the following:
1. Should indicate linearity.
   Would show no obvious systematic pattern either horizontally or vertically.
2. Should indicate normality.
   Would show the majority of points should lie along the indicated line.
3. Should indicate equality of variance.
   Would show horizontal red line.
4. Should indicate no large influence.
   Would flag observations that have high leverage (if $\boldsymbol{A}_{ii}>2p/n$) or high Cooke's distance (if $C_{i}>8/(n-2p)$ or high residual (if $|r_{i}|>2|)$.
