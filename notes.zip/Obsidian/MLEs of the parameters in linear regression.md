---
type: def
tag: MT2508
---
>[!def] FORM
>Using [[Least-squares estimation]] or [[Normal linear regression]], we know that
>- $\hat\alpha = \bar y-\hat \beta \bar x$ 
>- $\hat\beta=\frac{SS_{XY}}{SS_{XX}}$.

>[!gen]+ EXPECTATION:
>- $\mathbb{E}(\hat \alpha)=\alpha$
>- $\mathbb{E}(\hat \beta)=\beta$

>[!gen]+ VARIANCE:
>- $\text{Var}(\hat\alpha)=\sigma^{2}\left(\frac{1}{n}+ \frac{\bar{x}^{2}}{SS_{XX}} \right)$
>- $\text{Var}(\hat\beta)=\left( \frac{\sigma^{2}}{SS_{XX}} \right)$

>[!gen]+ DISTRIBUTION:
>- $\hat\alpha \sim N\left(\alpha,\sigma^{2}\left(\frac{1}{n}+ \frac{\bar{x}^{2}}{SS_{XX}} \right)\right)$
>- $\hat\beta \sim N\left(\beta,\frac{\sigma^{2}}{SS_{XX}}\right)$
>
>PROOF:
>$\hat \alpha$ and $\hat \beta$ are linear combinations of [[Normal distribution|normal]] random variables so $\hat \alpha$ and $\hat \beta$ are also normally distributed

>[!gen]+ [[Confidence intervals|CI]]/[[Standard error|STANDARD ERROR]]:
>The [[Variance and standard deviation|variance]] of $\hat \alpha$ and $\hat \beta$ is unkown so we estimate it using the [[Sample variance|sample variance]] $S^{2}=\frac{1}{n-2} \sum\limits_{i=1}^{n}(Y_{i}-\hat{y}_{i})^{2}$.
>It turns out that $$\frac{\hat{\alpha}-\alpha}{\sqrt{S^{2}\left(\frac{1}{n}+ \frac{\bar{x}^{2}}{SS_{XX}}\right)}}\sim t_{n-2} \ \ \text{ and } \ \ \frac{\hat{\beta}-\beta}{\sqrt{\frac{S^{2}}{SS_{XX}}}}\sim t_{n-2}$$
>Further calculations show that the confidence intervals are $$\hat{\alpha}\pm t_{n-2;0.975}\sqrt{S^{2}\left(\frac{1}{n}+ \frac{\bar{x}^{2}}{SS_{XX}}\right)} \ \ \text{ and } \ \ \hat{\beta} \pm t_{n-2;0.975}\sqrt{\frac{S^{2}}{SS_{XX}}}$$
