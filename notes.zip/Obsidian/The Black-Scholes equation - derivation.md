---
tags:
  - MT4551
aliases:
  - Black-Scholes equation
---
Let $V(S(t),t)$ be the value of a financial derivative where $S(t)$ is the stock price following a [[Geometric Brownian motion]].

> [!thm] Theorem
> The Black-Scholes equation is the partial differential equation
> $$\frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2}V}{\partial S^{2}} + rS \frac{\partial V}{\partial S} -rV =0$$

Proof:
We start by using [[Itô's lemma]] with $x=S$, $a = \mu S$, $b = \sigma S$, and $G(S,t) = V(S,t)$.
$$dV = \left(\frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2} V}{\partial S^{2}}\right)dt + \frac{\partial V}{\partial S} dS$$
where the random behaviour is held in the final term.

The key idea of the B-S equation is to eliminate the randomness using a mixture of assets.
Consider the following portfolio:
- hold 1 unit of the financial derivative (value $+ V$)
- hold $\Delta$ of the underlying asset (value $-\Delta S$)

Now the value of the portfolio is
$$\Pi = V- \Delta S$$
and
$$\begin{align*}
d \Pi &= d(V-\Delta S)\\
&= dV- \Delta dS\\
&=  \underbrace{\left(\frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2} V}{\partial S^{2}}\right)dt}_{\text{deterministic}} + \underbrace{\frac{\partial V}{\partial S} dS - \Delta dS}_\text{random}
\end{align*}$$

Now we wish to eliminate the random part of the equation so we set
$$\frac{\partial V}{\partial S}dS - \Delta dS =0 \implies \Delta dS= \frac{\partial V}{\partial S}dS \implies \Delta= \frac{\partial V}{\partial S}.$$

But now this portfolio gives a [[Risk-free assets|risk-free]] return.
By the law of no [[Arbitrage|arbitrage]], the portfolio $\Pi$ must give a return at the [[Risk-free assets|risk-free]] rate. Hence
$$\begin{align*}
& d \Pi=r \Pi dt\\
\implies & \left(\frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2} V}{\partial S^{2}}\right)dt = r (V-\Delta S)dt\\
\implies & \frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2} V}{\partial S^{2}} = rV - r \Delta S\\
\implies & \frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2} V}{\partial S^{2}} = rV - r \frac{\partial V}{\partial S} S\\
\implies & \frac{\partial V}{\partial t} + \frac{1}{2} \sigma^{2}S^{2} \frac{\partial^{2} V}{\partial S^{2}} - rV + rS \frac{\partial V}{\partial S} =0\\
\end{align*}$$
