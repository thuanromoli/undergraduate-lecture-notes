---
tags:
  - MT4554
type: def
aliases:
---
>[!def] Definition
>For an iterated game, the reservation utility is the minimax stage game payoff to player $i$,
>$$w_{i}=\min\limits_{\sigma^{t}_{-i}}\max\limits_{\sigma^{t}_{i}}u_{i}^{t}({\sigma^{t}_{i}},{\sigma^{t}_{-i}})$$
>that is, the lowest payoff player $i$'s opponents can hold him to by any choice of $\sigma^{t}_{-i}$, provided that player $i$ correctly foresees $\sigma^{t}_{-i}$ and plays a best response to it.

>[!gen] Observation
>Player $i$'s payoff is at least $w_{i}$ in any static equilibrium and in any [[Nash equilibrium]] of the repeated game, regardless of the level of the discount factor.
