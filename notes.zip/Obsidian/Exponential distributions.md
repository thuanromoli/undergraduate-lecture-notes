---
type: def
tags:
  - MT2504
  - MT4528
  - MT3508
  - MT3507
---
> [!gen] Relationships to other distributions
> - [[Gamma distributions]] $\Gamma(1,\lambda)$

> [!gen] Parameters
> $\lambda \in (0,\infty)$ - rate

> [!gen] Support
> $x\in [0,\infty)$ - time until an event 

>[!gen] [[Probability density function]]
>$$f(x)= \lambda e^{-\lambda x}$$

> [!gen] Typical use
> Used for waiting time until some event. Similar to Geometric, but with continuous wait time, instead of integer number of events.

>[!thm] Properties
> - $X \sim \Gamma(1, \lambda) \implies X \sim \text{Expon}( \lambda)$
>   Proof: use definitions.
> - $\mathbb E(X) = \frac{1}{\lambda}$, $\text{Var }(X) = \frac{1}{\lambda^{2}}$
>   Proof: use [[Gamma distributions|gamma distribution]] properties with $\alpha=1$.
> - $X_{i}\sim \Gamma(1, \lambda)$, where $X_{i}$ are independent rvs $\implies \sum\limits_{i=1}^{n}X_{i} \sim \Gamma\left(n, \lambda\right)$
>   Proof: use [[Gamma distributions|gamma distribution]] properties with $\alpha=1$.
