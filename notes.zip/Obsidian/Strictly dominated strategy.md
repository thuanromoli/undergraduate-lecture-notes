---
tags:
  - MT4554
type: def
aliases:
  - strictly dominated
---
Let $s_{-i}\in S_{-i}$ denote a strategy selection for all players except $i$. Then $(s_{i},s_{-i})$ is used to indicate the [[Pure strategies|pure strategy]] profile $(s_{1},...,s_{i-1},s_{i},s_{i+1},...,s_{N})$.
Similarly, for [[Mixed strategies|mixed strategies]] let $\sigma_{-i}$ denote the mixed strategy selections for all players except $i$. Then $(\sigma_{i}',\sigma_{-i})$ is used to indicate the mixed strategy profile $(\sigma_{1},...,\sigma_{i-1},\sigma_{i}',\sigma_{i+1},...,\sigma_{N})$.

>[!def] Definition
>A pure strategy $s_{i}$ is strictly dominated for player $i$ if there exists $\sigma_{i}'\in \sum_{i}$ such that
>$$u_{i}(\sigma_{i}',s_{-i})>u_{i}(s_{i},s_{-i}), \;\;\forall s_{-i}\in S_{-i}$$
>
