---
tags:
  - MT3508
aliases:
---
> [!def] The problem
> 
|  | pay | n | leave | remain |
| ---- | ---- | ---- | ---- | ---- |
| 1 | 9.27 | 46100 | 32071 | 14029 |
| 2 | 8.58 | 61358 | 40177 | 21181 |
| 3 | 10.77 | 72714 | 48128 | 24586 |
| 4 | 10.60 | 100415 | 61982 | 38433 |
| 5 | 9.05 | 55166 | 30994 | 24172 |
| 6 | 9.35 | 65005 | 37327 | 27678 |
> 
> ![[brexitbin_att.png|400]]
> 
> ![[brexitd_att.png|400]]
> 
> What relationship is there between tendency to vote for Brexit and median hourly income?

> [!gen] Model 1
> From the first graph, a binomial probability model may be reasonable for these data as we have a known number of trials and an observed number of successes (in our case, "leave").
> - $\boldsymbol{y}$ is a vector containing the 380 _success_ counts.
> - $\boldsymbol{n}=(n_{1},...,n_{380})$ comprising the 380 known numbers of voters.
> - $\boldsymbol{\theta}=p$ is the proportion of residents in favour of Brexit.
> 
> $$f(\boldsymbol{y}; \boldsymbol{\theta}, \boldsymbol{n})= \prod_{i=1}^{380} {n_{1}\choose y_{1}} p^{y_{i}}(1-p)^{n_{i}-y_{i}}$$

> [!gen] Model 2
> From the second graph, we might think that the proportion of a local authority that voted on Brexit depends on income. We therefore build a model in which $p$ depends on $\boldsymbol{x}=(x_{1},...,x_{380})$.
