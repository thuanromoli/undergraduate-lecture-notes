---
tags:
  - MT2501
  - MT3501
type: def
aliases:
  - linearly dependent
  - linearly independent
  - linear independence
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$, and let $v_{1},...,v_{k}$ be some vectors from $V$.

>[!def] Definition
>The vectors $v_{1},...,v_{k}$ are linearly independent if the only solution to the equation
>$$\alpha_{1}v_{1}+\alpha_{2}v_{2}+\ldots+\alpha_{k}v_{k}=\boldsymbol{0}$$
>is $\alpha_{1}=\alpha_{2}=\cdots=\alpha_{k}=0$ with $\alpha_{i}\in F$.

---

#### Spaced repetition

When are the vectors $v_{1},...,v_{k}$ linearly independent?
?
>The vectors $v_{1},...,v_{k}$ are linearly independent if the only solution to the equation
>$$\alpha_{1}v_{1}+\alpha_{2}v_{2}+\ldots+\alpha_{k}v_{k}=\boldsymbol{0}$$
>is $\alpha_{1}=\alpha_{2}=\cdots=\alpha_{k}=0$ with $\alpha_{i}\in F$