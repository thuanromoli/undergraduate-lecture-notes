---
tags:
  - MT3503
aliases:
---
Let $z$ and $w$ be [[Complex numbers|complex numbers]].

> [!thm]- $|\text{Re }z| \leqslant |z|$ and $|\text{Im }z| \leqslant |z|$

> [!thm]- $|zw| = |z||w|$ and $\arg (zw) = \arg z + \arg w$

> [!thm]- $|\bar z| = |z|$ and $\arg (\bar z) = -\arg z$

> [!thm]- $|1/z| = 1/|z|$ and $\arg (1/ z) = -\arg z$

> [!thm]- $\overline{zw} = \bar z \bar w$

> [!thm] [[De Moivre's Theorem]]

> [!thm]- $z + \bar z = 2 \text{Re }z$ and $z - \bar z = 2i \text{Im }z$

> [!thm]- The distance between $z$ and $w$ is defined as $|z-w|$. This is justified by the fact that the modulus satisfies "The [[Triangle inequality]]".
