---
tag: MT2506
type: def
alias: [surface integral]
---
Let $S$ be the general surface area of integration, $\boldsymbol{\hat n}$ its normal, and $C$ the bounding curve. Note: these three object obey the RHR with Thumb $S$, First $C$, and Second $\boldsymbol{\hat n}$.

>[!def] Defiition
> The general surface integral is: $$\iint_S\boldsymbol F(\boldsymbol r) \cdot \,\text{d}\boldsymbol S=\iint_S\boldsymbol F(\boldsymbol r) \cdot \boldsymbol n\,\text{d}S=\iint_Sg(\boldsymbol r) \cdot \,\text{d}S$$
