---
tags:
  - MT3502
aliases:
---
> [!thm]- The metric $$d(x,y) = |x-y|$$ forms a [[Metric spaces|metric space]] on $\mathbb R$

> [!thm]- The discrete metric $$d(x,y) = \begin{cases} 0  & \text{ if }x=y \\ 1 & \text{ if }x\neq y\end{cases}$$ forms a [[Metric spaces|metric space]] on any set $X$

> [!thm]- The Euclidean (or usual) metric $$d\big((x_{1},x_{2}),(y_{1},y_{2})\big) = + \sqrt{|x_{1}-y_{1}|^{2}+|x_{2}-y_{2}|^{2}}$$ forms a [[Metric spaces|metric space]] on $\mathbb R^{2}$
