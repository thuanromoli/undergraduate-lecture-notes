---
tags:
  - MT4509
aliases:
---
Assume a homogenous and irrotational flow.

> [!thm] Theorem
> Everywhere in the fluid,
> $$\frac{\partial \phi}{\partial t}+H = f(t)$$
> where $H= \frac{1}{2}  |\nabla \phi|^{2}+\frac{ p}{\rho}+ gz$.
> 
> That is, $\frac{\partial \phi}{\partial t}+H$ is constant in space (but may change through time).

Direct proof by taking the curl of [[Euler's equation]].
We use the handy identity $\boldsymbol{u \cdot \nabla u} = \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \boldsymbol{u} \times (\boldsymbol{\nabla \times u})$.
$$\begin{align*}
&\frac{D \boldsymbol{u}}{Dt} = - \frac{\nabla p}{\rho} + \boldsymbol{F}\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} +\boldsymbol{u} \cdot \nabla  \boldsymbol{u} = - \frac{\nabla p}{\rho} + \boldsymbol{F}\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} + \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) = - \frac{\nabla p}{\rho} + \boldsymbol{F}\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) =  - \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \frac{\nabla p}{\rho} + \boldsymbol{F}
\end{align*}$$
and assume that $\boldsymbol{F}=-\nabla V$ where $V$ is the potential $V=gz$.
$$\begin{align*}
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) =  - \frac{1}{2}\nabla |\boldsymbol{u}|^{2}- \frac{\nabla p}{\rho} - \nabla V \\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) =  - \nabla \left(\frac{1}{2} |\boldsymbol{u}|^{2} + \frac{ p}{\rho} + V\right)\\
\implies& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) =  - \nabla H
\end{align*}$$
where $H= \frac{1}{2}  |\boldsymbol{u}|^{2}+\frac{ p}{\rho}+ gz$.

Since the flow is irrotational, $\boldsymbol{u}=\nabla \phi$ and $\boldsymbol{\nabla  \times u}=\boldsymbol{0}$. Hence
$$\begin{align*}
& \frac{\partial \boldsymbol{u}}{\partial t} - \boldsymbol{u} \times (\boldsymbol{\nabla \times u}) =  - \nabla H\\
\implies& \frac{\partial\; \nabla \phi}{\partial t}-0= -\nabla H\\
\implies& \nabla \left(\frac{\partial \phi}{\partial t}+H\right)=0\\
\implies& \frac{\partial \phi}{\partial t}+H = f(t)\; \text{ i.e constant in space (but may change through time)}
\end{align*}$$
where $H= \frac{1}{2}  |\nabla \phi|^{2}+\frac{ p}{\rho}+ gz$.