---
tags:
  - MT4509
aliases:
---
[[Continuity equation]] (mass conservation)
$$\frac{\partial p}{\partial t}+\nabla \cdot (\rho \boldsymbol{u})=\frac{D \rho}{Dt}+\rho \nabla \cdot \boldsymbol{u}=0.$$
[[Euler's equation]]
$$\frac{D \boldsymbol{u}}{Dt}= -\frac{ \boldsymbol{\nabla }p}{\rho} + \boldsymbol{F}.$$
[[Integral momentum equation]](s)
$$\iiint_{V}\frac{\partial (\rho \boldsymbol{u})}{\partial t}dV=-\iint_{S \text{ closed}}\rho \boldsymbol{u}(\boldsymbol{u \cdot n})\;dS + \iiint_{V} \rho \boldsymbol{F}\;dV-\iint_{S \text{ closed}}\rho \boldsymbol{n}\;dS.$$
and when gravity is neglected,
$$\iint_{S \text{ closed}}(p \boldsymbol{n}+\rho \boldsymbol{u}(\boldsymbol{u \cdot n})) \;dS= \boldsymbol{0}.$$
