---
tags:
  - MT3508
aliases:
---
Let $x_{j}$ be a covariate.

> [!def] Definition
> The Variance Inflation Factor or VIF is defined as
> $$\text{VIF}_{j}= \frac{1}{1-R^{2}_{j}}$$
> where $R_{j}$ is the variability within $x_{j}$.

> [!gen] Remarks
> - The VIF measures the increase in standard error not due to $s^{2}$ or $\widehat{\text{Var}}(X_{j})$
> - If $\text{VIF}_{j}>4$ it indicates a possible multicollinearity problem.
> - If $\text{VIF}_{j}>10$ it indicates a serious multicollinearity problem.
