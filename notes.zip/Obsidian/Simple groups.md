---
tags:
  - MT4003
aliases:
  - simple group
  - simple
---
Let $G$ be a [[Groups|group]].

> [!def] Definition
> A group $G$ is simple if it is non-trivial and its only [[Normal subgroups|normal]] [[Subgroups|subgroups]] are $\boldsymbol{1}$ and $G$.
