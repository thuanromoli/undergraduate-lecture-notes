---
tags:
  - MT4527
aliases:
---
Let $(X_{t})_{t=1,...,T}$ be a sequence of [[Random variables|random variables]] with finite variance.

> [!gen] [[Statistical hypothesis|Hypothesis]]
> $H_{0}$: $X$ is a sequence of independent normal rvs.
> $H_{1}$: not the above.

> [!gen] [[Test statistics]]
> $$JB = \frac{T}{6}\left(S^{2}+\frac{1}{4}(K-3)^{2}\right) \sim \chi^{2}_{2}.$$
> where
> $$\begin{eqnarray*}
S & = & \dfrac{\dfrac{1}{T} \sum_{i=1}^{T}( x_i - \bar x)^3}{\left( \dfrac{1}{T} \sum_{i=1}^{T}( x_i - \bar x )^2\right)^{3/2}} \\
K & = & \dfrac{\dfrac{1}{T} \sum_{i=1}^{T}( x_i -  \bar x)^4}{\left(\dfrac{1}{T} \sum_{i=1}^{T}( x_i - \bar x)^2\right)^2} 
\end{eqnarray*}$$
