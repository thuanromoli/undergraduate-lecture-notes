---
tags:
  - MT3504
type: model
aliases:
---
>[!gen] PDE
>Consider a stretched string between two end-points at $x=0$ and $x=1$. The motion of free vibrations of the string is captured to good approximation by the partial differential equation
>$$u_{tt}=c^{2}u_{xx} \ \ \text{ with } \ \ u(0,t)=(1,t)=0$$
>![[waveeq_att.png]]

>[!gen] Solution
>Step 1.
>Let $u(x,t)=X(x)T(t)$ and substitute into the PDE:
>$u_{tt}=c^{2}u_{xx}$ $\implies$ $XT''=c^{2}X''T$ $\implies$ $\underbrace{\frac{X''}{X}}_{f(x)}=\underbrace{\frac{T''}{c^{2}T}}_{f(t)}$
>Since RHS and LHS are functions of different variables, they must be equal to a constant, say $-\lambda$.
>
>Step 2.
>Consider the boundary conditions and solve the homogenous problem.
>In our case $u(0,t)=0 \implies X(0)T(t)=0 \implies X(0)=0$ and $u(1,t)=0 \implies X(1)T(t)=0 \implies X(1)=0$ so we solve the $X$ ODE first.
>Let $\lambda=v^{2}>0$ and solve the ODE $\frac{X''}{X}=-\lambda \implies X''+v^{2}X=0$.
>If asked, consider all possible cases of $\lambda$. That is, $\lambda=0$, $\lambda>0$, and $\lambda<0$.
>The solution is $X=A\cos vx +B\sin vx$.
>Now use the boundary conditions.
>$X(0)=0 \implies A=0$.
>$X(1)=0 \implies B\sin v=0$ and since $B\neq 0$ (otherwise trivial), $\sin v = 0$.
>Now find that $v=n\pi$ for $n\in \mathbb Z$.
>So the separation constant is $\lambda=(n \pi)^{2}$ and $X=\sin (n \pi x)$ ($B=1$ wlog).
>
>STEP 3.
>Solve the $T$ ODE.
>$T=A\cos (n \pi c t)+B \sin(n \pi c t)$.
>
>STEP 4.
>The general solution is a [[linear superposition]] of the solutions of $X(x)T(t)=(\sin (n \pi x))(A\cos (n \pi c t)+B \sin(n \pi c t))$:
>$u(x,t)=\sum\limits_{n=1}^{\infty}\sin (n \pi x)(A\cos (n \pi c t)+B \sin(n \pi c t))$.
>To find the constants $A$ and $B$ use the initial conditions and [[Orthogonality|orthogonality]] by multiplying by $\sin(m \pi x)$ and integrating.
>Note: $\int_{0}^{1}\sin(n \pi x )\sin(m \pi x)=\delta_{m,n}$
