---
tags:
  - MT3501
type: def
aliases:
---
Let $V$ and $W$ be [[Vector spaces|vector spaces]] over a field $F$. Let $S$ and $T$ be [[Linear transformations|linear transformations]] $V\to W$ and $\alpha$ be a scalar from $F$.

>[!def] Definition
>We define the scalar multiple $\alpha T:V\to W$ by
>$$(\alpha T)(v)=\alpha \cdot T(v)$$

>[!thm] The scalar multiple $\alpha T$ is a [[Linear transformations|linear transformation]]
>Let $u,v\in V$ and $\lambda\in F$. Then
>1. $(\alpha T)(u +v)=\alpha T(u+v)$ = $\alpha (T(u)+T(v))$ = $\alpha T(u)+ \alpha T(v)$ = $(\alpha T)(u)+ (\alpha T)(v)$
>2. $(\alpha T)(\lambda v)=\alpha T(\lambda v )$ = $\alpha\lambda T(v)$ = $\lambda \alpha(T)(v)$ = $\lambda (\alpha T)(v)$
>Hence $\alpha T$ is a linear map.

---

#### Spaced repetition

What is the scalar multiple of linear transformations?
?
>We define the scalar multiple $\alpha T:V\to W$ by
>$$(\alpha T)(v)=\alpha \cdot T(v)$$

Prove that the scalar multiple $\alpha T$ is a [[Linear transformations|linear transformation]].
?
>Let $u,v\in V$ and $\lambda\in F$. Then
>1. $(\alpha T)(u +v)=\alpha T(u+v)$ = $\alpha (T(u)+T(v))$ = $\alpha T(u)+ \alpha T(v)$ = $(\alpha T)(u)+ (\alpha T)(v)$
>2. $(\alpha T)(\lambda v)=\alpha T(\lambda v )$ = $\alpha\lambda T(v)$ = $\lambda \alpha(T)(v)$ = $\lambda (\alpha T)(v)$
>Hence $\alpha T$ is a linear map.