---
type: model
tag: MT2507
---
>[!gen]+ Model
>$$\frac{\text{d}N}{\text{d}t} \propto -N$$

>[!gen]+ ODE
>$$\frac{\text{d}N}{\text{d}t} = -kN$$

>[!gen]+ Terms
>- $k$ is the decay rate and $k>0$;
>- $N(t)$ is the amount of substance and $N(t)>0$;
>- $t$ is the time and $t>0$.

>[!gen]+ Solution
>$$N=N_{0}e^{-kt}$$