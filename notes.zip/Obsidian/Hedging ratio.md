---
tags:
  - MT4551
aliases:
---

> [!thm] Hedging ratio for a European call option
> The hedging ratio $\Delta$ is
> $$\Delta = N(d_{1})$$
> where
> $$d_{1} = \frac{\ln S/E + (r + \frac{1}{2} \sigma^{2})(T-t) }{ \sigma(T-t)^{\frac{1}{2}}}.$$

Proof:
$$\begin{align*}
\Delta &= \frac{\partial C}{\partial S}\\
&= \frac{\partial }{\partial S} \Big(SN(d_{1})-Ee^{-r(T-t)}N(d_{2})\Big)\\
&= S \frac{\partial }{\partial S}N(d_{1})+N(d_{1}) -Ee^{-r(T-t)}\frac{\partial }{\partial S}N(d_{2})\\
&= SN'(d_{1})\frac{\partial d_{1}}{\partial S} + N(d_{1}) -Ee^{-r(T-t)}N'(d_{2})\frac{\partial d_{2}}{\partial S}.
\end{align*}$$
Now recall
$$\begin{align*}
& N(d) = \frac{1}{\sqrt{2 \pi}} \int_{-\infty}^{d}e^{-y^{2}/2}dy\\
\implies & \frac{\partial N}{\partial d} = \frac{1}{\sqrt{2 \pi}} e^{-d^{2}/2}
\end{align*}$$
and so
$$\frac{N'(d_{1})}{N'(d_{2})} =  \frac{\frac{1}{\sqrt{2 \pi}} e^{-d_{1}^{2}/2}}{ \frac{1}{\sqrt{2 \pi}} e^{-d_{2}^{2}/2}} = e^{(d_{2}^{2}-d_{1}^{2})/2}.$$
Note that $d_{1}$ and $d_{2}$ differ only by one sign so we use $(a+b)^{2}-(a-b)^{2}=4ab$ with $a = \frac{\ln (S/E) + r(T-t)}{\sigma(T-t)^\frac{1}{2}}$ and $b = - \frac{1}{2} \sigma(T-t)^\frac{1}{2}$ to deduce
$$\frac{N'(d_{1})}{N'(d_{2})} =  \exp\left\{ -\ln \left(\frac{S}{E}\right)-r(T-t)  \right\} = \frac{E}{S}e^{-r(T-t)}$$
and so 
$$SN'(d_{1})=Ee^{-r(T-t)}N'(d_{2})$$
and also
$$\frac{\partial d_{1}}{\partial S}= \frac{\partial d_{2}}{\partial S}= \frac 1{S \sigma(T-t)^\frac{1}{2}}$$So
$$\Delta=N(d_{1}).$$