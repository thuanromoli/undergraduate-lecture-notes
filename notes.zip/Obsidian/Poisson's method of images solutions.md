---
tags:
  - MT3506
aliases:
---
Let $\nabla ^{2}u =- \rho$ be [[Poisson's equation]].

> [!def] Half space boundary conditions
> ![[halfspace_att.png|150]]
> The conditions are
> $$\begin{cases}
   V: x>0 \\
   \partial V: x=0.
   \end{cases}$$

> [!def] Volume outside of a sphere of radius $a$
> ![[spherebc_att.png|150]]
> The conditions are
> $$\begin{cases}
   V: |\boldsymbol{r}|>a \\
   \partial V: |\boldsymbol{r}|=a.
   \end{cases}$$

> [!thm] The Green's function for the Dirichlet problem in the half space
> $$G_{D}(\boldsymbol{r},\boldsymbol{r}')=\frac{1}{4\pi|\boldsymbol{r}-\boldsymbol{r}'|}-\frac{1}{4 \pi |\boldsymbol{r}-\overline{\boldsymbol{r}}'|}$$
> where $\boldsymbol{r}'=(x',y',z')$ is in the half space and $\overline{\boldsymbol{r}}'=(-x',y',z')$ is a mirror image in the other half space.

> [!thm] The Green's function for the Neumann problem in the half space
> $$G_{N}(\boldsymbol{r},\boldsymbol{r}')=\frac{1}{4\pi|\boldsymbol{r}-\boldsymbol{r}'|}+\frac{1}{4 \pi |\boldsymbol{r}-\overline{\boldsymbol{r}}'|}$$
> where $\boldsymbol{r}'=(x',y',z')$ is in the half space and $\overline{\boldsymbol{r}}'=(-x',y',z')$ is a mirror image in the other half space.

> [!thm] The Green's function for the Dirichlet problem outside a sphere of radius $a$
> $$G_{D}(\boldsymbol{r},\boldsymbol{r}')=\frac{1}{4\pi|\boldsymbol{r}-\boldsymbol{r}'|}-\frac{a/l}{4 \pi|\boldsymbol{r}-(a^{2}/l^{2})\boldsymbol{r}'|}$$
> where $l=\sqrt{{x'}^{2}+{y'}^{2}+{z'}^{2}}$ and $\boldsymbol{r}'=(x',y',z')$ is outside the sphere and $(a^{2}/l^{2})\boldsymbol{r}'$ is a mirror image inside the sphere.

Proof 1:
Recall from [[Poisson's solution for the Dirichlet problem]] that we wish to find $G_{D}$ that satisfies
$$\begin{cases}
\nabla^{2} G_{D}(\boldsymbol{r},\boldsymbol{r}')=-\delta^{3}(\boldsymbol{r-\boldsymbol{r'}})  & x>0\\
G_{D}(\boldsymbol{r},\boldsymbol{r}') =0 & x=0\end{cases}$$
and also has that $G_{D}=G_{\infty} + G_{0}$ where $G_{0}$ satisfies
$$\begin{cases}
\nabla^{2}G_{0}=0 &  x>0 \\
G_{0}=-G_{\infty} & x=0.
\end{cases}$$
Recall that
$$G_{\infty}=\frac{1}{4\pi |\boldsymbol{r}-\boldsymbol{r}'|}=\frac{1}{4 \pi\Big[(x-x')^{2}+(y-y')^{2}+(z-z')^{2}\Big]^{1/2}}\stackrel{x=0}{=}\frac{1}{4 \pi\Big[{x'}^{2}+(y-y')^{2}+(z-z')^{2}\Big]^{1/2}}$$

Take, using the inspiration that $G_{0}$ should be like $-G_{\infty}$ for $x>0$ and should equal $-G_{\infty}$ on $x=0$,
$$G_{0}=-\frac{1}{4 \pi\Big[(x+x')^{2}+(y-y')^{2}+(z-z')^{2}\Big]^{1/2}}$$
and verify that it satisfies the right conditions.

On the boundary, at $x=0$,
$$\begin{align*}
G_{0}\bigg|_{x=0}&= \left.-\frac{1}{4 \pi\Big[(x+x')^{2}+(y-y')^{2}+(z-z')^{2}\Big]^{1/2}}\right|_{x=0}\\
&= -\frac{1}{4 \pi\Big[{x'}^{2}+(y-y')^{2}+(z-z')^{2}\Big]^{1/2}}\\
&= -\frac{1}{4 \pi\Big[{(-x')}^{2}+(y-y')^{2}+(z-z')^{2}\Big]^{1/2}}\\
&= \left.-\frac{1}{4 \pi\Big[(x-x')^{2}+(y-y')^{2}+(z-z')^{2}\Big]^{1/2}}\right|_{x=0}\\
&= -G_{\infty}\bigg|_{x=0}
\end{align*}$$
Furthermore, $G_{0}$ has no singularity in the domain $x>0$ and so $\nabla^{2}G_{0}=0$ for $x>0$.
Hence $G_{0}$ satisfies the right conditions.
So we combine the results to obtain
$$G_{D}(\boldsymbol{r},\boldsymbol{r}')=G_{\infty}(\boldsymbol{r},\boldsymbol{r}')+G_{0}(\boldsymbol{r},\boldsymbol{r}')=\frac{1}{4\pi|\boldsymbol{r}-\boldsymbol{r}'|}-\frac{1}{4 \pi |\boldsymbol{r}-\overline{\boldsymbol{r}}'|}$$
where $\boldsymbol{r}'=(x',y',z')$ is in the half space and $\overline{\boldsymbol{r}}'=(-x',y',z')$ is a mirror image in the other half space.

Proof 2:
Recall from [[Poisson's solution for the Neumann problem]] that we wish to find $G_{N}$ that satisfies
$$\begin{cases}
\nabla^{2} G_{N}(\boldsymbol{r},\boldsymbol{r}')=-\delta^{3}(\boldsymbol{r-\boldsymbol{r'}})  & x>0\\
\frac{\partial }{\partial n}G_{N}(\boldsymbol{r},\boldsymbol{r}') =g(\boldsymbol{r}) & x=0\end{cases}$$
We justify the argument geometrically and using electric fields.
![[halfspace_att.png|300]]
The arrows indicate the inside of the volume, the plane $x=0$ has a normal outwards from the volume (in opposite direction of the orange arrows).
Then, by definition $\frac{\partial G_{N}}{\partial n}=-\frac{\partial G_{N}}{\partial x}$ on the boundary.
Now imagine two point charges, one inside the volume at $\boldsymbol{r}'$ and one outside the volume at $\overline{\boldsymbol{r}}'$.
Then the electric field on the boundary should be zero, that is
$$\boldsymbol{E}=-\nabla G_{N}=\begin{pmatrix}- \frac{\partial G_{N}}{\partial x} \\ \vdots\end{pmatrix}= \boldsymbol{0},$$
where in particular $-\frac{\partial G_{N}}{\partial x}=0$.
So it must be the case that
$$\begin{cases}
\nabla^{2} G_{N}(\boldsymbol{r},\boldsymbol{r}')=-\delta^{3}(\boldsymbol{r-\boldsymbol{r'}})  & x>0\\
\frac{\partial }{\partial n}G_{N}(\boldsymbol{r},\boldsymbol{r}') =0 & x=0\end{cases}$$
It turns out that the solution that satisfies the above is
$$G_{N}(\boldsymbol{r},\boldsymbol{r}')=G_{\infty}(\boldsymbol{r},\boldsymbol{r}')+G_{0}(\boldsymbol{r},\boldsymbol{r}')=\frac{1}{4\pi|\boldsymbol{r}-\boldsymbol{r}'|}+\frac{1}{4 \pi |\boldsymbol{r}-\overline{\boldsymbol{r}}'|}$$
where $\boldsymbol{r}'=(x',y',z')$ is in the half space and $\overline{\boldsymbol{r}}'=(-x',y',z')$ is a mirror image in the other half space.

Proof 3:
Recall from [[Poisson's solution for the Dirichlet problem]] that we wish to find $G_{D}$ that satisfies
$$\begin{cases}
\nabla^{2} G_{D}(\boldsymbol{r},\boldsymbol{r}')=-\delta^{3}(\boldsymbol{r-\boldsymbol{r'}})  & |\boldsymbol{r}|>a\\
G_{D}(\boldsymbol{r},\boldsymbol{r}') =0 & |\boldsymbol{r}|=a\end{cases}$$
and also has that $G_{D}=G_{\infty} + G_{0}$ where $G_{0}$ satisfies
$$\begin{cases}
\nabla^{2}G_{0}=0 &  |\boldsymbol{r}|>a \\
G_{0}=-G_{\infty} & |\boldsymbol{r}|=a.
\end{cases}$$
Wlog we use $\boldsymbol{r}'=(x',0,0)$
Recall that
$$\begin{align*}
G_{\infty}&=\frac{1}{4\pi |\boldsymbol{r}-\boldsymbol{r}'|}\\
&=\frac{1}{4\pi |\boldsymbol{r}-(x',0,0)|}\\
&=\frac{1}{4 \pi\Big[(x-x')^{2}+y^{2}+z^{2}\Big]^{1/2}}\\
&=\frac{1}{4 \pi\Big[x^{2}-2xx'+{x'}^{2}+y^{2}+z^{2}\Big]^{1/2}}\\
&=\frac{1}{4 \pi\Big[a^{2}-2xx'+{x'}^{2}\Big]^{1/2}} \qquad \text{where }a^{2}=x^{2}+y^{2}+z^{2}\\
&=\frac{1}{4 \pi\Big[a^{2}-2xx'+{x'}^{2}\Big]^{1/2}} \cdot \frac{a/x'}{\big({a^{2}/{x'}^{2}\big)}^{1/2}}\\
&=\frac{a/x'}{4 \pi\Big[\frac{a^{4}}{{x'}^{2}}-2 \frac{a^{2}x}{{x'}}+ a^{2}\Big]^{1/2}}\\
&=\frac{a/x'}{4 \pi\Big[\frac{a^{4}}{{x'}^{2}}-2 \frac{a^{2}x}{{x'}}+ x^{2}+y^{2}+z^{2}\Big]^{1/2}}\\
&=\frac{a/x'}{4 \pi\Big[ \big(x-(a^{2}/x')\big)^{2}+y^{2}+z^{2} \Big]^{1/2}}
\end{align*}$$
Take, using the inspiration that $G_{0}$ should be like $-G_{\infty}$ for $x>0$ and should equal $-G_{\infty}$ on $x=0$,
$$G_{0}=-\frac{a/x'}{4 \pi\Big[ \big(x-\frac{a^{2}}{x'^{2}}x'\big)^{2}+y^{2}+z^{2} \Big]^{1/2}}.$$
We combine the results to obtain
$$G_{D}(\boldsymbol{r},\boldsymbol{r}')=G_{\infty}(\boldsymbol{r},\boldsymbol{r}')+G_{0}(\boldsymbol{r},\boldsymbol{r}')=\frac{1}{4\pi|\boldsymbol{r}-\boldsymbol{r}'|}- \frac{a/x'}{4 \pi|\boldsymbol{r}-\frac{a^{2}}{{x'}^{2}}\boldsymbol{r}'|}$$
where $\boldsymbol{r}'=(x',0,0)$ is outside the sphere and $(a^{2}/{x'}^{2})\boldsymbol{r}'=(a^{2}/x',0,0)$ is a mirror image inside the sphere.

This directly generalises for $\boldsymbol{r}'=(x',y',z')$ to the desired result.
