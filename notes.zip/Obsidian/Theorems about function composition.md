---
type: thm
tags:
  - MT2505
  - MT4003
---
Let $f:W\to X,\,g:X\to Y,\,h:Y\to Z$ be [[Functions|functions]].

>[!thm]- [[Function composition]] is [[Associativity|associative]]: $(fg)h=f(gh)$

^62b5af

Below is not needed for MT4003.

>[!thm]- if $f$ and $g$ are [[Injective functions|injective]], then the [[Function composition|composite]] $fg$ is injective
Suppose $x(fg)=y(fg)$ for $x,y \in W$
Then $xfg=yfg \implies (xf)g=(yf)g \implies xf=yf$ as $g$ is injective $\implies$ $x=y$ as $f$ is injective
Hence $\sigma \tau$ is injective

>[!thm]- if $f$ and $g$ are [[Surjective functions|surjective]], then the [[Function composition|composite]] $fg$ is surjective
Let $w\in W,x\in X,y\in Y$ be arbitrary.
Since $g$ is surjective, $\forall y \in Y \ \ \exists x\in X$ s.t $x g = y$
Since $f$ is surjective, $\forall w \in W \ \ \exists x\in X$ s.t $w f = x$
Then $wfg = (wf)g= xg= y$
Hence $\sigma \tau$ is surjective

>[!thm]- if $f$ and $g$ are [[Bijective functions|bijective]], then the [[Function composition|composite]] $fg$ is bijective
Suppose $f$ and $g$ are bijective then they are both surjective and injective.
Hence $fg$ is injective and surjective.
Hence $fg$ is bijective.