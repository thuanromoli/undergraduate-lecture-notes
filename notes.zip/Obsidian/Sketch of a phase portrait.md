---
type: mthd
tag: MT2507
---
#### [[Autonomous system of first order ODEs]] (Linear)
Let $\boldsymbol{\dot x} =A\boldsymbol{x}$ be the general linear autonomous system.

1. Find [[Eigenvectors and Eigenvalues|eigenvectors]] and [[Eigenvectors and Eigenvalues|eigenvectors]];
2. classify the [[Critical points and steady states|critical point]], by finding its [[Stability|stability]], hence find which [[Phase portrait|phase portrait]] it's suitable (note: the critical point is always $(0,0)$);
3. find the [[Nullclines|nullclines]] to see when the [[Trajectories|trajectories]] are vertical or horizontal;
4. find $\frac{\text{d}y}{\text{d}x}=\frac{\text{d}y}{\text{d}t}\text{/}\frac{\text{d}x}{\text{d}t}$ to see the direction of the [[Trajectories|trajectories]] at the axis by setting $x=0$ and $y=0$;
5. sketch with all the information above.

#### [[Autonomous system of first order ODEs]] (Non-Linear)
Let $\boldsymbol{\dot x}=\boldsymbol F(\boldsymbol x)$ be the general non-linear autonomous system.

1. Suppose the system has a [[Critical points and steady states|critical point]] $(x_0,y_0)$;
2. evaluate $J=\pmatrix{\frac{\partial F}{\partial x}&\frac{\partial F}{\partial y} \\ \frac{\partial G}{\partial x}&\frac{\partial G}{\partial y}}$ at $(x_0,y_0)$;
3. let $\boldsymbol u=\boldsymbol x -\boldsymbol x_0$ ($\implies \boldsymbol{\dot u}=\boldsymbol{\dot x}$), then $\boldsymbol {\dot u}\approx J\boldsymbol u$;
4. find the global [[Nullclines|nullclines]];
5. to sketch the global phase portrait, sketch the local portraits at each critical point and join the trajectories.