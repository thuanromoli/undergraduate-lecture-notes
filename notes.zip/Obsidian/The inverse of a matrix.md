---
tag: MT2501
type: def
alias:
- inverse
- invertible
---
Let $A\in M_n(F)$ be a [[Square matrices|square matrix]].

>[!def] Definition
>$A$ is invertible if there exists a matrix $B$ such that
>$$AB=BA=I_{n}$$
>where $I_{n}$ is the $n \times n$ [[Identity matrices|identity matrix]]

---

#### Spaced repetition
