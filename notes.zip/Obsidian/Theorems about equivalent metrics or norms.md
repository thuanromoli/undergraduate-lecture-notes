---
tags:
  - MT3502
aliases:
---
Let $d$ and $d'$ be [[Equivalence of metrics|equivalent]] [[Metric spaces|metrics]] on $X$. Let $x_{n},x \in X$.

> [!thm]- $x_{n}$ [[Convergence|converges]] to $x$ in $d$ $\iff$ $x_{n}$ [[Convergence|converges]] to $x$ in $d'$

Let ${\Vert \cdot \Vert}$ and ${\Vert \cdot \Vert}'$ be two [[Inner Product Norm|norms]] on the same [[Vector spaces|vector space]] $X$. Let $x_{n},x \in X$.

> [!thm]- $x_{n}$ [[Convergence|converges]] to $x$ in ${\Vert \cdot \Vert}$ $\iff$ $x_{n}$ [[Convergence|converges]] to $x$ in ${\Vert \cdot \Vert}'$

> [!thm]- The norms ${\Vert \cdot \Vert}_{1}$, ${\Vert \cdot \Vert}_{2}$, and ${\Vert \cdot \Vert}_\infty$ on $\mathbb R^{N}$ are all equivalent.
