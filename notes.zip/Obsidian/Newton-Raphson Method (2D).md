---
tag: MT2507
type: mthd
alias:
- 
---
Consider the following system of two non-linear equations: $$\matrix{f(x,y)=0 \\ g(x,y)=0}$$
>[!def]+ Definition
>The Newton-Raphson Method (2D) is the following iteration:
>$$\pmatrix{x_{n+1}\\y_{n+1}}=\pmatrix{x_{n}\\y_{n}} - J^{-1}(x_{n},y_{n})\pmatrix{f(x_{n},y_{n})\\g(x_{n},y_{n})}$$
>where $(x_{0},y_{0})$ is an initial guess for the solution of $f(x,y)=g(x,y)=0$ and $(x_{1},y_{1}),(x_{2},y_{2}),...,(x_{n},y_{n})$ are subsequent approximation for such soluution and $J$ is the Jacobian evaluated at $x_{n},y_{n}$: $J(x_{n},y_{n})=\pmatrix{\frac{\partial f}{\partial x} & \frac{\partial g}{\partial x} \\ \frac{\partial g}{\partial x} & \frac{\partial g}{\partial y}}_{(x_{n},y_{n})}$

---

#### Spaced repetition
