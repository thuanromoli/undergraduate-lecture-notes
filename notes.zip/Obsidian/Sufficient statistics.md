---
tags:
  - MT3507
aliases:
---
> [!def] Definition
> A statistic $t = T(X)$ is sufficient for the underlying parameter $\theta$ if the conditional probability distribution of the data $X$, given the statistic $t= T(X)$, does not depend on the parameter $\theta$.
