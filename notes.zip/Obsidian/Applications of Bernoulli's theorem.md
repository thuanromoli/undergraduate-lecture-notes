---
tags:
  - MT4509
aliases:
---
Torricelli.
![[toricelli_att.png|400]]
By [[Bernoulli's Theorem]], $H$ is constant.
At 1, $\boldsymbol{u}_{1}\approx 0$, $p_{1}=p_{a}$, $z_{1}=h$.
$H_{1} = \frac{1}{2}|\boldsymbol{u}_{1}|^{2}+\frac{p_{1}}{\rho}+gz_{1}=\frac{p_{a}}{\rho}+gh$.
At 2, $\boldsymbol{u}_{2} = (u,0,0)$, $p_{2}=p_{a}$, $z_{2}=0$.
$H_{2} = \frac{1}{2}|\boldsymbol{u}_{2}|^{2}+\frac{p_{2}}{\rho}+gz_{2}=\frac{p_{a}}{\rho}+\frac{1}{2}u^{2}$.
So since $H_{1}=H_{2}$, we have $gh = \frac{1}{2}u^{2} \implies u = \sqrt{2gh}$.

Streamtube.
![[streamtube_att.png|400]]
By volume flux conservation (or mass conservation as density is constant), we have
$A_{1}u_{1}=A_{2}u_{2}$.
At 1, $\boldsymbol{u}_{1} = (u_{1},0,0)$, $p_{1}$, $z_{1}$.
$H_{1} = \frac{1}{2}|\boldsymbol{u}_{1}|^{2}+\frac{p_{1}}{\rho}+gz_{1}=\frac{1}{2}u_{1}^{2}+\frac{p_{a}}{\rho}+gz_{1}$.
At 2, $\boldsymbol{u}_{2} = (u_{2}\frac{A_{1}}{A_{2}},0,0)$, $p_{2}$, $z_{2}$.
$H_{2} = \frac{1}{2}|\boldsymbol{u}_{2}|^{2}+\frac{p_{2}}{\rho}+gz_{2}=\frac{1}{2}u_{2}^{2} + \frac{p_{a}}{\rho}+gz_{2}$.
So $H_{1} = H_{2}$ implies that $p_{2} = p_{1} + \rho g(z_{1}-z_{2})+\frac{1}{2}\rho u_{1}^{2}(1-\frac{A_{1}^{2}}{A_{2}^{2}})$.

Siphon.
![[siphon_att.png|400]]
At 1, $\boldsymbol{u}_{1}\approx \boldsymbol{0}$, $p_{1}=p_{a}$, $z_{1}=h$.
$H_{1} =\frac{1}{2}|\boldsymbol{u}_{1}|^{2}+\frac{p_{1}}{\rho}+gz_{1}= \frac{p_{a}}{\rho}+gh$.
At 2, $\boldsymbol{u}_{2} = (u_{2},0,0)$, $p_{2}=p_{a}$, $z_{2}$.
$H_{2} = \frac{1}{2}|\boldsymbol{u}_{2}|^{2}+\frac{p_{2}}{\rho}+gz_{2}=\frac{1}{2} u^{2}_{2}+\frac{p_{a}}{\rho}+gz_{2}$.
So $H_{1} = H_{2}$ implies that $\frac{p_{a}}{\rho}+gh = \frac{1}{2}u_{2}^{2}+\frac{p_{a}}{\rho}+gz_{2} \implies u_{2}= \sqrt{2g(h-z_{2})}$.

Prandtl/Pitot tube
![[pitot_att.png|400]]
At a point at $-\infty$, $\boldsymbol{u}_{1}=(U_\infty,0,0)$, $p_{1}=p_{\infty}$, $z_{1}=h$, ignore gravity $g=0$.
$H_{1} =\frac{1}{2}|\boldsymbol{u}_{1}|^{2}+\frac{p_{1}}{\rho}+gz_{1}= \frac{1}{2}U_{\infty}^{2}+\frac{p_{\infty}}{\rho}$.
So in general,
$\frac{1}{2}|\boldsymbol{u}|^{2}+\frac{p}{\rho}= \frac{1}{2}U_{\infty}^{2}+\frac{p_{\infty}}{\rho}$.
$$\begin{cases}
\text{At A:} & u\approx 0 & p=p_{1} \\
\text{At B:} & u=U_{\infty}  & p=p_{\infty} \\
\end{cases} \implies U_{\infty}=\sqrt{2(p_{1}-p_\infty)/\rho}.$$
