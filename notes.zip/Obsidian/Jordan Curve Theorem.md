---
tags:
  - MT3503
aliases:
---
Let $\gamma:[a,b] \to \mathbb C$ be a [[Contours|contour]].

> [!thm] Theorem
> The complex plane can be expressed as the union three disjoint subsets:
> - $\gamma^{*}$, the [[Curves|image]] of $\gamma$.
> - $I(\gamma)$, the interior of $\gamma$, which is [[Open sets|open]], [[Boundedness|bounded]] and connected.
> - $E(\gamma)$, the exterior of $\gamma$, which is [[Open sets|open]], [[Boundedness|unbounded]] and connected.

![[jordan_att.png]]