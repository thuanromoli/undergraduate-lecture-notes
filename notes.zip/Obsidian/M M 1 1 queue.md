---
tags:
  - MT4528
type: model
aliases:
---
>[!def] Definition
>The M/M/1/1 queue has:
>- [[Poisson processes|Poisson process]] arrivals with rate $\lambda$
>- service times $\overset{iid}{\sim}\text{Exp}(\mu)$
>- one server and capacity is one, hence no waiting area
>  
>This is a [[Birth and death processes|Birth/death process]] where:
>$$\lambda_{n}=\begin{cases}
   \lambda & \text{for }n=0 \\
   0 & \text{for }n>0
   \end{cases}$$
>$$\mu_{n}=\begin{cases}
   0 & \text{for }n=0 \\
   \mu & \text{for }n>0 \\
   \end{cases}$$

>[!thm] Theorem
>For an M/M/1/1 queue, the [[Stationary distributions|stationary distribution]] of the process $\set{X(t):t\geqslant 0}$ is given by
>$$\begin{align*}
   \pi_{0}=\lim\limits_{t \to \infty}\mathbb P(X(t)=0) = \frac{\mu}{\mu+\lambda}\\
   \pi_{1}=\lim\limits_{t \to \infty}\mathbb P(X(t)=1) = \frac{\lambda}{\mu+\lambda}\\
   \end{align*}$$
>
>Proof: see [[Equilibrium distribution of a birth death process|this proposition]], and then use algebra.
