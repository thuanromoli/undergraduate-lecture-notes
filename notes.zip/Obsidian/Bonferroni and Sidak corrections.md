---
tags:
  - MT3508
aliases:
---
If you had 100 such comparisons and the means were equal in all groups, you would still expect 5 of the 100 comparisons to yield significant test statistics when using a significance level of 95%.

> [!def] Bonferroni correction
> Use $\alpha_{B} = \frac{\alpha}{M}$ where $M$ are the number of comparisons being made.

> [!def] Sidak correction
> Use $\alpha_{S} = 1-(1-\alpha)^{\frac{1}{M}}$ where $M$ are the number of comparisons being made.
