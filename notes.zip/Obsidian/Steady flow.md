---
tags:
  - MT4509
aliases:
---
> [!def] Definition
> An [[Incompressibility|incompressible]] flow is steady if $\boldsymbol{u}$ is independent of time $t$. That is, $\boldsymbol{u}=\boldsymbol{u}(\boldsymbol{x})$ and
> $$\frac{\partial \boldsymbol{u}}{\partial t}=0.$$

Note that a steady flow has $\frac{\partial \boldsymbol{u}}{\partial t}=0$, but its [[The material derivative|material derivative]] representing acceleration need not be zero. In fact,
$$\begin{align*}
\frac{D \boldsymbol{u}}{Dt} &= \frac{\partial \boldsymbol{u}}{\partial t} + (\boldsymbol{u}\cdot \nabla ) \boldsymbol{u}\\
&=  0 + (\boldsymbol{u}\cdot \nabla ) \boldsymbol{u}
\end{align*}$$
and since $(\boldsymbol{u}\cdot \nabla ) \boldsymbol{u}$ is in general not zero, fluid particles can still accelerate.
