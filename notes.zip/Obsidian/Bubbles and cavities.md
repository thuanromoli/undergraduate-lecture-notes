---
tags:
  - MT4509
aliases:
---
Consider an air bubble with radius $a(t)$.

ASSUMPTIONS
Inside the bubble for $r < a(t)$, constant mass $M_{\text{bubble}}=\rho_{\text{air}}V$ and constant pressure $p_{b}$.
In the fluid for $r>a(t)$, homogeneous and irrotational flow.

SETUP
We have a potential fluid $\nabla ^{2} \Phi =0$ and $\boldsymbol{u}=\nabla \Phi$ for $r>a(t)$.
Let $\Phi$ depend only on $r$ such that $\boldsymbol{u}=u_{r}\boldsymbol{e}_{r}= \frac{\partial \Phi}{\partial r}\boldsymbol{e}_{r}$.
Consider the potential $\Phi(r,t)=- \frac{A(t)}{r}$ and radial velocity $u_{r}=\frac{\partial \Phi}{\partial r}=\frac{A(t)}{r^{2}}$.
We are interested in determining $A(t)$ (use b.c.) and $a(t)$.

BOUNDARY CONDITIONS
[[Kinematic boundary condition]] $\boldsymbol{u \cdot n}= \boldsymbol{V \cdot n}$ at the boundary $r=a$ $\implies$ $u_{r}(a,t)=\frac{da}{dt}$.

EQUATIONS
$$\frac{da}{dt}=\frac{A}{a^{2}} \implies A=a^{2} a' \implies u_{r}(r,t)= \frac{a^{2}a'}{r^{2}}.$$
Next, we find an equation for $a(t)$.
We use [[Unsteady Bernoulli's Theorem]], take streamline with end points at -$\infty$ and on the bubble surface, ignore gravity.
At a far point: $p = p_\infty$, $|\boldsymbol{u}| \to 0$, $\Phi \to 0$.
On the body, $p=p_{b}$, $|\boldsymbol{u}|=|u_{r}(a,t)|$, $\Phi= \Phi(a,t)$.
$$\frac{p_\infty}{\rho}=\left .\frac{\partial \Phi}{\partial t}\right|_{r=a}+\frac{1}{2}a'^{2}+\frac{p_{b}}{\rho}$$
Note that $\Phi=-\frac{A(t)}{r} \implies \left.\frac{\partial \Phi}{\partial t}\right|_{r=a}=\left. - \frac{1}{r}A'(t) \right|_{r=a}=- \frac{A'}{a}$. Hence
$$\begin{align*}
\frac{p_\infty}{\rho}&=\frac{-A'}{a}+\frac{p_{b}}{\rho}+\frac{1}{2}a'^{2}\\
\frac{p_\infty}{\rho}&=\frac{-\frac{d}{dt}(a^{2}a')}{a}+\frac{p_{b}}{\rho}+\frac{1}{2}a'^{2}\\
\frac{p_{b}-p_\infty}{\rho}&= \frac{2aa'^{2}+a^{2}a''}{a}-\frac{1}{2}a'^{2}\\
\frac{p_{b}-p_\infty}{\rho}&= aa''+\frac{3}{2}a'^{2}
\end{align*}$$
This is called Rayleigh Equation.

> [!gen]- SOLUTIONS (CASE 1 small oscillations about a rest state)
> In the air bubble for $r<a$, assume adiabatic:
> $$\begin{align*}
> &\frac{p_{b}}{\rho_\text{air}^{\gamma}}=\text{constant} 
> \; \text{where} \; \gamma=c_{p}/c_{v}= \text{constant}\\
> \implies& p_{b}V^\gamma= \text{constant}\\
> \implies& p_{b}a^{3 \gamma} = \text{constant}.
> \end{align*}$$
> At equilibrium ($a'=0$), using the Rayleigh Equation and integration, we have
> $$\begin{cases}
> a'=0 \implies p_{b}-p_{\infty}=0\\
> \frac{da}{dt} =0 \implies a= a_{0}
> \end{cases}$$
> So we must have
> $$p_{b}a^{3 \gamma}= \text{constant} = p_{\infty}a_{0}^{3 \gamma}.$$
> So into Rayleigh equation, set $p_{b}= p_{\infty}\left(\frac{a_{0}}{a}\right)^{3 \gamma}$ and we have
> $$\frac{p_{\infty}}{\rho}\left[\left(\frac{a_{0}}{a}\right)^{3 \gamma}-1\right]=a a''+\frac{3}{2}a'^{2} \tag 1$$
> That is the equation we want to analyse. Start by linearising.
> 
> LINEARISATION
> Consider a small oscillation $\xi(t)$ such that $a=a_{0}+ \xi$.
> Then $a'= \xi'$ and $a''=\xi''$. Equation (1) becomes
> $$\begin{align*}
> a_{0} \xi'' + O(\xi^{2})&= \frac{p_{\infty}}{\rho}\left[ \left( \frac{a_{0}}{a_{0}+\xi} \right)^{3\gamma}-1 \right]\\
> &=\frac{p_\infty}{\rho}\left[\left(1+\frac{\xi}
> {a_{0}}\right)^{-3 \gamma}-1\right]\\
> &\approx   \frac{p_\infty}{\rho}\left(-3 \gamma \left(\frac{\xi}{a_{0}}\right)\right)\\
> &= -\frac{3 \gamma p_\infty}{\rho}\frac{\xi}{a_{0}}
> \end{align*}$$
> where $\frac{3 \gamma p_\infty}{\rho}$ is the speed of sound squared as $r \to \infty$. Hence
> $$\begin{align*}
> &a_{0} \xi''= -\frac{3 \gamma p_\infty}{\rho}\frac{\xi}{a_{0}} \\
> \implies& \xi''= - \left(\frac{3 \gamma p_\infty}{\rho}\right) \frac{\xi}{a_{0}^{2}} \\
> \implies& \xi'' + \frac{c_{s}^{2}}{a_{0}^{2}}\xi =0\\
> \implies& \xi'' + \omega_{0}^{2}\xi=0,
> \end{align*}$$
> we obtained the classic harmonic oscillator equation.

> [!gen]- SOLUTIONS CASE 2 collapse
> Assume $p_{b}$ is a constant.
> Note that
> $$\begin{align*}
> Ca^{n} \frac{d}{dt}(a^{m}a')&=Ca^{n}[ma^{m-1}a'+a^{m}a'']\\
> &= C[ma^{n+m-1}a'^{2}+a^{m+n}a'']
> \end{align*}$$
> and we want this to be equal to the RHS of the Rayleigh equation
> $$\begin{align*}
> &C[ma^{n+m-1}a'^{2}+a^{m+n}a''] = aa''+\frac{3}{2}a'^{2}\\
> \implies& m+n =1, C=1\\
> \implies& m= \frac{3}{2}, n = -\frac{1}{2}.
> \end{align*}$$
> So we use the identity
> $$a^{-1/2}\frac{d}{dt}(a^{3/2}a')=aa'' + \frac{3}{2}a'^{2}.$$
> Into Rayleigh equation, noting a constant LHS,
> $$\begin{align*}
> &B= a a'' +\frac{3}{2}a'^{2}\\
> \implies& B=a^{-1/2}\frac{d}{dt}(a^{3/2}a')\\
> \implies& Ba^{1/2}=\frac{d}{dt}(a^{3/2}a')\\
> \implies&Ba^{2}a' = a^{3/2}a'\frac{d}{dt}(a^{3/2}a')\\
> \implies&\frac{d}{dt}\left(\frac{Ba^{3}}{3}\right)=\frac{d}{dt}\left(\frac{1}{2}(a^{3/2}a')^{2}\right)\\
> \implies&\frac{1}{3}Ba^{3}+D = \frac{1}{2}(a^{3/2}a')^{2}\\
> \implies&\frac{2}{3}Ba^{3}+2D = a^{3}a'^{2}\\
> \implies&\frac{2}{3}B+\frac{E}{a^{3}}=a'^{2}
> \end{align*}$$
> Initial conditions $a(0)=a_{0}$ and $a'(0)=0$ gives $\frac{2}{3}B = \frac{E}{a_{0}^{3}} \implies E=\frac{2}{3}B a_{0}^{3}$. So
> $$\begin{align*}
> &a'^{2}= \frac{2}{3}B\left[1-\left(\frac{a_{0}}{a}\right)^{3}\right]\\
> \implies&a'^{2}= \frac{2}{3} \frac{p_{b}-p_\infty}{\rho}\left[1-\left(\frac{a_{0}}{a}\right)^{3}\right]\\
> \end{align*}$$
> Using the approximation $\frac{p_{b}-p_{\infty}}{\rho}\approx - \frac{p_\infty}{\rho}$ we have
> $$\begin{align*}
> &a'^{2}= \frac{2}{3} \frac{p_{b}-p_\infty}{\rho}\left[1-\left(\frac{a_{0}}{a}\right)^{3}\right]\\
> \implies&a'^{2}= -\frac{2p_\infty}{3\rho}\left[1-\left(\frac{a_{0}}{a}\right)^{3}\right]\\
> \implies&a'^{2}= \frac{2p_\infty}{3\rho}\left[\left(\frac{a_{0}}{a}\right)^{3}-1\right]\\
> \implies&a'^{2}=c^{2}_{s}\left[\left(\frac{a_{0}}{a}\right)^{3}-1\right]\\
> \implies&a'= \pm \sqrt{c^{2}_{s}\left[\left(\frac{a_{0}}{a}\right)^{3}-1\right]}
> \end{align*}$$
> where $c_{s}$ is the speed of sound and we take the negative root for bubble collapse.
