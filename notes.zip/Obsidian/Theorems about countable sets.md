---
tags:
  - MT3502
aliases:
---
> [!thm]- The set $\mathbb N \times \mathbb N$ is [[Countable sets|countable]]
> We need to find a way to enumerate the set.
> ![[nncountable_att.png]]
> Thus we may enumerate $\mathbb N \times \mathbb N$ as
> $$(1,1),(1,2),(2,1),(1,3),(2,2),(3,1),(1,4),...$$
> And more formally, the mapping $f: \mathbb N \times \mathbb N \to \mathbb N$ where
> $$f(a,b) = \left( \sum\limits_{k=1}^{a+b-2} k \right) + a = \frac{1}{2}(a+b-2)(a+b-1)+a$$
> is a [[Bijective functions|bijection]] that gives the position of $(a,b)$ in the list.

> [!thm]- $A_{1},...,A_{n}$ are countable $\implies$ $A_{1}\times \cdots \times A_{n}$ is countable
> If $A_{1}$, $A_{2}$ are countable, then $A_{1} \times A_{2}$ is countable as $A_{1} \simeq \mathbb N$ and $A_{2} \simeq \mathbb N$ and apply the above theorem.
> By iteration, we obtain the required result.

> [!thm]- Every non-empty subset of a countable set is countable or finite
> If $A$ is countable, we may list its elements as $(a_{1},a_{2},...)$.
> Any subsets may be enumerated by deleting elements not in the subset, i.e. as $(a_{i_{1}},a_{i_{2}},...)$ where $1 \leqslant i_{1} < i_{2} < \ldots$
> This either terminates or give an enumeration of a countable set.

> [!thm]- If $f:A\to B$ is a [[Surjective functions|surjection]] and $A$ is countable then $B$ is countable or finite
> Note: $A$ is "bigger" than $B$.
> List $A$ as $(a_{1},a_{2},...)$.
> Then define $A' \subseteq A$ by $A' = \set{a_{i} \in A : f(a_{i} \neq f(a_{j}) \text{ for all } 1 \leqslant j < i }$.
> Then $f: A' \to B$ is reduced to an injection and so is a bijection.
> So $A' \simeq B$, and since $A'$ is countable by the above theorem, then $B$ is countable or finite.

> [!thm]- If $f:A\to B$ is an [[Injective functions|injection]] and $B$ is countable then $A$ is countable or finite.
> Note: $B$ is "bigger" than $A$.
> We have $f(A) \subseteq B$.
> Since $B$ is countable, then so is $f(A)$ by the above theorem.
> Then $f: A \to f(A)$ is a bijection.
> So $A \simeq f(A)$, and since $f(A)$ is countable or finite, so is $A$.

^e649c1

