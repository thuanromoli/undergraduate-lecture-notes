---
tags:
  - MT3504
type: 
aliases:
---
Let $C^{2}(a,b)$ be the [[Inner product space of twice-differentiable functions|inner product space of twice-differentiable functions]].

>[!def] Definition
>The differential operator of a Sturm-Liouville problem is
>$$L=- \frac{d}{dx}(p(x) \frac{d}{dx})+q(x)$$
>or, in other words,
>$$L[y]=- \frac{d}{dx}(p(x) \frac{dy}{dx})+q(x)y=-(py')'+qy$$
>such that
>- $p>0$ on $(a,b)$, ($p=0$ is allowed at $a$ or $b$).
>- $L$ acts on $C(a,b)$.

>[!thm] Theorem
>All second-order linear differential operators may be written in a Sturm-Liouville form.
>
>Proof:
>Let $L$ be the operator in a Sturm-Liouville form and let $L_{2}$ be the general operator.
>Then multiply $L_{2}[y]=f$ by an integrating factor $\mu(x)$.
>Then compare $L[y]=f$ to $\mu L_{2}[y]=\mu g$.
>$$\begin{align*}
   L[y]=f &\implies -(py')'+qy=f\\
   &\implies \;-py''-\;\;\;p'y'+qy\;\;=f\\
   \mu L_{2}[y]=\mu g &\implies \mu a_{2}y'' +\mu a_{1}y' + \mu a_{0}=\mu g
   \end{align*}$$
>so by comparison (we grouped them as such to simplify calculations),
>$$\begin{cases}
   -p=\mu a_{2}\\
   -p'=\mu a_{1}\\
   q=\mu a_{0}\\
   f=\mu g
   \end{cases}$$
>and dividing the second equation by the first one,
>$$\frac{-p'}{-p}=\frac{\mu a_{1}}{\mu a_{2}} \implies \frac{p'}{p}=\frac{a_{1}}{a_{2}}$$
>and finally we obtain
>$$\begin{cases}
   p = \exp \int_{}^{} \frac{a_{1}}{a_{2}}dx>0 \\
   \mu = -\frac{1}{a_{2}}\exp \int_{}^{} \frac{a_{1}}{a_{2}}dx \\
   q =  -\frac{a_{0}}{a_{2}}\exp \int_{}^{} \frac{a_{1}}{a_{2}}dx \\
   f = -\frac{g}{a_{2}}\exp \int_{}^{} \frac{a_{1}}{a_{2}}dx
   \end{cases}$$
>In particular, we have that $p,\mu,q,f$ are all defined and so if we wish to convert between $L_{2}$ and  $L$, we find $p,\mu,q,f$.
