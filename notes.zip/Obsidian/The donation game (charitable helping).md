---
tags:
  - MT4554
type: model
aliases: []
---
>[!gen] Why are we studying this?
>We emphasise that cooperation is strictly dominated in a one-shot game and that “A rational player, who seeks to maximise their payoff in the donation game, should not pay a net cost to provide a net benefit to their opponent”.
>Perhaps it isn’t so surprising that a rational player, who seeks only to maximise their own payoff, wouldn’t do this. It’s also a kind of extreme selfless form of cooperation. As originally described, cooperation means working together towards a common good.

>[!def] Definition
>The donation game is a game where the act of cooperation consists of expending a cost $c$ to provide a benefit $b$ to the other player, while the act of defection entails no cost and provides no benefit.
>This satisfies the definition of a [[The prisoner's dilemma|Prisoner's Dilemma]] provided that $b>b-c>0>-c$, that is $b>0$, $c>0$, and $b>c$.
>
>![[donationgame_att.png|300]]

>[!gen] Solution (one shot game)
>A [[Rationality|rational]] player would play $D$ as $C$ is [[Strictly dominated strategy|strictly dominated]] and therefore the [[Iterated strict dominance|ISD]] solution is $(D,D)$ (note that $(D,D)$ is also both [[Rationalizability|rationalisable]] and a [[Nash equilibrium]]).

>[!gen] Social dilemma and Pareto optimal.
>The payoff structure ensures that the game is a social dilemma, because mutual cooperation, $(C,C)$ is Pareto optimal but mutual defection $(D,D)$ is the unique solution for rational players.

>[!gen] Solution (population level)
>Suppose that there are $N$ players and $n$ players play $C$.
>Then the [[Population level payoff|population level payoffs]] are
>$$\begin{align*}
   V_{C} &= \frac{1}{2}[(n-1)(b-c)+(N-n)(-c)]+ \frac{1}{2}[(n-1)(b-c)+(N-n)(-c)]\\
   &= (n-1)(b-c)-c(N-n)\\
   V_{D} &= \frac{1}{2}[(n)(b)+(N-n-1)(0)] + \frac{1}{2}[(n)(b)+(N-n-1)(0)]\\
   &= nb
   \end{align*}$$
>And so a player will be incentivised to switch to $D$ if
>$$\begin{align*}
   &\;\;\;\;\;\;\;\;\;\;V_{D}>V_{C}\\
   &\iff nb > (n-1)(b-c)-c(N-n)\\
   &\iff nb>nb-nc-b+c-cN+nc\\
   &\iff 0 > -b+c-cN\\
   &\iff -(b-c)-cN<0\\
   \end{align*}$$
>Which is always satisfied hence players are always incentivised to switch to defect, just as in the pairwise game