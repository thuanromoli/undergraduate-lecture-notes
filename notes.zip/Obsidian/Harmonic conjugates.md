---
tags:
  - MT3503
aliases:
  - harmonic conjugate
---
Let $V$ be an [[Open sets|open subset]] of $\mathbb R^{2}$. Let $u:V \to \mathbb R$ be a harmonic [[Functions|function]] defined on $V$.

> [!def] Definition
> A harmonic conjugate of $u$ is a function $v: V \to \mathbb R$ such that $f(x+iy)=u(x,y)+iv(x,y)$ is holomorphic, with real part $u$.
