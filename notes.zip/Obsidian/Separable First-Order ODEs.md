---
type: mthd
tags:
  - MT2507
  - MT3504
aliases:
---
>[!gen] ODE
>$$\frac{dy}{dx}=f(y)f(x)$$

>[!thm] Proof of $\int f(y) \frac{dy}{dx}dx=\int f(y) dy$
>- Consider the chain rule: $$\frac{du}{dx}=\frac{du}{dy} \frac{dy}{dx}$$
>- We try to use the subsitution $u=\int f(y)dy$ into the chain rule and integrate: $$\frac{d}{dx}\left(\int f(y)dy\right)=\frac{d}{dy}\left(\int f(y)dy\right) \frac{dy}{dx}$$
>- $$\frac{d}{dx}\left(\int f(y)dy\right)=f(y)\frac{dy}{dx}$$
>- $$\int\frac{d}{dx}\left(\int f(y)dy\right)dx=\int f(y)\frac{dy}{dx}dx$$
>- $$\int f(y)dy=\int f(y)\frac{dy}{dx}dx$$

>[!gen] Solution
>$$\frac{1}{f(y)} \frac{dy}{dx}=f(x)$$
>$$\int \frac{1}{f(y)} \frac{dy}{dx} dx=\int f(x)dx$$
>$$\int \frac{1}{f(y)}dy=\int f(x)dx$$

---

#### Spaced repetition

What is the form of a separable first-order ODE?
?
>$\frac{dy}{dx}=f(y)f(x)$

How do you solve $y'=f(y)f(x)$?
?
>$\frac{1}{f(y)} \frac{dy}{dx}=f(x)$
>$\int \frac{1}{f(y)} \frac{dy}{dx} dx=\int f(x)dx$
>$\int \frac{1}{f(y)}dy=\int f(x)dx$

Prove that $\int f(y) \frac{dy}{dx}dx=\int f(y) dy$.
?
>- Consider the chain rule: $$\frac{du}{dx}=\frac{du}{dy} \frac{dy}{dx}$$
>- We try to use the subsitution $u=\int f(y)dy$ into the chain rule and integrate: $$\frac{d}{dx}\left(\int f(y)dy\right)=\frac{d}{dy}\left(\int f(y)dy\right) \frac{dy}{dx}$$
>- $$\frac{d}{dx}\left(\int f(y)dy\right)=f(y)\frac{dy}{dx}$$
>- $$\int\frac{d}{dx}\left(\int f(y)dy\right)dx=\int f(y)\frac{dy}{dx}dx$$
>- $$\int f(y)dy=\int f(y)\frac{dy}{dx}dx$$