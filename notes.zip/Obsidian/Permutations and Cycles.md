---
aliases:
  - permutation
  - permutations
  - cycle
type: def
tags:
  - MT2505
  - MT4003
---
Let $X$ be a set.

>[!def] Definition
>A permutation of $X$ is any [[Bijective functions|bijective function]] $\sigma: X\to X$

Let $i_1,i_2,...,i_n$ be $r$ distinct elements from $X=\{1,2,\ldots,n\}$ and $S_n$ be the [[The symmetric group|symmetric group]] of degree $n$.

>[!def] $r$-cycles
>The $r$-cycle $(i_1\,i_2\ldots i_r)$ is the permutation in $S_{n}$ which maps $i_1 \mapsto i_2$, $i_2 \mapsto i_3$, ..., $i_{r-1} \mapsto i_r$, $i_r \mapsto i_1$, and fixes all other points in $X$

>[!def] Disjoint cycles
>The two cycles $(i_1\,i_2\ldots i_r)$ and $(j_1\,j_2\ldots j_r)$ are disjoint if $\set{i_1,i_2,\ldots,i_r} \cap \set{j_1,j_2,\ldots,j_s}=\varnothing$.

>[!def] Transpositions
>A transposition is a cycle of length 2 of the form $(i \ \ j)$

Let $\sigma \in S_{n}$ be a permutation in the [[The symmetric group|symmetric group]] of degree $n$.

>[!def] Even permutation
>$\sigma$ is an even [[Permutations and Cycles|permutation]] if it can be written as a product of an even number of transpositions.

>[!def] Odd permutation
>$\sigma$ is an odd [[Permutations and Cycles|permutation]] if it can be written as a product of an odd number of transpositions.

A [[Theorems about permutations and cycles|theorem about even and odd permutations]] tells us that a permuation is either odd or even and cannot be both.