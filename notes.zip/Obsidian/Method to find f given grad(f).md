---
type: mthd
tag: MT2506
---
Given that $\boldsymbol F= F_x \boldsymbol i + F_y \boldsymbol j + F_z \boldsymbol k$ and that $\boldsymbol F= \boldsymbol \nabla f$ ([[Gradient]]), find $f$.

1. Note: $\boldsymbol\nabla f=\frac{\partial f}{\partial x} \boldsymbol i+\frac{\partial f}{\partial y} \boldsymbol j + \frac{\partial f}{\partial z} \boldsymbol k$;
2. By equation coefficients:
	1. $\frac{\partial f}{\partial x} = F_x$
	2. $\frac{\partial f}{\partial y} = F_y$
	3. $\frac{\partial f}{\partial z} = F_z$
3. (1): $\frac{\partial f}{\partial x} = F_x$$\implies$ (3) $f = I_x + f_1(y,z)$ where $\int F_x \text{ d}x = I_x$ for clarity;
4. (2): $\frac{\partial f}{\partial y} = F_y$$\implies$$\frac{\partial}{\partial y} (I_x + f_1(y,z)) = F_y$$\implies$$\frac{\partial f_1}{\partial y} = G$$\implies$(4) $f_1=I_y+f_2(z)$;
5. Combining (3) and (4): (5) $f=I_x + I_y + f_2(z)$;
6. (3): $\frac{\partial f}{\partial z} = F_z$$\implies$$\frac{\partial}{\partial z}(I_x + I_y + f_2(z)) = F_z$$\implies$$\frac{\partial f_2}{\partial z} = H$$\implies$(6) $f_2 = I_z + C$;
7. Combining (5) and (6): $f= I_x + I_y +I_z +C$.

---

#### Spaced repetition

Given that $\boldsymbol F= F_x \boldsymbol i + F_y \boldsymbol j + F_z \boldsymbol k$ and that $\boldsymbol F= \boldsymbol \nabla f$ ([[Gradient]]), show the algorithm to find $f$
?
1. Note: $\boldsymbol\nabla f=\frac{\partial f}{\partial x} \boldsymbol i+\frac{\partial f}{\partial y} \boldsymbol j + \frac{\partial f}{\partial z} \boldsymbol k$;
2. By equation coefficients:
	1. $\frac{\partial f}{\partial x} = F_x$
	2. $\frac{\partial f}{\partial y} = F_y$
	3. $\frac{\partial f}{\partial z} = F_z$
3. (1): $\frac{\partial f}{\partial x} = F_x$$\implies$ (3) $f = I_x + f_1(y,z)$ where $\int F_x \text{ d}x = I_x$ for clarity;
4. (2): $\frac{\partial f}{\partial y} = F_y$$\implies$$\frac{\partial}{\partial y} (I_x + f_1(y,z)) = F_y$$\implies$$\frac{\partial f_1}{\partial y} = G$$\implies$(4) $f_1=I_y+f_2(z)$;
5. Combining (3) and (4): (5) $f=I_x + I_y + f_2(z)$;
6. (3): $\frac{\partial f}{\partial z} = F_z$$\implies$$\frac{\partial}{\partial z}(I_x + I_y + f_2(z)) = F_z$$\implies$$\frac{\partial f_2}{\partial z} = H$$\implies$(6) $f_2 = I_z + C$;
7. Combining (5) and (6): $f= I_x + I_y +I_z +C$.