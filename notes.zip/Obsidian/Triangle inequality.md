---
tags:
  - MT3501
  - MT3503
type: thm
aliases:
  - triangle inequalities
---
#### For analysis:
Let $z,w$ be [[Complex numbers|complex numbers]].

> [!thm] Theorem
> 1. $|z+w| \leqslant |z|+ |w|$
> 2. $|z-w| \geqslant  \bigg | |z| - |w| \bigg |$

Proof:
We start by proving the first statement.
$$\begin{align*}
|z+w|^{2} &= (z + w)\overline{(z+w)} && \text{since }|z|^{2}=a^{2}+b^{2}= (a+bi)(a-bi)= z\bar z\\
&= (z + w)(\bar z+ \bar w)\\
&= z\bar z+z\bar w+ w\bar z + w \bar w\\
&= |z|^{2}+ z\bar w + \overline{z\bar w} + |w|^{2} && \text{since } w \bar z = \overline{\bar w}\bar z = \overline{\bar wz}\\
&= |z|^{2}+ 2\text{Re }(z\bar w) + |w|^{2} && \text{since } z + \bar z = a + bi + a - bi = 2a = 2 \text{Re }z\\
& \leqslant |z|^{2} + 2 |z \bar w| + |w|^{2} && \text{since } \text{Re }z \leqslant |z|\\
&= |z|^{2}+ 2|z||\bar w| + |w|^{2}\\
&= |z|^{2}+ 2|z|| w| + |w|^{2}\\
&= (|z| + |w|)^{2}.
\end{align*}$$

Now we can proceed to prove the second statement.
$$\begin{align*}
&|z| = |z - w + w | \leqslant |z-w| + |w| \implies |z-w|\geqslant  |z| - |w|\;\;\;(1)\\
&|w| = |w - z + z | \leqslant |w-z| + |z| \implies |w-z|\geqslant  |w| - |z|\;\;\;(2)\\\\
&\begin{cases}
(1)\;\;|z-w|\geqslant  |z| - |w|\\
(2)\;\;|w-z|\geqslant  |w| - |z|\\
\end{cases} \implies
\begin{cases}
|z-w|\geqslant  |z| - |w|\\
|z-w|\geqslant  |w| - |z|\\
\end{cases} \implies
\begin{cases}
|z-w|\geqslant  |z| - |w|\\
|z-w|\geqslant  -(|z|-|w|)\\
\end{cases}\\\\
&\implies |z-w| \geqslant \bigg | |z| -|w| \bigg|.
\end{align*}$$

#### For linear algebra:
Let $V$ be an [[Inner product spaces|inner product space]] with inner product $\langle \cdot,\cdot \rangle$.

>[!thm] Theorem
>$\Vert u+v \Vert \leqslant \Vert u \Vert+\Vert v \Vert$

Proof:
$$\begin{align*}
{\Vert u+v \Vert}^{2} &= \langle u+v,u+v \rangle\\
&= \langle u,u+v \rangle+\langle v,u+v \rangle\\
&= \overline{\langle u+v,u \rangle} + \overline{\langle u+v,v \rangle}\\
&= \langle u,u \rangle + \langle u,v \rangle + \overline{\langle u,v \rangle} + \langle v,v \rangle\\
&= {\Vert u \Vert}^{2}+2 \text{ Re} \langle u,v \rangle + {\Vert v \Vert}^{2}\\
&\leqslant  {\Vert u \Vert}^{2}+2 |\langle u,v \rangle|+{\Vert v \Vert}^{2}\\
&\leqslant {\Vert u \Vert}^{2}+2 (\Vert u \Vert \cdot \Vert v \Vert)+{\Vert v \Vert}^{2}\\
&= (\Vert u \Vert+\Vert v \Vert)^{2}\\
\end{align*}$$
Taking square roots gives the result.