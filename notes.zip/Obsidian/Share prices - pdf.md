---
tags:
  - MT4551
aliases:
---
Consider the [[Geometric Brownian motion|geometric Brownian share price model]] $dS = \mu S dt + \sigma S dW$.

> [!thm] Theorem
> The pdf of the share price is
> $$P(S) = \frac{1}{\sqrt{2 \pi \sigma^{2} t}} \frac{1}{S} \exp\left\{-\frac{\left[\ln(S/S_{0}) - (\mu - \frac{1}{2}\sigma^{2})t\right]^{2}}{2 \sigma^{2}t}\right\}$$

> [!gen] Remarks
> - As $S \to 0$, $P(S) \to 0$.
> - Defined for $S>0$.
> - The pdf is a log-normal distribution.
> - The peak occurs at $S=S_{0} \exp \left[\left(\mu - \frac{3}{2} \sigma^{2}\right)t\right]$ 

Proof:
The form of the equation $dS = S f(t) dt$ suggests that $\ln S$ might be useful.
So apply [[Itô's lemma]] with $x=S$, $a = \mu S$, $b = \sigma S$, and $G(S,t) = \ln S$.
$$\begin{align*}
d (\ln S) &= \left[\frac{\partial }{\partial t} \ln S + \mu S \frac{\partial }{\partial S} \ln S + \frac{1}{2} \sigma^{2}S^{2}\frac{\partial^{2}}{\partial S^{2}} \ln S\right]dt + \sigma S \frac{\partial }{\partial S} \ln S \;dW\\
&= \left[\mu S \cdot  \frac{1}{S} + \frac{1}{2} \sigma^{2}S^{2}\left(- \frac{1}{S^{2}}\right)\right]dt + \sigma S \cdot \frac{1}{S} dW\\
&= \left(\mu - \frac{1}{2}\sigma^{2}\right)dt +\sigma\; dW.
\end{align*}$$
Therefore $\ln S$ follows the standard [[Wiener process]] and takes the form
$$\ln S \sim N\left(\left(\mu - \frac{1}{2} \sigma^{2}\right)\Delta t, \sigma^{2}\Delta t\right).$$
At time $t$, $X= \ln S$ has probability distribution
$$f(X) = \frac{1}{\sqrt{2 \pi \sigma^{2} t}} \exp\left\{-\frac{\left[(X-X_{0}) - (\mu - \frac{1}{2}\sigma^{2})t\right]^{2}}{2 \sigma^{2}t}\right\}.$$
Now recall that $P(S)dS$ is [[Particles random walk - time dependant process|the probability of finding]] $S$ in the interval $[S,S+dS]$.
By the same logic $f(X)dX$ is the probability of finding $X$ in the interval $[X,X+dX]$.
Now, if the same intervals are mapped correctly, the probability of landing in such intervals should be the same. That is,
$$P(S)dS = f(X)dX$$
and by rearranging,
$$\begin{align*}
P(S) &= f(X) \frac{dX}{dS} \\
&= f(X) \frac{d}{dS}\ln S \\
&= \frac{1}{S}f(X)\\
&= \frac{1}{\sqrt{2 \pi \sigma^{2} t}} \frac{1}{S} \exp\left\{-\frac{\left[(X-X_{0}) - (\mu - \frac{1}{2}\sigma^{2})t\right]^{2}}{2 \sigma^{2}t}\right\}\\
&= \frac{1}{\sqrt{2 \pi \sigma^{2} t}} \frac{1}{S} \exp\left\{-\frac{\left[\ln(S/S_{0}) - (\mu - \frac{1}{2}\sigma^{2})t\right]^{2}}{2 \sigma^{2}t}\right\}.
\end{align*}$$
