---
type: thm
tag: MT2505
---
Let $G$ be a [[Groups|group]] and let $N$ be a [[Normal subgroups]] of $G$.
Let $G/N$ be the [[Quotients groups|quotient group]].

>[!thm]- $G/N$ is a group