---
alias: unbiased estimator
type: def
tag: MT2508
---
>[!def] Definition
>An [[Estimators|estimator]] $T$ of $\theta$ is unbiased if $\mathbb{E}(T)=\theta$

---

#### Spaced repetition

What is an unbiased estimator?
?
An [[Estimators|estimator]] $T$ of $\theta$ is unbiased if $\mathbb{E}(T)=\theta$
