---
tags:
  - MT3501
  - MT3504
type: 
aliases:
  - self-adjoint
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Inner product spaces|inner product space]] with inner product $\langle \cdot , \cdot \rangle$.

>[!def] Definition
>A linear transformation $T:V\to V$ is self-adjoint if $T^{*}=T$.

BELOW FOR APPLIED MATHEMATICS:

Let $C^{2}(a,b)$ be the [[Inner product space of twice-differentiable functions|inner product space of twice-differentiable functions]].
Let $L$ be in [[Sturm-Liouville form]].

>[!def] Definition
>$L$ is self-adjoint if
>$$\int_{a}^{b}(y_{1}L[y_{2}]-y_{2}L[y_{1}])dx=0$$