---
type: def
tags:
  - MT2508
  - MT3508
  - MT3507
aliases:
  - log-likelihood
---
Let $\boldsymbol y=\set{y_{1},...,y_{n}}$ be a set of observations each with [[Probability mass function|pmf]]/[[Probability density function|pdf]] $f(y_{i})$ which depend on some known explanatory variables $\boldsymbol{x}$, known parameters $\boldsymbol{\gamma}$, and unknown parameters $\boldsymbol{\theta}$.

> [!def] Definition
> The log-likelihood is the log of the [[likelihood]]:
> $$l(\boldsymbol{\theta};\boldsymbol{y},\boldsymbol{x},\boldsymbol{\gamma})=\log L(\boldsymbol{\theta};\boldsymbol{y},\boldsymbol{x},\boldsymbol{\gamma})= \sum\limits_{i=1}^{n} \log f(y_{i})$$
