---
tags:
  - MT4531
aliases:
---
Let $\theta \in \Theta$ be a parameter of interest. Let $H_{0}: \theta \in \Theta_{0}$ vs $H_{1}: \theta \in \Theta_{1}$ be hypothesis statements, where $\Theta_{0}$ and $\Theta_{1}$ are disjoint and exhaustive subsets of the parameter space $\Theta$.
Assign a prior on the parameter statement: let $p_{i}=\mathbb P(H_{i})= \mathbb P(\theta \in \Theta_{i})$, for $i=0,1$, such that $p_{0}+p_{1}=0$.

> [!def] Definition
> The Bayes factor for $H_{0}$ against $H_{1}$ is a test statistic of ratio of posterior odds to prior odds
> $$B_{01} = \frac{\mathbb{P}(\theta \in
\Theta_0|\mathbf{x})/\mathbb{P}(\theta \in \Theta_1|\mathbf{x})}
{p_0/p_1}
= \frac{p_{1}\mathbb{P}(\theta \in
\Theta_0|\mathbf{x})}{p_{0}\mathbb{P}(\theta \in \Theta_1|\mathbf{x})} = \frac{f(\mathbf{x}|\theta \in \Theta_0)}{f(\mathbf{x}|\theta \in
\Theta_1)}.$$

> [!gen]- Motivation
> The prior odds for $H_{0}$ against $H_{1}$ are $p_{0}/p_{1}$. The prior odds specify your prior beliefs concerning which of the two hypothesis are more likely.
> Once we specified the prior, we observe data $\boldsymbol{x}$, and wish to update our prior beliefs concerning the hypothesis. We do this by calculating the corresponding posterior odds, given by,
> $$\frac{\mathbb{P}(\theta \in \Theta_0|\mathbf{x})}{\mathbb{P}(\theta \in
>     \Theta_1|\mathbf{x})} = \frac{p_0 f(\mathbf{x}|\theta \in \Theta_0)
> / f(\mathbf{x})} {p_1
>     f(\mathbf{x}|\theta \in \Theta_1)/ f(\mathbf{x})}
> = \frac{p_0 f(\mathbf{x}|\theta \in \Theta_0)} {p_1
>     f(\mathbf{x}|\theta \in \Theta_1)}$$
> Then if the posterior odds are greater than one, we would favour the null hypothesis.
> 
> Bayes factor is a slight modification of the above statistic.

> [!thm]- Optimal decision
> Under the loss function
> $$L = \begin{cases}
   0  & \text{choose } H_{0} \text{ when } H_{0} \text{ is true}; \\
   0  & \text{choose } H_{1} \text{ when } H_{1} \text{ is true}; \\
   l_{10}  & \text{choose } H_{1} \text{ when } H_{0} \text{ is true}; \\
   l_{01}  & \text{choose } H_{0} \text{ when } H_{1} \text{ is true}, \\
   \end{cases}$$
> the optimal decision is to choose $H_{1}$ over $H_{0}$ if and only if
> $$B_{01}< \frac{l_{01} \mathbb P(H_{1})}{l_{10} \mathbb P(H_{0})}.$$

> [!thm] Simple hypothesis ($H_{0}:\theta= \theta_{0}$ vs $H_{1}: \theta = \theta_{1}$)
> Use 
> $$B_{01} = \frac{f(\mathbf{x}|\theta \in \Theta_0)}{f(\mathbf{x}|\theta \in
\Theta_1)}.$$

> [!thm] Composite hypothesis ($H_{0}:\theta \in  \Theta_{0}$ vs $H_{1}: \theta \in  \Theta_{1}$)
> Suppose we have the prior for $\theta$, namely $p(\theta)$. Then
> $$\begin{align*}
\mathbb P(\theta \in \Theta_{i})&=\int_{\theta \in \Theta_{i}}^{}p(\theta) \;d \theta\\
\mathbb P(\theta \in \Theta_{i}|\boldsymbol{x})&=\int_{\theta \in \Theta_{i}}^{}\pi(\theta|\boldsymbol{x}) \;d \theta
\end{align*}$$
> and
> $$B_{01} = \frac{p_{1}\int_{\theta \in \Theta_{0}}^{}\pi(\theta|\boldsymbol{x}) \;d \theta}{p_{0}\int_{\theta \in \Theta_{1}}^{}\pi(\theta|\boldsymbol{x}) \;d \theta}.$$

> [!thm] Composite hypothesis ($H_{0}:\theta =  \theta_{0}$ vs $H_{1}: \theta \neq  \theta_{0}$)
> Suppose that we have the posterior for $\theta$ conditional on the null hypothesis, namely $p(\theta|H_{i})$.
> Then, by noting that $p(H_{i}|\theta)=p(\theta  \in \Theta_{i}|\theta)= 1$ when $\theta \in \Theta_{i}$ and zero otherwise,
> $$p(\theta|H_{i})= \frac{p(H_{i}|\theta)p(\theta)}{p(H_{i})}=\begin{cases}
   1 \cdot p (\theta) / p_{i}  &  \text{when } \theta \in \Theta_{i} \\
   0 & \text{otherwise.}
   \end{cases}$$
> Hence, when $\theta \in \Theta_{i}$, $p(\theta)=p(\theta|H_{i})p(H_{i})$. Another proof would be using conditional probability: (1) $p(\theta,H_{i})=p(\theta)p(H_{i})=p(\theta)$ when $\theta \in \Theta_{i}$ and zero otherwise; (2) $p(\theta,H_{i})=p(\theta|H_{i})p(H_{i})$. Combine and we have the above result.
> Now, let's calculate the posterior of the hypothesis test
> $$\begin{align*}
   \mathbb P(\theta \in \Theta_{i}|\boldsymbol{x}) &= \int_{\theta \in \Theta_{i}}^{}\pi(\theta|\boldsymbol{x}) \;d \theta\\
   &= \frac{1}{f(\boldsymbol{x})}\int_{\theta \in \Theta_{i}}^{} f(\boldsymbol{x}| \theta)p(\theta) \;d \theta\\
   &= \frac{1}{f(\boldsymbol{x})}\int_{\theta \in \Theta_{i}}^{} f(\boldsymbol{x}| \theta)p(\theta|H_{i})p(H_{i})\;d \theta\\
   &= \frac{p_{i}}{f(\boldsymbol{x})}\int_{\theta \in \Theta_{i}}^{} f(\boldsymbol{x}| \theta)p(\theta|H_{i})\;d \theta
   \end{align*}$$
> So
> $$B_{01} = \frac{p_{1}p_{0}\int_{\theta \in \Theta_{0}}^{} f(\boldsymbol{x}| \theta)p(\theta|H_{0}) \;d \theta}{p_{0}p_{1}\int_{\theta \in \Theta_{1}}^{} f(\boldsymbol{x}| \theta)p(\theta|H_{1}) \;d \theta},$$
> which is the ratio of weighted likelihoods by the densities $p_{i}(\theta)$.
