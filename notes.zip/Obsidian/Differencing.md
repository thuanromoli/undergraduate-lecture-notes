---
tags:
  - MT4527
aliases:
---
Let $X_{t}=\sum\limits_{i=0}^{k}a_{i}t^{i}+Y_{t}$ be a [[Classical decomposition model|polynomial trend model]].

> [!thm] Theorem
> Applying the [[Lag-1 difference operator|lag-1]] $k$ times will reduce the polynomial trend to a constant. That is, 
> $$\nabla^{k}X_{t} = \cdots + \nabla^{k} m_{t} + \cdots$$
> where $\nabla^{k}m_{t}=a_{k}$ is constant.

Let $X_{t} = m_{t}+s_{t}+Y_{t},$ be the [[Classical decomposition model|classical decomposition model]].

> [!thm] Theorem
> Applying the [[Lag-d difference operator|lag-d]] $k$ will reduce the classical composition model to a non-seasonal with trend model. That is, 
> $$\nabla_{d}X_{t} = m_{t}-m_{t-d} + Y_{t} - Y_{t-d}$$
> as $s_{t} = s_{t-d}$.
