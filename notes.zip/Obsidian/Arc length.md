---
type: def
tags:
  - MT2506
aliases:
  - arc length
---
Let $\boldsymbol r(s)$ be a curve.

>[!def] Definition
>The arc length of the curve is:
>$$\int_{s_1}^{s_2}\lvert\frac{\text{d}\boldsymbol r}{\text{d}s}\rvert\text{d}s=
\int_{s_1}^{s_2}\sqrt{(\frac{\text{d}x}{\text{d}s})^2+(\frac{\text{d}y}{\text{d}s})^2+(\frac{\text{d}z}{\text{d}s})^2}\text{d}s$$

---

#### Spaced repetition

Define the arc length of a curve
?
$$\int_{s_1}^{s_2}\lvert\frac{\text{d}\boldsymbol r}{\text{d}s}\rvert\text{d}s=
\int_{s_1}^{s_2}\sqrt{(\frac{\text{d}x}{\text{d}s})^2+(\frac{\text{d}y}{\text{d}s})^2+(\frac{\text{d}z}{\text{d}s})^2}\text{d}s$$
