---
tags:
  - MT3506
aliases:
---
>[!gen] ODE
>$$x^{2}y''+xy'+(x^{2}-\nu^{2})y=0$$
>where $\nu$ is a parameter.

> [!gen] Motivation
> This equation arises from the separation of variables problems in cylindrical or plane polar coordinates.

> [!gen] Solution (at $x=0$)
> Step 0: classification of point.
> The ode in standard form is $y''+\frac{1}{z}y'+\frac{(x^{2}- \nu^{2})}{x^{2}} y=0$. And at $x=0$, $p(x)$ and $q(x)$ are both unbounded. However, $xp(x) =1$ and $x^{2}q(x)=-\nu^{2}$ at $x=0$ and so it is a regular singular point.
> 
> Step 1,2.
> Consider a solution of the form $y = \sum\limits_{n=0}^{\infty}a_{n}x^{n+s}$.
> Then $y' = \sum\limits_{n=0}^{\infty}a_{n}(n+s)x^{n+s-1}$ and $y'' = \sum\limits_{n=0 }^{\infty}a_{n}(n+s)(n+s-1)x^{n+s-2}$.
> 
> Step 3: sub into the ODE.
> $$\sum\limits_{n=0}^{\infty}\Big[ (n+s)^{2}- \nu^{2} \Big]a_{n} x^{n+s}+ \sum\limits_{n=2}^{\infty}a_{n-2}x^{n+s}=0$$
> 
> Step 4: indicial equation and recurrence relations.
> $$\begin{cases}
   n=0 \implies a_{0}(s^{2}-\nu^{2}) = 0 \\
   n = 1 \implies a_{1}(2s+1) = 0 \\
   n \geqslant 2 \implies a_{n}(n^{2}+2ns) + a_{n-2}= 0
   \end{cases}$$
> We use the first equation to find a solution for $s$.
> We have $s= \pm \nu$.
> The second equation and the theory from the general method tell us that we have issues when $s_{1}-s_{2}=N \in \mathbb N$ $\iff$ $\nu - (- \nu)=N$ $\iff$ $\nu = N/2 = 0,\frac{1}{2},1,...$

> [!gen] Case 1: $\nu\neq 0, \frac{1}{2},1,\cdots$
> We are guaranteed two linearly independent solutions.
> Note that $a_{1}(2s+1)=0$ if and only if $a_{1}=0$ or $s=- \frac{1}{2}$ but $s = \pm \nu \neq \pm \frac{1}{2}$. So it must be $a_{1}=0$
> Step 5: solve the recurrence relation.
> $$\begin{cases}
   a_{0} = \text `a_{0} \text ' \\
   a_{1} = 0 \\
   a_{n} = - \frac{a_{n-2}}{n(n+2s)}, & n \geqslant 2.
   \end{cases}$$
> It turns out that
> $$a_{2k} = \frac{(-1)^{k}a_{0}\Gamma(1+s)}{2^{2k} \Gamma(k+1)\Gamma(k+1+s)}$$
> and we often take the convention $a_{0}=\frac{1}{2^{s}}\Gamma(1+s)$ so that the solution is
> $$\begin{align*}
   y(x) &= A \underbrace{\sum\limits_{k=0}^{\infty}\frac{(-1)^{k}}{\Gamma(k+1) \Gamma(k+1+ \nu)}\left(\frac{x}{2}\right)^{2k+ \nu}}_{s=+\nu} + B\underbrace{\sum\limits_{k=0}^{\infty}\frac{(-1)^{k}}{\Gamma(k+1) \Gamma(k+1- \nu)}\left(\frac{x}{2}\right)^{2k -\nu}}_{s=-\nu}\\
   &= A J_{\nu}(x)+BJ_{-\nu}(x)
   \end{align*}$$
   where $A$ and $B$ are arbitrary constants and $J_{\pm \nu}(x)$ is the Bessel function of the first kind.

> [!gen] Case 2: $\nu= 0, \frac{1}{2},1,\cdots$
> Briefly,
> - If $\nu=0$, then $s_{1}=s_{2}=0$ and we only have one linearly independent solution $J_{0}(x)$. We must therefore use a Bessel function of the second kind $Y_{0}(x)=J_{0}(x)\log x + \sum\limits_{n=0}^{\infty}b_{n}x^{n}$.
> - If $\nu=\frac{1}{2}$, then surprisingly there are no problems as the recurrence relation will give rise to both an odd and even series.
> - If $\nu=1,\frac{3}{2},2,...$ the recurrence relation leads to a contradiction
> Example: Let $\nu = N/2$ and consider $s_{2}= - \nu =-N/2$ for some $N \in \mathbb N$.
> Then the recurrence relation 
> $$\begin{align*}
   a_{n}(n^{2}+2ns) + a_{n-2}= 0 \implies a_{N} (N + 2N (-N /2)) + a_{N-2}=0 \implies a_{N-2}=0
   \end{align*}$$
> But recursively,
> $$\begin{cases}
   a_{0} = \text `a_{0} \text ' \\
   a_{2} = -\frac{a_{0}}{2(2-10)} \neq 0 \\
   a_{4} = -\frac{a_{2}}{4(4-10)} \neq 0 \\
   \vdots \\
   a_{N-2} = -\frac{a_{N-4}}{(N-4)(N-4 + 2 (N/2))} =-\frac{a_{N-4}}{(N-4)(N-4 + N)} \neq 0
   \end{cases}$$
> But this is a contradiction.
> So once again we seek a solution of the second kind $Y_{N}(x)=J_{N}(x)\log x + \sum\limits_{n=0}^{\infty}b_{n}x^{n}$.
> 
> Hence the solutions for $\nu =  0,\frac{1}{2},1,...$ are of the form
> $$y(x) = A J_{\nu}(x)+B Y_{\nu}(x)$$
> where $J_{\nu}(x)$ is a Bessel function of the first kind and $Y_{\nu}(x)$ is a Bessel function of the second kind that can be defined by
> $$Y_{\nu}(x)=\frac{J_{\nu}(x)\cos (\nu \pi)- J_{- \nu}(x)}{\sin  (\nu \pi)}.$$
