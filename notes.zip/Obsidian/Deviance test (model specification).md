---
tags:
  - MT3508
aliases:
---
> [!gen] [[Statistical hypothesis|Hypothesis]]
> $H_{0}$: the data follow a specified distribution.
> $H_{1}$: the data do not follow a specified distribution.

> [!gen] [[Test statistics]] ($\phi$ must be known, can't use with Bernoulli)
> $$D = \phi D^{*} \sim \phi \chi^{2}_{n-p}.$$
