---
type: thm
tags:
  - MT2505
  - MT4003
---
Let $G$ be a [[Groups|group]] and $N$ be a [[Normal subgroups|normal]] [[Subgroups|subgroup]] of $G$.

> [!thm]- $N \mathrel{\unlhd} G \iff N$ is a union of [[Conjugacy classes|conjugacy classes]] of $G$
> Suppose $N \mathrel{\unlhd} G$.
> Then for each element $x\in N$ and $g \in G$ the element $x^{g}\in N$.
> Hence the conjugacy class $x^{G}$ is a subset of $N$.
> As a union of subsets of a set is a subset of that set,
> $$N = \bigcup_{x\in N}\set{x} \subseteq \bigcup_{x\in N} x^{G} \subseteq N$$
> and so $N=\bigcup_{x\in N} \set{x^{g}:g\in G}$, and $N$ is a union of conjugacy classes.
> 
> Conversely, suppose that $N$ is a union of conjugacy classes.
> Then each element $x\in N$ is in some conjugacy class $y^{G}\subseteq N$ for some $y\in G$.
> But [[Conjugacy|conjugacy]] is an [[Equivalence relations|equivalence relation]], so $x^{G} = y^{G}$ and so $x^{G}\in N$.
> It now follows that the subgroup $N$ is [[Normal subgroups|normal]] in $G$, as for all $g\in G$, the conjugate $x^{g}\in x^{G}\subseteq N$.

^0df01d

> [!thm]- If $N \mathrel{\unlhd} G$ and $N \leqslant H \leqslant G$ then $N \mathrel{\unlhd} H$
> If $N \mathrel{\unlhd} G$ then $x^{g} \in N$ for all $x\in N$ and $g \in G$.
> So since $h \in G$, we deduce that $x^{h} \in N$ for all $x \in N$ and $h \in H$. So $N \mathrel{\unlhd} H$.

^b1e549

Below is not needed for MT4003.

> [!thm] Theorem
> All of the following statements are equivalent:
> 1. $N$ is a [[Normal subgroups|normal subgroup]] of $G$
> 2. the set $g^{-1}Ng=\set{g^{-1}xg : x\in N}$ equals $N \;\;\forall g\in G$
> 3. every [[Cosets|left coset]] of $N$ in $G$ is also a [[Cosets|right coset]] of $N$ in $G$ and vice-versa
> 4. $Ng=gN \;\;\forall g\in G$
