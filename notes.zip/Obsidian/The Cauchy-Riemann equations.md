---
tags:
  - MT3503
aliases:
---
Let $U$ be an [[Open sets|open subset]] of $\mathbb C$ and $f: U \to \mathbb C$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] defined on $U$.

> [!thm] [[Differentiability]] $\implies$ C-R equations are satisfied
> Write $f$ as its [[Real decomposition of complex functions|real decomposition]] $f(x+iy)=u(x,y)+iv(x,y)$ and suppose that $f$ is [[Differentiability|differentiable]] at $c=a+ib \in U$
> 
> Then the partial derivatives
> $$\frac{\partial u}{\partial x},\;\; \frac{\partial u}{\partial y}, \;\;\frac{\partial v}{\partial x}, \;\;\frac{\partial v}{\partial y}$$
> of $u$ and $v$ exist at $(a,b)$ and satisfy
> $$\frac{\partial u}{\partial x}=\frac{\partial v}{\partial y}, \;\; \frac{\partial v}{\partial x}= - \frac{\partial u}{\partial y}.$$

> [!thm] C-R equations are satisfied AND derivatives are [[Continuity|continuous]] $\implies$ Differentiability
> Write $f$ as its [[Real decomposition of complex functions|real decomposition]] $f(x+iy)=u(x,y)+iv(x,y)$ and suppose that the partial derivatives
> $$\frac{\partial u}{\partial x},\;\; \frac{\partial u}{\partial y}, \;\;\frac{\partial v}{\partial x}, \;\;\frac{\partial v}{\partial y}$$
> of $u$ and $v$ exist and are continuous on $U$, and satisfy
> $$\frac{\partial u}{\partial x}=\frac{\partial v}{\partial y}, \;\; \frac{\partial v}{\partial x}= - \frac{\partial u}{\partial y}$$
> at every point of $U$.
> 
> Then $f$ is [[Holomorphic functions|holomorphic]] on $U$.

Proof: We prove the first statement only.
So suppose that $f$ is differentiable at $c \in U$.
Then $f'(c)= \lim\limits_{h \to 0}\frac{f(c+h)-f(c)}{h}$ exists and the limit must approach the same value no matter how $h$ approaches 0. 
In particular, we let $h\to 0$ through real numbers or through purely imaginary numbers to obtain the same limit.

Using the [[Real decomposition of complex functions|real decomposition of complex functions]], write $z= x+iy$ and $f(x+iy)=u(x,y) + iv(x,y)$ whenever $x+iy \in U$.
Fix a point $c = a+ib \in U$.
![[CRequations_att.png|500]]
Suppose now that $h$ is sufficiently small, such that $c+h =a+ib+h \in U$.
That is, we approach $c$ through the real line:
$$\begin{align*}
\lim\limits_{h \to 0}\frac{f(c+h)-f(c)}{h} &= \lim\limits_{h \to 0}\frac{f(a+ib+h)-f(a+ib)}{h}\\
&= \lim\limits_{h \to 0}\left(\frac{u(a+h,b)+iv(a+h,b)}{h} - \frac{u(a,b)+iv(a,b)}{h} \right)\\
&= \lim\limits_{h \to 0}\left(\frac{u(a+h,b)-u(a,b)}{h} +i \frac{v(a+h,b)-v(a,b)}{h}\right)\\
&=\lim\limits_{h \to 0}\left(\frac{u(a+h,b)-u(a,b)}{h}\right) +i\lim\limits_{h \to 0}\left(\frac{v(a+h,b)-v(a,b)}{h}\right)\\
&= \left.\frac{\partial u}{\partial x}\right|_{(a,b)} + i\left.\frac{\partial v}{\partial x}\right|_{(a,b)}.
\end{align*}$$
Suppose further that $h=ik$ is sufficiently small, such that  $c+ik=a+ib+ik \in U$.
Now we approach $c$ from the imaginary line:
$$\begin{align*}
\lim\limits_{k \to 0}\frac{f(c+h)-f(c)}{h} &= \lim\limits_{k \to 0}\frac{f(a+ib+ik)-f(a+ib)}{ik}\\
&= \lim\limits_{h \to 0}\left(\frac{u(a,b+k)+iv(a,b+k)}{ik} - \frac{u(a,b)+iv(a,b)}{ik} \right)\\
&= \lim\limits_{h \to 0}\left(\frac{u(a,b+k)-u(a,b)}{ik} +i \frac{v(a,b+k)-v(a,b)}{ik}\right)\\
&=\lim\limits_{h \to 0}\left(\frac{u(a,b+k)-u(a,b)}{ik}\right) +i\lim\limits_{h \to 0}\left(\frac{v(a,b+k)-v(a,b)}{ik}\right)\\
&=-i\lim\limits_{h \to 0}\left(\frac{u(a,b+k)-u(a,b)}{k}\right) +\lim\limits_{h \to 0}\left(\frac{v(a,b+k)-v(a,b)}{k}\right)\\
&= -i\left.\frac{\partial u}{\partial y}\right|_{(a,b)} + \left.\frac{\partial v}{\partial y}\right|_{(a,b)}\\
&= \left.\frac{\partial v}{\partial y}\right|_{(a,b)} -i\left.\frac{\partial u}{\partial y}\right|_{(a,b)}.
\end{align*}$$
The limits we just found must equal each other, so by comparing real and imaginary parts, we obtain
$$\frac{\partial u}{\partial x}=\frac{\partial v}{\partial y}, \;\; \frac{\partial v}{\partial x}= - \frac{\partial u}{\partial y}$$
as required.