---
tags:
  - MT3508
aliases:
  - null deviance
  - residual deviance
---
> [!def] Null deviance
> The null deviance is the [[Deviance and scaled deviance|deviance]] of the intercept-only model.

> [!gen] Remarks
> - It has $n-1$ degrees of freedom, where $n$ is the parameter count of the [[Saturated model|saturated model]] and $1$ is the parameter count of the intercept-only model.
> - It is analogous to the total sum of squares in a linear regression.
> - It is equal to the total sum of squares for a normal GLM with identity link.

> [!def] Residual deviance
> The residual deviance is the [[Deviance and scaled deviance|deviance]] of the fitted model.

> [!gen] Remarks
> - It has $n-p$ degrees of freedom, where $n$ is the parameter count of the [[Saturated model|saturated model]] and $p$ is the parameter count of the fitted model.
> - It is analogous to the residual sum of squares in a linear regression.
> - It is equal to the residual sum of squares for a normal GLM with identity link.
