---
tags:
  - MT3508
aliases:
  - LRCI
  - PLCI
---
> [!def] Relative likelihood function
> If the [[Likelihood|likelihood]] function $L(\theta)$ is maximised at $\theta = \widehat \theta$, the relative likelihood function is given by
> $$R(\theta) = \frac{L(\theta)}{L( \widehat \theta)}.$$
> 
> Note: (1) $R(\widehat \theta) = 1$, and (2) $0 < L(\theta) \leqslant 1 \implies 0<R(\theta)\leqslant 1$.

> [!def] Likelihood region
> A $100 \gamma \%$ likelihood region for $\theta$ is given by
> $$\set{\theta: R(\theta) \geqslant \gamma}.$$

> [!gen] Method
> Plot the log relative likelihood function $r(\theta) = l(\theta) - l(\widehat \theta)$.
> Note: (1) $r(\widehat \theta) = 0$, and (2) $-\infty<R(\theta)\leqslant 0$.
> And so the $100 \gamma \%$ likelihood interval is given by $\set{\theta: r(\theta) \geqslant \log \gamma}$.

> [!def] Definition
> The likelihood ratio statistic is defined by
> $$W(\theta) = -2r(\theta)$$
> and under appropriate regularity conditions, it can be shown that if $\theta$ is a one dimensional parameter, $W(\theta)$ has approximately a $\chi_{1}^{2}$ distribution for large samples.

> [!gen] Method (1 parameter only)
> Discretely:
> 1. Evaluate $l(\theta_{i};y)$ for $i =1,2,...$.
> 2. Calculate the differences $l(\widehat \theta;y)-l(\theta_{i};y)$ for $i=1,2,...$.
> 3. Find the lowest and largest $\theta_{i}$ for which the difference is smaller than 1.92 (the 95th quantile of the [[Chi-squared distributions]]).
> 
> Graphically:
> 1. Plot $l(\theta;y)$ against $\theta$.
> 2. Find the values of $\theta$ that satisfy $l(\widehat \theta;y)-l(\theta;y) \leqslant 1.92$.
> 3. So since $l(\widehat \theta;y)$ is a constant, say $M$, we seek to solve $M-1.92 \leqslant l(\theta;y)$.
> 4. In `R` this can be done by using `uniroot` and by solving $l(\theta;y)=M-1.92 \implies l(\theta;y)-(M-1.92)=0$

Note: we don't need to know how to find PLCIs for more than 1 parameter.
Note: we can use this result since it turns out that $W = 2 \left\{ l(\widehat{\boldsymbol{\theta}}; y) - l(\widehat{\boldsymbol{\theta}_0}; y) \right\} \sim \chi^2_r$ where the first $r$ elements of $\boldsymbol{\theta}$ are equal to some hypothesised values.