---
tags:
  - MT4528
type: 
aliases:
---
Let $\set{X(t):t \geqslant 0}$ be a [[Birth and death processes|Birth/death process]].

>[!thm] Theorem
>The [[Stationary distributions|limiting distribution]] $\pi_{n}=\lim\limits_{t \to \infty} \mathbb P(X(t)=n)$ exists if and only if
>$$R=\sum\limits_{n=1}^{\infty} \frac{\lambda_{n-1}\cdot\ldots\cdot \lambda_{0}}{\mu_{n}\cdot\ldots\cdot \mu_{1}} = \sum\limits_{n=1}^{\infty}R_{n}<\infty$$
>and in that case is given by
>$$\pi_{n}=\begin{cases}
   (1+R)^{-1} & \text{for } n=0 \\
   R_{n}(1+R)^{-1} & \text{for } n \geqslant 1
   \end{cases}$$
>Note that here we are assuming that $\mu_{n}>0$ for $n=1,2,...$

Proof:
We will only show that if a distribution exists, then it is of the form above.
Furthermore we use the [[Kolmogorov forward equations]] and the following theorem (only intuition is given): if a function in its limit is constant, then its derivative is 0.

So, suppose that an equilibrium distribution exists.
Then, $\pi_{0}(t)=\lim\limits_{t \to \infty}u_{0}(t)$ is constant in its limit. In particular, its derivative is 0.
The derivative is given by the Kolmogorov equations:
$$\frac{d}{dt}(\pi_{n}(t))=-\lambda_{0}\pi_{0}+\mu_{1}\pi_{1}=0$$
such that
$$\pi_{1}=\frac{\lambda_{0}}{\mu_{1}}\pi_{0}=R_{1}\pi_{0}$$
Similarly, $\pi_{1}(t)=\lim\limits_{t \to \infty}u_{1}(t)$ is constant in its limit. In particular, its derivative is 0.
The derivative is given by the Kolmogorov equations:
$$\frac{d}{dt}(\pi_{1}(t))=\lambda_{0}\pi_{0}-(\lambda_{1}+\mu_{1})\pi_{1}+\mu_{2}\pi_{2}=0$$
such that
$$\pi_{2}=\frac{\lambda_{1}\lambda_{0}}{\mu_{2}\mu_{1}}\pi_{0}=R_{2}\pi_{0}$$
Then by induction or otherwise we can show that
$$\pi_n=R_{n}\pi_{0}$$
Then using the honesty condition, $\sum\limits_{n=0}^{\infty}\pi_{n}=1$ we conclude that
$$\begin{align*}
 & \sum\limits_{n=0}^{\infty}\pi_{n}=1\\
 \iff &\pi_{0}+\sum\limits_{n=1}^{\infty}\pi_{n}=1\\
 \iff &\pi_{0}+\sum\limits_{n=1}^{\infty}R_{n}\pi_{0}=1\\
 \iff &\pi_{0}+\pi_{0}\sum\limits_{n=1}^{\infty}R_{n}=1\\
 \iff &\pi_{0}+\pi_{0}R=1\\
 \iff &\pi_{0}(1+R)=1\\
 \iff &\pi_{0}=(1+R)^{-1}
 \end{align*}$$
