---
type: def
tag: MT2507
---
>[!def] Definition
>Using the 1st and 2nd [[Newton's Laws of motion]], the Equation of Motion is the following:$$\boldsymbol F = \frac{d \boldsymbol p}{dt}=m\frac{d \boldsymbol v}{dt}=m\frac {d^{2}\boldsymbol r}{dt^{2}}$$where $m$ is the mass of the object.
