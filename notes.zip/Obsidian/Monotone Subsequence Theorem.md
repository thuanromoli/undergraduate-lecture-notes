---
tags:
  - MT2502
aliases:
---
Let $(x_{n})_{n}$ be a [[Sequences|sequence]].

> [!thm] Theorem
> Every sequence $(x_{n})_{n}$ has a [[Monotonicity|monotone]] [[Subsequences|subsequence]].
