---
tags:
  - MT3503
aliases:
---
Let $f$ be a [[Functions|function]] of a [[Complex numbers|complex variable]] with an [[Isolated singularity|isolated singularity]] at $a$ and [[Laurent series]]  $\sum\limits_{\infty}^{\infty}c_{n}(z-a)^{n}$ at $a$.

> [!def] Definition
> The residue of $f$ at $a$ is the coefficient $c_{-1}$ appearing in the Laurent series, we write
> $$c_{-1} = \mathrm{res}(f,a)$$
> for this residue.
