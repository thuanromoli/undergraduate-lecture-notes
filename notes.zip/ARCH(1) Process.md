---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A stochastic process $(\varepsilon_{t})_{t \in \mathbb Z}$ is called an autoregressive conditionally heteroscedastic process of order 1 if there exists an independent [[White noise|white noise]] $(\eta_{t})_{t \in \mathbb Z}$ of unit variance $\sigma^{2}_\eta=1$ and real numbers $\alpha_{0}>0, \alpha_{1}\geqslant 0$ such that for all $t \in \mathbb Z$,
> $$\begin{align*}
   \varepsilon_{t}&=\sigma_{t} \eta_{t} \qquad\text{with}\\
   \sigma^{2}_{t} &= \alpha_{0}+\alpha_{1} \varepsilon^{2}_{t-1}
   \end{align*}$$
> where $\eta_{t}$ is referred to as "innovation".

> [!thm] Properties (under certain [[Stationarity of AR(p) Processes|regularity conditions]])
> - Unconditional mean $$\mathbb E(\varepsilon_{t})=0.$$
> - Unconditional variance (requiring $\alpha_{1}<1$) $$\text{Var }(\varepsilon_{t})= \frac{\alpha_{0}}{1-\alpha_{1}}.$$
> - Kurtosis (requiring normal $\eta_{t}$, $\alpha_{1}< \sqrt{3}/3$) $$\kappa_{\varepsilon}=3 \frac{1-\alpha_{1}^{2}}{1-3\alpha_{1}^{2}}>3$$

> [!gen] Remarks
> - An ARCH(1) process is a white noise.
> - The innovation's distribution is often specified as normal (then $\eta$ is a Gaussian white noise) or t-distributed (if heavy tails are needed).
> - Under suitable conditions, the ARCH(1) model can be represented in the form of an AR(1) process for $\varepsilon^{2}_{t}$ with mean $\frac{\alpha_{0}}{1-\alpha_{1}}$: $$\varepsilon^{2}_{t}= \alpha_{0}+\alpha_{1}\varepsilon^{2}_{t-1}+ \zeta_{t} \quad \text{with white noise} \quad \zeta_{t}= \varepsilon^{2}_{t}-\sigma_{t}^{2}.$$
> - ARCH(1) displays volatility clustering.
