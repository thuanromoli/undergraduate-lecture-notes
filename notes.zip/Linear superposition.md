---
tags:
  - MT3504
type: thm
aliases:
---
>[!thm] Theorem
>If $f_{1}(x)$ has [[Fourier Series]] $S_{1}$ and$f_{2}(x)$ has [[Fourier Series]] $S_{2}$, then $f(x)=\alpha f_{1}(x)+\beta f_{2}(x)$ has series $S=\alpha S_{1} + \beta S_{2}$.
>
>Proof: omitted (use the notion of integration as a linear operator).
