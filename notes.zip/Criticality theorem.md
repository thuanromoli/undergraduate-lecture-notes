---
tags:
  - MT4528
type: thm
aliases:
---
Let $\set{X_{n}:n=0,1,...}$ be a [[Galton-Watson processes|Galton-Watson process]] starting at $X_{0}=1$.
Let $\mu=\sum\limits_{k=0}^{\infty}kp_{k}$ denote the mean of offspring produced by a single individual.

>[!thm] Theorem
>1. $\mu < 1 \implies \mathbb E(X_{n})\to 0,\text{Var}(X_{n})\to 0,e=1$ (subcritical).
>2. $\mu = 1 \implies \mathbb E(X_{n})=1,\text{Var}(X_{n})\to \infty,e=1$ (critical).
>3. $\mu > 1 \implies \mathbb E(X_{n})\to \infty,\text{Var}(X_{n})\to \infty,e<1$ (supercritical).

Proof: omitted.
