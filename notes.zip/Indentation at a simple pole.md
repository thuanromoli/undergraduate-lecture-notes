---
tags:
  - MT3503
aliases:
---
> [!thm] Theorem
> Suppose that $f$ has a simple [[Classification of isolated singularities|pole]] at a point $a$ and $\gamma_\delta$ is a positively oriented arc of a circle centred at $a$, radius $\delta >0$ and subtending an angle $\theta$ at $a$. Then
> $$\lim_{\delta \to 0} \int_{\gamma_{\delta}} f(z) \, \mathrm{d}z = i \theta \mathrm{res}(f,a).$$

![[indpole_att.png|300]]