---
tags:
  - MT3506
aliases:
---
Let $\phi$ and $\psi$ be scalar fields.

> [!thm] Theorem
> Green's first identity is
> $$\iiint_{V} [\phi \nabla ^{2}\psi+\nabla  \psi \cdot \nabla \phi]\;dV = \iint_{S \text{ closed }} \phi \frac{\partial \psi}{\partial n}\;dS.$$

> [!thm] Theorem
> Green's second identity is $$\iiint_{V}[\phi \nabla ^{2}\psi-\psi \nabla ^{2}\phi]\;dV = \iint_{S}\left[\phi \frac{\partial \psi}{\partial n} - \psi \frac{\partial \phi}{\partial n}\right]dS.$$

Proof:
We start by noting that $\nabla \cdot (f \boldsymbol{F})=f (\nabla \cdot \boldsymbol{F})+ \boldsymbol{F} \cdot \nabla f$.
Let $f = \phi$ and $\boldsymbol{F}= \nabla \psi$ and write the above as $\nabla \cdot (\phi \nabla \psi) = \phi(\nabla \cdot \nabla \psi)+ \nabla \psi \cdot \nabla \phi$.
Then using [[Gauss' Theorem]],
$$\begin{align*}
&\iiint_{V} \boldsymbol{\nabla  \cdot}(\phi \nabla \psi)\;dV = \iint_{S \text{ closed}}(\phi \nabla  \psi)\cdot \boldsymbol{n}\;dS\\
\implies&\iiint_{V}[\phi(\nabla  \cdot \nabla \psi)+\nabla \psi \cdot \nabla \phi]\;dV = \iint_{S \text{ closed}} \phi \frac{\partial \psi}{\partial n} \;dS\\
\implies& \iiint_{V} [\phi \nabla ^{2}\psi+\nabla  \psi \cdot \nabla \phi]\;dV = \iint_{S \text{ closed }} \phi \frac{\partial \psi}{\partial n}\;dS
\end{align*}$$
This is Green's first identity.

Now we swap $\phi$ and $\psi$.
$$\begin{align*}
&\iiint_{V}[\psi \nabla ^{2}\phi+\nabla \psi \cdot \nabla  \phi]\;dV = \iint_{S}\psi \frac{\partial \phi}{\partial n}dS
\end{align*}$$
and subtract from the first expression to obtain Green's second identity
$$\begin{align*}
&\iiint_{V}[\phi \nabla ^{2}\psi-\psi \nabla ^{2}\phi]\;dV = \iint_{S}\left[\phi \frac{\partial \psi}{\partial n} - \psi \frac{\partial \phi}{\partial n}\right]dS.
\end{align*}$$