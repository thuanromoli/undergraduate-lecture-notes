---
tags:
  - MT3501
type: def
aliases:
  - minimum polynomial
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $T:V\to V$ be a [[Linear transformations|linear transformation]].

>[!def] Definition
>The minimum [[Polynomials|polynomial]] $m_{T}(x)$ is the monic [[Polynomials|polynomial]] over $F$ with smallest degree such that
>$$m_{T}(T)=0$$

>[!thm] Theorem
>The minimum [[Polynomials|polynomial]] $m_{T}(x)$ always exists and is unique.
>
>Proof existence:
>Recall that
>1. the composite of two linear transformations is also a linear transformation: in particular, $T^{2},T^{3},...$ are all linear transformations.
>2. [[The scalar multiple of linear transformations|a scalar multiple of a linear transformation]] is a linear transformation.
>3. [[The sum of linear transformations|the sum of two linear transformations]] is a linear transformation.
>
>Consider a [[Polynomials|polynomial]] $f(x)$ over the [[Fields (Algebra)|field]] $F$, say $f(x)=a_{0}+a_{1}x+a_{2}x^{2}+\cdots+a_{k}x^{k}$.
>The facts above ensure that we have a well-defined linear transformation $f(T)=a_{0}I+a_{1}T+a_{2}T^{2}+\cdots+a_{k}T^{k}$.
>
>Moreover, if $\dim V=n$ then the space $\mathcal{L}(V,V)$ has dimension $n^{2}$ (see [[The set of all linear transformations|the set of all linear maps]]).
>Now consider the following collection of [[Linear transformations|linear transformations]]: $I,T,T^{2},...,T^{n^{2}}$.
>There are $n^{2}+1$ linear transformations listed, so they must form a [[Linear independence|linearly dependent]] set. Hence there exists scalars $\alpha_{0},\alpha_{1},...,\alpha_{n^{2}}$ such that
>$\alpha_{0}I+\alpha_{1}T+\alpha_{2}T^{2}+\cdots+\alpha_{n^{2}}T^{n^{2}}=0$.
>Omitting zero coefficients and dividing by the lsat non-zero scalar $\alpha_{k}$ yields an expression of the form
>$T^{k}+b_{k-1}T^{k-1}+\ldots+b_{2}T^{2}+b_{1}T+b_{0}I=0$
>where $b_{i}=\alpha_{i}/\alpha_{k}$ for $i=1,2,...,k-1$.
>Hence there exists a monic [[Polynomials|polynomial]] $f(x)=x^{k}+b_{k-1}x^{k-1}+\ldots+b_{2}x^{2}+b_{1}x+b_{0}=0$ such that $f(T)=0$.
>
>Proof uniqueness:
>Suppose that $f(x)=\sum\limits_{i=1}^{k}\alpha_{i}x_{i}$ with $\alpha_{k}=0$ and $g(x)=\sum\limits_{i=1}^{k}\beta_{i}x_{i}$ with $\beta_{k}=0$ are two different [[polynomials]] of the same degree such that $f(T)=g(T)=0$, then
>$h(x)=f(x)-g(x)=\sum\limits_{i=0}^{k}(\alpha_{i}-\beta_{i})x^{i}$ with $\alpha_{k}=\beta_{k}=1$.
>Hence $h(x)=\sum\limits_{i=0}^{k-1}(\alpha_{i}-\beta_{i})x^{i}$ and a scalar multiple of $h(x)$ is monic such that $h(T)=0$.
