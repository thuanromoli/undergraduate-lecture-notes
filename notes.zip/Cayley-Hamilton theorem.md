---
tags:
  - MT3501
type: thm
aliases:
---
Let $V$ be a [[Dimension|finite-dimensional]] [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$ and let $T:V\to V$ be a [[Linear transformations|linear transformation]].

>[!thm] Theorem
>If $C_{T}(x)$ is the [[Characteristic polynomials|characteristic polynomial]] of $T$, then
>$$C_{T}(T)=0$$
