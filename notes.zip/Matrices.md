---
type: def
tag: MT2501
alias: [matrix,matrices]
---
Let $S$ be a set.

>[!def] Matrix
>A $m\times n$ matrix over $S$ is an array consisting of $m$ rows and $n$ columns, with entries from $S$:
>$$\begin{pmatrix}
 a_{11} & a_{12} & \cdots & a_{1n} \\
 a_{21} & a_{22} & \cdots & a_{2n} \\
 \vdots & \vdots & \ddots & \vdots \\
 a_{m1} & a_{n2} & \cdots & a_{mn} \\
 \end{pmatrix}$$
>where $a_{ij} \in S \;\;\forall i,j$.

>[!def] Set of all matrices over $S$
>The set of all $m\times n$ matrices over $S$ is denoted by $M_{m\times n}(S)$
