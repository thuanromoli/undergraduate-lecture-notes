---
tags:
  - MT3504
type: mthd
aliases:
---
>[!gen] ODE
>$$ay''+by'+cy=0$$
>where $a,b,c$ are constants.

>[!gen] Auxiliary equation
>Let $y=e^{\lambda x}$ where $\lambda$ is constant.
>Then $a \lambda^{2}e^{\lambda x}+b \lambda e^{\lambda x}+ c e^{\lambda x}=0$.
>The auxiliary equation is
>$$a \lambda^{2}+b \lambda+c=0$$

>[!gen] Solution
>There are three cases to consider depending on the roots of the auxiliary equation:
>1. $\lambda_{1}\neq \lambda_{2}$ with $\lambda_{1},\lambda_{2}\in \mathbb{R}$ (distinct real roots): $y_{1}=e^{\lambda_{1}x}$, $y_{2}=e^{\lambda_{2}x}$.
>2. $\lambda_{1} = \lambda_{2}$ with $\lambda_{1},\lambda_{2}\in \mathbb{R}$ (repeated real roots): $y_{1}=e^{\lambda_{1}x}$, $y_{2}=xe^{\lambda_{1}x}$.
>3. $\lambda_{\pm} = \alpha+i \beta$ with $\lambda_{\pm}\in \mathbb{C}$ (complex conjugate roots): $y_{1}=e^{\alpha x}\cos(\beta x)$, $y_{2}=e^{\alpha x}\sin(\beta x)$.
>
>And for each of these cases, the [[General solution of Second-Order ODEs|complimentary function]] is
>$$y=Ay_{1}+By_{2}$$ where $A$ and $B$ are constants.

---

#### Spaced repetition

What is the form of a constant coefficients homogeneous second-order ODE?
?
>$ay''+by'+cy=0$ where $a,b,c$ are constants.

What is the auxiliary equation of a constant coefficients homogeneous second-order ODE?
?
>$a \lambda^{2}+b \lambda+c=0$

How do you solve $ay''+by'+cy=0$?
?
>There are three cases to consider depending on the roots of the auxiliary equation:
>1. $\lambda_{1}\neq \lambda_{2}$ with $\lambda_{1},\lambda_{2}\in \mathbb{R}$ (distinct real roots): $y_{1}=e^{\lambda_{1}x}$, $y_{2}=e^{\lambda_{2}x}$.
>2. $\lambda_{1} = \lambda_{2}$ with $\lambda_{1},\lambda_{2}\in \mathbb{R}$ (repeated real roots): $y_{1}=e^{\lambda_{1}x}$, $y_{2}=xe^{\lambda_{1}x}$.
>3. $\lambda_{\pm} = \alpha+i \beta$ with $\lambda_{\pm}\in \mathbb{C}$ (complex conjugate roots): $y_{1}=e^{\alpha x}\cos(\beta x)$, $y_{2}=e^{\alpha x}\sin(\beta x)$.
>
>And for each of these cases, the [[General solution of Second-Order ODEs|complimentary function]] is
>$$y=Ay_{1}+By_{2}$$ where $A$ and $B$ are constants.
