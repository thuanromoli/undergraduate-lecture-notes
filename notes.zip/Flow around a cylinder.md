---
tags:
  - MT4509
aliases:
---
Consider an inviscid, incompressible and potential flow.

> [!thm] Flow around a cylinder
> The potential and components of velocity for the irrotational flow around a 2d cylinder, of radius $R_{0}$ are
> $$\begin{cases}
   \Phi &= \frac{\Gamma \phi}{2 \pi}+U \left(R+ \frac{R_{0}^{2}}{R}\right)\cos \phi\\
   u_{R}&= U\left(1-\frac{R_{0}^{2}}{R^{2}}\right)\cos \phi\\
   u_{\phi}&= \frac{\Gamma}{2 \pi R}-U\left(1+\frac{R_{0}^{2}}{R^{2}}\right)\sin \phi
   \end{cases}$$
> ![[cylinderflow_att.png|400]]


Consider a 2D flow in a domain $\mathbb R^{2}\setminus A$. This domain is multiply connected.
Key prediction: there can be lift even without drag.
Let us use the potential
$$\Phi =\Phi_{0}+\Phi_{1}+\Phi_{2}= \underbrace{\frac{\Gamma \phi}{2 \pi}}_\text{circulation} + \underbrace{Ux}_{\text{unfifrom flow}} + \underbrace{\frac{U R_{0}^{2}x}{R^{2}}}_{\text{dipole}}.$$

> [!gen]- Motivation behind the circulation term
> We are in potential flow, how can there be circulation?
> On the boundary $C_{A}$ there might be circulation.
> 
> Consider two contours $C_{1}$ and $C_{2}$.
> ![[contouraerofoil_att.png|200]]
> $C_{1}$ is called reducible and
> $$\Gamma_{2} = \oint_{\mathcal C_{2}}\boldsymbol{u \cdot }d \boldsymbol{l}=\iint_{A(\mathcal C_{2})} (\nabla  \times \boldsymbol{u}) \cdot \boldsymbol{n}\;dS=0$$
> while $C_{2}$ is called irreducible and we need to be more careful. Consider the contour $C$ composed as below.
> ![[circaerofoil_att.png|200]]
> then (analogue to the [[Deformation Theorem]]) we have
> $$\Gamma_{1}= \oint_{\mathcal C_{1}}\boldsymbol{u \cdot}d \boldsymbol{l}= \iint_{A(\mathcal C_{1})\setminus A} (\boldsymbol{\nabla  \times u}) \cdot \boldsymbol{n}\;dS+\oint_{\partial A}\boldsymbol{u \cdot}d \boldsymbol{l}= 0+\oint_{\partial A}\boldsymbol{u \cdot}d \boldsymbol{l}$$
> i.e., $\Gamma_{1}$ is the same for any curve $\mathcal C$ which goes around $A$, anti-clockwise.
> 
> Now recall that $\boldsymbol{u}= \nabla \Phi$.
> $$\Gamma_{1}=  \oint_\mathcal {C_{1}} \boldsymbol{u} \cdot d \boldsymbol{l}=\oint_\mathcal {C_{1}} \nabla \Phi \cdot d \boldsymbol{l}=\oint_\mathcal{C_{1}} d \Phi = \Phi \Big|_{\mathcal {C_{1}}} \implies \Phi \text{ is multivalued}.$$
> Then note that
> $$\Phi=B \phi \implies \Phi \Big|_\mathcal {C_{1}}=B \phi\Big|_{\phi=2 \pi}- B \phi\Big|_{\phi=0} = 2 \pi B= \Gamma \implies B = \frac{\Gamma}{2 \pi}$$
> for some $\Gamma$.
> 
> Note that $\nabla ^{2}\phi =0$ so $\phi$ is a potential.
> So $\Phi = \frac{\Gamma \phi}{2 \pi}$, which is multivalued. But the velocity field is still single valued
> $u_{R} = \frac{\partial \Phi}{\partial R}=0$ and $u_{\phi}= \frac{1}{R}\frac{\partial \Phi}{\partial \phi}= \frac{\Gamma}{2 \pi R}$.

It can be shown that $\Phi$ is indeed a potential as $\nabla^{2}\Phi=0$.

We want to express the potential in polar coordinates
![[spherpolcoord_att.png|300]]

It turns out that
$$\begin{cases}
   \Phi &= \frac{\Gamma \phi}{2 \pi}+U \left(R+ \frac{R_{0}^{2}}{R}\right)\cos \phi\\
   u_{R}&= U\left(1-\frac{R_{0}^{2}}{R^{2}}\right)\cos \phi\\
   u_{\phi}&= \frac{\Gamma}{2 \pi R}-U\left(1+\frac{R_{0}^{2}}{R^{2}}\right)\sin \phi
   \end{cases}$$

What happens on the surface, at $R=R_{0}$?
$$\begin{cases}
   u_{R}&=0\\
   u_{\phi}&= \frac{\Gamma}{2 \pi R_{0}}-2U \sin \phi
   \end{cases}$$
We want to evaluate where the stagnation points exist so we want to see where $u_\phi=0$.
$$u_{\phi}= 0 \iff \frac{\Gamma}{2 \pi R_{0}}-2U \sin \phi =0 \iff \sin \phi = \frac{\Gamma}{4 \pi R_{0} U}<1$$
Different cases
- $\Gamma=0 \qquad\qquad\;\implies \sin \phi=0 \qquad\implies$ two stagnation points at $\phi=0 \text{ and } \phi=\pi$.
- $0<\Gamma<4 \pi R_{0}U\implies 0 <\sin \phi <1 \implies$ two stagnation points in the range $0 < \phi < \pi$.
- $\Gamma=4 \pi R_{0}U \quad\;\;\implies \sin \phi =1 \qquad\implies$ stagnation points coalesce at $\phi= \pi/2$.
- $\Gamma>4 \pi R_{0}U \quad\;\;\implies \sin \phi >1 \qquad\implies$ stagnation point leaves the cylinder.

We want to work out the force.
$$\boldsymbol{F}=- \iint_{S \text{ closed}}(p-p_{\infty}) \cdot n \;dS$$
But we need to find $p$ first.
Assume $\Gamma < 4 \pi R_{0} U$ so that we can use a streamline going from $-\infty$ to the surface of a cylinder, assume a steady flow, ignore gravity.

We use steady Bernoulli, take streamline with end points at -$\infty$ and on the cylinder surface.
At a far point: $p = p_\infty$, $|\boldsymbol{u}| \to \sqrt{U^{2}\cos^{2} \theta+U^{2}\sin^{2} \theta}=U$.
On the body, $p=?$, $|\boldsymbol{u}|=|u_{\phi}|$.
$$\frac{p_\infty}{\rho}+\frac{1}{2}U^{2}=\frac{p(R_{0}, \phi)}{\rho}+\frac{1}{2}u_{\phi}^2$$
So
$$p(R_{0}, \phi)=p_\infty+\frac{1}{2}\rho\left[U^{2}-\left(\frac{\Gamma}{2\pi R_{0}}\right)^{2}  + \frac{2 \Gamma U \sin \phi}{\pi R_{0}} -4U^{2} \sin^{2} \phi  \right]$$
The force is
$$\boldsymbol{F}=-\int_{0}^{2 \pi}(p-p_\infty)\boldsymbol{n}\;dS$$
where $\boldsymbol{n}=(\cos \phi, \sin \phi)$ is the outward normal and $dS =R_{0}d \phi$ is the differential surface area, so
$$\boldsymbol{F}=-\int_{0}^{2 \pi}(p-p_\infty)\boldsymbol{e}_{R}\;R_{0} d \phi.$$
- The pressure is symmetric about $\phi=\pi/2$ so $p(\phi)=p(\pi-\phi) \implies F_{x}=0$, hence there are no drag forces on the cylinder (d'Alembert's paradox).
  ![[presscyl_att.png|300]]
- The pressure is not symmetric about $\phi=0$ so
  $$\begin{align*}
F_{y}&= \boldsymbol{F} \cdot \boldsymbol{j}\\
&= -R_{0} \int_{0}^{2 \pi} (p-p_{\infty})\sin \phi \;d \phi\\
&= \cdots\\
&= - \rho \Gamma U.
\end{align*}$$
Hence, while there is no drag, there is lift on the cylinder, a force of $L=- \rho \Gamma U$, provided $\Gamma<0$.
When circulation is in the same direction as the flow,
- below surface there is faster flow, and lower pressure,
- above surface there is slower flow, and higher pressure,
so downwards force.

