---
tags:
  - MT4003
aliases:
  - conjugacy class
---
Let $G$ be a [[Groups|group]] and $x$ be an element of $G$.

> [!def] Definition
> The conjugacy class of $x$ in $G$, written $x^{G}$, is the $\sim$-[[Equivalence classes|equivalence class]] of $x$, that is,
> $$x^{G} = \set{x^{g} : g\in G}$$
> the set of all [[Conjugacy|conjugates]] of $x$ in $G$.
