---
tags:
  - MT4528
type: 
aliases:
---
Let $\set{X(t):t \geqslant 0}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov process]] with [[State spaces|state space]] $S$.

>[!def] Definition
>The infinitesimal generator matrix of a Markov process is given by
>$$\boldsymbol{Q=}\begin{pmatrix}
   -\lambda_{1} & \lambda_{1}p_{12} & \lambda_{1}p_{13} & \cdots \\
   \lambda_{2}p_{21} & -\lambda_{2} & \lambda_{2}p_{23} \\
   \lambda_{3}p_{31} & \lambda_{3}p_{32} & -\lambda_{3} \\
   \vdots & & & \ddots
   \end{pmatrix}$$
>In other words, $\boldsymbol{Q}=[q_{ij}]$ where
>$$q_{ij}=\begin{cases}
   -\lambda_{i} & \text{for } i=j \\
   \lambda{i}p_{ij} & \text{for } i\neq j
   \end{cases}$$

>[!gen] Remarks
>1. One can define a Markov process by specifying $\boldsymbol{Q}$.
>2. $\boldsymbol{Q}$ contains all information on the distribution of the sojourn times and the probabilities of transitions.
>3. In each row of $\boldsymbol{Q}$, the entries sum to 0.
>4. $\boldsymbol{Q}$ is the counterpart of the [[One-step transition probability matrices|one-step tpm]] for discrete-time Markov chains.
>5. A lot of the theory on continuous-time Markov chains is very similar to what we already seen.
