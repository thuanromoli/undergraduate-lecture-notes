---
type: mthd
tag: MT2508
alias: least-squares estimate
---
Consider a [[Simple linear regression|simple linear regression]] model: $Y_i=\alpha+\beta x_i + \varepsilon_i$ for $i=1,...,n$ where $\varepsilon_1,...,\varepsilon_n$ are ind. [[Random variables|rvs]]. with mean zero and constant variance $\sigma^2$.

Consider the vertical distances $\varepsilon_i=y_i-(\alpha+\beta x_i$) for $i=1,...n$ between the observed values $y_1,...,y_n$ and the corresponding values $Y_1=\alpha+\beta x_1,...,Y_n=\alpha+\beta x_n$.

The method of least squares identifies $\hat \alpha$ and $\hat\beta$ by minimising $$S(\alpha,\beta)=\sum_{i=1}^n(y_i-(\alpha+\beta x_i))^2=\sum_{i=1}^n\varepsilon_i^2$$that is, finding $\alpha$ and $\beta$ that satisfy $\frac{\partial S}{\partial \alpha}=\frac{\partial S}{\partial \beta}=0$.

Like using the [[Normal linear regression]] method, we obtain $$\hat\alpha = \bar y-\hat \beta \bar x \ \ \text{ and } \ \ \hat\beta=\frac{SS_{XY}}{SS_{XX}}$$