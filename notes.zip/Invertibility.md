---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A [[Stationarity|weakly stationary]] [[Stochastic processes|stochastic process]] $(X_{t})_{t \in \mathbb N}$ is invertible with respect to a [[White noise|white noise]] $(\varepsilon_{t})_{t \in \mathbb N}$ if there exists real numbers $(\phi_{j})_{j \in \mathbb N_{0}}$ with $\sum\limits_{j=0}^{\infty}|\phi_{j}|< \infty$ and we can write $$\varepsilon_{t}=\sum\limits_{j=0}^{\infty}\pi_{j}X_{t-j} \quad \forall t \in \mathbb Z.$$

> [!def] Definition
> A [[Stationarity|weakly stationary]] [[Stochastic processes|stochastic process]] $(X_{t})_{t \in \mathbb Z}$ is invertible if there exists a polynomial function $\vartheta(B)$ with a well-defined inverse $\vartheta^{-1}(B)$ and we can write
> $$\varepsilon_{t}=\vartheta^{-1}(B)X_{t} \quad \forall t \in \mathbb Z.$$
> In other words, the process is invertible if the roots of the complex polynomial $\vartheta(z)$ lie outside of the unit circle, that is $|z|>1$.
