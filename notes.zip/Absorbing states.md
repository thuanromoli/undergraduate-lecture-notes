---
tags:
  - MT4528
type: def
aliases:
  - absorbing
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S$.

>[!def] Definition
>A state $i \in S$ is called absorbing if
>$$p_{ii}=\mathbb{P}(X_{t+1}=i | X_{t}=i)=1$$
>That is, once we get to state $i$, there is no escape. 
