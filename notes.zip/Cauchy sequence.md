---
tags:
  - MT2502
  - MT3502
aliases:
  - Cauchy
---
#### For real analysis in any [[Metric spaces|metric]] or [[Normed spaces|normed]] space

> [!def] Definition
> In a metric space $(X,d)$, the sequence $(x_{n})_{n}$ is called Cauchy if
> $$\forall \varepsilon>0 \;\; \exists N \in \mathbb N \;\; \text{s.t}\;\; \forall n,m \in \mathbb N, \;\; n,m \geqslant N \implies d(x_{n},x_{m}) \leqslant \varepsilon.$$
> Equivalently, in a metric space $(X,{\Vert \cdot \Vert})$, the sequence $(x_{n})_{n}$ is called Cauchy if
> $$\forall \varepsilon>0 \;\; \exists N \in \mathbb N \;\; \text{s.t}\;\; \forall n,m \in \mathbb N, \;\; n,m \geqslant N \implies {\Vert x_{n}-x_{m} \Vert} \leqslant \varepsilon.$$

> [!thm] Theorem
> In a metric or normed space, every [[Convergence|convergent]] sequence is a Cauchy sequence.
> Note: the converse is not necessarily true (see [[Completeness|complete spaces]]).

#### For real analysis in the metric $(\mathbb R,|\cdot |)$
Let $(x_{n})_{n}$ be a [[Sequences|sequence]] of real numbers.

> [!def] Definition
> A Cauchy sequence is a sequence that satisfies the following:
> $$\forall \varepsilon>0 \;\; \exists N \in \mathbb N \;\; \text{s.t}\;\; \forall n,m \in \mathbb N, \;\; n,m \geqslant N \implies |x_{n}-x_{m}| \leqslant \varepsilon.$$
