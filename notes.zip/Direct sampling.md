---
tags:
  - MT4531
aliases:
---
See:
[[Method of inversion]]
[[Rejection sampling]]
[[Importance sampling]]
$$\begin{vmatrix}
\hline
 & \text{PROS} & \text{CONS} \\ \hline
 \text{Method of inversion} & \text{Simplest} & \text{Inverse CDF} \\ &&\text{must be computable} \\ \hline
\text{Rejection sampling} & \text{Can be use when the} & \text{Probability of rejection may be high} \\ &\text{inverse CDF is not easy to find}
 \\ \hline
\text{Importance sampling} & \text{Can use it for any densities}  & \text{High variance of the estimator}\\
&\text{if they are continuous}& \text{if }g \text{ is not suitable} \\
&\text{and have the same support}  \\ \hline 
\end{vmatrix}$$
