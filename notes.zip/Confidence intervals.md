---
alias:
  - CI
  - confidence interval
type: def
tag: MT2508
---
>[!def] Definition
>A confidence interval (CI) for a parameter $\theta$ is an interval that contains the true value of $\theta$ with some probability.

If we were to repeat the experiment hundreds (or thousands, or millions) of times, we would expect that $100(1 − \alpha)\%$ of the derived CIs would contain the true value of $\theta$.

A $100(1 − \alpha)\%$ CI does not mean the true value lies in the interval with probability $(1 − α)$, the probability statement relates to the random interval. Once the observation is made, it either lies or does not lie in the CI.
