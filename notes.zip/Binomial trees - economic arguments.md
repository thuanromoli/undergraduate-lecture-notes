---
tags:
  - MT4551
aliases:
---
We proceed to show that we can [[Binomial trees - specifying u, d, and p|specify u, d, and p]] using economic arguments as well.

Assume that we hold $- \Delta$ of the underlying asset for each unit of derivative.
![[bintreeecon_att.png]]

Then at $t = 0$ we have a portfolio $\Pi_{0}= V_{0} - \Delta S$.
And at $t = T$ we have one of the following portfolios $\Pi_{1} = V_{1}- \Delta(Su)$ or $\Pi_{2} = V_{2}- \Delta(Sd)$.
Now we choose $\Delta$ to eliminate risk $\Pi_{1}= \Pi_{2} \implies V_{1} - \Delta(Su) = V_{2}- \Delta(Sd) \implies \Delta = \frac{V_{1}-V_{2}}{S(u-d)}$.
If risk is eliminated, then
$$\begin{align*}
&\Pi_{0}e^{r \delta t}=\Pi_{1}(=\Pi_{2})\\
\implies &(V_{0}- \Delta S) e ^{r \delta t} = V_{1}- \Delta(Su)\\
\implies &\left(V_{0}- \frac{V_{1}-V_{2}}{S(u-d)}\cdot S\right) e ^{r \delta t} = V_{1}- \frac{V_{1}-V_{2}}{S(u-d)}(Su)\\
\implies &\left(V_{0}- \frac{V_{1}-V_{2}}{u-d}\right) e ^{r \delta t} = V_{1}- \frac{V_{1}-V_{2}}{u-d}(u)\\
\implies &V_{0}- \frac{V_{1}-V_{2}}{u-d} = e ^{-r \delta t} \left(V_{1}- \frac{V_{1}-V_{2}}{u-d}\cdot u\right)\\
\implies &V_{0}- \frac{V_{1}-V_{2}}{u-d} = e ^{-r \delta t} \left(\frac{V_{1}u-V_{1}d}{u-d}- \frac{V_{1}u-V_{2}u}{u-d}\right)\\
\implies &V_{0}= e ^{-r \delta t} \left(\frac{V_{1}u-V_{1}d}{u-d}- \frac{V_{1}u-V_{2}u}{u-d}\right) + \left(\frac{V_{1}-V_{2}}{u-d}\cdot e^{r \delta t}\right)e ^{-r \delta t}\\
\implies &V_{0}= e ^{-r \delta t} \left(\frac{V_{1}u-V_{1}d}{u-d}- \frac{V_{1}u-V_{2}u}{u-d}+\frac{V_{1}e^{r \delta t}-V_{2}e^{r \delta t}}{u-d}\right) \\
\implies &V_{0}= e ^{-r \delta t} \left(\frac{-V_{1}d}{u-d}- \frac{-V_{2}u}{u-d}+\frac{V_{1}e^{r \delta t}-V_{2}e^{r \delta t}}{u-d}\right) \\
\implies &V_{0}= e ^{-r \delta t} \left(V_{1}\frac{e^{r \delta t}-d}{u-d} +V_{2} \frac{u-e^{r\delta t}}{u-d}\right)\\
\implies &V_{0}= e ^{-r \delta t} \left(V_{1}p +V_{2}(1-p)\right)
\end{align*}$$
where $p = \frac{e^{r \delta t}-d}{u-d}$ just like in [[Binomial trees - specifying u, d, and p|the derivation form the B-S theory]]. The other relations also hold.
