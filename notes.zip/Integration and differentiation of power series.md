---
tags:
  - MT3502
aliases:
---
Let the [[Power series|power series]] $S(x) = \sum\limits_{n=0}^{\infty}a_{n}x^{n}$ have [[Radius of convergence|radius of convergence]] $R>0$.

> [!thm] Theorem
> For $|x| < R$, the sum $S$ is [[Continuity|continuous]] at $x$, and
> $$\int_{0}^{x}S = \sum\limits_{n=0}^{\infty}\frac{a_{n}}{n+1}x^{n+1} \qquad \text{and} \qquad S'(x) = \sum\limits_{n=0}^{\infty}n a_{n} x^{n-1}.$$
