---
tags:
  - MT3501
type: thm
aliases:
---
Suppose that $V$ is a [[Dimension|finite-dimensional]] [[Inner product spaces|inner product space]] with [[Bases|basis]] $v_{1},v_{2},...,v_{n}$.

>[!gen] Algorithm
>Step 1: Define $e_{1}= \frac{1}{\Vert v_{1} \Vert}v_{1}$.
>
>Step $k$: Suppose $\set{e_{1},e_{2},...,e_{k-1}}$ has been constructed. Define
>$$w_{k}=v_{k}- \sum\limits_{i=1}^{k-1}\langle v_{k},e_{i} \rangle e_{i}$$
>and
>$$e_{k}=\frac{1}{\Vert w_{k} \Vert}w_{k}$$

^ed162b

>[!thm] Theorem
>The set $\set{e_{1},e_{2},...,e_{n}}$ as described above defines an [[Orthogonality|orthonormal]] [[Bases|basis]] for $V$.

Proof:
We need to claim that for $k=1,2,...,n$, the set $\set{e_{1},e_{2},...,e_{n}}$ is defined, orthonormal, and contained in $\text{Span}(v_{1},...,v_{k})$.

Basis, $k=1$.

Checking if $\set{e_{1}}$ is defined.
$v_{1}$ is a vector in the basis so $v_{1}\neq 0$ and hence $e_{1}= \frac{1}{\Vert v_{1} \Vert}v_{1}$ is defined.

Checking if $\set{e_{1}}$ is orthonormal.
There are no requirements for orthogonality as the size is 1.
Furthermore by construction, $\Vert e_{1} \Vert=1$ and so the set is orthonormal.

Checking if $\set{e_{1}}\subseteq \text{Span}(v_{1})$.
By definition, $e_{1}$ is a [[Linear combinations|linear combination]] of $v_{1}$ so it belongs to its [[Span|span]].

Assumption, $k>1$.
Suppose that $\set{e_{1},...,e_{k-1}}$ is defined, orthonormal, and contained in $\text{Span}(v_{1},...,v_{k-1})$

Inductive, consider $e_{k}=\frac{1}{\Vert w_{k} \Vert}w_{k}$ where $w_{k}=v_{k}- \sum\limits_{i=1}^{k-1}\langle v_{k},e_{i} \rangle e_{i}$.

Checking if $\set{e_{1},e_{2},...,e_{k}}$ is defined.
$\set{e_{1},e_{2},...,e_{k-1}}$ is defined by assumption so we need to check $e_{k}$.
That is, we need $\Vert w_{k} \Vert \neq 0$ and therefore $w_{k}\neq \boldsymbol{0}$. Let's proceed by contradiction.
Suppose that $w_{k}=\boldsymbol{0}$. Then
$$v_{k}=\sum\limits_{i=1}^{k-1}\langle v_{k},e_{i} \rangle e_{i} \in \text{Span}(e_{1},...,e_{k-1})\subseteq \text{Span}(v_{1},...,v_{k-1})$$
by assumption.
But this contradicts $\set{v_{1},...,v_{n}}$ being linearly independent.
Thus $w_{k}\neq \boldsymbol{0}$ and $\Vert w_{k} \Vert \neq 0$ and $e_{k}$ is defined.

Checking if $\set{e_{1},e_{2},...,e_{k}}$ is orthonormal.
$\set{e_{1},e_{2},...,e_{k-1}}$ is orthonormal by assumption so we need to check that $e_{k}$ is orthogonal to ${e_{1},e_{2},...,e_{k-1}}$ in other words, that $\langle e_{k},e_{j} \rangle=0$ for $j=1,2,...,k-1$
We compute $\langle w_{k},e_{j} \rangle$ for $j=1,2,...,k-1$.
$$\begin{align*}
\langle w_{k},e_{j} \rangle &= \Big\langle v_{k}-\sum\limits_{i=1}^{k-1}\langle v_{k},e_{i} \rangle e_{i},e_{j}\Big\rangle\\
&= \langle v_{k},e_{j} \rangle-\sum\limits_{i=1}^{k-1}\langle v_{k},e_{i} \rangle \langle e_{i},e_{j} \rangle\\
&= \langle v_{k},e_{j} \rangle-\sum\limits_{i=1}^{k-1}\langle v_{k},e_{i} \rangle \langle e_{i},e_{j} \rangle\\
&= \langle v_{k},e_{j} \rangle - \langle v_{k},e_{j} \rangle \langle v_{j},v_{j} \rangle\\
&= \langle v_{k},e_{j} \rangle -\langle v_{k},e_{j} \rangle {\Vert e_{j} \Vert}^{2}\\
&= \langle v_{k},e_{j} \rangle -\langle v_{k},e_{j} \rangle =0
\end{align*}$$
Hence
$$\langle e_{k},e_{j} \rangle = \Big\langle \frac{1}{\Vert w_{k} \Vert}w_{k},e_{j} \Big\rangle=\frac{1}{\Vert w_{k} \Vert} \langle w_{k},e_{j} \rangle=0$$
for $j=1,2,...,k-1$
So $\set{e_{1},e_{2},...,e_{k}}$ is an orthogonal set.
Furthermore, ${e_{1},e_{2},...,e_{k-1}}$ have unit norm by assumption and $\Vert e_{k} \Vert = 1$ by construction.
Hence $\set{e_{1},e_{2},...,e_{k}}$ is an orthonormal set.

Checking if $\set{e_{1},e_{2},...,e_{k}}\subseteq \text{Span}(v_{1},...,v_{k})$
$\set{e_{1},e_{2},...,e_{k-1}}\subseteq \text{Span}(v_{1},...,v_{k-1})$ by assumption so we need to check that $e_{k}$ is contained in $\text{Span}(v_{1},...,v_{k})$.
$$\begin{align*}
e_{k} &= \frac{1}{\Vert w_{k} \Vert} \left(v_{k} - \sum\limits_{i=1}^{k-1} \langle v_{k},e_{i} \rangle e_{i}\right)\\
&\in \text{Span}(e_{1},e_{2},...,e_{k-1},v_{k})\\
&\subseteq \text{Span}(v_{1},v_{2},...,v_{k-1},v_{k})
\end{align*}$$
Hence $\set{e_{1},e_{2},...,e_{k}}$ is contained in $\text{Span}(v_{1},...,v_{k})$.

