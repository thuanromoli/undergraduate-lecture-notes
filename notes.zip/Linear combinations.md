---
tags:
  - MT2501
  - MT3501
type: def
aliases:
  - linear combination
---
Let $V$ be a [[Vector spaces|vector space]] over a [[Fields (Algebra)|field]] $F$, and let $v_{1},...,v_{k}$ be some vectors from $V$.

>[!def] Definition
>A vector $v$ is a linear combination of the vectors $v_{1},...,v_{k}$ if there are scalars $\alpha_{1},...,\alpha_{k} \in F$ such that
>$$v=\alpha_{1}v_{1}+\alpha_{2}v_{2}+\ldots+\alpha_{k}v_{k}$$

---

#### Spaced repetition

When is a vector $v$ a linear combination of the vectors $v_{1},...,v_{k}$?
?
>A vector $v$ is a linear combination of the vectors $v_{1},...,v_{k}$ if there are scalars $\alpha_{1},...,\alpha_{k} \in F$ such that
>$$v=\alpha_{1}v_{1}+\alpha_{2}v_{2}+\ldots+\alpha_{k}v_{k}$$
