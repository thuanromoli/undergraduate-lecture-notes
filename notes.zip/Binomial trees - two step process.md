---
tags:
  - MT4551
aliases:
---
Let $S$ be the share price at time $t$.

Over the interval $\delta t$, the share price may
1. Increase by a factor $u>1$, with probability $p$.
2. Decrease by a factor $d < 1$, with probability $1-p$.

Over the interval $2\delta t$, the share price follows

![[bintreetwoshare_att.png]]

Label the payoff at $T$ with
$$V = \begin{cases}
U & \text{if share price is }Su^{2} \\
M & \text{if share price is }Sud \\
D & \text{if share price is }Sd^{2}
\end{cases}$$
![[bintreetwofd_att.png]]

and then we apply the [[Binomial trees - single step process|one step process]] to $X$ and $Y$ and then $V_{0}$:
$$\begin{align*}
X &= e^{-r \delta t}[pU + (1-p)M]\\
Y &= e^{-r \delta t}[pM + (1-p)D]\\\\
V_{0} &= e^{-r \delta t}[pX + (1-p)Y].
\end{align*}$$