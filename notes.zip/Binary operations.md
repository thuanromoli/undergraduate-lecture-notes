---
tags:
  - MT2505
  - MT4003
type: def
aliases:
  - binary operation
---
Let $A$ be a set.

>[!def] Definition
>A binary operation on $A$ is a [[Functions|function]] $$A\times A \to A$$defined on the set $A \times A=\{(a,b):a,b\in A\}$, which is the pairs of points in $A$ which maps to $A$.
