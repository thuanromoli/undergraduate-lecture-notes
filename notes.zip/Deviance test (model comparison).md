---
tags:
  - MT3508
aliases:
---
> [!gen] [[Statistical hypothesis|Hypothesis]]
> $H_{0}$: the model with less parameters is correct.
> $H_{1}$: the model with more parameters is correct.

Let $\widehat {\boldsymbol{\mu}_{0}}$ and $\widehat {\boldsymbol{\mu}_{1}}$ be the estimated mean vectors under $H_{0}$ and $H_{1}$ with $p_{0}$ and $p_{1}$ parameters respectively.

> [!gen] [[Test statistics]] ($\phi$ must be known, can use with any GLM)
> $$\begin{align*}
   \hbox{LRT} &= D^{*}_{0} - D^{*}_{1} \\
   &= 2\left\{l(\boldsymbol{y},\phi; \boldsymbol{y}) - l(\widehat {\boldsymbol{\mu}_{0}},\phi; \boldsymbol{y})\right\} - 2\left\{l(\boldsymbol{y},\phi; \boldsymbol{y}) - l(\widehat {\boldsymbol{\mu}_{1}},\phi; \boldsymbol{y})\right\}\\
   &= 2\left\{l(\widehat {\boldsymbol{\mu}_{1}},\phi; \boldsymbol{y}) - l(\widehat {\boldsymbol{\mu}_{0}},\phi; \boldsymbol{y})\right\} \sim \chi^{2}_{p_{1}-p_{0}}.
   \end{align*}$$

> [!gen] [[Test statistics]] ($\phi$ does not need to be known, can't use with Bernoulli)
> Assuming $D^{*}_{0}-D^{*}_{1}$ and $D^{*}_{1}$ are asymptotically independent under $H_{0}$.
> $$\begin{align*}
   F^{*} &= \frac{(D_{0}-D_{1})/(p_{1}-p_{0})}{D_{1}/(n-p_{1})} \\
   &= \frac{(D^{*}_{0}-D^{*}_{1})/(p_{1}-p_{0})}{D^{*}_{1}/(n-p_{1})} \sim F_{(p_{1}-p_{0}),(n-p_{1})}.
   \end{align*}$$
> This is obtain by using $D^{*}_{0}-D^{*}_{1} \sim \chi^{2}_{p_{1}-p_{0}}$ and $D^{*}_{1} \sim \chi_{n-p_{1}}$

> [!gen] [[Test statistics]] ($\phi$ does not need to be known, can use with any GLM)
> We use the estimator $\widehat \phi = \frac{D_{1}}{n-p_{1}}$ and $\widehat {D^{*}_{i}} = D_{i}/\widehat \phi$.
> $$\begin{align*}
   \hbox{LRT} &= \widehat {D^{*}_{0}} - \widehat {D^{*}_{1}} \\
   &= \frac{D_{0} - D_{1}}{\widehat \phi}\\
   &= \frac{D_{0} - D_{1}}{D_{1}/(n-p_{1})}\\
   &= (p_{1}-p_{0}) \frac{(D_{0} - D_{1})/(p_{1}-p_{0})}{D_{1}/(n-p_{1})}\\
   &= (p_{1}-p_{0})F^{*} \sim F_{(p_{1}-p_{0}),\infty}.
   \end{align*}$$
