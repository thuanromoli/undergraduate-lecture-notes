---
tags:
  - MT2502
aliases:
---
Let $a,b \in \mathbb R$ with $a<b$.

> [!thm] Theorem
> Suppose that $f:[a,b] \to \mathbb R$ is [[Continuity|continuous]] and $f$ is [[Differentiability|differentiable]] on $(a,b)$.
> Then there exists $\theta \in (a,b)$ such that
> $$f'(\theta)=\frac{f(b)-f(a)}{b-a}.$$

![The Mean Value Theorem](https://i.ytimg.com/vi/eUwZk39IK3c/maxresdefault.jpg)