---
type: mthd
tag: MT2508
---
Given the [[Test statistics|test statistic]] $T$, the [[Significance level|significance level]] $\alpha$, and the parameter $\theta$, find the [[Power of a test|power]] $\beta$.

1. Find $L$ and $U$ s.t $\mathbb P(T\leqslant L)=\alpha / 2$ and $\mathbb P(T\geqslant U)=\alpha/2$, where $T$ is distributed under $H_0$ (i.e $\theta= \theta_{0}$);
2. $\beta = \mathbb P(T\leqslant L) +\mathbb P(T \geqslant U)$, where $T$ is distributed under $H_1$ (i.e $\theta=\theta_1$).

---

#### Spaced repetition

Given the [[Test statistics|test statistic]] $T$, the [[Significance level|significance level]] $\alpha$, and the parameter $\theta$, find the [[Power of a test|power]] $\beta$.
?
1. Find $L$ and $U$ s.t $\mathbb P(T\leqslant L)=\alpha / 2$ and $\mathbb P(T\geqslant U)=\alpha/2$, where $T$ is distributed under $H_0$ (i.e $\theta= \theta_{0}$);
2. $\beta = \mathbb P(T\leqslant L) +\mathbb P(T \geqslant U)$, where $T$ is distributed under $H_1$ (i.e $\theta=\theta_1$).