---
tags:
  - MT3502
aliases:
---
Let $(X,{\Vert \cdot \Vert})$ be a normed space.

> [!thm]- ${\left\Vert \sum\limits_{i=1}^{n}x_{i} \right\Vert} \leqslant \sum\limits_{i=1}^{n} {\Vert x_{i} \Vert}$ for all $x_{i}\in X$

> [!thm]- $\bigg| {\Vert x \Vert}  - {\Vert y \Vert} \bigg | \leqslant {\Vert x-y \Vert}$
