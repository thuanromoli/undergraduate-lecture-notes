---
tags:
  - MT4528
type: model
aliases:
---
>[!def] Definition
>The M/M/s/s queue has:
>- [[Poisson processes|Poisson process]] arrivals with rate $\lambda$
>- service times $\overset{iid}{\sim}\text{Exp}(\mu)$
>- $s$ servers and capacity is $s$
>This is a [[Birth and death processes|Birth/death process]] where:
>$$\lambda_{n}=\begin{cases}
   \lambda & \text{for }0 \leqslant n < s \\
   0 & \text{for }n \geqslant s
   \end{cases}$$
>$$\mu_{n}=\begin{cases}
   0 & \text{for }n=0 \\
   n\mu & \text{for }n>0 \\
   \end{cases}$$

>[!gen] Motivation for values of $\mu$
>Suppose that $n \leqslant s$ servers are busy at time $t$.
>The conditional probability that any particular server has not finished serving by time $t+h$ is $e^{-\mu h}$ (from the c.d.f. of the exponential distribution).
>Thus the conditional probability that no server has finished by time $t+h$ is $(e^{-\mu h})^{n}=e^{-n \mu h}$, so that the conditional probability that at least one server has finished by the time $t+h$ is
>$$1-e^{-n \mu h}=1-(1-n \mu h +o(h))=n \mu h + o (h)$$
>which means that the service rate, i.e. the death rate, is equal to $n \mu$.

>[!thm] Theorem
>For an M/M/s/s queue, the [[Stationary distributions|stationary distribution]] of the process $\set{X(t):t\geqslant 0}$ is given by
>$$\begin{align*}
   \pi_{n} &= \frac{\frac{1}{n!}\left(\frac{\lambda}{\mu}\right)^{n}}{\sum\limits_{j=0}^{s} \frac{1}{j!}\left(\frac{\lambda}{\mu}\right)^{j}}
   \end{align*}$$
>for $0 \leqslant n \leqslant s$
>
>Proof: see [[Equilibrium distribution of a birth death process|this proposition]], and then use algebra.

>[!thm] Erlang's loss formula
>Taking $n=s$ in the above theorem, corresponds to the case when all the servers are busy. Thus, when the process is in equilibrium, then the probability for an arriving customer to be turned down is
>$$\pi_{s} = \frac{1}{s!}\left(\frac{\lambda}{\mu}\right)^{s}\left(\sum\limits_{j=0}^{s} \frac{1}{j!}\left(\frac{\lambda}{\mu}\right)^{j}\right)^{-1}$$
