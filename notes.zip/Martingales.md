---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A [[Stochastic processes|stochastic process]] $(X_{t})_{t \in \mathbb Z}$ is called a martingale if
> $$\mathbb E(X_{t}|X_{t-1},X_{t-2},...)=X_{t-1} \quad \forall t.$$
