---
tags:
  - MT4527
aliases:
  - ACVF
  - ACF
  - autocorrelation matrix
---
Let $(X_{t})_{t \in \mathbb Z}$ be a [[Stationarity|weakly stationary]] [[Stochastic processes|stochastic process]].

> [!def] ACVF
> The autocovariance function of $X$ is
> $$\gamma_{X}(h) = \text{Cov}(X_{t},X_{t+h}).$$
> The sample autocovariance function of $X$ is
> $$\widehat\gamma_{X}(h) = \frac{1}{T} \sum\limits_{t=1}^{T-|h|}(x_{t+|h|}-\bar x)(x_{t}-\bar x).$$

> [!def] ACF
> The autocorrelation function of $X$ is
> $$\rho_{X}(h) = \text{Corr}(X_{t},X_{t+h})=\frac{\gamma_{X}(h)}{\gamma_{X}(0)}.$$
> 
> The sample autocorrelation function is
> $$\widehat \rho_{X}(h) =\frac{\widehat \gamma_{X}(h)}{\widehat \gamma_{X}(0)}.$$

> [!gen]- Motivation
> For a [[Stationarity|weakly stationary]] [[Stochastic processes|stochastic process]], we have that $\text{Cov}(X_{t},X_{s}) = \text{Cov}(X_{t+h},X_{s+h})$.
> Setting $s = t$ yields $\text{Cov}(X_{t},X_{t}) = \text{Cov}(X_{t+h},X_{t+h})$, that is $\text{Var }(X_{t}) = \text{Var }(X_{t+h})$.
> Hence $\text{Corr}(X_{t},X_{s}) = \text{Corr}(X_{t+h},X_{s+h})$ which, as similarly discussed for covariance, implies that $\text{Corr}(X_{t},X_{t_h}) = \text{Corr}(X_{s},X_{s+h})$.
> So it depends only on the lag, and it is useful to define functions for the covariance and correlation in terms of the lag only.

> [!def] Autocorrelation matrix
> The autocorrelation matrix of lag $k$ of $X$ is the  $k\times k$ matrix $R_{k} = (\rho_{X}(i-j))_{i,j=1,...,k}$. It summarises the autocorrelation functions up to lag $k$, and explicitly is
> $$\begin{equation}
R_k = \left( \begin{array}{ccccc}
1 & \rho_X (1) & \rho_X (2) & ... & \rho_X (k-1) \\
\rho_X (1) & 1 & \rho_X (1) & ... & \rho_X (k-2) \\
\rho_X (2) & \rho_X (1) & 1 & ... & \rho_X (k-3) \\
\vdots & \vdots &  \vdots & \ddots& \vdots \\
 \rho_X (k-1) & \rho_X (k-2) &\rho_X (k-3) &  ... & 1
\end{array} \right).\end{equation}$$

> [!def] Partial autocorrelation function
> See [[PACF]].
