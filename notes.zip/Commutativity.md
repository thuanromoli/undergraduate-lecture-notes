---
tag: MT2505
type: def
alias: [commutativity,commutative]
---
Let $A$ be a set and $*$ be a [[Binary operations|binary operation]] on $A$.

>[!def] Definition
>$*$ is commutative if $a*b = b*a \ \ \forall a,b \in A$.
