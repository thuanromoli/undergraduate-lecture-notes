---
type: thm
tag: MT2507
---
>[!thm] Theorem
>The escape velocity is the minimum velocity required at the Earth's surface to fully escape from the Earth's gravity: $$v_{e}= \sqrt{2gR_{E}}=\sqrt{\frac{2GM}{R}}$$

PROOF:
	1. Consider the equation obtained from [[1D motion in variable gravity]]: $v \frac{dv}{dr}=-g \left(\frac{R_{E}}{r}\right)^{2}$
	2. Then $v^{2}= {v_{0}}^{2}+2gR_{E}(\frac{R_{E}}{r}-1)$
	3. We need $v>0 \;\;\forall r>0$ so ${v_{0}}^{2}+2gR_{E}(\frac{R_{E}}{r}-1)>0$
	4. Since $\lim_\limits{r\to \infty}(\frac{R_{E}}{r})=0$ we need ${v_{0}}^{2}+2gR_{E}(0-1)>0 \implies {v_{0}}^{2}-2gR_{E}>0$
	5. That is $v_{0}> \sqrt{2gR_{R}}$ as defined.