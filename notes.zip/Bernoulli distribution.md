---
type: def
tags:
  - MT2504
  - MT3508
---
> [!gen] Parameters
> $p \in [0,1]$ - success probability

> [!gen] Support
> $x\in\set{0,1}$

>[!gen] [[Probability mass function]]
>$$f(x)= p^{x}(1-p)^{1-x}$$

> [!gen] Typical use
> Used for binary (e.g. success/failure, Yes/No) data.
