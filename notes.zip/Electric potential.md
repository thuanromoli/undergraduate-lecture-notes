---
tags:
  - MT3506
aliases:
---
Let $\boldsymbol{r}= (x,y,z)$ and $r = |\boldsymbol{r}| = (x^{2}+y^{2}+z^{2})^{\frac{1}{2}}$.

> [!def] Potential due to a point charge
> The potential associated with a point charge of strength $q_{1}$, located at $\boldsymbol{r}=\boldsymbol{r}_{1}$ is
> $$\phi(\boldsymbol{r}) = \frac{q_{1}}{4 \pi |\boldsymbol{r}-\boldsymbol{r}_{1}|}.$$

> [!def] Electric field
> The electric field associated with the potential due to a point charge is
> $$\boldsymbol{E}=- \nabla \phi = \boldsymbol{E}(\boldsymbol{r})= \frac{q_{1}}{4 \pi} \frac{\boldsymbol{r}- \boldsymbol{r}_{1}}{|\boldsymbol{r}-\boldsymbol{r}_{1}|^{3}}.$$

> [!def] Multiple point charges
> If we have $N$ point charges, with strength $q_{n}$, located at $\boldsymbol{r}_{n}$ for $n=1,...,N$, then we have
> $$\begin{align*}
   \phi(r) &= \sum\limits_{n=1}^{N}\frac{q_{n}}{4 \pi |\boldsymbol{r}-\boldsymbol{r}_{n}|}\\
   \boldsymbol{E}(\boldsymbol{r}) &= \sum\limits_{n=1}^{N} \frac{q_{n}}{4 \pi} \frac{\boldsymbol{r}-\boldsymbol{r}_{n}}{|\boldsymbol{r}-\boldsymbol{r}_{n}|^{3}}.\end{align*}$$
   The the force at $\boldsymbol{r}_{j}$ due to all other points would be
   $$\boldsymbol{F}=q_{j}\boldsymbol{E} = q_{j}\left[\sum\limits_{\begin{align} n=1\\ n \neq j\end{align}}^{N} \frac{q_{n}}{4 \pi} \frac{\boldsymbol{r}-\boldsymbol{r}_{n}}{|\boldsymbol{r}-\boldsymbol{r}_{n}|^{3}}\right]_{\boldsymbol{r}=\boldsymbol{r}_{j}}.$$
