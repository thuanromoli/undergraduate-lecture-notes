---
tags:
  - MT3502
aliases:
  - finite set
---
Let $A$ and $B$ be a non-empty sets.

> [!def] Finite sets
> $A$ is finite if it is [[Similarity|similar]] to $\set{1,2,...,n}$ for some $n \in \mathbb N$, in which case we say that $A$ has cardinality $n \in N$ and we write $|A| = n$.
> A non-empty set that is not finite is infinite.

> [!def] Infinite sets
> If two sets $A$ and $B$ are similar, then we write $|A|=|B|$ and they have the same cardinality.
> We say that $A$ has cardinality less than or equal to $B$ if there is an [[Injective functions|injection]] $f:A\to B$, and we write this as $|A| \leqslant |B|$.
> We say that $A$ has cardinality strictly less than $B$ if $|A| \leqslant |B|$ and $|A| \neq |B|$, in which case we write $|A| < |B|$.
