---
aliases:
  - functions
  - function
type: def
tags:
  - MT2505
  - MT2502
  - MT3502
---
Let $X$ and $Y$ be any sets.

>[!def] Defintion
>A function $f$ from $X$ to $Y$ assigns to each element of $X$ exactly one element of $Y$. We write $f: X \to Y$.

> [!def] Definition
> $f$ is a function if
> $$\forall x \in X, \; \exists! \; y\in Y \; \text{ s.t }\; y=xf$$

>[!gen]+ Distinctions between functions
>- A function can be genereal, [[Surjective functions|surjective]], [[Injective functions|injective]] or [[Bijective functions|bijective]].
>![[functions_att.png|250]]
>- A function can be [[Odd functions|odd]], [[Even functions|even]], or neither even nor odd. When functions are multiplied, to establish odd or even, think about addition of integers.
>- A function can be [[Periodic functions|periodic]].
