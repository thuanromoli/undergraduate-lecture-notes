---
tags:
  - MT3504
type: 
aliases:
---
>[!def] General form
>A general second-order PDE (that we will consider) is of the form
>$$au_{xx}+2bu_{xy}+cu_{yy}=F(x,y,u,u_x,u_{y})$$
>where depending on $a(x,y),b(x,y),c(x,y)$ (classification does not depend on $F$) we have a:
>- hyperbolic PDE if $b^{2}-ac>0$ (typified by the wave equation)
>- parabolic PDE if $b^{2}-ac=0$ (typified by the heat equation)
>- elliptic PDE if $b^{2}-ac<0$ (typified by the Laplace's equation)
>
>Note that these are local properties and they depend on $a,b,c$ at a point:
>- if $a,b,c$ are constant these properties hold everywhere in $(x,y)$
>- if $a,b,c$ depend on $x,y$ then these properties depend on $(x,y)$ and hence an equation can change from one type to the other and we end up with a mixed PDE.

>[!thm] Characteristics
>The characteristics equation for a second-order PDE is
>$$\frac{dy}{dx}=\frac{b\pm \sqrt{b^{2}-ac}}{a}\equiv \mu_{\pm}$$

>[!gen] Intuition of where the characteristics come from
>- By [[Hyperbolic Second-Order PDEs|this method]], constant coefficients hyperbolic PDEs can be transformed to $u_{\zeta \eta}=0$ by change of variables to characteristics coordinates. This idea can be extended to non-constant coefficient case.
>- A different intuition uses the idea that a problem is not well defined if $\frac{dy}{dx}=\mu_{\pm}$ and the [[The Cauchy initial value problem|initial data]] is on a curve $\Gamma$ with same shape as $\frac{dy}{dx}$.
>  This is because if the characteristics and $\Gamma$ are of the same shape, they will not intersect and they will not form a well-defined [[The Cauchy initial value problem|Cauchy problem]].
