---
tags:
  - MT3504
type: def
aliases:
  - direction field
---
Consider $y'=f(x,y)$

>[!def] Definition
>The direction field is the graph obtained by drawing on the [[Phase plane|phase plane]] short line segments at many points $(x,y)$, each line segment having slope equal to $f(x,y)$ at that point.
>The slope is equal to $f(x,y)$ since by definition $\frac{dy}{dx}=f(x,y)$.

---

#### Spaced repetition

Define what is a direction field.
?
>The direction field is the graph obtained by drawing on the [[Phase plane|phase plane]] short line segments at many points $(x,y)$, each line segment having slope equal to $f(x,y)$ at that point.
>The slope is equal to $f(x,y)$ since by definition $\frac{dy}{dx}=f(x,y)$.