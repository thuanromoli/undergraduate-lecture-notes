---
type: def
tag: MT2506
---
Proceed as with [[General surface integral|surface integral]] but consider all surfaces that completely enclose a volume.