---
tags:
  - MT4528
type: thm
aliases:
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S$.

>[!thm] Theorem
>If $\set{X_{t}:t=0,1,2,...}$ is [[Ergodic Markov chains|ergodic]], then there exists a unique [[Stationary distributions|stationary distribution]] $\boldsymbol{\pi}$ and
>$$\lim_{t\to\infty}u_{j}(t)=\pi_{j}=\frac{1}{\mu_{j}} \;\;\forall j\in S$$
