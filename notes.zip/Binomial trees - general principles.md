---
tags:
  - MT4551
aliases:
---
Let $S$ be the share price at time $t$.

> [!gen] Method
> 1. Start with current share price $S$ and construct a $N$-step tree ending at $t = T$ (see [[Binomial trees - single step process|the one step process]], and note that $d$ and $d$ are specified from $r$ and $\sigma$).
> 2. At expiry we know the share value at each final node, so obtain the value of the option from its payoff at expiry.
> 3. Work back through each node obtaining options value from the two that connect to it (see [[Binomial trees - two step process|the two step proess]]).

