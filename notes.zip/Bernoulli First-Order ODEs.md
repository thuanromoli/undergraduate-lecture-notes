---
type: mthd
tags:
  - MT3504
aliases:
---
>[!gen] ODE
>$$y'+p(x)y=q(x)y^{n}$$

>[!gen] Subsitution
>$$v(x)=y^{1-n}$$
>such that $\frac{dv}{dx}=(1-n)y^{-n} \frac{dy}{dx}$

>[!gen] Solution
>$$\frac{dy}{dx}+p(x)y=q(x)y^{n}$$
>$$(1-n)y^{-n} \frac{dy}{dx} + (1-n)y^{-n} p(x) y=(1-n)y^{-n} q(x) y^{n}$$
>$$\frac{dv}{dx}+(1-n)y^{1-n}p(x)=(1-n)q(x)$$
>$$\frac{dv}{dx}+(1-n)p(x)v(x)=(1-n)q(x)$$
>Then integrate as a [[Linear First-Order ODEs]].

---

#### Spaced repetition

What is the form of a Bernoulli first-order ODE?
?
>$y'+p(x)y=q(x)y^{n}$

How do you solve $y'+p(x)y=q(x)y^{n}$?
?
>Using substitution $v(x)=y^{1-n}$
>$\frac{dy}{dx}+p(x)y=q(x)y^{n}$
>$(1-n)y^{-n} \frac{dy}{dx} + (1-n)y^{-n} p(x) y=(1-n)y^{-n} q(x) y^{n}$
>$\frac{dv}{dx}+(1-n)y^{1-n}p(x)=(1-n)q(x)$
>$\frac{dv}{dx}+(1-n)p(x)v(x)=(1-n)q(x)$
>Then integrate as a linear equation.