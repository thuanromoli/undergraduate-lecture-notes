---
tags:
  - MT4551
aliases:
---
> [!thm] The solution to the diffusion equation
> Solving the [[Diffusion equation - derivation|diffusion equation]] is an [[Initial values and IVP|initial value problem]] on the infinite domain with [[Initial values and IVP|initial conditions]] $\rho(x,0)$.
> 
> Suppose that a particle starts at $x'$ and arrives at $x$ with probability
> $$\frac{1}{\sqrt{4 \pi D t}}\exp \left\{- \frac{(x-x')^{2}}{4Dt}\right\}.$$
> Then the solution to the diffusion equation is
> $$\rho(x,t) = \frac{1}{\sqrt{4 \pi D t}} \int_{-\infty}^{\infty} \rho(x',0) \exp \left\{- \frac{(x-x')^{2}}{4Dt}\right\}dx'.$$
