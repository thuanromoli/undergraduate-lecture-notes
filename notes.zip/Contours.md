---
tags:
  - MT3503
aliases:
  - contour
---
> [!def] Definition
> A contour is a piecewise smooth, simple, closed [[Curves|curve]].
