---
type: def
tags:
  - MT2508
  - MT3508
---
Let $U$ and $V$ be [[Random variables|rvs]]. Define $X=\frac{U/m}{V/n}$

>[!gen] Conditions
>$U$ and $V$ must be [[Independent events|independent]] and from a [[Chi-squared distributions]] with $U\sim\chi^2_m$ and $V\sim\chi^2_n$

>[!gen] Distribution
>$X\sim F_{m,n}$ with $m$ and $n$ degrees of freedom

> [!gen] Typical use
> Used for ratios of two independent Chi-squared random variables.
