---
type: thm
tags:
  - MT2505
  - MT4003
---
Let $G=\set{e,a,b,c}$.

> [!def] Cayley table
The table represent the $V_4$ Klein-4 [[Groups|group]].
>
|     | e   | a   | b   | c   |
| ---- | ---- | ---- | ---- | ---- |
| e   | e   | a   | b   | c   |
| a   | a   | e   | c   | b   |
| b   | b   | c   | e   | a   |
| c   | c   | b   | a   | e   |
