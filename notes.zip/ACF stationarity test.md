---
tags:
  - MT4527
aliases:
---
Let $(X_{t})_{t=1,...,T}$ be a sequence of [[Random variables|random variables]] with finite variance.

> [!thm] Theorem
> For large $T$, if $X$ is [[Stationarity|weakly stationary]] with independent [[White noise|white noise]] innovations., then the [[ACVF and ACF|sample autocorrelations]] of $X$, $\widehat {\boldsymbol{\rho}}_{k}=(\widehat \rho_{X}(1),...,\widehat \rho_{X}(k))$ are such that
> $$ \hat{\boldsymbol{\rho}}_k \stackrel{asy}{\sim} \text{MN} (\boldsymbol{\rho}_k, \frac{1}{T} \boldsymbol{W})$$
> where ${\boldsymbol{\rho}}_{k}=( \rho_{X}(1),..., \rho_{X}(k))$ and $\boldsymbol{W}=(w_{ij})_{i,j=1,...,k}$ for
> $$\begin{align*}
   w_{ij} & = \sum_{k=1}^{\infty} \left(\rho_X (k+i) + \rho_X (k-i) - 2\rho_X (i)\rho_X (k) \right) \\
   & \phantom{=} \hspace{0.6cm} \times \left( \rho_X (k+j) + \rho_X (k-j) - 2\rho_X (j)\rho_X (k) \right).
   \end{align*}$$

> [!gen] [[Statistical hypothesis|Hypothesis]]
> $H_{0}$: $X$ is [[Stationarity|weakly stationary]] with independent [[White noise|white noise]] innovations.
> $H_{1}$: opposite.

> [!gen] Plot
> Under more specific $H_{0}$ cases, 95% of the sample autocorrelations should fall inside certain [[Normal confidence intervals|normal intervals]].
> - For an MA($q$) process, $\widehat \rho_{X}(i) \stackrel{asy}{=}N\Big(0,\frac{1}{T}\big[1+2\sum\limits_{k=1}^{q}\rho^{2}_{X}(k)\big]\Big)$ for $i>q$.
> - For an iid sequence, $\widehat \rho_{X}(i) \stackrel{asy}{=}N(0,\frac{1}{T})$ for $i>1$. Note: this is exactly the same case as [[ACF independence test]].
