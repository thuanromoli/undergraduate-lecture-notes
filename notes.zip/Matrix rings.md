---
type: thm
tag: MT2505
---
Let $R$ be a [[Rings|ring]] and $M_n(R)$ be the set of all $n\times n$ [[Matrices|matrices]].

>[!thm] Theorem
>$M_n(R)$ is a [[Rings|ring]] with respect to [[Matrix addition|matrix addition]] and [[Matrix multiplication|matrix multiplication]].
