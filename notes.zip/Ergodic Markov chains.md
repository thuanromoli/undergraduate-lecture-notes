---
tags:
  - MT4528
type: def
aliases:
---
Let $\set{X_{t}:t=0,1,2,...}$ be a [[Homogeneous Markov chains|homogeneous]] [[Markov chains and processes|Markov chain]] with [[State spaces|state space]] $S$.

>[!def] Definition
>A Markov chain is called ergodic if it is [[Irreducible Markov chains|irreducible]] and all states are [[Recurrent states|positive recurrent]] and [[Periodic and aperiodic states|aperiodic]].
