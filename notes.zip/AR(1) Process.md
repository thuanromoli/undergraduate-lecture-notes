---
tags:
  - MT4527
aliases:
---
> [!def] Definition
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is called an autoregressive process of order 1 if it is [[Stationarity|weakly stationary]] and there exists a [[White noise|white noise]] $(\varepsilon_{t})_{t \in \mathbb Z}$ and a real number $\phi \in \mathbb R$ such that for all $t \in \mathbb Z$,
> $$X_{t}=\phi X_{t-1}+\varepsilon_{t}.$$
> 
> A stochastic process $(X_{t})_{t \in \mathbb Z}$ is an autoregressive process of order 1 with mean $\mu$ if $X_{t}-\mu$ is an AR(1) process.

> [!thm] Properties (when $|\phi|<1$)
> - $(X_{t})_{t \in \mathbb Z}$ is [[Stationarity|weakly stationary]] by definition, [[Invertibility|invertible]] with respect to $(\varepsilon_{t})_{t \in \mathbb Z}$, and [[Causality|causal]].
> - $$\gamma_X (h) = \frac{\sigma^{2}_\varepsilon}{1-\phi^{2}}\phi^{|h|}.$$
> - $$\rho_X (h) = \phi^{|h|}.$$
> - $$\alpha_{X}(h)=\begin{cases} \phi &\quad h=1 \\0 &\quad h>1.\end{cases}$$

> [!gen] Remarks
> 1. There are three cases
>     - If $|\phi|=1$, then the process is a [[Random walks|random walk]] (not stationary).
>     - If $|\phi|<1$, then the process is a stationary [[MA(inf) Process|MA(inf) process]].
>     - If $|\phi|>1$, then the process is a explosive process (not [[Causality|causal]]).
> 2. There are two cases
>     - An AR(1) process satisfies the [[Markov chains and processes|Markov process|Markov property]] as $\mathbb E(X_{t}|X_{t-1},X_{t-2},...)=\phi X_{t-1}=\mathbb E(X_{t}|X_{t-1})$.
>     - An AR(1) process is not a [[Martingales|martingale]] since $\mathbb E(X_{t}|X_{t-1},X_{t-2},...)=\phi X_{t-1} \neq X_{t-1}$, as $\phi \neq 1$.
> - We can write $X_{t}-\mu=\phi(X_{t-1}-\mu)+\varepsilon_{t} \iff X_{t}=\phi_{0}+\phi X_{t-1}+\varepsilon_{t}$ where $\phi_{0}=\mu(1-\phi)$ and $\mu=\frac{\phi_{0}}{1-\phi}$.
> - In the definition of Moving Average processes we did not presuppose weak stationarity, because for these processes weak stationarity is automatically fulfilled. This is not true for autoregressive processes. Therefore, weak stationarity is explicitly postulated in their definition.

![[ar1_att.png]]
