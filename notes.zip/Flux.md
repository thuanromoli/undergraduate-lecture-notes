---
type: def
tag: MT2506
---
>[!def] Definition
>The (net) flux is the [[General surface integral|surface integral]]
>$$\iint_{S}\boldsymbol{F}(\boldsymbol{r}) \boldsymbol{\cdot} \text{ d}\boldsymbol{S}$$
>and it is used to define the [[Divergence|divergence]]:
>$$\lim_{V\to 0}\frac{1}{V}\iint_{S \text{ closed}}\boldsymbol{F}(\boldsymbol{r}) \boldsymbol{\cdot} \text{ d}\boldsymbol{S}$$

PROOF:
	Let $V= \ \text{d}y \ \text{d}x  \ \text{d}z$ be an infinitesimally small volume [[Boundedness|bounded]] by a closed surface $S$.
	1. By [[Gauss' Theorem]]: $\iiint_{V}\boldsymbol{\nabla \cdot F}\text{ dV}=\iint_{S \text{ closed}}\boldsymbol{F}(\boldsymbol{r}) \cdot \text{d}\boldsymbol{S}$
	2. $(\boldsymbol\nabla\cdot\boldsymbol F)\boldsymbol \cdot \boldsymbol V=\iint_{S \text{ closed}}\boldsymbol{F}(\boldsymbol{r}) \boldsymbol{\cdot} \text{ d}\boldsymbol{S}$
	3. $(\boldsymbol\nabla\cdot\boldsymbol F)\boldsymbol=\frac{1}{V}\iint_{S \text{ closed}}\boldsymbol{F}(\boldsymbol{r}) \boldsymbol{\cdot} \text{ d}\boldsymbol{S}$
