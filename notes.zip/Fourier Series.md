---
type: thm
tags:
  - MT2507
  - MT3504
  - MT3506
---
Let $f(x)$ be a [[Functions|function]] defined on the [[The standard interval|standard interval]] $[-l,l)$.

>[!def] Real definition
>The fourier Series of $f(x)$ is
>$$S(x)\equiv \frac{a_{0}}{2}+ \sum\limits_{j=1}^{\infty}a_{j}\cos\left(\frac{j \pi x}{l}\right)+\sum\limits_{j=1}^{\infty}b_{j}\sin\left(\frac{j \pi x}l\right)$$
>where $\cos(\frac{j \pi x}{l})$ and $\sin(\frac{j \pi x}{l})$ are called Fourier modes and
>- if $j=0$ then it's a constant mode.
>- if $j=1$ then it's a fundamental mode.
>- if $j \geqslant 2$ then it's a harmonic mode.

>[!thm]- Coefficients of the Fourier modes
>- $a_{0}=\frac{1}{l}\int_{-l}^{l}f(x) \ dx$
>- $a_{n}= \frac{1}{l}\int_{-l}^{l}f(x)\cos\left(\frac{n \pi x}{l}\right) \ dx$
>- $b_{n}= \frac{1}{l}\int_{-l}^{l}f(x)\sin\left(\frac{n \pi x}{l}\right) \ dx$
>
>Proof outline:
>$f(x)=S(x)$ $\implies$ $f(x)\cdot 1= S(x) \cdot 1$ $\implies$ $\int\limits_{-l}^{l}f(x)\cdot 1 \;dx= \int\limits_{-l}^{l}S(x) \cdot 1\;dx$
>$\implies$ $\langle f(x),1\rangle = \int\limits_{-l}^{l}S(x)\cdot 1=\int\limits_{-l}^{l}\frac{a_{0}}{2}=la_{0}$ (use [[Orthogonality|orthogonality]] of sine and cosine)
>Then re-arrange to find $a_{0}$.
>Similar for the others.

>[!def] Complex definition
>The fourier Series of $f(x)$ is
>$$S(x) \equiv \sum\limits_{n=-\infty}^{\infty}c_{n} e^\frac{i n \pi x}l$$
>where
>- $c_{0}=\frac{a_{0}}{2}$
>- $c_{n}=\frac{a_{n}-ib_{n}}{2}$, $n>0$
>- $c_{-n}=\frac{a_{n}+ib_{n}}{2}$, $-n<0$

>[!thm]- Coefficients of the Fourier series
>- $c_{0}=\frac{1}{l}\int_{-l}^{l}f(x) \ dx$
>- $c_{n}= \frac{1}{2l}\int_{-l}^{l}f(x)e^\frac{-i n \pi x}{l} dx$
>
>Proof outline:
>Note that $\int_{-l}^{l}e^\frac{i(n-m)\pi x}{l}dx=2l$ if $n=m$ otherwise,
>$$\int_{-l}^{l}e^{\frac{i(n-m)\pi x}{l}}dx=\left[\frac{e^{\frac{i(n-m)\pi x}{l}}}{\frac{i(n-m)\pi}{l}}\right]_{-l}^{l}=\frac{1}{\frac{i(n-m)\pi}{l}}[e^{\frac{i(n-m)\pi l}{l}}-e^{-\frac{i(n-m)\pi l}{l}}]=Ae^{-\frac{i(n-m)\pi l}{l}}[e^{2i(n-m)\pi l}-1]=0$$
>Now we have that:
>$$\begin{align*}
   & f(x)=S(x) \\
   \implies & f(x)\cdot e^\frac{-im \pi x}{l}= S(x) \cdot e^\frac{-im \pi x}{l}\\
   \implies & \int_{-l}^{l}f(x)\cdot e^\frac{-im \pi x}{l} \;dx= \int_{-l}^{l}S(x) \cdot e^{\frac{-im \pi x}{l}\;dx}\\
   \implies & \langle f(x),e^{\frac{-im \pi x}{l}}\rangle = \int_{-l}^{l}S(x)\cdot e^{\frac{-im \pi x}{l}}dx= \int_{-l}^{l} \sum\limits_{n=-\infty}^{\infty}c_{n}e^{\frac{i(n-m)\pi x}{l}}dx=c_{m}\int_{-l}^{l}e^{\frac{i(n-m)\pi x}{l}}dx=2lc_{m}
   \end{align*}$$

^723e05

>[!thm] Convergence
>$S(x)$ is periodic with period $L=2l$ and converges to the [[Periodic extension of a function|periodic extension]] of $f(x)$ (which has also period $L=2l$) on $(-\infty,\infty)$ when $f(x)$ is [[Continuity|continuous]], while if $f(x)$ has discontinuities then $S(x)$ converges to all points apart from discontinuities where it converges to the average value of $f(x)$ from the RHS and LHS of the discontinuity.
>
>Proof Omitted
