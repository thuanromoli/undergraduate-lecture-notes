---
tags:
  - MT4528
type: def
aliases:
---
>[!def] Definition
>A 1-D random walk is a [[Homogeneous Markov chains|homogeneous ]] [[Markov chains and processes|Markov chain]] $\set{X_{t}:t=0,1,...}$, such that $X_{t+1}=X_{t}+Z_{t}$ where each $Z_{t}$ has the same [[probability mass function]] $p_{k}=\mathbb{P}(Z=k)$, independently of each other and $X_{t}$.
