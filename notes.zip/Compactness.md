---
tags:
  - MT3502
aliases:
  - compact
---
Let $(X,d)$ be a [[Metric spaces|metric space]]. Let $K \subseteq X$ be a subset.

> [!def] Definition (classic)
> $K$ is compact if every [[Covers|open cover]] of $K$ has a finite subcover.

> [!def] Definition (sequential)
> $K$ is sequentially compact if any [[Sequences|sequence]] $(x_{n})_{n}$ in $K$ has a [[Subsequences|subsequence]] in $K$ whose [[Limits|limit]] is in $K$. That is,
> $$\exists \text{ a subsequence }(x_{n_{k}})_{k} \text{ in } K \text{ and limit } x_{0} \in K \text{ such that } x_{n_{k}} \to x_{0}$$
> where $(x_{n})_{n}$ in $K$ means $x_{n} \in K \;\;\forall n \in \mathbb N$.

> [!thm] Theorem
> $K$ is compact if and only if it is sequentially compact.
