---
tags: 
aliases:
---
Let $0 \leqslant R < S \leqslant \infty$ and $A = \set{z \in \mathbb C:R<|z-a|<S}$, an open annulus centred on $a \in \mathbb C$.

> [!thm] Theorem
> Assume that $f$ is [[Holomorphic functions|holomorphic]] on $A$. Then
> $$f(z) = \sum\limits_{n=-\infty}^{\infty}c_{n}(z-a)^{n}$$
> for all $z \in A$, where the coefficients are given by
> $$c_{n}= \frac{1}{2 \pi i }\int_{\gamma}^{}\frac{f(w)}{(w-a)^{n+1}}dw$$
> for all integers $n$, where $\gamma$ is a positively oriented circular [[Contours|contour]] of some radius about $a$ whose image is contained inside $A$.
